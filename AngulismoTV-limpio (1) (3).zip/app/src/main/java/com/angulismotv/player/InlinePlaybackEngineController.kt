package com.angulismotv.player

import android.content.Context
import android.os.Handler
import android.util.Log
import com.angulismotv.models.StreamType
import com.google.android.exoplayer2.C
import com.google.android.exoplayer2.ExoPlayer
import com.google.android.exoplayer2.PlaybackException
import com.google.android.exoplayer2.Player
import com.google.android.exoplayer2.audio.AudioAttributes
import com.google.android.exoplayer2.ui.PlayerView

/**
 * Owns the native engine for the small/inline player: creation, listener registration,
 * startup timeout, audio-track diagnostics, detachment for fullscreen handoff and release.
 * UI state remains in ChannelsFragment through the callbacks.
 */
class InlinePlaybackEngineController(
    private val handler: Handler,
    private val isGenerationCurrent: (Int) -> Boolean,
    private val callbacks: Callbacks
) {
    interface Callbacks {
        fun onPlaybackStateChanged(player: ExoPlayer, generation: Int, state: Int)
        fun onIsPlayingChanged(player: ExoPlayer, generation: Int)
        fun onPlayerError(generation: Int)
        fun onStartFailure(generation: Int, error: Exception)
        fun onStartupTimeout(generation: Int, streamUrl: String, streamType: String)
    }

    var player: ExoPlayer? = null
        private set

    private var playerView: PlayerView? = null
    private var playerListener: Player.Listener? = null
    private var startupTimeoutRunnable: Runnable? = null
    private var generation: Int = INVALID_GENERATION
    private var streamUrl: String = ""
    private var streamType: String = StreamType.AUTO

    /** Starts a fresh native playback session and owns all cleanup if setup fails. */
    fun start(
        context: Context,
        targetView: PlayerView,
        url: String,
        type: String,
        playbackGeneration: Int
    ) {
        release()
        playerView = targetView
        generation = playbackGeneration
        streamUrl = url
        streamType = type

        try {
            val mediaSource = StreamMediaSourceFactory.create(url, type)
            val audioAttributes = AudioAttributes.Builder()
                .setUsage(C.USAGE_MEDIA)
                .setContentType(C.AUDIO_CONTENT_TYPE_MOVIE)
                .build()
            val createdPlayer = ExoPlayer.Builder(context)
                .setAudioAttributes(audioAttributes, /* handleAudioFocus= */ true)
                .setHandleAudioBecomingNoisy(true)
                .setLoadControl(
                    StreamMediaSourceFactory.createLoadControl(StreamMediaSourceFactory.BufferProfile.INLINE)
                )
                .build()

            player = createdPlayer
            targetView.player = createdPlayer
            targetView.useController = false
            installListener(createdPlayer, playbackGeneration, url, type)
            createdPlayer.setMediaSource(mediaSource)
            createdPlayer.playWhenReady = true
            createdPlayer.prepare()
        } catch (error: Exception) {
            Log.e(TAG, "No se pudo iniciar la fuente", error)
            release()
            callbacks.onStartFailure(playbackGeneration, error)
        }
    }

    /** Attaches a player transferred back from UnifiedPlayerActivity without rebuffering it. */
    fun attachExistingPlayer(
        existingPlayer: ExoPlayer,
        targetView: PlayerView,
        url: String,
        type: String,
        playbackGeneration: Int
    ) {
        if (player !== existingPlayer) {
            release()
        } else {
            detachListenerAndTimeout()
            playerView?.let { previousView ->
                if (previousView !== targetView && previousView.player === existingPlayer) {
                    previousView.player = null
                }
            }
        }
        player = existingPlayer
        playerView = targetView
        generation = playbackGeneration
        streamUrl = url
        streamType = type
        targetView.player = existingPlayer
        targetView.useController = false
        installListener(existingPlayer, playbackGeneration, url, type)
    }

    /** Removes ownership/listeners but deliberately does not stop or release the transferred player. */
    fun detachForHandoff(): ExoPlayer? {
        val current = player ?: return null
        detachListenerAndTimeout()
        playerView?.let { view ->
            if (view.player === current) view.player = null
        }
        player = null
        playerView = null
        generation = INVALID_GENERATION
        streamUrl = ""
        streamType = StreamType.AUTO
        return current
    }

    /** Stops and releases the owned native engine. Safe to call repeatedly. */
    fun release() {
        detachListenerAndTimeout()
        val current = player
        val currentView = playerView
        if (currentView != null && currentView.player === current) {
            currentView.player = null
        }
        player = null
        playerView = null
        generation = INVALID_GENERATION
        streamUrl = ""
        streamType = StreamType.AUTO
        if (current != null) {
            runCatching {
                current.stop()
                current.clearMediaItems()
                current.release()
            }.onFailure { error ->
                Log.w(TAG, "Error al liberar el reproductor integrado", error)
            }
        }
    }

    /** Re-arms the watchdog after resume/show when a player is still starting. */
    fun scheduleStartupTimeout(expectedPlayer: ExoPlayer?, expectedGeneration: Int) {
        val current = expectedPlayer ?: return
        if (!isCurrent(current, expectedGeneration)) return
        if (!InlineStartupTimeoutPolicy.shouldFire(
                generationIsCurrent = isGenerationCurrent(expectedGeneration),
                playerIsCurrent = current === player,
                playbackFinished = current.playbackState == Player.STATE_READY ||
                    current.playbackState == Player.STATE_ENDED
            )) {
            cancelStartupTimeout()
            return
        }
        cancelStartupTimeout()
        val expectedUrl = streamUrl
        val expectedType = streamType
        val timeout = Runnable {
            if (!isCurrent(current, expectedGeneration)) return@Runnable
            val finished = current.playbackState == Player.STATE_READY ||
                current.playbackState == Player.STATE_ENDED
            if (!InlineStartupTimeoutPolicy.shouldFire(
                    generationIsCurrent = isGenerationCurrent(expectedGeneration),
                    playerIsCurrent = current === player,
                    playbackFinished = finished
                )) {
                cancelStartupTimeout()
                return@Runnable
            }
            startupTimeoutRunnable = null
            Log.w(
                TAG,
                "La fuente no llegó a READY dentro del plazo: type=$expectedType, " +
                    "host=${StreamUtils.hostForLog(expectedUrl)}"
            )
            callbacks.onStartupTimeout(expectedGeneration, expectedUrl, expectedType)
        }
        startupTimeoutRunnable = timeout
        handler.postDelayed(timeout, STARTUP_TIMEOUT_MS)
    }

    fun cancelStartupTimeout() {
        startupTimeoutRunnable?.let { handler.removeCallbacks(it) }
        startupTimeoutRunnable = null
    }

    private fun installListener(
        targetPlayer: ExoPlayer,
        playbackGeneration: Int,
        url: String,
        type: String
    ) {
        val listener = object : Player.Listener {
            override fun onPlaybackStateChanged(state: Int) {
                if (!isCurrent(targetPlayer, playbackGeneration)) return
                if (state == Player.STATE_READY || state == Player.STATE_ENDED) cancelStartupTimeout()
                callbacks.onPlaybackStateChanged(targetPlayer, playbackGeneration, state)
            }

            override fun onIsPlayingChanged(isPlaying: Boolean) {
                if (isCurrent(targetPlayer, playbackGeneration)) {
                    callbacks.onIsPlayingChanged(targetPlayer, playbackGeneration)
                }
            }

            override fun onTracksChanged(tracks: Tracks) {
                if (!isCurrent(targetPlayer, playbackGeneration)) return
                PlayerAudioDiagnostics.logTracks("inline", tracks, type, url)
            }

            override fun onPlayerError(error: PlaybackException) {
                if (!isCurrent(targetPlayer, playbackGeneration)) return
                cancelStartupTimeout()
                PlayerAudioDiagnostics.logPlaybackError("inline", type, url, error)
                callbacks.onPlayerError(playbackGeneration)
            }
        }
        playerListener = listener
        targetPlayer.addListener(listener)
        if (targetPlayer.playbackState != Player.STATE_READY && targetPlayer.playbackState != Player.STATE_ENDED) {
            scheduleStartupTimeout(targetPlayer, playbackGeneration)
        }
    }

    private fun isCurrent(candidate: ExoPlayer, candidateGeneration: Int): Boolean =
        player === candidate && generation == candidateGeneration && isGenerationCurrent(candidateGeneration)

    private fun detachListenerAndTimeout() {
        cancelStartupTimeout()
        val oldPlayer = player
        playerListener?.let { listener ->
            if (oldPlayer != null) runCatching { oldPlayer.removeListener(listener) }
        }
        playerListener = null
    }

    companion object {
        private const val TAG = "InlinePlayer"
        private const val STARTUP_TIMEOUT_MS = 12_000L
        private const val INVALID_GENERATION = -1
    }
}
