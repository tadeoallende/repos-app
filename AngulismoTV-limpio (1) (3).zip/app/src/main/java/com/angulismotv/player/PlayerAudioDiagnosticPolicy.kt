package com.angulismotv.player

/** Pure classification for audio-track diagnostics; it does not change playback policy. */
object PlayerAudioDiagnosticPolicy {
    enum class TrackState {
        NO_TRACKS,
        NO_SUPPORTED_TRACKS,
        NO_SELECTED_TRACK,
        READY
    }

    fun classifyTracks(
        audioTrackCount: Int,
        supportedTrackCount: Int,
        selectedTrackCount: Int
    ): TrackState {
        if (audioTrackCount <= 0) return TrackState.NO_TRACKS
        if (supportedTrackCount <= 0) return TrackState.NO_SUPPORTED_TRACKS
        if (selectedTrackCount <= 0) return TrackState.NO_SELECTED_TRACK
        return TrackState.READY
    }

    /** Keep logs useful while avoiding exception messages that may contain signed stream URLs. */
    fun causeChain(error: Throwable?, maxDepth: Int = 5): List<String> {
        if (maxDepth <= 0) return emptyList()
        val result = mutableListOf<String>()
        val seen = java.util.Collections.newSetFromMap(java.util.IdentityHashMap<Throwable, Boolean>())
        var current = error
        while (current != null && result.size < maxDepth && seen.add(current)) {
            val item = current
            result += item.javaClass.simpleName.ifBlank { item.javaClass.name }
            current = item.cause
        }
        return result
    }
}
