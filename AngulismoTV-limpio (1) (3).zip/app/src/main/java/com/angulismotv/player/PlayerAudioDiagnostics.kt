package com.angulismotv.player

import android.util.Log
import com.google.android.exoplayer2.C
import com.google.android.exoplayer2.PlaybackException
import com.google.android.exoplayer2.Tracks

/** Shared, privacy-conscious diagnostics for native playback on inline and fullscreen surfaces. */
object PlayerAudioDiagnostics {
    private const val TAG = "PlayerAudio"

    fun logTracks(surface: String, tracks: Tracks, type: String, url: String) {
        var audioCount = 0
        var supportedCount = 0
        var selectedCount = 0
        tracks.groups.forEachIndexed { groupIndex, group ->
            if (group.type != C.TRACK_TYPE_AUDIO) return@forEachIndexed
            for (trackIndex in 0 until group.length) {
                audioCount++
                val selected = group.isTrackSelected(trackIndex)
                val support = group.getTrackSupport(trackIndex)
                if (support == C.FORMAT_HANDLED || support == C.FORMAT_EXCEEDS_CAPABILITIES) supportedCount++
                if (selected) selectedCount++
                val format = group.getTrackFormat(trackIndex)
                Log.i(
                    TAG,
                    "surface=$surface, type=$type, group=$groupIndex, track=$trackIndex, selected=$selected, " +
                        "support=${supportLabel(support)}, mime=${format.sampleMimeType}, " +
                        "codecs=${format.codecs}, channels=${format.channelCount}, sampleRate=${format.sampleRate}"
                )
            }
        }

        val state = PlayerAudioDiagnosticPolicy.classifyTracks(audioCount, supportedCount, selectedCount)
        val host = StreamUtils.hostForLog(url)
        when (state) {
            PlayerAudioDiagnosticPolicy.TrackState.NO_TRACKS ->
                Log.w(TAG, "surface=$surface, state=no_audio_tracks, type=$type, host=$host")
            PlayerAudioDiagnosticPolicy.TrackState.NO_SUPPORTED_TRACKS ->
                Log.w(TAG, "surface=$surface, state=no_supported_audio_track, type=$type, host=$host")
            PlayerAudioDiagnosticPolicy.TrackState.NO_SELECTED_TRACK ->
                Log.w(TAG, "surface=$surface, state=no_selected_audio_track, type=$type, host=$host")
            PlayerAudioDiagnosticPolicy.TrackState.READY ->
                Log.d(TAG, "surface=$surface, state=audio_track_selected, type=$type, host=$host")
        }
    }

    fun logPlaybackError(surface: String, type: String, url: String, error: PlaybackException) {
        val causes = PlayerAudioDiagnosticPolicy.causeChain(error.cause).joinToString(" -> ")
            .ifBlank { "none" }
        Log.e(
            TAG,
            "surface=$surface, playback_error=${error.errorCodeName}, errorCode=${error.errorCode}, " +
                "type=$type, host=${StreamUtils.hostForLog(url)}, causeChain=$causes"
        )
        if (causes.contains("DecoderInitializationException") ||
            causes.contains("AudioSink") || causes.contains("AudioTrack")) {
            Log.w(TAG, "surface=$surface, audio_path_failure_suspected=true, type=$type")
        }
    }

    private fun supportLabel(support: Int): String = when (support) {
        C.FORMAT_HANDLED -> "handled"
        C.FORMAT_EXCEEDS_CAPABILITIES -> "exceeds_capabilities"
        C.FORMAT_UNSUPPORTED_SUBTYPE -> "unsupported_subtype"
        C.FORMAT_UNSUPPORTED_TYPE -> "unsupported_type"
        else -> "unknown_$support"
    }
}
