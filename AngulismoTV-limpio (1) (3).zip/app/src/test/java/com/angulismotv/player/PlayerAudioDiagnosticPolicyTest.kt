package com.angulismotv.player

import org.junit.Assert.assertEquals
import org.junit.Test

class PlayerAudioDiagnosticPolicyTest {
    @Test fun noExposedAudioTracksAreDistinguished() {
        assertEquals(
            PlayerAudioDiagnosticPolicy.TrackState.NO_TRACKS,
            PlayerAudioDiagnosticPolicy.classifyTracks(0, 0, 0)
        )
    }

    @Test fun unsupportedAudioTracksAreDistinguished() {
        assertEquals(
            PlayerAudioDiagnosticPolicy.TrackState.NO_SUPPORTED_TRACKS,
            PlayerAudioDiagnosticPolicy.classifyTracks(2, 0, 0)
        )
    }

    @Test fun supportedButUnselectedAudioTracksAreDistinguished() {
        assertEquals(
            PlayerAudioDiagnosticPolicy.TrackState.NO_SELECTED_TRACK,
            PlayerAudioDiagnosticPolicy.classifyTracks(2, 1, 0)
        )
    }

    @Test fun selectedSupportedTrackIsReady() {
        assertEquals(
            PlayerAudioDiagnosticPolicy.TrackState.READY,
            PlayerAudioDiagnosticPolicy.classifyTracks(2, 2, 1)
        )
    }

    @Test fun causeChainIsBoundedAndAvoidsCycles() {
        val root = IllegalStateException("do not include this message")
        val middle = IllegalArgumentException()
        root.initCause(middle)
        middle.initCause(root)
        assertEquals(
            listOf("IllegalStateException", "IllegalArgumentException"),
            PlayerAudioDiagnosticPolicy.causeChain(root, 5)
        )
    }
}
