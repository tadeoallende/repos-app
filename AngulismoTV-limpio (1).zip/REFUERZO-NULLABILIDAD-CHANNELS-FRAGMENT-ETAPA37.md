# Etapa 37 — refuerzo de nulabilidad en ChannelsFragment

## Cambios

- Se quitaron las cuatro aserciones `!!` restantes de `ChannelsFragment.kt`.
- Los callbacks de ocultar controles y filtrar la búsqueda ahora programan una variable local `Runnable` ya no nula, en vez de volver a leer la propiedad nullable con `!!`.
- La apertura de fullscreen tras rotar captura el canal con `?: return` y pasa esa referencia comprobada.
- La recuperación en `onResume()` captura el canal activo una sola vez y utiliza esa referencia comprobada para reanudar el reproductor.

## Motivo

Estas rutas dependen de callbacks y del ciclo de vida de Fragment/Views. Evitar `!!` hace explícito el valor que se programa o se usa y elimina posibles fallos por una lectura nullable repetida, sin alterar la política de reproducción ni de orientación.

## Validación y límites

- Búsqueda estática: `ChannelsFragment.kt` ya no contiene `!!`; `UnifiedPlayerActivity.kt` continúa sin contener `!!`.
- Se revisarán integridad del ZIP y sintaxis XML de los recursos al empaquetar.
- No equivale a una compilación Android. El entorno previo no pudo descargar Gradle 8.13 por falta de conexión a `services.gradle.org`; permanece pendiente compilar y probar en dispositivo.
