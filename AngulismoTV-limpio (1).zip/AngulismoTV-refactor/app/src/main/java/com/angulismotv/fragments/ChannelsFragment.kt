package com.angulismotv.fragments

import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.Editable
import android.text.TextWatcher
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.animation.AnimationUtils
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import androidx.core.content.ContextCompat
import androidx.core.view.isVisible
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.angulismotv.MainActivity
import com.angulismotv.R
import com.angulismotv.UnifiedPlayerActivity
import com.angulismotv.data.LoadResult
import android.widget.Toast
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout
import com.angulismotv.adapters.ChannelsAdapter
import com.angulismotv.models.Channel
import com.angulismotv.utils.DeviceHelper

class ChannelsFragment : Fragment() {

    // Views
    private lateinit var channelsRecycler: RecyclerView
    private lateinit var progressBar: ProgressBar
    private lateinit var swipeRefresh: SwipeRefreshLayout
    private lateinit var stateContainer: LinearLayout
    private lateinit var retryButton: TextView
    private lateinit var errorText: TextView
    private lateinit var categoriesContainer: LinearLayout
    private lateinit var searchInput: EditText
    private lateinit var btnSearch: ImageView

    // Adapter y datos
    private lateinit var channelsAdapter: ChannelsAdapter
    private var originalChannels = listOf<Channel>()
    private var filteredChannels = listOf<Channel>()
    private var currentCategory = "todos"
    private var isSearchVisible = false

    // ✅ Lista dinámica de categorías (se genera desde los datos)
    private var categories = mutableListOf<Pair<String, String>>()

    // Mapeo de nombres de categoría para mostrar en español
    private val categoryNames = mapOf(
        "todos" to "TODOS",
        "deportes" to "DEPORTES",
        "noticias" to "NOTICIAS",
        "peliculas" to "PELÍCULAS",
        "infantiles" to "INFANTILES",
        "educativos" to "EDUCATIVOS",
        "internacionales" to "INTERNACIONALES",
        "estilo-vida" to "ESTILO VIDA",
        "musicales" to "MUSICALES",
        "documentales" to "DOCUMENTALES",
        "eventos" to "EVENTOS"
    )

    // Optimizaciones
    private val searchHandler = Handler(Looper.getMainLooper())
    private var searchRunnable: Runnable? = null
    private val SEARCH_DELAY = 300L

    private var isTV = false

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        return inflater.inflate(R.layout.fragment_channels, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        isTV = DeviceHelper.isTV(requireContext())

        initViews(view)
        setupSearch()
        setupRecyclerView()
        setupStates()
        renderInitialState()

    }

    private fun initViews(view: View) {
        channelsRecycler = view.findViewById(R.id.channels_recycler)
        progressBar = view.findViewById(R.id.progress_bar)
        errorText = view.findViewById(R.id.error_text)
        swipeRefresh = view.findViewById(R.id.swipe_refresh)
        stateContainer = view.findViewById(R.id.state_container)
        retryButton = view.findViewById(R.id.retry_button)
        categoriesContainer = view.findViewById(R.id.categories_container)
        searchInput = view.findViewById(R.id.search_input)
        btnSearch = view.findViewById(R.id.btn_search)
    }

    private fun setupSearch() {
        btnSearch.setOnClickListener {
            toggleSearch()
        }

        searchInput.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                searchRunnable?.let { searchHandler.removeCallbacks(it) }
                searchRunnable = Runnable { applyFiltersAndUpdate() }
                searchHandler.postDelayed(searchRunnable!!, SEARCH_DELAY)
            }
            override fun afterTextChanged(s: Editable?) {}
        })
    }

    private fun toggleSearch() {
        isSearchVisible = !isSearchVisible

        if (isSearchVisible) {
            searchInput.visibility = View.VISIBLE
            searchInput.requestFocus()
            if (!isTV) {
                val imm = requireContext().getSystemService(android.content.Context.INPUT_METHOD_SERVICE) as android.view.inputmethod.InputMethodManager
                imm.showSoftInput(searchInput, android.view.inputmethod.InputMethodManager.SHOW_IMPLICIT)
            } else {
                searchInput.startAnimation(AnimationUtils.loadAnimation(requireContext(), android.R.anim.fade_in))
            }
        } else {
            searchInput.visibility = View.GONE
            searchInput.text.clear()
            if (!isTV) {
                val imm = requireContext().getSystemService(android.content.Context.INPUT_METHOD_SERVICE) as android.view.inputmethod.InputMethodManager
                imm.hideSoftInputFromWindow(searchInput.windowToken, 0)
            }
            applyFiltersAndUpdate()
        }
    }

    private fun applyFiltersAndUpdate() {
        if (originalChannels.isEmpty()) return

        val categoryFiltered = if (currentCategory == "todos") {
            originalChannels
        } else {
            originalChannels.filter { it.category == currentCategory }
        }

        val searchQuery = searchInput.text.toString().trim()
        filteredChannels = if (searchQuery.isNotEmpty()) {
            val query = searchQuery.lowercase()
            categoryFiltered.filter { channel ->
                channel.name.lowercase().contains(query)
            }
        } else {
            categoryFiltered
        }

        channelsAdapter.submitList(filteredChannels)

        if (filteredChannels.isEmpty()) {
            showState("No se encontraron canales", isError = false, showRetry = false)
        } else {
            hideState()
        }
    }

    // ✅ Función que genera categorías DINÁMICAMENTE desde los canales
    private fun generateCategoriesFromChannels(channels: List<Channel>) {
        if (channels.isEmpty()) return

        val uniqueCategories = channels.mapNotNull { it.category }
            .filter { it.isNotBlank() && it != "todos" }
            .distinct()
            .sorted()

        categories.clear()
        categories.add("todos" to "TODOS")

        uniqueCategories.forEach { categoryKey ->
            val displayName = categoryKey.replace("-", " ").uppercase()
            categories.add(categoryKey to displayName)
        }

        setupCategories()
    }

    private fun setupCategories() {
        categoriesContainer.removeAllViews()

        if (categories.isEmpty()) {
            // Si no hay categorías, mostrar al menos "todos"
            categories.add("todos" to "TODOS")
        }

        for ((key, label) in categories) {
            val chip = LayoutInflater.from(requireContext())
                .inflate(R.layout.item_category, categoriesContainer, false) as TextView

            chip.text = label
            chip.tag = key
            chip.isSelected = key == currentCategory

            updateChipStyle(chip, chip.isSelected)

            if (isTV) {
                setupTVFocusEffect(chip)
            } else {
                chip.setOnTouchListener { _, _ ->
                    chip.isSelected = true
                    false
                }
            }

            chip.setOnClickListener { selectCategory(key) }
            categoriesContainer.addView(chip)
        }

        if (isTV) {
            categoriesContainer.post {
                val selectedChip = categoriesContainer.findViewWithTag<TextView>(currentCategory)
                selectedChip?.requestFocus()
            }
        }
    }

    private fun updateChipStyle(chip: TextView, isSelected: Boolean) {
        if (isSelected) {
            chip.setBackgroundResource(R.drawable.bg_category_selected)
            chip.setTextColor(ContextCompat.getColor(requireContext(), R.color.text_primary))
        } else {
            chip.setBackgroundResource(R.drawable.bg_category_default)
            chip.setTextColor(ContextCompat.getColor(requireContext(), R.color.text_secondary))
        }
    }

    private fun setupTVFocusEffect(chip: TextView) {
        chip.onFocusChangeListener = View.OnFocusChangeListener { _, hasFocus ->
            if (hasFocus) {
                chip.animate().scaleX(1.05f).scaleY(1.05f).setDuration(150).start()
                val parent = chip.parent as? ViewGroup
                parent?.scrollTo(chip.left - 50, 0)
            } else {
                chip.animate().scaleX(1f).scaleY(1f).setDuration(150).start()
            }
        }
    }

    private fun selectCategory(categoryKey: String) {
        if (currentCategory == categoryKey) return

        currentCategory = categoryKey

        for (i in 0 until categoriesContainer.childCount) {
            val chip = categoriesContainer.getChildAt(i) as TextView
            updateChipStyle(chip, chip.tag == categoryKey)
        }

        applyFiltersAndUpdate()

        if (isSearchVisible) {
            toggleSearch()
        }

        channelsRecycler.smoothScrollToPosition(0)
    }

    private fun setupRecyclerView() {
        channelsRecycler.layoutManager = GridLayoutManager(requireContext(), calculateSpanCount())

        channelsAdapter = ChannelsAdapter { channel, position ->
            openPlayer(channel, position)
        }

        channelsRecycler.adapter = channelsAdapter

        if (isTV) {
            channelsRecycler.isFocusable = true
            channelsRecycler.requestFocus()
        }
    }

    /** Columnas según el ancho disponible: TV por rangos fijos; móvil/tablet una cada ~320dp. */
    private fun calculateSpanCount(): Int {
        val dpWidth = resources.configuration.screenWidthDp
        return if (isTV) {
            when {
                dpWidth >= 1920 -> 6
                dpWidth >= 1280 -> 5
                dpWidth >= 720 -> 4
                else -> 3
            }
        } else {
            (dpWidth / 320).coerceAtLeast(1)
        }
    }

    // La activity maneja la rotación sin recrearse, así que hay que recalcular las columnas a mano.
    override fun onConfigurationChanged(newConfig: android.content.res.Configuration) {
        super.onConfigurationChanged(newConfig)
        if (!::channelsRecycler.isInitialized) return
        (channelsRecycler.layoutManager as? GridLayoutManager)?.spanCount = calculateSpanCount()
    }

    /** Al crear las vistas: muestra la carga en curso o el último resultado que tenga la activity. */
    private fun renderInitialState() {
        val main = activity as? MainActivity
        val result = main?.getLoadResult()
        if (main == null || main.isLoadingChannels() || result == null) {
            showLoading(true)
        } else {
            applyResult(result)
        }
    }

    private fun setupStates() {
        swipeRefresh.setColorSchemeResources(R.color.accent)
        swipeRefresh.setProgressBackgroundColorSchemeResource(R.color.space_surface_raised)
        swipeRefresh.isEnabled = !isTV // en TV no hay gesto: se usa el botón Reintentar
        swipeRefresh.setOnRefreshListener { (activity as? MainActivity)?.reloadChannels() }
        retryButton.setOnClickListener { (activity as? MainActivity)?.reloadChannels() }
    }

    private fun applyResult(result: LoadResult) {
        originalChannels = result.channels
        currentCategory = "todos"
        showLoading(false)
        swipeRefresh.isRefreshing = false

        if (originalChannels.isEmpty()) {
            filteredChannels = emptyList()
            channelsAdapter.submitList(emptyList())
            categoriesContainer.removeAllViews()
            when {
                result.notConfigured ->
                    showState("Todavía no hay una lista de canales configurada.", isError = false, showRetry = false)
                result.failed ->
                    showState("No se pudo cargar la lista de canales.\nRevisá tu conexión e intentá de nuevo.", isError = true, showRetry = true)
                else ->
                    showState("La lista de canales está vacía.", isError = false, showRetry = true)
            }
        } else {
            generateCategoriesFromChannels(originalChannels)
            applyFiltersAndUpdate()
        }
    }

    private fun showState(message: String, isError: Boolean, showRetry: Boolean) {
        errorText.text = message
        errorText.setTextColor(
            ContextCompat.getColor(requireContext(), if (isError) R.color.error else R.color.text_secondary)
        )
        retryButton.isVisible = showRetry
        stateContainer.isVisible = true
        if (showRetry && isTV) retryButton.requestFocus()
    }

    private fun hideState() {
        stateContainer.isVisible = false
    }

    private fun showLoading(show: Boolean) {
        progressBar.isVisible = show
    }

    /** True si las vistas ya existen (entre onViewCreated y onDestroyView). */
    private fun isViewReady() = view != null && ::progressBar.isInitialized && ::channelsAdapter.isInitialized

    /** La activity avisa que empezó (o se repitió) la carga de la lista. */
    fun onLoadStarted() {
        if (!isViewReady()) return
        hideState()
        if (!swipeRefresh.isRefreshing) showLoading(true)
    }

    /**
     * La activity llama a esto cuando termina de cargar. Si el fragmento todavía no creó sus vistas
     * no hay nada que actualizar: [renderInitialState] leerá el resultado desde la activity al crearlas.
     */
    fun showResult(result: LoadResult) {
        if (!isViewReady()) return
        applyResult(result)
    }

    // En TV, al volver del reproductor el foco regresa al canal que se estaba mirando.
    override fun onResume() {
        super.onResume()
        if (isTV && !isHidden && isViewReady()) restoreTvFocus()
    }

    private fun restoreTvFocus() {
        val position = channelsAdapter.getLastFocusedPosition()
        if (position < 0 || position >= channelsAdapter.itemCount) return
        channelsRecycler.scrollToPosition(position)
        channelsRecycler.post {
            channelsRecycler.findViewHolderForAdapterPosition(position)?.itemView?.requestFocus()
        }
    }

    private fun openPlayer(channel: Channel, position: Int) {
        if (channel.streamUrl.isNullOrEmpty() && channel.options.isNullOrEmpty()) {
            Toast.makeText(requireContext(), "Este canal no tiene fuentes disponibles", Toast.LENGTH_SHORT).show()
            return
        }

        val intent = Intent(requireContext(), UnifiedPlayerActivity::class.java).apply {
            putParcelableArrayListExtra("channels", ArrayList(originalChannels))
            putExtra("channel_index", originalChannels.indexOfFirst {
                it.name == channel.name && it.logo == channel.logo
            })
            putExtra("channel_name", channel.name)
            putExtra("channel_logo", channel.logo)
            putExtra("stream_url", channel.streamUrl)
            putExtra("stream_type", channel.streamType ?: "hls")
            // Si ya hay un reproductor flotante, reutilizar esa instancia y cambiar el canal.
            addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP)
        }
        startActivity(intent)

        if (!isTV) {
            requireActivity().overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        searchRunnable?.let { searchHandler.removeCallbacks(it) }
    }
}