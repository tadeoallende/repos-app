package com.angulismotv

import android.os.Bundle
import android.util.Log
import android.view.KeyEvent
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import com.angulismotv.databinding.ActivityMainBinding
import com.angulismotv.fragments.AgendaFragment
import com.angulismotv.fragments.ChannelsFragment
import com.angulismotv.fragments.ForumFragment
import com.angulismotv.fragments.MulticamFragment
import com.angulismotv.data.ChannelRepository
import com.angulismotv.data.LoadResult
import com.angulismotv.models.Channel
import com.angulismotv.utils.DeviceHelper
import com.angulismotv.utils.UpdateManager
import com.bumptech.glide.Glide
import kotlinx.coroutines.launch

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private var allChannels = listOf<Channel>()
    private var channelsLoading = true
    private var lastLoadResult: LoadResult? = null
    private var isTV = false

    // ── Navegación ──────────────────────────────────────────────────────────
    // Sección activa actual — arranca siempre en Canales
    private var currentNavId: Int = R.id.nav_channels

    // Instancias únicas de cada fragment: se crean una vez y se reusan con
    // show/hide para preservar estado (scroll, datos cargados, etc.)
    private val fragmentChannels by lazy { ChannelsFragment() }
    private val fragmentAgenda   by lazy { AgendaFragment() }
    private val fragmentMulticam by lazy { MulticamFragment() }
    private val fragmentForum    by lazy { ForumFragment() }

    // ────────────────────────────────────────────────────────────────────────

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        isTV = DeviceHelper.isTV(this)

        Glide.with(this)
            .load(R.drawable.logo2)
            .placeholder(android.R.drawable.ic_menu_gallery)
            .error(android.R.drawable.ic_menu_gallery)
            .into(binding.logoImage)

        setupNavigation()
        setupBackHandler()
        loadAllChannels()

        // Check de actualizaciones (silencioso — solo muestra diálogo si hay novedad)
        UpdateManager(this).checkForUpdates(silent = true)
    }

    // ==================== NAVEGACIÓN ====================

    private fun setupNavigation() {
        // Mostrar el fragment inicial sin animación
        supportFragmentManager.beginTransaction()
            .add(R.id.fragment_container, fragmentChannels, TAG_CHANNELS)
            .commit()

        if (isTV) {
            binding.bottomNavigation.visibility = View.GONE
            binding.sideMenu.visibility = View.VISIBLE
            setupSideMenu()
        } else {
            binding.sideMenu.visibility = View.GONE
            binding.bottomNavigation.visibility = View.VISIBLE
            setupBottomNavigation()
        }
    }

    /**
     * Navega a la sección indicada por navId.
     * - Reutiliza instancias existentes (show/hide) en vez de recrear fragments.
     * - En TV mantiene estable la barra de navegación y actualiza el estado seleccionado.
     */
    private fun navigateTo(navId: Int) {
        if (navId == currentNavId) return

        val target = fragmentForId(navId)
        val transaction = supportFragmentManager.beginTransaction()
            .setCustomAnimations(android.R.anim.fade_in, android.R.anim.fade_out)

        // Ocultar el fragment actual
        supportFragmentManager.findFragmentByTag(tagForId(currentNavId))
            ?.let { transaction.hide(it) }

        // Mostrar (o agregar si es la primera vez) el fragment destino
        if (target.isAdded) {
            transaction.show(target)
        } else {
            transaction.add(R.id.fragment_container, target, tagForId(navId))
        }

        transaction.commit()
        currentNavId = navId

        if (isTV) {
            updateSideMenuSelection(navId)
        } else {
            // Sincronizar el ítem seleccionado del BottomNavigation
            if (binding.bottomNavigation.selectedItemId != navId) {
                binding.bottomNavigation.selectedItemId = navId
            }
        }
    }

    private fun fragmentForId(navId: Int): Fragment = when (navId) {
        R.id.nav_channels -> fragmentChannels
        R.id.nav_agenda   -> fragmentAgenda
        R.id.nav_multicam -> fragmentMulticam
        R.id.nav_forum    -> fragmentForum
        else              -> fragmentChannels
    }

    private fun tagForId(navId: Int): String = when (navId) {
        R.id.nav_channels -> TAG_CHANNELS
        R.id.nav_agenda   -> TAG_AGENDA
        R.id.nav_multicam -> TAG_MULTICAM
        R.id.nav_forum    -> TAG_FORUM
        else              -> TAG_CHANNELS
    }

    // ==================== BACK HANDLER ====================

    /**
     * Lógica de back unificada para móvil y TV:
     *
     * 1. Si el fragment visible tiene su propio manejo de back → delegar
     * 2. Si no estamos en Canales → volver a Canales (sección raíz)
     * 3. Si ya estamos en Canales → confirmar salida con diálogo
     *
     * Para TV también se intercepta KEYCODE_BACK en dispatchKeyEvent
     * antes de que cualquier vista lo consuma.
     */
    private fun setupBackHandler() {
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                handleBack()
            }
        })
    }

    private fun handleBack() {
        // 1. Intentar que el fragment activo maneje el back (ej: WebView con historial)
        val activeFragment = supportFragmentManager.findFragmentByTag(tagForId(currentNavId))
        if (activeFragment is BackHandler && activeFragment.handleBack()) return

        // 2. Si no estamos en la sección raíz, volver a Canales
        if (currentNavId != R.id.nav_channels) {
            navigateTo(R.id.nav_channels)
            return
        }

        // 3. Estamos en la raíz → confirmar salida
        showExitDialog()
    }

    private fun showExitDialog() {
        AlertDialog.Builder(this)
            .setTitle("Salir de AngulismoTV")
            .setMessage("¿Querés cerrar la aplicación?")
            .setPositiveButton("Salir") { _, _ -> finish() }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    // ==================== TV KEY DISPATCH ====================

    /**
     * Para TV interceptamos el back a nivel de Activity antes de que
     * cualquier View o Fragment lo consuma — mismo patrón que UnifiedPlayerActivity.
     */
    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        if (!isTV) return super.dispatchKeyEvent(event)
        if (event.action != KeyEvent.ACTION_DOWN) return super.dispatchKeyEvent(event)

        if (event.keyCode == KeyEvent.KEYCODE_BACK) {
            handleBack()
            return true
        }

        return super.dispatchKeyEvent(event)
    }

    // ==================== SIDE MENU (TV) ====================

    private fun setupSideMenu() {
        setupSideMenuItem(
            container = binding.menuChannels,
            label     = binding.menuChannelsText,
            navId     = R.id.nav_channels
        )
        setupSideMenuItem(
            container = binding.menuAgenda,
            label     = binding.menuAgendaText,
            navId     = R.id.nav_agenda
        )
        setupSideMenuItem(
            container = binding.menuMulticam,
            label     = binding.menuMulticamText,
            navId     = R.id.nav_multicam
        )
        setupSideMenuItem(
            container = binding.menuForum,
            label     = binding.menuForumText,
            navId     = R.id.nav_forum
        )

        // Selección y foco inicial: así el mando arranca en una sección clara,
        // en lugar de saltar a un control interno del fragmento.
        updateSideMenuSelection(currentNavId)
        binding.menuChannels.post { binding.menuChannels.requestFocus() }
    }

    private fun setupSideMenuItem(container: LinearLayout, label: TextView, navId: Int) {
        // En TV la barra permanece expandida: el foco cambia el borde, no el tamaño.
        label.visibility = View.VISIBLE
        container.isFocusable = true
        container.isFocusableInTouchMode = true
        container.isClickable = true
        container.setBackgroundResource(R.drawable.side_menu_item_bg)
        container.isSelected = navId == currentNavId
        container.setOnClickListener { navigateTo(navId) }
    }

    private fun updateSideMenuSelection(navId: Int) {
        listOf(
            binding.menuChannels to R.id.nav_channels,
            binding.menuAgenda to R.id.nav_agenda,
            binding.menuMulticam to R.id.nav_multicam,
            binding.menuForum to R.id.nav_forum,
        ).forEach { (view, id) ->
            view.isSelected = id == navId
            // Aplicar el selector siempre para que tanto el elemento seleccionado
            // como los demás tengan un estado de foco estable con el mando.
            view.setBackgroundResource(R.drawable.side_menu_item_bg)
        }
    }

    // ==================== BOTTOM NAVIGATION (MÓVIL) ====================

    private fun setupBottomNavigation() {
        binding.bottomNavigation.setOnItemSelectedListener { item ->
            // Evitar re-navegación al mismo destino
            if (item.itemId != currentNavId) {
                navigateTo(item.itemId)
            }
            true
        }
    }

    // ==================== DATA LOADING ====================

    private fun loadAllChannels() {
        channelsLoading = true
        fragmentChannels.onLoadStarted()
        lifecycleScope.launch {
            val result = ChannelRepository.loadAll()
            allChannels = result.channels
            lastLoadResult = result
            channelsLoading = false
            fragmentChannels.showResult(result)
            Log.d(TAG, "Canales cargados: ${allChannels.size} (fallo=${result.failed})")
        }
    }

    // ==================== PUBLIC API ====================

    fun getChannels(): List<Channel> = allChannels

    fun isLoadingChannels(): Boolean = channelsLoading

    fun getLoadResult(): LoadResult? = lastLoadResult

    /** Vuelve a pedir la lista de canales (botón Reintentar y deslizar para actualizar). */
    fun reloadChannels() = loadAllChannels()

    // ==================== COMPANION ====================

    companion object {
        private const val TAG          = "MainActivity"
        private const val TAG_CHANNELS = "fragment_channels"
        private const val TAG_AGENDA   = "fragment_agenda"
        private const val TAG_MULTICAM = "fragment_multicam"
        private const val TAG_FORUM    = "fragment_forum"
    }
}

/**
 * Interface que pueden implementar los Fragments para manejar
 * el botón Back internamente (ej: WebView con historial de navegación).
 *
 * Retornar true significa "yo lo manejé, no hagas nada más".
 * Retornar false delega el back a MainActivity.
 */
interface BackHandler {
    fun handleBack(): Boolean
}