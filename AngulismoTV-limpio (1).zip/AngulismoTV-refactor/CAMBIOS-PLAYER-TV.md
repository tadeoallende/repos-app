# Cambios iniciales: reproductor móvil y navegación Android TV

Esta copia parte del proyecto original y conserva el motor actual de reproducción.

## Celular

- `UnifiedPlayerActivity` ya no está fijada horizontalmente desde el manifiesto.
- Al abrir un canal, la actividad solicita orientación vertical y reduce su ventana a un marco 16:9 en la parte superior. La pantalla anterior queda visible fuera de ese marco.
- Se añadió un botón de pantalla completa. Al activarlo, la ventana vuelve a ocupar toda la pantalla y solicita orientación horizontal; al salir, vuelve a vertical y al tamaño compacto.
- El botón de cerrar permanece disponible mientras el reproductor está en modo compacto. La tecla Atrás sale primero de pantalla completa y luego permite cerrar el reproductor.
- Al seleccionar otro canal con el reproductor compacto abierto, se reutiliza la instancia mediante `singleTop` y se cambia el canal en lugar de apilar otra actividad.
- La ventana del reproductor es opaca y no flotante a nivel de tema; esto evita la incompatibilidad de orientación que tienen ciertas combinaciones de actividades translúcidas y cambios de orientación.

## Android TV

- El menú principal lateral ahora tiene ancho fijo de `190dp`; las etiquetas no desaparecen ni aparecen al recibir foco.
- Los cuatro destinos mantienen altura, márgenes y relleno estables. El foco cambia el fondo/borde en lugar de estirar el menú.
- Al iniciar, el foco del control remoto se coloca en **Canales**.
- La navegación conserva la instancia de cada fragmento y resalta el destino seleccionado.

## Archivos principales modificados

- `app/src/main/AndroidManifest.xml`
- `app/src/main/java/com/angulismotv/UnifiedPlayerActivity.kt`
- `app/src/main/java/com/angulismotv/MainActivity.kt`
- `app/src/main/java/com/angulismotv/fragments/ChannelsFragment.kt`
- `app/src/main/res/layout/activity_unified_player.xml`
- `app/src/main/res/layout/activity_main.xml`
- `app/src/main/res/drawable/side_menu_item_bg.xml`
- `app/src/main/res/values/themes.xml`
- Iconos nuevos: `ic_fullscreen.xml` e `ic_fullscreen_exit.xml`

## Validación realizada

- Se analizaron los 54 XML del directorio `app/src/main`: todos pasan el parseo XML.
- Se revisaron estáticamente los puntos clave y no se detectaron errores de parseo Kotlin en los archivos tocados.
- No se pudo confirmar una compilación APK completa en este entorno: no hay Android SDK local y la descarga de Gradle requiere conexión de red. Conviene compilar el ZIP en Android Studio o mediante el workflow de GitHub Actions antes de instalarlo en un dispositivo.

## Prueba manual recomendada

1. En un celular, abrir un canal y comprobar que la aplicación permanece vertical, el vídeo ocupa el marco superior y la pantalla anterior sigue visible debajo.
2. Tocar el botón de pantalla completa y confirmar el giro horizontal; salir con el icono o Atrás y confirmar que vuelve al modo compacto vertical.
3. En el modo compacto, tocar otro canal de la pantalla inferior y verificar que cambia el canal sin abrir una segunda ventana del reproductor.
4. En Android TV, recorrer Canales, Agenda, Multicam y Foro con la cruceta, comprobando que el menú conserva el ancho y muestra claramente el foco y la sección seleccionada.
