# AngulismoTV — Etapa 29: zapping rápido sin perder pulsaciones

## Problema
`handleTVKey()` solo llamaba a `changeChannel()` cuando `isZapping` era falso. Durante el cambio de canal, las pulsaciones adicionales de CH+/CH- se consumían sin producir un cambio, aunque el usuario estuviera manteniendo o pulsando rápidamente la cruceta.

## Cambio implementado
- Las teclas arriba/abajo de Android TV siempre delegan el cambio de canal a `changeChannel()` cuando el panel lateral y los controles no interceptan la navegación.
- `changeChannel()` acumula el desplazamiento mientras se carga el canal actual, en vez de descartar las pulsaciones.
- Al terminar la transición, `finishZappingTransition()` aplica el desplazamiento acumulado como un nuevo destino. Si llegan más pulsaciones durante la siguiente transición, se vuelven a acumular.
- El desplazamiento se normaliza con el tamaño del catálogo para conservar el comportamiento circular al pasar del primer canal al último y viceversa.
- Recargar la transmisión o destruir la actividad limpia el desplazamiento pendiente para que no se aplique después de una acción no relacionada.

## Validación estática
- Revisado el flujo de `handleTVKey()` → `changeChannel()` → `zapTo()` → `finishZappingTransition()`.
- Verificado que la transición normal mantiene el bloqueo contra cargas concurrentes y que el acumulado se vacía antes de iniciar el siguiente cambio.
- El ZIP se comprueba por integridad y se comparan los cambios contra la etapa 28.
- No se afirma compilación ni prueba en Android TV: requieren ejecutar Gradle y probar CH+/CH- con el control remoto real.

## Pruebas manuales recomendadas
1. Pulsar CH+ dos o tres veces rápidamente y comprobar que el último canal coincide con la cantidad de pulsaciones.
2. Repetir con CH- y con pulsaciones mixtas CH+/CH-.
3. Probar desde el primer canal hacia atrás y desde el último hacia delante.
4. Cambiar de canal y pulsar recargar durante la transición; confirmar que no queda un salto pendiente.
5. Verificar que la navegación del panel lateral y el movimiento de foco de los controles no cambian.
