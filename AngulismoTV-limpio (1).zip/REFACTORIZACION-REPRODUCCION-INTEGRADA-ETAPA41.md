# Etapa 41 — extracción del motor de reproducción integrada

## Objetivo

Separar de `ChannelsFragment` la propiedad y el ciclo de vida del motor ExoPlayer integrado, sin trasladar a un controlador la interfaz ni la selección de canales/fuentes.

## Cambios

- Nuevo `InlinePlaybackEngineController`: crea ExoPlayer con los atributos de audio y el perfil de buffer `INLINE`, instala y quita el listener, registra diagnósticos de pistas de audio, gobierna el timeout inicial de 12 segundos, libera el motor y puede desprenderlo sin liberarlo para el handoff hacia `UnifiedPlayerActivity`.
- `ChannelsFragment` conserva la coordinación de UI, elección manual de fuente, errores visibles, WebView/iframe, Cast, controles y ciclo de vida del fragmento. Recibe eventos del motor mediante callbacks.
- El retorno desde pantalla completa conecta el mismo ExoPlayer al controlador sin reconstruir el elemento multimedia. La transferencia a pantalla completa elimina listener/timeout y desacopla la vista, pero no pausa ni libera el reproductor transferido.
- Nuevo `InlineStartupTimeoutPolicy` y cuatro pruebas unitarias para verificar que el watchdog solo actúe si coinciden la generación y el reproductor, y si la reproducción todavía no llegó a `READY`/`ENDED`.

## Comprobaciones realizadas

- Revisión estática de todos los usos del reproductor integrado, arranque, retorno desde fullscreen, `onPause`, ocultación del fragmento, recarga y `onDestroyView`.
- Comprobación de que `ChannelsFragment` ya no implementa directamente el listener ExoPlayer ni almacena el `Runnable` del timeout.
- Comprobación de los casos puros de `InlineStartupTimeoutPolicy` mediante Kotlin aislado.
- Integridad del ZIP y sintaxis XML comprobadas al empaquetar.

## Pendiente / límites

No se afirma que esta etapa haya compilado con Gradle ni que se haya probado en un dispositivo. El entorno anterior no pudo resolver `services.gradle.org` para descargar Gradle 8.13. Hace falta ejecutar `testDebugUnitTest`/`assembleDebug` con Gradle disponible y probar un stream nativo, iframe, recarga, pausa/reanudación, handoff ida/vuelta y cierre del fragmento en Android real.
