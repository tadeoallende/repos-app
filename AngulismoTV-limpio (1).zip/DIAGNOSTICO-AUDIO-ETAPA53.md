# Etapa 53 — Diagnóstico de audio nativo

## Objetivo

Mejorar la evidencia disponible para investigar canales que muestran video pero no emiten audio en Android TV. Esta etapa no cambia selección de códecs, volumen, mezcla ni estrategia de reintentos: hacerlo sin registros del dispositivo podría romper canales que ya funcionan.

## Cambios

- `PlayerAudioDiagnostics` unifica el registro de pistas en el reproductor integrado y fullscreen.
- Cada pista registra superficie, tipo de fuente, grupo/índice, selección, compatibilidad reportada por ExoPlayer, MIME, codec declarado, canales y frecuencia de muestreo.
- Resume cada estado como `no_audio_tracks`, `no_supported_audio_track`, `no_selected_audio_track` o `audio_track_selected`.
- Los errores nativos incluyen el nombre/código de error de ExoPlayer y los tipos de excepción encadenados; no se registran mensajes completos de excepción ni URLs completas para evitar exponer tokens de streams.
- Se marca como sospechoso el camino de audio cuando la cadena de causas menciona inicialización de decodificador o fallos de `AudioSink`/`AudioTrack`. Es una pista diagnóstica, no un diagnóstico definitivo.
- `PlayerAudioDiagnosticPolicy` es una política pura con pruebas unitarias para estados de pista y cadenas de causas cíclicas/acotadas.

## Validación realizada

- Compilación aislada con `kotlinc` de la política pura y seis escenarios de humo.
- Compilación de sintaxis de `PlayerAudioDiagnostics` con stubs locales de Android/ExoPlayer; esto valida sintaxis y contratos usados, pero no sustituye al compilador Android real.
- Se deben volver a analizar los XML y verificar el ZIP después de empaquetar.
- La suite Gradle completa no se puede confirmar mientras el entorno no pueda descargar Gradle 8.13 desde `services.gradle.org`.

## Cómo usar los nuevos registros en un dispositivo

1. Reproducir un canal afectado y otro que sí tenga sonido en el mismo Android TV.
2. Probar primero en el reproductor integrado y luego en fullscreen.
3. Filtrar Logcat por `PlayerAudio`.
4. Compartir las líneas de estado de pistas y `playback_error` de ambos canales, ocultando cualquier dato de cuenta/dispositivo que no quiera compartir.

Interpretación inicial: `no_audio_tracks` puede indicar una fuente/manifest sin pista de audio expuesta; `no_supported_audio_track` apunta a compatibilidad de formato; `no_selected_audio_track` indica que no quedó pista elegida; `audio_track_selected` con silencio requiere revisar errores de sink/decoder, el formato real y la salida de audio del dispositivo. Ninguna categoría por sí sola prueba la causa final.
