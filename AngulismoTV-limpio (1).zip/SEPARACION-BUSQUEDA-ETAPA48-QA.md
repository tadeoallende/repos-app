# QA — etapa 48

- [x] El cambio de texto publica la consulta inmediatamente.
- [x] La aplicación de la lista se difiere hasta que vence el debounce vigente.
- [x] Tareas de debounce antiguas no pueden reemplazar el resultado actual.
- [x] Aplicar/limpiar inmediatamente cancela tareas pendientes.
- [x] Limpiar sin aplicar permite que el llamador haga una sola actualización tras un cambio de categoría.
- [x] La disposición impide futuras acciones del controlador.
- [x] El binding elimina su `TextWatcher` al destruirse.
- [x] Apertura/cierre sincronizan visibilidad del contenedor y campo, icono del header y teclado.
- [x] La selección de categoría no dispara dos actualizaciones por cerrar la búsqueda.
- [x] Los 74 archivos XML se analizaron correctamente.
- [x] El ZIP acumulativo pasa `unzip -t`.
- [ ] Build oficial Android y suite Gradle: bloqueados por la descarga de Gradle 8.13 (`services.gradle.org`, `UnknownHostException`).
- [ ] Pruebas en dispositivos reales Android móvil/TV: pendientes.
