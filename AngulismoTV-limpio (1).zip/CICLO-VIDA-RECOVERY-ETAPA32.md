# AngulismoTV — Etapa 32: ciclo de vida del controlador de recuperación

## Problema
`recovery` era una propiedad `by lazy`, pero `onDestroy()` llamaba siempre a `recovery.dispose()`. Si la actividad se destruía antes de que cualquier flujo de reproducción accediera al controlador, esa llamada lo inicializaba justo durante la destrucción.

## Cambio
- Se conservó la inicialización diferida mediante `Lazy`, pero se guardó su delegado en `recoveryDelegate`.
- `onDestroy()` solo llama a `dispose()` si el controlador ya fue inicializado (`recoveryDelegate.isInitialized()`).
- Los puntos de uso existentes siguen accediendo a la propiedad `recovery`; no se cambia la política de reconexión ni el watchdog.

## Validación
- Revisión estática del delegado, de sus usos y del orden de limpieza en `onDestroy()`.
- ZIP verificado por integridad y 74 XML revisados sin errores.
- Falta ejecutar Gradle y comprobar el ciclo de vida en dispositivos; no se declara compilación ni prueba funcional.
