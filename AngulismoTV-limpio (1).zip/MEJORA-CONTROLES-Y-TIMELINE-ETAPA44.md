# Etapa 44 — Controles y línea de tiempo del reproductor integrado

## Alcance

Esta tanda separa la política de visibilidad/auto-ocultado de los controles táctiles de `ChannelsFragment` y endurece la conversión y el ciclo de vida del refresco de la línea de tiempo compartida con pantalla completa.

## Cambios

- Nuevo `InlineControlsAutoHideController`: gestiona mostrar temporalmente, mantener controles visibles durante un error, ocultar explícitamente, alternar visibilidad, cancelar el temporizador y disponer el controlador sin tocar vistas destruidas.
- Elimina de `ChannelsFragment` el estado `inlineControlsVisible` y el `Runnable` de auto-ocultado; la UI se actualiza por callbacks y la clase conserva la propiedad de sus vistas.
- Evita que una tarea de auto-ocultado antigua o ya encolada oculte una instancia más reciente de los controles.
- Al ocultar los controles se detiene el refresco de la línea de tiempo; al volver a mostrarlos se actualiza y, si corresponde, se reinicia el ciclo de actualización.
- Durante un gesto de búsqueda o con el selector modal de fuentes abierto, los controles quedan persistentes; al terminar la interacción vuelve el temporizador normal.
- `PlayerTimelineMath` centraliza el mapeo posición/progreso, limita los valores fuera de rango y evita overflow al calcular posiciones largas.
- `PlayerTimelineController` valida duraciones positivas, no asigna repetidamente el `max` del seek bar y comprueba la identidad del `Runnable` antes de programar el siguiente tick.
- El retorno desde pantalla completa vuelve a reiniciar las actualizaciones de la línea de tiempo si se conserva un reproductor nativo listo y los controles siguen visibles.

## Validación realizada

- 10 pruebas aisladas ejecutadas con un runner local: temporizador de controles, reinicio del plazo, tareas obsoletas, controles persistentes, TV/contenedor no disponible, disposición y conversiones del seek bar incluidos los extremos.
- `PlayerTimelineController` compiló con `kotlinc` contra stubs de sus dependencias Android/ExoPlayer para verificar sintaxis y firmas.
- La suite Gradle real no pudo ejecutarse en este entorno porque el wrapper necesita Gradle 8.13 y la descarga de `services.gradle.org` no está disponible. Esto no equivale a compilar la app Android.
- No se probó en hardware Android/Android TV. La confirmación de los cambios de reproducción, fullscreen y Cast requiere una compilación real y pruebas en dispositivo.

## Archivos principales

- `app/src/main/java/com/angulismotv/player/InlineControlsAutoHideController.kt`
- `app/src/main/java/com/angulismotv/player/PlayerTimelineMath.kt`
- `app/src/main/java/com/angulismotv/player/PlayerTimelineController.kt`
- `app/src/main/java/com/angulismotv/fragments/ChannelsFragment.kt`
- `app/src/test/java/com/angulismotv/player/InlineControlsAutoHideControllerTest.kt`
- `app/src/test/java/com/angulismotv/player/PlayerTimelineMathTest.kt`
