# Etapa 57 — Fallback de decodificador y panel "Info de audio"

## Objetivo

Reducir los canales con video pero sin audio y poder diagnosticarlos sin Logcat. Esta etapa no agrega códecs nuevos: eso (Media3 + FFmpeg) queda pendiente hasta confirmar con datos reales que el problema es el códec.

## Cambios

- `StreamMediaSourceFactory.createRenderersFactory()` crea un `DefaultRenderersFactory` con `setEnableDecoderFallback(true)`. Si el decodificador preferido de un códec falla al inicializarse, ExoPlayer prueba los demás del dispositivo. Se usa en el reproductor integrado y en pantalla completa.
- Panel **Info de audio** (botón con icono de parlante en los controles de pantalla completa, visible solo con fuentes nativas). Muestra modelo y Android del dispositivo, canal, tipo y host de la fuente, estado del audio, y por pista: códec, MIME, canales, frecuencia, soporte y si está seleccionada, más el último error. Nunca muestra la URL completa.
- Aviso breve (Toast) cuando el canal tiene audio pero ninguna pista es compatible con el dispositivo (`no_supported_audio_track`). No se avisa por "sin pistas": en HLS puede ser transitorio.
- `PlayerAudioDiagnostics.logTracks()` ahora devuelve un resumen (`AudioSummary`) y `logPlaybackError()` devuelve un texto corto del error. Los logs `PlayerAudio` se mantienen.

## Cómo usarlo con un usuario afectado

1. Abrir el canal sin sonido en pantalla completa.
2. Tocar o seleccionar el botón de parlante (Info de audio) y mandar una captura.
3. Interpretar: "no puede decodificar ese formato" = códec; "no expone pistas" = fuente; "pista seleccionada" con silencio = volumen/salida de audio del dispositivo.

## Validación

- Se verificó que los XML (layout e icono) están bien formados y se revisó el diff a mano.
- **No se compiló ni se ejecutaron pruebas**: el entorno no tiene Kotlin ni acceso a Gradle. Hay que compilar y probar en un dispositivo.
- Pruebas unitarias nuevas en `PlayerAudioDiagnosticPolicyTest` (aviso solo para audio no soportado y textos por estado).
