# Etapa 45 — extracción del estado visual de ChannelsFragment

## Objetivo

Separar la presentación de los reproductores y del catálogo de canales de la coordinación de datos/ciclo de vida que mantiene `ChannelsFragment`, sin cambiar el flujo de reproducción ni la navegación.

## Cambios

- `InlinePlayerVisualController`: concentra la presentación del spinner, el mensaje de error y sus ayudas, la visibilidad de las superficies nativa/WebView, la barra de controles, la línea de tiempo, el botón reproducir/pausar y el selector de fuentes. No crea, pausa ni libera ExoPlayer/WebView; esa propiedad sigue en los controladores de reproducción.
- `TvPlayerPreviewRenderer`: concentra la composición exclusiva de Android TV para estado vacío, identidad del canal, categoría, guía contextual, foco y mensajes de estado de Cast. Las vistas opcionales permiten usar la misma clase desde la pantalla móvil sin depender de IDs que no existen en ese layout.
- `ChannelCatalogStateRenderer`: concentra la carga de la lista, el `SwipeRefreshLayout`, el estado de error/vacío, el botón Reintentar y la limpieza de listeners al destruir la vista.
- `ChannelCatalogEmptyStatePolicy`: decide de forma pura qué estado vacío presentar para una lista sin configurar, una carga fallida o una lista correctamente cargada pero vacía. Mantiene la precedencia anterior de `notConfigured` sobre `failed`.
- `ChannelsFragment`: delega las actualizaciones visuales a los renderizadores; se conservan allí las decisiones de selección de canal, catálogo, reproducción, Cast y traspaso a pantalla completa.

## Validación realizada

- `ChannelsFragment.kt` pasó de 1.697 a 1.657 líneas respecto de la etapa 44.
- Las clases visuales nuevas compilaron con `kotlinc` contra stubs mínimos de las APIs Android usadas. Esto verifica sintaxis/firmas básicas, no compila la aplicación completa contra el SDK.
- Harness aislados: 22 comprobaciones de renderizado/estados del catálogo, 11 escenarios de vista previa TV y 5 escenarios de la política de estado vacío.
- Se añadieron cinco pruebas unitarias JUnit para `ChannelCatalogEmptyStatePolicy`.
- Validación XML y prueba de integridad del ZIP sin errores.

## Pendiente conocido

No se pudo ejecutar Gradle/JUnit ni `assembleDebug`: el wrapper intenta descargar Gradle 8.13 y el entorno no resuelve `services.gradle.org`. Sigue pendiente probar reproducción nativa, WebView, retorno de fullscreen, errores y Cast en un dispositivo real. Los harness aislados no sustituyen esas comprobaciones.
