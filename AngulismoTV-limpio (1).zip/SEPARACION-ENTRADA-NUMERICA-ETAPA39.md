# Separación de entrada numérica de canales — Etapa 39

## Cambio

Se extrajo la entrada por número de canal del mando a `ChannelNumberEntryController` (`player/ChannelNumberEntryController.kt`). El controlador ahora coordina:

- el buffer con 3, 4 o 5 cifras según el tamaño del catálogo;
- el texto y la visibilidad del indicador `CANAL`;
- el timeout de confirmación de 1,5 segundos;
- el borrado y la cancelación de callbacks al cambiar el catálogo o destruir el reproductor;
- la validación del rango antes de delegar la selección.

`UnifiedPlayerActivity` conserva la decisión de cambiar de canal (`zapTo`) y solo recibe el número confirmado. No cambia el formato visual del indicador ni los criterios de selección de canal.

## Validaciones realizadas

- Harness Kotlin aislado del controlador y el buffer: 6 escenarios OK (selección inmediata válida, entrada inválida con timeout, catálogo de cinco cifras, confirmación durante zapping, limpieza y disposición).
- Búsqueda estática: no quedan referencias antiguas a `channelNumberBuffer`, `clearChannelNumberRunnable` ni `channelNumberTimeoutMs` en `UnifiedPlayerActivity`.
- Revisar integridad del ZIP y XML al empaquetar.

## Limitaciones

El harness usa stubs mínimos para `Handler`, `View` y `TextView`; sirve para comprobar sintaxis y flujo del controlador, pero no reemplaza JUnit/Gradle ni una prueba en Android TV. La compilación completa de Android sigue pendiente por la descarga de Gradle 8.13 bloqueada en el entorno de trabajo.
