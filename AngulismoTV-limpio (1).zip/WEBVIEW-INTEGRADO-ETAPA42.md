# Etapa 42 — WebView integrado modular

## Objetivo

Separar de `ChannelsFragment` la configuración y la navegación del reproductor iframe, junto con las operaciones de ciclo de vida que no dependen de la interfaz del catálogo.

## Cambios

- Nuevo `InlineWebViewPlaybackController`: configura el WebView, instala los `WebViewClient`/`WebChromeClient`, rechaza permisos y ventanas emergentes, aplica la política de navegación de origen, cancela errores SSL y procesa errores de carga del documento principal.
- Los callbacks de carga y error validan la generación vigente mediante `WebViewLoadEventGate`. Los errores duplicados de una misma generación se agrupan para no disparar varias veces el mensaje de error; un fallo ya notificado no puede quedar oculto por un `onPageFinished` tardío.
- Se añadieron cuatro pruebas unitarias para eventos de generación obsoleta, deduplicación de errores y reinicio de estado al cargar una nueva fuente.
- El controlador centraliza `stopAndHide`, pausa/reanudación, limpieza de una página antes de usar una fuente nativa, destrucción y el detach/reattach del WebView transferido a fullscreen.
- `ChannelsFragment` conserva las responsabilidades visuales: spinner, mensaje de error, controles, timeline y la decisión de fuente elegida.
- La transferencia de fullscreen conserva la instancia exacta del WebView. Si Android destruye la vista del fragmento durante una rotación, `onDestroyView` no debe borrar ni destruir el documento que ya pertenece a `UnifiedPlayerActivity`.

## Validación

- Se revisaron los call sites de inicio de iframe, cambio a fuente nativa, recarga, cierre, pausa/reanudación, fullscreen y devolución de sesión.
- La política de navegación existente conserva sus pruebas unitarias (host original/subdominios, hosts parecidos y recursos secundarios/redirecciones).
- XML y empaquetado se vuelven a verificar en esta etapa.
- La compilación Gradle de la app queda pendiente: el entorno no puede descargar Gradle 8.13 desde `services.gradle.org`. No se afirma que el APK compile ni que el flujo se haya probado en un dispositivo.
