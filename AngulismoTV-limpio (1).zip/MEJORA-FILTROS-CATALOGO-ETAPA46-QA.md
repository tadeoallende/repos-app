# QA — etapa 46

## Alcance revisado

- Estado de categoría, país y consulta centralizado en `ChannelCatalogFilterController`.
- Normalización de selección cuando se reemplaza el catálogo.
- Búsqueda insensible a mayúsculas y diacríticos.
- Debounce de 300 ms con cancelación al ejecutar filtros inmediatos y al destruir la vista.
- Restauración de foco de Android TV separada de `ChannelsFragment`, con comprobaciones de vigencia antes de usar vistas.

## Resultados locales

- 20 métodos de prueba aislados ejecutados mediante un runner Kotlin local; los métodos de prueba reales se compilaron con stubs mínimos para JUnit y APIs Android que no están disponibles en el runner. **No equivale al task oficial de Gradle/JUnit.**
- `ChannelCatalogFilterController`, `ChannelFilterPolicy` y la lógica del catálogo compilaron en aislamiento y pasaron sus escenarios.
- `ChannelCatalogFocusController` compiló con stubs mínimos para verificar sintaxis y firmas; no valida la navegación real de RecyclerView en hardware.
- 74 XML parseados correctamente.
- Comprobación léxica de delimitadores para todos los Kotlin modificados: correcta.
- `ChannelsFragment.kt`: 1.657 → 1.620 líneas (−37 respecto a etapa 45).
- Integridad del ZIP acumulativo: correcta.

## Bloqueos / pruebas pendientes

`bash ./gradlew testDebugUnitTest --no-daemon` no pudo iniciar el build: el wrapper intenta descargar Gradle 8.13 y falla con `UnknownHostException: services.gradle.org`. Faltan la compilación Android completa, el task oficial de JUnit y las pruebas en un móvil/Android TV reales (teclado, D-pad, foco tras filtros y cambios de catálogo).
