# Etapa 52 — Preservar la intención de reproducción en el ciclo de vida

## Hallazgo

`ChannelsFragment.onPause()` y `onHiddenChanged(true)` pausaban el motor integrado, pero `onResume()` y `onHiddenChanged(false)` llamaban incondicionalmente a `player.play()`. Eso podía reanudar un canal que el usuario había pausado antes de cambiar de aplicación, ocultar el fragmento o volver desde una pantalla que no reutilizara la sesión nativa.

## Cambio

- Se añadió `InlinePlaybackResumeIntent`, un estado pequeño y comprobable que captura `playWhenReady` antes de la pausa.
- Capturas repetidas de `onPause`/`onHiddenChanged` no pisan la intención original.
- Al volver a estar visible, la intención capturada se consume una sola vez y se restaura mediante `playWhenReady`.
- Si no hubo una pausa de ciclo de vida registrada, el código no fuerza la reproducción.
- La restauración de una sesión entregada explícitamente por `InlinePlayerHandoff` conserva su comportamiento actual (`session.wasPlaying`).

## Pruebas y límites

`InlinePlaybackResumeIntentTest` cubre: estado pausado, estado reproduciendo, callbacks duplicados y ausencia de intención capturada. La clase es Kotlin puro y se puede compilar de forma aislada. Esto no reemplaza una compilación Android ni pruebas con dispositivos reales.
