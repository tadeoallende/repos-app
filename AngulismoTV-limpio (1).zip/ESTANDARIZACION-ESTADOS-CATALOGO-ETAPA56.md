# Etapa 56 — Estados visuales del catálogo y foco

## Objetivo

Unificar la diferencia visual entre foco, selección y estado normal en filas/categorías; evitar que el anillo de foco borre por completo la señal de selección; hacer visible el foco del buscador; y corregir la variante de estilo del control principal inline para TV que había heredado el fondo prominente de móvil en la etapa 55.

## Cambios

- Normalicé a 2 dp el contorno de foco en los selectores de filas, categorías, buscador, acceso al buscador, menú lateral y controles inline.
- `item_channel_bg` incorpora un estado explícito combinado `selected + focused`, conservando la identidad visual del canal seleccionado sin perder el anillo de foco.
- Las filas seleccionadas de los paneles laterales ahora mantienen un relleno de selección visible al recibir foco, con el mismo contorno de 2 dp.
- El campo de búsqueda comunica el foco a su superficie exterior. `ChannelSearchInputBinding` instala y elimina el listener junto con el watcher para respetar el ciclo de vida de la vista.
- Separamos `Widget.AngulismoTV.InlineControl.Primary.TV`: mantiene el fondo circular en TV, mientras que móvil conserva el tratamiento prominente anterior.
- Unifiqué estilo y espaciado del botón «Reintentar» en móvil y TV, y la apariencia del mensaje de catálogo vacío.
- El menú principal de TV sigue usando el selector de foco habitual y la selección sigue cambiando únicamente el color del icono; no se añade fondo cian por selección.

## Validación

- Se parsearon todos los XML de recursos; la comprobación inicial tuvo 74 archivos y 0 errores de sintaxis.
- La comprobación de referencias locales se realiza contemplando recursos no XML (por ejemplo, iconos de launcher en WebP) y referencias `@+id`.
- Se revisaron en los selectores los estados combinados, la prioridad de los estados y el grosor del contorno.
- Las referencias `R.*` usadas por Kotlin/Java fueron contrastadas contra los recursos del proyecto: 0 referencias faltantes. En layouts/drawables no quedaron medidas positivas `dp`/`sp` codificadas directamente fuera de `values`.
- `ChannelSearchInputBinding.kt` superó una compilación Kotlin aislada con stubs mínimos de Android; esto comprueba sintaxis del binding, pero no sustituye la compilación Android real.
- Se marcó `gradlew` como ejecutable para facilitar el uso local. La prueba `testDebugUnitTest` no pudo iniciarse porque Gradle intenta descargar `gradle-8.13` y el entorno devuelve `UnknownHostException: services.gradle.org`. No es un fallo de test: el build quedó bloqueado antes de la configuración del proyecto.
- No hay pruebas visuales en Android TV/teléfono en esta etapa.

## Alcance

La etapa es de presentación/estados. No cambia el filtrado del catálogo, la selección de canales, los favoritos, la navegación de Agenda ni la lógica del reproductor.
