# Etapa 38 — referencias no nulas en los controladores de reproducción

## Cambios

- `PlayerTimelineController.startUpdates()` ahora crea un `Runnable` local, lo registra en `updateRunnable` y lo programa sin `!!`.
- `PlaybackRecoveryController.startWatchdog()` aplica el mismo patrón al watchdog.
- `PlaybackRecoveryController.scheduleReconnect()` aplica el mismo patrón a la tarea de reconexión.
- No se modificaron los intervalos, las condiciones de reintento ni las decisiones de recuperación.

## Validación

- Búsqueda estática en el código fuente de la app: las tres aserciones `!!` de estos controladores desaparecieron; `ChannelsFragment.kt` y `UnifiedPlayerActivity.kt` continúan sin `!!`.
- La integridad del ZIP y los XML se verificarán en el artefacto generado.
- La compilación Android completa sigue pendiente: el entorno no pudo descargar Gradle 8.13 desde `services.gradle.org`. No se afirma que esta etapa haya pasado compilación o pruebas en dispositivo.
