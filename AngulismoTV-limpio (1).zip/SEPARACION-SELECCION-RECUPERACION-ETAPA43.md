# Etapa 43 — Selección de fuente y estado de sesión del reproductor integrado

## Objetivo

Reducir las responsabilidades de `ChannelsFragment` sin cambiar el comportamiento de selección manual de fuentes ni interrumpir el intercambio de sesión con `UnifiedPlayerActivity`.

## Cambios

- Se añadió `InlineSourceResolver`, que resuelve el tipo y la URL de una opción seleccionada, o de la URL principal cuando no hay opciones. Devuelve resultados tipados para selección inválida y URL vacía; no salta silenciosamente a otra fuente cuando el índice de una lista de opciones es incorrecto.
- Se añadió `InlinePlaybackSessionState`, que centraliza canal, índice de fuente, URL/tipo actuales y generación de callbacks. `ChannelsFragment` consulta este estado en vez de mantener copias mutables separadas.
- La restauración desde fullscreen, el comienzo de otro canal, la recarga/cambio de fuente y el cierre pasan por operaciones explícitas sobre el estado. Esto hace que los callbacks de generaciones anteriores se puedan invalidar de forma consistente.
- El fallo de reproducción ahora se resuelve de forma atómica: solo falla el intento vigente; se invalida su generación, se detiene el descubrimiento de Cast, se libera el motor fallido y se muestra el mensaje. Se conserva el índice seleccionado para que **Recargar** vuelva a intentar esa fuente, sin hacer fallback automático a otra.
- El estado recuerda que una fuente falló, por lo que Cast no vuelve a aparecer al reanudar la pantalla hasta que se inicie un nuevo intento.
- Se centralizó en el estado la condición base de elegibilidad para Cast, evitando que el fragmento vuelva a deducirla con varias propiedades independientes.
- Las opciones sin nombre se muestran con etiquetas útiles (`Fuente 1`, `Fuente 2`, etc.) en el selector.
- `InlineWebViewPlaybackController` ahora transforma excepciones síncronas al configurar/cargar el WebView en un fallo controlado, protege las operaciones de pausa/reanudación/limpieza y garantiza que los pasos de destrucción se intenten de forma independiente.
- `onHiddenChanged(false)` ya comprueba que la vista actual exista antes de acceder a las vistas `lateinit`; estar “inicializado” no significa que una vista de una instancia anterior siga viva después de `onDestroyView`.

## Comportamiento que se mantiene

- La selección de fuentes continúa siendo manual.
- Recargar conserva el canal y el índice elegidos.
- Los fallos de generaciones anteriores no cambian el error ni liberan recursos del intento actual.
- El WebView transferido a fullscreen conserva la instancia/documento; las operaciones de limpieza no deben destruir la instancia transferida.
- Una fuente iframe no se ofrece como destino de Cast desde el botón integrado.

