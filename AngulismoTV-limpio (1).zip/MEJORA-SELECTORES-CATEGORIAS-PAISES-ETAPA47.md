# Etapa 47 — Selectores de categorías y países

## Objetivo

Separar la construcción visual de la tira de categorías y el selector de países de `ChannelsFragment`, preservando el comportamiento móvil y la navegación por mando de Android TV.

## Cambios

- `ChannelCategoryRailRenderer` construye y actualiza los chips de categorías/país, la selección visual y los enlaces de foco de Android TV. También limpia las referencias de foco al desaparecer el catálogo.
- `CountryFilterDialogController` concentra la creación y el ciclo de vida del diálogo de países. No almacena la selección: la devuelve al fragmento mediante un callback.
- `CountryFilterOptionsPolicy` produce opciones deterministas, elimina duplicados y valores vacíos, ordena por etiqueta y vuelve a «Todos los países» si la selección dejó de existir.
- `ChannelCategoryRailPolicy` normaliza la lista de chips, garantiza «Todos» en primer lugar y elimina claves repetidas o vacías.
- `ChannelCategoryLabels` centraliza las etiquetas en español y el formato de nombres de categoría que no estén en el mapa conocido.
- `ChannelsFragment` ahora solicita las opciones al controlador de catálogo y delega el dibujo, el estilo y el foco. Se eliminó su lista mutable duplicada de categorías y el bloque de construcción de chips/diálogo.
- Los diálogos abiertos se cierran al iniciar o aplicar una recarga para no seleccionar opciones de un catálogo anterior.
- Si el catálogo queda vacío, se limpian los chips y los enlaces de foco; no quedan referencias a botones ya removidos.
- La política de categorías ahora distingue `International`, `Lifestyle`/`Estilo de vida` y `Events`/`Eventos` como `Internacionales`, `Estilo de vida` y `Eventos`, en lugar de clasificarlos como «Otros» o «Entretenimiento». La generación de categorías calcula primero los grupos presentes y evita volver a recorrer toda la lista para cada grupo.

## Verificación

- `ChannelsFragment.kt`: 1.620 → 1.458 líneas frente a la etapa 46 (162 líneas menos).
- 11 escenarios Kotlin aislados aprobados para normalización de chips, opciones del diálogo, etiquetas en español, mapeo de categorías y filtros combinados.
- Los controladores `ChannelCategoryRailRenderer` y `CountryFilterDialogController` compilaron de forma aislada contra stubs de sus APIs Android/AndroidX. Esto comprueba sintaxis y firmas utilizadas, pero no equivale al build real de la aplicación.
- Se añadieron siete métodos de prueba JUnit para `ChannelCategoryRailPolicy`, `CountryFilterOptionsPolicy` y `ChannelCategoryLabels`, además de un caso JUnit para los nuevos grupos de categorías en `ChannelFilterPolicyTest` (ocho métodos nuevos en total).
- La suite oficial no pudo ejecutarse. `bash ./gradlew testDebugUnitTest --no-daemon` falla antes de iniciar Gradle porque no se puede resolver `services.gradle.org` (`UnknownHostException`) al descargar Gradle 8.13.

## Pendiente

- Ejecutar `testDebugUnitTest` y `assembleDebug` en un entorno con Gradle 8.13 disponible.
- Probar el comportamiento visual/foco en un Android TV real y el selector en un móvil.
- Los cambios permanecen en el ZIP acumulativo; no se publicaron en GitHub.
