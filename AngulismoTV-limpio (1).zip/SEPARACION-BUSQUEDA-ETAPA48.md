# Etapa 48 — búsqueda y sincronización de filtros

## Objetivo

Separar la edición de texto de la consulta y su temporizador de `ChannelsFragment`, además de unificar la transición de visibilidad de la búsqueda para móvil y Android TV.

## Cambios

- `ChannelSearchQueryController` administra el valor vigente de la consulta, publica los cambios inmediatamente al controlador de filtros y limita la aplicación de la lista a la última tarea de debounce.
- `ChannelSearchInputBinding` conecta `EditText` con el controlador y elimina explícitamente el `TextWatcher` en `dispose()`. También encapsula el borrado inmediato y el borrado sin aplicar, necesario cuando un cambio de categoría ya va a aplicar los filtros.
- `ChannelsFragment.setupSearch()` delega la sincronización y el debounce. Las aplicaciones inmediatas cancelan una actualización pendiente y no procesan tareas una vez destruida la vista.
- La transición de visibilidad de búsqueda se centralizó en `setSearchVisible()`: mantiene sincronizados `isSearchVisible`, el contenedor, el campo, el teclado y el icono del encabezado.
- Al seleccionar una categoría con la búsqueda abierta se limpia la consulta sin enviar dos actualizaciones de lista; la aplicación se realiza una sola vez al terminar de cambiar la categoría.
- Al abrir la vista previa móvil se actualiza el icono del encabezado para no dejar el botón en estado «cerrar búsqueda» mientras el campo está oculto.

## Validación

- 6 pruebas focalizadas de `ChannelSearchQueryControllerTest` ejecutadas con un runner local compatible con las anotaciones y aserciones de JUnit: aprobadas.
- Compilación aislada de `ChannelSearchQueryController` y `ChannelSearchInputBinding` con `kotlinc`, usando stubs mínimos para las clases Android de texto: aprobada.
- Smoke test aislado del binding: borrado inmediato, cancelación de callbacks pendientes y eliminación del `TextWatcher`: aprobado.
- Revisión estática de las rutas de apertura/cierre desde el encabezado, cierre por Back, cambio de categoría y destrucción de la vista.
- 74 XML analizados: sin errores.
- Integridad del ZIP: verificada.

## Pendiente

No se pudo ejecutar `testDebugUnitTest`: el wrapper necesita descargar Gradle 8.13, pero el entorno falla al resolver `services.gradle.org` (`UnknownHostException`). Los stubs verifican el código del controlador y el binding a nivel aislado, no la compilación contra AndroidX/SDK reales ni la experiencia en dispositivos. La integración del fragmento queda pendiente de validación mediante el build real y pruebas manuales en móvil/TV.
