# AngulismoTV — Overlay común para reproductores WebView (Etapa 40)

## Objetivo

Reutilizar el overlay existente de AngulismoTV para controlar tanto ExoPlayer como los reproductores web detectables. No se incorpora un segundo panel ni se modifica el comportamiento de zapping asociado a la visibilidad del overlay.

## Cambios

- Los botones actuales de reproducir/pausar y retroceder/adelantar se enrutan al puente WebView también en móvil.
- La política de visibilidad muestra esos controles únicamente cuando el puente confirma un reproductor controlable.
- La línea de tiempo existente admite un estado externo en milisegundos y envía el seek al puente WebView. ExoPlayer y el reproductor inline conservan su flujo anterior.
- La detección mantiene el adaptador específico de Bitmovin y agrega un fallback para `HTMLVideoElement`, usado como medio de reproducción por implementaciones habituales de HLS.js, Shaka, Clappr, Video.js y otros.
- Se ocultan los controles duplicados de transporte detectables en esos reproductores; se conservan controles de subtítulos, calidad y configuración del proveedor que todavía no tienen un equivalente nativo.
- En móvil, un toque sobre un video detectado muestra el overlay de AngulismoTV o reinicia su temporizador si ya está visible. El evento táctil no se consume, de modo que los menús de calidad, subtítulos y configuración del proveedor siguen siendo utilizables. Si no se detecta un reproductor controlable, el toque llega a la página sin intervención.
- Se separan los cambios de estado de reproducción de las actualizaciones de tiempo para no reconstruir el orden de foco en cada `timeupdate`.

## Límites conocidos

El fallback HTML5 solo puede detectar un video que pertenezca al documento que recibe el script. La política de mismo origen del navegador impide inspeccionar directamente el contenido de iframes de otro dominio desde la página padre. Esos casos requieren una vía de integración expuesta por el proveedor o una estrategia específica de navegación/foco; no se consideran compatibles por el solo hecho de encontrar un iframe.

Los adaptadores específicos para opciones de audio, subtítulos, calidad, velocidad y menús de cada proveedor quedan para etapas posteriores. Esta etapa unifica transporte básico: play/pause, salto de 10 segundos y seek de la línea de tiempo cuando hay duración finita.

## Verificaciones realizadas

- Compilación aislada de `WebViewScripts.kt` con Kotlin: correcta.
- Sintaxis del JavaScript generado: correcta con Node.js.
- Prueba de comportamiento con un `HTMLVideoElement` simulado: detección, play, pause y seek correctos.
- Prueba de instalación de CSS para suprimir transportes duplicados: correcta.
- Cinco pruebas de contrato del puente (nombres de API, consultas, fallback HTML5 y reinyección): 5/5 correctas.
- `PlayerTimelineController.kt` y `PlayerControlStateController.kt`: compilación aislada con stubs Android/ExoPlayer: correcta.
- Política de visibilidad móvil y renderizado/búsqueda de la línea de tiempo externa: prueba de comportamiento correcta.
- Compilación completa y suite Android: no ejecutadas. El wrapper requiere descargar Gradle 8.13 desde `services.gradle.org`, host no accesible en este entorno.
