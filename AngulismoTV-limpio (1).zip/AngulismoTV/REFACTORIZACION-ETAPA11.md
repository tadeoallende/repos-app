# AngulismoTV — Etapa 11 (Espacial + Frutiger Aero)

## Objetivo

Unificar la identidad espacial azul noche/cian con detalles Frutiger Aero: superficies aqua tipo cristal, brillos suaves, degradados luminosos y bordes claros, sin perder contraste ni legibilidad.

## Cambios visuales

- La paleta mantiene el fondo espacial oscuro, pero incorpora matices oceánicos, aqua luminoso y un toque verde agua; el violeta espacial queda como acento secundario.
- Los paneles y botones ganan degradados tipo vidrio y reflejos suaves, con contornos aqua.
- El selector lateral, las categorías, los marcos de logos, los contadores, la búsqueda y las superficies emergentes comparten el mismo lenguaje visual.
- El panel de controles y las etiquetas del reproductor tienen un acabado aqua translúcido sobre una base oscura para que el vídeo siga siendo el protagonista.
- Se conservaron las fuentes, los textos, las dimensiones y el orden de navegación existentes.

## Restricciones preservadas

- No se modificó ningún archivo Kotlin.
- Las dos columnas del selector lateral permanecen contiguas y en el mismo orden.
- No se modificaron anchos, pesos, alturas, constraints ni reglas del `player_container`; la lógica que achica el vídeo al abrir el menú permanece idéntica.
- No se cambiaron IDs, listeners, navegación, reproducción ni comportamiento del mando.

## Validación

- Revisados los XML de recursos y manifest para comprobar que sean XML bien formados.
- Verificada la integridad del ZIP.
- Los XML de layout y los archivos Kotlin se conservaron respecto a Etapa 10/Etapa 11 previa; sólo se actualizaron colores, drawables de estilo, tema de control visual y esta documentación.
- La compilación y la apariencia final aún necesitan confirmación mediante GitHub Actions y prueba en TV/celular; no se afirma que se haya compilado o probado en dispositivo.
