# AngulismoTV — Etapa 7: identidad visual y menús coherentes

## Base

Parte de `AngulismoTV-TV-Player-Etapa6.zip`, la versión que el usuario confirmó que funciona bien en su televisor.

## Cambios aplicados

- La paleta compartida mantiene el azul noche, pasa el acento principal a cian y reserva el magenta para detalles secundarios.
- Los diálogos AppCompat y Material reciben overlays con texto claro, superficies oscuras y acentos de la app.
- Los diálogos del framework Android también reciben un overlay oscuro para evitar que algunas ventanas muestren el estilo predeterminado del sistema.
- `PopupMenu` de AppCompat, menús overflow y menús contextuales del framework reutilizan un fondo oscuro con esquinas redondeadas y borde discreto.
- Se armoniza la paleta del tema de Google Cast sin cambiar el flujo de conexión.
- La pantalla de errores pasa al tema de la app, en lugar del tema Material genérico del sistema.
- Se conserva el fondo negro de la actividad del reproductor para no lavar el video.
- No se agregan funciones nuevas ni se modifican intencionalmente reproducción, selección de fuentes o navegación.

## Validación realizada

- Los 58 archivos XML del proyecto se analizaron sintácticamente sin errores.
- Se comprobó la integridad del ZIP de salida.
- **La compilación Android no pudo verificarse en este entorno**: Gradle 8.13 no está disponible localmente y la descarga falla por `UnknownHostException` de `services.gradle.org`.
- No se puede dar por probada la apariencia final hasta instalarla y abrir los menús en un televisor/celular real.

## Pruebas recomendadas

1. Desde el reproductor, abrir «Seleccionar fuente» y comprobar fondo, texto, botones y navegación con el mando.
2. Desde inicio, pulsar Atrás y revisar el diálogo de salida.
3. Revisar los diálogos de actualización y Google Cast cuando estén disponibles.
4. Abrir cada menú emergente/contextual que use la app y comprobar que no aparece texto oscuro sobre fondo oscuro ni estilos claros predeterminados.
5. Confirmar que los canales, el foco y la reproducción se comportan como en la etapa 6.
