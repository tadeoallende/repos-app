# Compilar sin Android Studio

1. Creá un repositorio en GitHub (puede ser privado) y subí esta carpeta.
   `local.properties`, los `.apk`, los `.jks` y los tokens ya están excluidos por `.gitignore`.
2. Entrá a la pestaña **Actions**: el workflow **Build** corre solo en cada push (o con *Run workflow*).
3. Si compila bien, al final aparece el artefacto **AngulismoTV-debug** con el APK para instalar.
4. Si falla, abrí el paso en rojo, copiá el error (líneas que empiezan con `e:`) y pasámelo.

## Configuración (opcional)
La app lee estas URLs al compilar. Si no las definís, compila igual pero la lista de canales queda vacía.

- **En GitHub Actions:** en el repo, *Settings → Secrets and variables → Actions → New repository secret*,
  creá `CHANNELS_URL`, `EVENTS_URL`, `UPDATE_URL` y/o `WEB_BASE_URL`. El workflow ya las toma.
- **En tu PC:** copiá `local.properties.example` a `local.properties` y completalo.

Ojo: todo lo que se compila dentro del APK puede extraerse de él, así que no pongas ahí credenciales.


## Etapa 7
Esta versión unifica la paleta y el tratamiento visual de diálogos y menús. La compilación debe hacerse en un entorno Android con la distribución Gradle 8.13 disponible; en el entorno de edición no se pudo descargar por falta de conexión a `services.gradle.org`.


### Corrección de etapa 7 (error AAPT)
Si descargaste la primera etapa 7 y falló con `resource android:style/Widget.Material.ContextPopupMenu is private`, usa esta versión corregida. El estilo contextual ya no hereda del recurso interno de Android.
