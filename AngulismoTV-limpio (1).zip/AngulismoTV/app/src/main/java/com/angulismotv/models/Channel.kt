package com.angulismotv.models

import android.os.Parcelable
import kotlinx.parcelize.Parcelize

/** Tipos de reproducción soportados. */
object StreamType {
    const val HLS = "hls"
    const val DASH = "dash"
    const val MP4 = "mp4"
    const val IFRAME = "iframe"
    const val AUTO = "auto"
}

/** Canal listo para usar en la UI. Se construye desde [com.angulismotv.data.ChannelRepository]. */
@Parcelize
data class Channel(
    val name: String = "",
    val logo: String = "",
    val streamUrl: String? = null,
    val streamType: String? = StreamType.HLS,
    val options: List<StreamOption>? = null,
    val show: Boolean = true,
    val category: String = "todos",
    /** Número de canal (1, 2, 3…) según el orden de la lista; se asigna al cargarla. */
    val number: Int = 0
) : Parcelable

/** Fuente alternativa de un canal (se prueban en orden hasta que una funcione). */
@Parcelize
data class StreamOption(
    val name: String = "",
    val iframe: String = "",
    val streamType: String = StreamType.IFRAME
) : Parcelable
