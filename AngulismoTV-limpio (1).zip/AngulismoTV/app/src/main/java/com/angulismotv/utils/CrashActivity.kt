package com.angulismotv.utils

import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.graphics.Typeface
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

/**
 * Pantalla de error (solo debug). Se arma por código, sin layouts ni temas de la app,
 * para que funcione aunque el crash haya sido justamente por un recurso o un tema.
 */
class CrashActivity : Activity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val report = intent.getStringExtra(EXTRA_REPORT).orEmpty().ifEmpty { "Sin detalles del error." }
        val density = resources.displayMetrics.density
        fun dp(value: Int) = (value * density).toInt()

        val title = TextView(this).apply {
            text = "La app se cerró por un error"
            setTextColor(0xFFE8ECF8.toInt())
            textSize = 18f
            setTypeface(typeface, Typeface.BOLD)
        }
        val hint = TextView(this).apply {
            text = "Tocá «Copiar» y pegale el texto a Claude."
            setTextColor(0xFF9AA3C0.toInt())
            textSize = 13f
            setPadding(0, dp(4), 0, dp(12))
        }
        val body = TextView(this).apply {
            text = report
            typeface = Typeface.MONOSPACE
            textSize = 11f
            setTextColor(0xFFB8C0E0.toInt())
            setTextIsSelectable(true)
        }
        val scroll = ScrollView(this).apply { addView(body) }

        val copy = Button(this).apply {
            text = "Copiar"
            setOnClickListener {
                val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                clipboard.setPrimaryClip(ClipData.newPlainText("Error AngulismoTV", report))
                Toast.makeText(this@CrashActivity, "Copiado", Toast.LENGTH_SHORT).show()
            }
        }
        val share = Button(this).apply {
            text = "Compartir"
            setOnClickListener {
                val send = Intent(Intent.ACTION_SEND)
                    .setType("text/plain")
                    .putExtra(Intent.EXTRA_TEXT, report)
                startActivity(Intent.createChooser(send, "Compartir error"))
            }
        }
        val close = Button(this).apply {
            text = "Cerrar"
            setOnClickListener { finishAndRemoveTask() }
        }
        val buttons = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            val params = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            addView(copy, params)
            addView(share, params)
            addView(close, params)
        }

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(0xFF070B1C.toInt())
            setPadding(dp(16), dp(32), dp(16), dp(16))
            addView(title)
            addView(hint)
            addView(scroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
            addView(buttons)
        }
        setContentView(root)
    }

    companion object {
        const val EXTRA_REPORT = "report"
    }
}
