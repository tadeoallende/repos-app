package com.angulismotv.adapters

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.angulismotv.R

class CategoriesAdapter(
    private val onCategoryClick: (String) -> Unit
) : RecyclerView.Adapter<CategoriesAdapter.CategoryViewHolder>() {

    data class CategoryItem(val key: String, val name: String, val count: Int)

    private var categories = listOf<CategoryItem>()
    private var selectedCategory = "todos"

    fun submitList(newCategories: List<CategoryItem>, selected: String) {
        categories = newCategories
        selectedCategory = selected
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): CategoryViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_category_side, parent, false)
        view.isFocusable = true
        view.isFocusableInTouchMode = true
        return CategoryViewHolder(view)
    }

    override fun onBindViewHolder(holder: CategoryViewHolder, position: Int) {
        val category = categories[position]
        holder.bind(category, category.key == selectedCategory)
        holder.itemView.setOnClickListener {
            onCategoryClick(category.key)
        }
    }

    override fun getItemCount() = categories.size

    inner class CategoryViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val nameView: TextView = itemView.findViewById(R.id.category_name)
        private val countView: TextView = itemView.findViewById(R.id.category_count)

        fun bind(category: CategoryItem, isSelected: Boolean) {
            nameView.text = category.name
            countView.text = "${category.count}"
            itemView.setBackgroundResource(
                if (isSelected) R.drawable.side_channel_item_selected
                else R.drawable.side_channel_item_bg
            )
        }
    }
    // En CategoriesAdapter.kt
    fun clearSelection() {
        selectedCategory = ""
        notifyDataSetChanged()
    }

    fun setSelectedCategory(categoryKey: String) {
        selectedCategory = categoryKey
        notifyDataSetChanged()
    }
}