package com.angulismotv.adapters

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.animation.DecelerateInterpolator
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.RecyclerView
import java.util.Locale
import com.angulismotv.R

/** Categorías del panel lateral del reproductor. Conserva la selección sin recrear toda la lista. */
class CategoriesAdapter(
    private val onCategoryClick: (String) -> Unit
) : RecyclerView.Adapter<CategoriesAdapter.CategoryViewHolder>() {

    data class CategoryItem(val key: String, val name: String, val count: Int)

    private var categories: List<CategoryItem> = emptyList()
    private var selectedCategory = "todos"

    fun submitList(newCategories: List<CategoryItem>, selected: String) {
        val oldCategories = categories
        val oldSelected = selectedCategory
        val nextCategories = newCategories.toList()
        val nextSelected = selected

        val diff = DiffUtil.calculateDiff(object : DiffUtil.Callback() {
            override fun getOldListSize() = oldCategories.size
            override fun getNewListSize() = nextCategories.size

            override fun areItemsTheSame(oldPosition: Int, newPosition: Int): Boolean =
                oldCategories[oldPosition].key == nextCategories[newPosition].key

            override fun areContentsTheSame(oldPosition: Int, newPosition: Int): Boolean {
                val oldItem = oldCategories[oldPosition]
                val newItem = nextCategories[newPosition]
                val oldWasSelected = oldItem.key == oldSelected
                val newIsSelected = newItem.key == nextSelected
                return oldItem == newItem && oldWasSelected == newIsSelected
            }
        })

        categories = nextCategories
        selectedCategory = nextSelected
        diff.dispatchUpdatesTo(this)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): CategoryViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_category_side, parent, false)
        view.isFocusable = true
        view.isFocusableInTouchMode = true
        view.isClickable = true
        // Movimiento corto y sutil: ayuda a identificar el foco con mando sin alterar la selección.
        view.setOnFocusChangeListener { focusedView, hasFocus ->
            focusedView.animate().cancel()
            val targetScale = if (hasFocus) 1.018f else 1.0f
            val targetElevation = if (hasFocus) 5f * focusedView.resources.displayMetrics.density else 0f
            focusedView.animate()
                .scaleX(targetScale)
                .scaleY(targetScale)
                .translationZ(targetElevation)
                .setDuration(120L)
                .setInterpolator(DecelerateInterpolator())
                .start()
        }
        return CategoryViewHolder(view)
    }

    override fun onBindViewHolder(holder: CategoryViewHolder, position: Int) {
        val category = categories[position]
        holder.bind(category, category.key == selectedCategory)
        holder.itemView.setOnClickListener { onCategoryClick(category.key) }
    }

    override fun getItemCount() = categories.size

    fun getPositionForKey(categoryKey: String): Int =
        categories.indexOfFirst { it.key == categoryKey }

    inner class CategoryViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val iconView: ImageView = itemView.findViewById(R.id.category_icon)
        private val nameView: TextView = itemView.findViewById(R.id.category_name)
        private val countView: TextView = itemView.findViewById(R.id.category_count)

        fun bind(category: CategoryItem, isSelected: Boolean) {
            itemView.animate().cancel()
            itemView.scaleX = 1f
            itemView.scaleY = 1f
            itemView.translationZ = 0f
            itemView.alpha = 1f
            nameView.text = category.name
            iconView.setImageResource(iconFor(category.key))
            countView.text = category.count.toString()
            itemView.setBackgroundResource(
                if (isSelected) R.drawable.side_channel_item_selected
                else R.drawable.side_channel_item_bg
            )
            itemView.contentDescription = "${category.name}, ${category.count} canales"
        }
    }

    private fun iconFor(categoryKey: String): Int {
        val key = categoryKey.trim().lowercase(Locale.ROOT)
        return when {
            key == "todos" || key == "todo" || key == "all" -> R.drawable.ic_category_all
            key.contains("deport") || key.contains("sport") -> R.drawable.ic_category_sports
            key.contains("document") -> R.drawable.ic_category_documentary
            key.contains("educ") -> R.drawable.ic_category_education
            key.contains("estilo") || key.contains("vida") || key.contains("lifestyle") -> R.drawable.ic_category_lifestyle
            key.contains("evento") || key.contains("event") -> R.drawable.ic_category_events
            key.contains("infantil") || key.contains("kids") || key.contains("niño") || key.contains("nino") -> R.drawable.ic_category_kids
            key.contains("música") || key.contains("musica") || key.contains("music") -> R.drawable.ic_category_music
            else -> R.drawable.ic_category_other
        }
    }

    fun clearSelection() = submitList(categories, "")

    fun setSelectedCategory(categoryKey: String) = submitList(categories, categoryKey)
}
