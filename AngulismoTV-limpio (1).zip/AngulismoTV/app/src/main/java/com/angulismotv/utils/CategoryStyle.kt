package com.angulismotv.utils

/**
 * Cada categoría tiene su propio color dentro de la paleta Medianoche: el mosaico de sus canales
 * y el título de su sección. Las categorías desconocidas reciben un color estable según su nombre.
 */
object CategoryStyle {

    /** @param tile color de fondo del mosaico; @param accent color del título de la sección. */
    data class Style(val tile: Int, val accent: Int)

    private val known = mapOf(
        "noticias" to Style(0xFF2B3580.toInt(), 0xFFA5B4FF.toInt()),
        "internacionales" to Style(0xFF1F5C7A.toInt(), 0xFF7FD6E8.toInt()),
        "argentina" to Style(0xFF2E4A7D.toInt(), 0xFF8FB8FF.toInt()),
        "deportes" to Style(0xFF1F6B55.toInt(), 0xFF7FE0B8.toInt()),
        "peliculas" to Style(0xFF6B2E5E.toInt(), 0xFFF0A6E0.toInt()),
        "infantiles" to Style(0xFF8A5A1F.toInt(), 0xFFFFC978.toInt()),
        "musicales" to Style(0xFF7A2E48.toInt(), 0xFFFF9EBB.toInt()),
        "documentales" to Style(0xFF3F5F2E.toInt(), 0xFFB5E08F.toInt()),
        "educativos" to Style(0xFF2E6B6B.toInt(), 0xFF8FE0D8.toInt()),
        "generales" to Style(0xFF4A3A8C.toInt(), 0xFFC3AAFF.toInt()),
        "todos" to Style(0xFF2B3580.toInt(), 0xFFA5B4FF.toInt())
    )

    private val fallback = listOf(
        Style(0xFF37306E.toInt(), 0xFFB9A8F5.toInt()),
        Style(0xFF2E4A7D.toInt(), 0xFF8FB8FF.toInt()),
        Style(0xFF1F5C7A.toInt(), 0xFF7FD6E8.toInt()),
        Style(0xFF4A3A8C.toInt(), 0xFFC3AAFF.toInt())
    )

    private val displayNames = mapOf(
        "todos" to "Todos",
        "peliculas" to "Películas",
        "estilo-vida" to "Estilo de vida"
    )

    fun of(category: String): Style {
        val key = category.trim().lowercase()
        return known[key] ?: fallback[(key.hashCode() and Int.MAX_VALUE) % fallback.size]
    }

    /** "estilo-vida" → "Estilo de vida", "noticias" → "Noticias". */
    fun displayName(category: String): String {
        val key = category.trim().lowercase()
        displayNames[key]?.let { return it }
        return key.replace('-', ' ').replace('_', ' ').replaceFirstChar { it.uppercase() }.ifEmpty { "Canales" }
    }
}
