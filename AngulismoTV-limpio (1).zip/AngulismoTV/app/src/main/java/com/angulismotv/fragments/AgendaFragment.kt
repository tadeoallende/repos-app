package com.angulismotv.fragments

import android.content.pm.ActivityInfo
import android.content.res.Configuration
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import android.widget.ProgressBar
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import com.angulismotv.BuildConfig
import com.angulismotv.R

class AgendaFragment : Fragment() {

    private lateinit var webView: WebView
    private lateinit var progressBar: ProgressBar
    private lateinit var errorText: TextView
    private lateinit var customViewContainer: FrameLayout
    private var customView: View? = null
    private var originalOrientation = 0
    private var isInFullscreen = false
    private val mainHandler = Handler(Looper.getMainLooper())
    private val allowedDomains = listOf("angulismotv-dnh.pages.dev", "angulismotv.workers.dev")

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        return inflater.inflate(R.layout.fragment_agenda, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        webView = view.findViewById(R.id.web_view)
        progressBar = view.findViewById(R.id.progress_bar)
        errorText = view.findViewById(R.id.error_text)
        customViewContainer = view.findViewById(R.id.custom_view_container)

        setupWebView()
        loadAgenda()
    }

    private fun setupWebView() {
        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            loadWithOverviewMode = true
            useWideViewPort = true
            setSupportZoom(true)
            builtInZoomControls = true
            displayZoomControls = false
            mediaPlaybackRequiresUserGesture = false
            allowFileAccess = true
            allowContentAccess = true
            cacheMode = WebSettings.LOAD_DEFAULT

            javaScriptCanOpenWindowsAutomatically = false
            setSupportMultipleWindows(false)
        }

        webView.webViewClient = object : WebViewClient() {

            override fun onPageFinished(view: WebView?, url: String?) {
                val blockPopupsScript = """
                    (function() {
                        window.open = function() { 
                            console.log('Popup bloqueado');
                            return null; 
                        };
                        window.alert = function() { return null; };
                        window.confirm = function() { return false; };
                        window.prompt = function() { return null; };
                        
                        var originalAppendChild = document.body.appendChild;
                        document.body.appendChild = function(element) {
                            if (element.tagName === 'IFRAME') {
                                var src = element.src || '';
                                if (src.includes('ads') || src.includes('popup') || 
                                    src.includes('adservice') || src.includes('doubleclick') ||
                                    src.includes('googlesyndication')) {
                                    console.log('iframe publicitario bloqueado');
                                    return null;
                                }
                            }
                            return originalAppendChild.call(this, element);
                        };
                        
                        setTimeout(function() {
                            var iframes = document.querySelectorAll('iframe');
                            for(var i = 0; i < iframes.length; i++) {
                                var src = iframes[i].src;
                                if (src.includes('ads') || src.includes('popup') || 
                                    src.includes('adservice') || src.includes('doubleclick')) {
                                    iframes[i].remove();
                                }
                            }
                        }, 2000);
                    })();
                """.trimIndent()
                view?.loadUrl("javascript:$blockPopupsScript")

                val ensureButtonScript = """
                    (function() {
                        var btn = document.getElementById('fullscreen');
                        if (btn && !btn._patched) {
                            btn._patched = true;
                            btn.addEventListener('click', function(e) {
                                e.preventDefault();
                                e.stopPropagation();
                                if (window.AgendaFullscreen) {
                                    if (window.AgendaFullscreen.isFullscreen && window.AgendaFullscreen.isFullscreen()) {
                                        window.AgendaFullscreen.exit();
                                    } else {
                                        window.AgendaFullscreen.enter();
                                    }
                                }
                                return false;
                            });
                        }
                    })();
                """.trimIndent()
                view?.loadUrl("javascript:$ensureButtonScript")
                progressBar.visibility = View.GONE
            }

            override fun onReceivedError(view: WebView?, errorCode: Int, description: String?, failingUrl: String?) {
                errorText.text = "Error al cargar la agenda: $description"
                errorText.visibility = View.VISIBLE
                progressBar.visibility = View.GONE
            }

            override fun shouldOverrideUrlLoading(view: WebView?, url: String?): Boolean {
                if (url == null) return true

                val isAllowed = allowedDomains.any { url.contains(it) }

                if (!isAllowed) {
                    android.util.Log.d("AgendaFragment", "Popup bloqueado: $url")
                    return true
                }

                view?.loadUrl(url)
                return true
            }

            fun onCreateWindow(view: WebView?, isDialog: Boolean, isUserGesture: Boolean, resultMsg: android.os.Message?): Boolean {
                android.util.Log.d("AgendaFragment", "Nueva ventana bloqueada")
                return true
            }
        }

        webView.addJavascriptInterface(AgendaFullscreenInterface(), "AgendaFullscreen")

        webView.webChromeClient = object : WebChromeClient() {
            override fun onShowCustomView(view: View?, callback: CustomViewCallback?) {
                if (isInFullscreen) {
                    callback?.onCustomViewHidden()
                    return
                }

                isInFullscreen = true
                customView = view
                originalOrientation = activity?.requestedOrientation ?: 0

                mainHandler.post {
                    enterFullscreen()
                }
            }

            override fun onHideCustomView() {
                if (!isInFullscreen) return

                mainHandler.post {
                    exitFullscreen()
                }
            }

            override fun onProgressChanged(view: WebView?, newProgress: Int) {
                if (newProgress < 100) {
                    progressBar.visibility = View.VISIBLE
                    errorText.visibility = View.GONE
                } else {
                    progressBar.visibility = View.GONE
                }
            }

            override fun onJsAlert(view: WebView?, url: String?, message: String?, result: android.webkit.JsResult?): Boolean {
                result?.confirm()
                return true
            }

            override fun onJsConfirm(view: WebView?, url: String?, message: String?, result: android.webkit.JsResult?): Boolean {
                result?.confirm()
                return true
            }
        }
    }

    private fun enterFullscreen() {
        isInFullscreen = true

        // Ocultar UI de la app
        activity?.window?.addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN)
        (activity as? AppCompatActivity)?.supportActionBar?.hide()

        // Ocultar bottom navigation (móvil)
        activity?.findViewById<View>(R.id.bottom_navigation)?.visibility = View.GONE

        // Ocultar menú lateral (TV)
        //activity?.findViewById<View>(R.id.side_menu)?.visibility = View.GONE

        // Ocultar header (logo)
        activity?.findViewById<View>(R.id.header_container)?.visibility = View.GONE
        activity?.findViewById<View>(R.id.logo_image)?.visibility = View.GONE

        // Cambiar orientación
        activity?.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE

        // Mostrar contenedor personalizado
        customViewContainer.visibility = View.VISIBLE
        customView?.let { customViewContainer.addView(it) }
        webView.visibility = View.GONE
    }

    private fun exitFullscreen() {
        isInFullscreen = false

        // Restaurar UI de la app
        activity?.window?.clearFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN)
        (activity as? AppCompatActivity)?.supportActionBar?.show()

        // Restaurar bottom navigation (móvil)
        activity?.findViewById<View>(R.id.bottom_navigation)?.visibility = View.VISIBLE

        // Restaurar menú lateral (TV)
        activity?.findViewById<View>(R.id.side_menu)?.visibility = View.VISIBLE

        // Restaurar header (logo)
        activity?.findViewById<View>(R.id.header_container)?.visibility = View.VISIBLE
        activity?.findViewById<View>(R.id.logo_image)?.visibility = View.VISIBLE

        // Restaurar orientación
        activity?.requestedOrientation = originalOrientation

        // Restaurar WebView
        customViewContainer.removeAllViews()
        customViewContainer.visibility = View.GONE
        webView.visibility = View.VISIBLE

        customView = null
    }

    inner class AgendaFullscreenInterface {
        @android.webkit.JavascriptInterface
        fun enter() {
            activity?.runOnUiThread {
                if (!isInFullscreen) {
                    enterFullscreen()
                }
            }
        }

        @android.webkit.JavascriptInterface
        fun exit() {
            activity?.runOnUiThread {
                if (isInFullscreen) {
                    exitFullscreen()
                }
            }
        }

        @android.webkit.JavascriptInterface
        fun isFullscreen(): Boolean {
            return isInFullscreen
        }
    }

    private fun loadAgenda() {
        progressBar.visibility = View.VISIBLE
        errorText.visibility = View.GONE
        webView.loadUrl(BuildConfig.WEB_BASE_URL + "/app/agenda")
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        if (isInFullscreen) {
            activity?.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        if (isInFullscreen) {
            activity?.requestedOrientation = originalOrientation
            activity?.window?.clearFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN)
            (activity as? AppCompatActivity)?.supportActionBar?.show()
            activity?.findViewById<View>(R.id.bottom_navigation)?.visibility = View.VISIBLE
            activity?.findViewById<View>(R.id.side_menu)?.visibility = View.VISIBLE
            activity?.findViewById<View>(R.id.header_container)?.visibility = View.VISIBLE
            activity?.findViewById<View>(R.id.logo_image)?.visibility = View.VISIBLE
        }
        webView.destroy()
    }
}