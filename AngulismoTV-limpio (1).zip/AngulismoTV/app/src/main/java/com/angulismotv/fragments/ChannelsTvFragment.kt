package com.angulismotv.fragments

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.Editable
import android.text.TextWatcher
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.core.content.ContextCompat
import androidx.core.view.isVisible
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.angulismotv.BackHandler
import com.angulismotv.MainActivity
import com.angulismotv.R
import com.angulismotv.UnifiedPlayerActivity
import com.angulismotv.adapters.ChannelSectionsAdapter
import com.angulismotv.data.ChannelSections
import com.angulismotv.data.LoadResult
import com.angulismotv.models.Channel

/**
 * Pantalla de canales para TV: títulos por categoría, tarjetas grandes y navegación pensada para
 * el control remoto. Va junto al menú lateral (que está en la activity).
 */
class ChannelsTvFragment : Fragment(), ChannelsScreen, RailContent, BackHandler {

    private lateinit var recycler: RecyclerView
    private lateinit var progressBar: ProgressBar
    private lateinit var stateContainer: LinearLayout
    private lateinit var errorText: TextView
    private lateinit var retryButton: TextView
    private lateinit var headerCount: TextView
    private lateinit var searchBar: View
    private lateinit var searchInput: EditText

    private lateinit var adapter: ChannelSectionsAdapter
    private lateinit var gridManager: GridLayoutManager

    private var allChannels = listOf<Channel>()
    private var query = ""
    private var lastFocused: Channel? = null
    private var initialFocusDone = false

    private val handler = Handler(Looper.getMainLooper())
    private var searchRunnable: Runnable? = null

    private fun main(): MainActivity? = activity as? MainActivity

    private fun isViewReady() = view != null && ::adapter.isInitialized

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View =
        inflater.inflate(R.layout.fragment_channels_tv, container, false)

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        recycler = view.findViewById(R.id.channels_recycler)
        progressBar = view.findViewById(R.id.progress_bar)
        stateContainer = view.findViewById(R.id.state_container)
        errorText = view.findViewById(R.id.error_text)
        retryButton = view.findViewById(R.id.retry_button)
        headerCount = view.findViewById(R.id.header_count)
        searchBar = view.findViewById(R.id.search_bar)
        searchInput = view.findViewById(R.id.search_input)

        setupRecycler()
        setupSearch()
        retryButton.setOnClickListener { main()?.reloadChannels() }
        renderInitialState()
    }

    override fun onDestroyView() {
        handler.removeCallbacksAndMessages(null)
        super.onDestroyView()
    }

    // ---------- Grilla ----------

    private fun setupRecycler() {
        adapter = ChannelSectionsAdapter(
            isTV = true,
            onClick = ::openChannel,
            onFocused = { lastFocused = it },
            onLeftEdge = { main()?.focusRail() }
        )

        val manager = GridLayoutManager(requireContext(), calculateSpanCount())
        manager.spanSizeLookup = object : GridLayoutManager.SpanSizeLookup() {
            override fun getSpanSize(position: Int): Int = if (adapter.isHeader(position)) manager.spanCount else 1
        }
        gridManager = manager

        recycler.layoutManager = manager
        recycler.adapter = adapter
        recycler.itemAnimator = null // sin animaciones de ítems: evita que el foco "salte" al actualizar
    }

    /** Tarjetas de al menos CARD_MIN_WIDTH_DP: más columnas cuanto más ancha es la pantalla. */
    private fun calculateSpanCount(): Int {
        val railDp = 64
        val paddingsDp = 24 + 48
        val availableDp = resources.configuration.screenWidthDp - railDp - paddingsDp
        return (availableDp / CARD_MIN_WIDTH_DP).coerceAtLeast(3)
    }

    // ---------- Estados de carga ----------

    private fun renderInitialState() {
        val activity = main()
        val result = activity?.getLoadResult()
        if (activity == null || activity.isLoadingChannels() || result == null) {
            progressBar.isVisible = true
        } else {
            applyResult(result)
        }
    }

    override fun onLoadStarted() {
        if (!isViewReady()) return
        hideState()
        progressBar.isVisible = true
    }

    override fun showResult(result: LoadResult) {
        if (!isViewReady()) return
        applyResult(result)
        if (result.fromCache) {
            Toast.makeText(requireContext(), "No se pudo actualizar la lista: mostrando la última guardada", Toast.LENGTH_LONG).show()
        }
    }

    private fun applyResult(result: LoadResult) {
        allChannels = result.channels
        progressBar.isVisible = false
        render()

        if (allChannels.isEmpty()) {
            when {
                result.notConfigured ->
                    showState("Todavía no hay una lista de canales configurada.", isError = false, showRetry = false)
                result.failed ->
                    showState("No se pudo cargar la lista de canales.\nRevisá tu conexión e intentá de nuevo.", isError = true, showRetry = true)
                else ->
                    showState("La lista de canales está vacía.", isError = false, showRetry = true)
            }
        } else if (!initialFocusDone) {
            focusFirstCardIfIdle()
        }
    }

    private fun render() {
        val visible = if (query.isBlank()) {
            allChannels
        } else {
            allChannels.filter { it.name.contains(query, ignoreCase = true) }
        }

        adapter.submit(ChannelSections.group(visible), gridManager.spanCount)

        headerCount.text = when {
            allChannels.isEmpty() -> ""
            query.isBlank() -> "${allChannels.size} en vivo"
            else -> "${visible.size} resultados"
        }

        if (allChannels.isNotEmpty()) {
            if (visible.isEmpty()) showState("No se encontraron canales", isError = false, showRetry = false) else hideState()
        }
    }

    private fun showState(message: String, isError: Boolean, showRetry: Boolean) {
        errorText.text = message
        errorText.setTextColor(
            ContextCompat.getColor(requireContext(), if (isError) R.color.error else R.color.text_secondary)
        )
        retryButton.isVisible = showRetry
        stateContainer.isVisible = true
        if (showRetry && main()?.userHasNavigated() != true) retryButton.requestFocus()
    }

    private fun hideState() {
        stateContainer.isVisible = false
    }

    // ---------- Foco ----------

    /** Al abrir la app, el foco empieza en el contenido (no en el menú, que se desplegaría solo). */
    private fun focusFirstCardIfIdle() {
        if (main()?.userHasNavigated() == true || !isVisible) return
        initialFocusDone = true
        recycler.post { if (isViewReady()) requestContentFocus() }
    }

    override fun requestContentFocus(): Boolean {
        if (!isViewReady()) return false
        val remembered = lastFocused?.let { adapter.positionOf(it) } ?: -1
        val target = if (remembered >= 0) remembered else adapter.firstCardPosition()
        if (target < 0) return false

        recycler.scrollToPosition(target)
        recycler.post { recycler.findViewHolderForAdapterPosition(target)?.itemView?.requestFocus() }
        return true
    }

    // Al volver del reproductor el foco regresa al canal que se estaba mirando
    override fun onResume() {
        super.onResume()
        if (!isViewReady() || isHidden) return
        if (!initialFocusDone && allChannels.isNotEmpty()) {
            focusFirstCardIfIdle()
        } else if (activity?.currentFocus == null) {
            requestContentFocus()
        }
    }

    // ---------- Búsqueda ----------

    private fun setupSearch() {
        searchInput.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                searchRunnable?.let { handler.removeCallbacks(it) }
                searchRunnable = Runnable {
                    query = s?.toString()?.trim().orEmpty()
                    render()
                }
                handler.postDelayed(searchRunnable!!, SEARCH_DELAY_MS)
            }
            override fun afterTextChanged(s: Editable?) {}
        })

        searchInput.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_SEARCH || actionId == EditorInfo.IME_ACTION_DONE) {
                hideKeyboard()
                requestContentFocus()
                true
            } else {
                false
            }
        }
    }

    /** Lo llama el menú lateral (opción Buscar). */
    fun openSearch() {
        if (!isViewReady()) return
        searchBar.isVisible = true
        searchInput.requestFocus()
        val imm = requireContext().getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
        imm.showSoftInput(searchInput, InputMethodManager.SHOW_IMPLICIT)
    }

    private fun closeSearch() {
        searchRunnable?.let { handler.removeCallbacks(it) }
        searchInput.setText("")
        query = ""
        searchBar.isVisible = false
        hideKeyboard()
        render()
        requestContentFocus()
    }

    private fun hideKeyboard() {
        val imm = requireContext().getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
        imm.hideSoftInputFromWindow(searchInput.windowToken, 0)
    }

    /** Atrás con la búsqueda abierta la cierra (y devuelve la lista completa). */
    override fun handleBack(): Boolean {
        if (isViewReady() && searchBar.isVisible) {
            closeSearch()
            return true
        }
        return false
    }

    // ---------- Reproductor ----------

    private fun openChannel(channel: Channel) {
        if (channel.streamUrl.isNullOrEmpty() && channel.options.isNullOrEmpty()) {
            Toast.makeText(requireContext(), "Este canal no tiene fuentes disponibles", Toast.LENGTH_SHORT).show()
            return
        }

        val intent = Intent(requireContext(), UnifiedPlayerActivity::class.java).apply {
            putParcelableArrayListExtra("channels", ArrayList(allChannels))
            putExtra("channel_index", allChannels.indexOfFirst { it.name == channel.name && it.logo == channel.logo })
            putExtra("channel_name", channel.name)
            putExtra("channel_logo", channel.logo)
            putExtra("stream_url", channel.streamUrl)
            putExtra("stream_type", channel.streamType ?: "hls")
        }
        startActivity(intent)
    }

    private companion object {
        const val CARD_MIN_WIDTH_DP = 156
        const val SEARCH_DELAY_MS = 250L
    }
}
