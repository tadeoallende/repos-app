package com.angulismotv.adapters

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.RecyclerView
import com.angulismotv.R
import com.angulismotv.models.Channel
import com.angulismotv.utils.loadChannelLogo

/** Lista de canales del panel lateral del reproductor. */
class SideChannelsAdapter(
    private val onItemClick: (Channel, Int) -> Unit
) : RecyclerView.Adapter<SideChannelsAdapter.ViewHolder>() {

    private var channels: List<Channel> = emptyList()
    private var selectedIndex: Int = -1

    fun submitList(newChannels: List<Channel>, selectedIdx: Int) {
        val old = channels
        val diff = DiffUtil.calculateDiff(object : DiffUtil.Callback() {
            override fun getOldListSize() = old.size
            override fun getNewListSize() = newChannels.size
            override fun areItemsTheSame(o: Int, n: Int) = old[o].name == newChannels[n].name
            override fun areContentsTheSame(o: Int, n: Int) = old[o] == newChannels[n]
        })
        channels = newChannels
        selectedIndex = selectedIdx
        diff.dispatchUpdatesTo(this)
    }

    override fun getItemCount() = channels.size

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_channel_side, parent, false)
        view.isFocusable = true
        view.isFocusableInTouchMode = true
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val channel = channels[position]
        holder.bind(channel, position == selectedIndex)
        holder.itemView.setOnClickListener { onItemClick(channel, position) }
    }

    class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val logo: ImageView = itemView.findViewById(R.id.channel_logo)
        private val name: TextView = itemView.findViewById(R.id.channel_name)
        private val optionsIndicator: ImageView = itemView.findViewById(R.id.options_indicator)

        fun bind(channel: Channel, isSelected: Boolean) {
            name.text = channel.name
            optionsIndicator.visibility = if (!channel.options.isNullOrEmpty()) View.VISIBLE else View.GONE
            itemView.setBackgroundResource(
                if (isSelected) R.drawable.side_channel_item_selected else R.drawable.side_channel_item_bg
            )
            logo.loadChannelLogo(channel.name, channel.logo, cornerRadiusPx = 12)
        }
    }
}
