package com.angulismotv.utils

/** Hasta dos letras para el logo automático: "DW Español" → "DE", "Chaco TV" → "CT", "France 24 English" → "FE". */
fun channelInitials(name: String): String {
    val words = name.split(Regex("[^\\p{L}\\p{N}]+")).filter { it.isNotEmpty() }
    val wordsWithLetters = words.filter { it.first().isLetter() }.ifEmpty { words }
    return when {
        wordsWithLetters.isEmpty() -> "?"
        wordsWithLetters.size == 1 -> wordsWithLetters[0].take(2)
        else -> "${wordsWithLetters[0].first()}${wordsWithLetters[1].first()}"
    }.uppercase()
}
