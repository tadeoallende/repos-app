package com.angulismotv.data

import com.angulismotv.models.Channel
import com.angulismotv.models.StreamOption
import com.angulismotv.models.StreamType
import com.google.gson.Gson
import com.google.gson.JsonParseException
import com.google.gson.annotations.SerializedName

/**
 * Convierte el JSON de canales en modelos de la app. Es lógica pura (sin red ni Android) para
 * poder probarla con tests unitarios.
 *
 * Formato: { "channels": [ { name, logo, streamUrl, streamType, show, category,
 *                            options: [ { name, iframe, streamType } ] } ] }
 */
object ChannelParser {

    private val gson = Gson()

    // DTOs: todo nullable porque Gson ignora los valores por defecto de Kotlin.
    private data class Response(val channels: List<ChannelDto?>?)

    private data class ChannelDto(
        val name: String?,
        val logo: String?,
        val streamUrl: String?,
        val streamType: String?,
        val show: Boolean?,
        val category: String?,
        val options: List<OptionDto?>?
    )

    private data class OptionDto(
        val name: String?,
        @SerializedName("iframe") val url: String?,
        val streamType: String?
    )

    /**
     * @throws IllegalArgumentException si el texto está vacío, no es JSON válido o no trae "channels".
     */
    fun parse(json: String, defaultCategory: String): List<Channel> {
        val response = try {
            gson.fromJson(json, Response::class.java)
        } catch (e: JsonParseException) {
            throw IllegalArgumentException("JSON inválido: ${e.message}", e)
        }
        val entries = response?.channels
            ?: throw IllegalArgumentException("El JSON está vacío o no tiene la lista \"channels\"")
        return entries.mapNotNull { it?.toChannel(defaultCategory) }
    }

    private fun ChannelDto.toChannel(defaultCategory: String): Channel? {
        if (show == false) return null

        val validOptions = options.orEmpty()
            .filterNotNull()
            .filter { !it.url.isNullOrBlank() }
            .map { StreamOption(it.name ?: "Opción", it.url!!, it.streamType ?: StreamType.IFRAME) }

        if (streamUrl.isNullOrBlank() && validOptions.isEmpty()) return null

        return Channel(
            name = name ?: "Sin nombre",
            logo = logo.orEmpty(),
            streamUrl = streamUrl?.takeIf { it.isNotBlank() },
            streamType = streamType ?: StreamType.HLS,
            options = validOptions.ifEmpty { null },
            category = category ?: defaultCategory
        )
    }
}
