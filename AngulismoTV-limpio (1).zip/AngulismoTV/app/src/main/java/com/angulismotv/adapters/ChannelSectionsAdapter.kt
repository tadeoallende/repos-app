package com.angulismotv.adapters

import android.graphics.drawable.GradientDrawable
import android.util.TypedValue
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.TextView
import androidx.core.view.isVisible
import androidx.recyclerview.widget.RecyclerView
import com.angulismotv.R
import com.angulismotv.data.ChannelSections
import com.angulismotv.models.Channel
import com.angulismotv.utils.CategoryStyle
import com.angulismotv.utils.loadChannelLogo
import java.util.Locale

/**
 * Canales agrupados por categoría en una sola grilla: cada sección tiene un título que ocupa toda
 * la fila, seguido de sus tarjetas. Una sola lista (en vez de filas anidadas) hace que el foco con
 * el control remoto sea predecible: arriba/abajo/izquierda/derecha siguen la grilla.
 */
class ChannelSectionsAdapter(
    private val isTV: Boolean,
    private val onClick: (Channel) -> Unit,
    private val onFocused: (Channel) -> Unit,
    private val onLeftEdge: () -> Unit
) : RecyclerView.Adapter<RecyclerView.ViewHolder>() {

    private sealed interface Row {
        data class Header(val title: String, val count: Int, val accent: Int) : Row
        data class Card(val channel: Channel, val column: Int, val rowEnd: Boolean, val tile: Int) : Row
    }

    private var rows: List<Row> = emptyList()

    fun submit(sections: List<ChannelSections.Section>, spanCount: Int) {
        val span = spanCount.coerceAtLeast(1)
        rows = sections.flatMap { section ->
            val style = CategoryStyle.of(section.category)
            val header: Row = Row.Header(CategoryStyle.displayName(section.category), section.channels.size, style.accent)
            val cards: List<Row> = section.channels.mapIndexed { index, channel ->
                val column = index % span
                val isLast = index == section.channels.lastIndex
                Row.Card(channel, column = column, rowEnd = column == span - 1 || isLast, tile = style.tile)
            }
            listOf(header) + cards
        }
        notifyDataSetChanged()
    }

    fun isHeader(position: Int): Boolean = rows.getOrNull(position) is Row.Header

    fun positionOf(channel: Channel): Int = rows.indexOfFirst { it is Row.Card && it.channel == channel }

    fun firstCardPosition(): Int = rows.indexOfFirst { it is Row.Card }

    override fun getItemCount(): Int = rows.size

    override fun getItemViewType(position: Int): Int =
        if (rows[position] is Row.Header) TYPE_HEADER else TYPE_CARD

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        val inflater = LayoutInflater.from(parent.context)
        return if (viewType == TYPE_HEADER) {
            HeaderHolder(inflater.inflate(R.layout.item_section_header, parent, false))
        } else {
            CardHolder(inflater.inflate(R.layout.item_channel_card, parent, false))
        }
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        when (val row = rows[position]) {
            is Row.Header -> (holder as HeaderHolder).bind(row)
            is Row.Card -> (holder as CardHolder).bind(row)
        }
    }

    override fun onViewRecycled(holder: RecyclerView.ViewHolder) {
        if (holder is CardHolder) holder.reset()
    }

    private class HeaderHolder(view: View) : RecyclerView.ViewHolder(view) {
        private val title: TextView = view.findViewById(R.id.section_title)
        private val count: TextView = view.findViewById(R.id.section_count)

        fun bind(row: Row.Header) {
            title.text = row.title
            title.setTextColor(row.accent)
            count.text = row.count.toString()
        }
    }

    private inner class CardHolder(view: View) : RecyclerView.ViewHolder(view) {
        private val tile: FrameLayout = view.findViewById(R.id.card_tile)
        private val logo: ImageView = view.findViewById(R.id.card_logo)
        private val number: TextView = view.findViewById(R.id.card_number)
        private val options: ImageView = view.findViewById(R.id.card_options)
        private val name: TextView = view.findViewById(R.id.card_name)

        private var channel: Channel? = null
        private var column = 0
        private var rowEnd = false

        init {
            if (isTV) {
                // TV: se mira desde lejos, así que números y nombres más grandes
                number.setTextSize(TypedValue.COMPLEX_UNIT_SP, 24f)
                name.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15f)
            }

            view.setOnClickListener { channel?.let { onClick(it) } }

            view.setOnFocusChangeListener { v, hasFocus ->
                val scale = if (hasFocus) FOCUS_SCALE else 1f
                v.animate()
                    .scaleX(scale)
                    .scaleY(scale)
                    .translationZ(if (hasFocus) FOCUS_Z else 0f)
                    .setDuration(FOCUS_ANIM_MS)
                    .start()
                if (hasFocus) channel?.let { onFocused(it) }
            }

            view.setOnKeyListener { _, keyCode, event ->
                if (event.action != KeyEvent.ACTION_DOWN) return@setOnKeyListener false
                when {
                    // Izquierda en la primera columna: se llega al borde de la grilla y se pasa al menú lateral
                    keyCode == KeyEvent.KEYCODE_DPAD_LEFT && column == 0 -> {
                        onLeftEdge()
                        true
                    }
                    // Derecha en la última tarjeta de la fila: no saltar a la fila siguiente
                    keyCode == KeyEvent.KEYCODE_DPAD_RIGHT && rowEnd -> true
                    else -> false
                }
            }
        }

        fun bind(row: Row.Card) {
            val item = row.channel
            channel = item
            column = row.column
            rowEnd = row.rowEnd

            tile.background = GradientDrawable().apply {
                setColor(row.tile)
                cornerRadius = TILE_CORNER_DP * itemView.resources.displayMetrics.density
            }

            number.text = if (item.number > 0) String.format(Locale.US, "%02d", item.number) else ""
            options.isVisible = !item.options.isNullOrEmpty()
            name.text = item.name
            logo.loadChannelLogo(item.name, item.logo, withBackground = false)

            itemView.contentDescription =
                if (item.number > 0) "Canal ${item.number}, ${item.name}" else item.name
        }

        fun reset() {
            channel = null
            itemView.scaleX = 1f
            itemView.scaleY = 1f
            itemView.translationZ = 0f
        }
    }

    private companion object {
        const val TYPE_HEADER = 0
        const val TYPE_CARD = 1
        const val FOCUS_SCALE = 1.06f
        const val FOCUS_Z = 12f
        const val FOCUS_ANIM_MS = 120L
        const val TILE_CORNER_DP = 10f
    }
}
