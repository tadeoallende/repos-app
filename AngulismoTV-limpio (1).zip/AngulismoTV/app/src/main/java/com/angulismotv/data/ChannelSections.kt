package com.angulismotv.data

import com.angulismotv.models.Channel

/** Agrupa los canales por categoría para mostrarlos en secciones. Lógica pura, sin Android. */
object ChannelSections {

    data class Section(val category: String, val channels: List<Channel>)

    /**
     * Las secciones siguen el orden en que aparece cada categoría en la lista (así el JSON manda),
     * y dentro de cada una se conserva el orden original. Categorías vacías o en distinta
     * capitalización ("Noticias" / "noticias") se unifican.
     */
    fun group(channels: List<Channel>): List<Section> {
        val groups = LinkedHashMap<String, MutableList<Channel>>()
        for (channel in channels) {
            val key = channel.category.trim().lowercase().ifEmpty { "todos" }
            groups.getOrPut(key) { mutableListOf() }.add(channel)
        }
        return groups.map { (category, list) -> Section(category, list) }
    }
}
