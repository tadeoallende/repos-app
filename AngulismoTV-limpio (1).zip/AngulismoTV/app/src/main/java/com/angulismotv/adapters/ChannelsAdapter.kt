package com.angulismotv.adapters

import android.view.LayoutInflater
import android.util.TypedValue
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.AsyncListDiffer
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.RecyclerView
import com.angulismotv.R
import com.angulismotv.models.Channel
import com.angulismotv.utils.DeviceHelper
import com.angulismotv.utils.loadChannelLogo
import com.bumptech.glide.Glide

class ChannelsAdapter(
    private val onItemClick: (Channel, Int) -> Unit
) : RecyclerView.Adapter<ChannelsAdapter.ChannelViewHolder>() {

    // ✅ AsyncListDiffer para actualizaciones eficientes
    private val differ = AsyncListDiffer(this, object : DiffUtil.ItemCallback<Channel>() {
        override fun areItemsTheSame(oldItem: Channel, newItem: Channel): Boolean {
            return oldItem.name == newItem.name && oldItem.logo == newItem.logo
        }

        override fun areContentsTheSame(oldItem: Channel, newItem: Channel): Boolean {
            return oldItem == newItem
        }
    })

    private var isTV = false
    private var lastFocusedPosition = -1

    fun submitList(newChannels: List<Channel>) {
        differ.submitList(newChannels)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ChannelViewHolder {
        isTV = DeviceHelper.isTV(parent.context)
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_channel, parent, false)
        return ChannelViewHolder(view, isTV)
    }

    override fun onBindViewHolder(holder: ChannelViewHolder, position: Int) {
        val channel = differ.currentList[position]
        holder.bind(channel, position)

        holder.itemView.setOnClickListener {
            onItemClick(channel, holder.bindingAdapterPosition)
        }
        holder.itemView.nextFocusLeftId = View.NO_ID

        // Mejor manejo de foco para TV.
        if (isTV) {
            setupTVFocus(holder)
        }
    }

    private fun setupTVFocus(holder: ChannelViewHolder) {
        holder.itemView.apply {
            isFocusable = true
            isFocusableInTouchMode = true

            setOnFocusChangeListener { _, hasFocus ->
                // El selector item_channel_bg dibuja el foco sin escalar ni desplazar tarjetas vecinas.
                if (hasFocus) {
                    lastFocusedPosition = holder.bindingAdapterPosition
                    val recycler = parent as? RecyclerView
                    val spanCount = (recycler?.layoutManager as? androidx.recyclerview.widget.GridLayoutManager)?.spanCount ?: 1
                    nextFocusLeftId = if (holder.bindingAdapterPosition >= 0 && holder.bindingAdapterPosition % spanCount == 0) R.id.menu_channels else View.NO_ID
                }
                animate().cancel()
                scaleX = 1f
                scaleY = 1f
            }
        }
    }

    override fun getItemCount() = differ.currentList.size

    // ✅ Método útil para recuperar el último foco
    fun getLastFocusedPosition(): Int = lastFocusedPosition

    inner class ChannelViewHolder(
        itemView: View,
        private val isTV: Boolean
    ) : RecyclerView.ViewHolder(itemView) {

        private val logo: ImageView = itemView.findViewById(R.id.channel_logo)
        private val channelName: TextView = itemView.findViewById(R.id.channel_name)
        private val optionsIndicator: ImageView = itemView.findViewById(R.id.options_indicator)

        init {
            if (isTV) {
                // TV: se ve desde lejos, así que texto y logo más grandes
                val density = itemView.resources.displayMetrics.density
                channelName.setTextSize(TypedValue.COMPLEX_UNIT_SP, 18f)
                logo.layoutParams = logo.layoutParams.apply {
                    width = (56 * density).toInt()
                    height = (56 * density).toInt()
                }
                val padding = (16 * density).toInt()
                itemView.setPadding(padding, padding, padding, padding)
            }
        }

        private var currentChannel: Channel? = null

        fun bind(channel: Channel, position: Int) {
            currentChannel = channel

            // Nombre del canal
            channelName.text = channel.name
            channelName.isSelected = isTV  // Para marquee en TV

            // Indicador de opciones múltiples
            val hasOptions = !channel.options.isNullOrEmpty()
            optionsIndicator.visibility = if (hasOptions) View.VISIBLE else View.GONE

            logo.loadChannelLogo(channel.name, channel.logo, cornerRadiusPx = 12)

            itemView.contentDescription = "${channel.name}, ${if (hasOptions) "con opciones" else "canal"}"
        }

        fun recycle() {
            Glide.with(itemView.context).clear(logo)
            currentChannel = null
        }
    }

    // ✅ Limpiar recursos cuando el adapter se destruye
    override fun onViewRecycled(holder: ChannelViewHolder) {
        super.onViewRecycled(holder)
        holder.recycle()
    }
}