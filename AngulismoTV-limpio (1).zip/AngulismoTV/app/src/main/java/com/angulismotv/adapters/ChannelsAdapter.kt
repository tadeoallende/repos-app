package com.angulismotv.adapters

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.AsyncListDiffer
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.RecyclerView
import com.angulismotv.R
import com.angulismotv.models.Channel
import com.angulismotv.utils.DeviceHelper
import com.bumptech.glide.Glide
import com.bumptech.glide.load.resource.bitmap.RoundedCorners
import com.bumptech.glide.request.RequestOptions

class ChannelsAdapter(
    private val onItemClick: (Channel, Int) -> Unit
) : RecyclerView.Adapter<ChannelsAdapter.ChannelViewHolder>() {

    // ✅ AsyncListDiffer para actualizaciones eficientes
    private val differ = AsyncListDiffer(this, object : DiffUtil.ItemCallback<Channel>() {
        override fun areItemsTheSame(oldItem: Channel, newItem: Channel): Boolean {
            return oldItem.name == newItem.name && oldItem.logo == newItem.logo
        }

        override fun areContentsTheSame(oldItem: Channel, newItem: Channel): Boolean {
            return oldItem == newItem
        }
    })

    private var isTV = false
    private var lastFocusedPosition = -1

    fun submitList(newChannels: List<Channel>) {
        differ.submitList(newChannels)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ChannelViewHolder {
        isTV = DeviceHelper.isTV(parent.context)
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_channel, parent, false)
        return ChannelViewHolder(view, isTV)
    }

    override fun onBindViewHolder(holder: ChannelViewHolder, position: Int) {
        val channel = differ.currentList[position]
        holder.bind(channel, position)

        holder.itemView.setOnClickListener {
            onItemClick(channel, holder.adapterPosition)
        }

        // ✅ Mejor manejo de focus para TV
        if (isTV) {
            setupTVFocus(holder, position)
        }
    }

    private fun setupTVFocus(holder: ChannelViewHolder, position: Int) {
        holder.itemView.apply {
            isFocusable = true
            isFocusableInTouchMode = true

            setOnFocusChangeListener { _, hasFocus ->
                if (hasFocus) {
                    lastFocusedPosition = position
                    animateFocusIn(this)
                } else {
                    animateFocusOut(this)
                }
            }
        }
    }

    private fun animateFocusIn(view: View) {
        view.animate()
            .scaleX(1.05f)
            .scaleY(1.05f)
            .setDuration(150)
            .withEndAction {
                view.elevation = 12f
            }
            .start()
    }

    private fun animateFocusOut(view: View) {
        view.animate()
            .scaleX(1f)
            .scaleY(1f)
            .setDuration(150)
            .withEndAction {
                view.elevation = 2f
            }
            .start()
    }

    override fun getItemCount() = differ.currentList.size

    // ✅ Método útil para recuperar el último foco
    fun getLastFocusedPosition(): Int = lastFocusedPosition

    inner class ChannelViewHolder(
        itemView: View,
        private val isTV: Boolean
    ) : RecyclerView.ViewHolder(itemView) {

        private val logo: ImageView = itemView.findViewById(R.id.channel_logo)
        private val channelName: TextView = itemView.findViewById(R.id.channel_name)
        private val optionsIndicator: ImageView = itemView.findViewById(R.id.options_indicator)

        // ✅ Cache para evitar recálculos
        private var currentChannel: Channel? = null
        private val glideOptions = RequestOptions()
            .placeholder(R.drawable.ic_channel_placeholder)
            .error(R.drawable.ic_channel_placeholder)
            .transform(RoundedCorners(12))  // Esquinas redondeadas

        fun bind(channel: Channel, position: Int) {
            currentChannel = channel

            // Nombre del canal
            channelName.text = channel.name
            channelName.isSelected = isTV  // Para marquee en TV

            // Indicador de opciones múltiples
            val hasOptions = !channel.options.isNullOrEmpty()
            optionsIndicator.visibility = if (hasOptions) View.VISIBLE else View.GONE

            // ✅ Cargar logo con optimizaciones
            loadLogo(channel.logo)

            // ✅ Mejorar accesibilidad
            if (isTV) {
                itemView.contentDescription = "${channel.name}, ${if (hasOptions) "con opciones" else "canal"}"
            }
        }

        private fun loadLogo(logoUrl: String) {
            if (logoUrl.isEmpty()) {
                logo.setImageResource(R.drawable.ic_channel_placeholder)
                return
            }

            // ✅ Priorizar visibilidad
            if (logo.isLaidOut) {
                Glide.with(itemView.context)
                    .load(logoUrl)
                    .apply(glideOptions)
                    .into(logo)
            } else {
                // Si la vista aún no está medida, esperar
                logo.post {
                    Glide.with(itemView.context)
                        .load(logoUrl)
                        .apply(glideOptions)
                        .into(logo)
                }
            }
        }
        fun recycle() {
            Glide.with(itemView.context).clear(logo)
            currentChannel = null
        }
    }

    // ✅ Limpiar recursos cuando el adapter se destruye
    override fun onViewRecycled(holder: ChannelViewHolder) {
        super.onViewRecycled(holder)
        holder.recycle()
    }
}