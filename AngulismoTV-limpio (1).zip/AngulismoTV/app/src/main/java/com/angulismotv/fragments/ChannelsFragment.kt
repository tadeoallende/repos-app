package com.angulismotv.fragments

import android.content.Intent
import android.content.res.Configuration
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.Editable
import android.text.TextWatcher
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.MotionEvent
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.view.animation.AnimationUtils
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.SeekBar
import android.widget.TextView
import androidx.core.content.ContextCompat
import androidx.core.view.isVisible
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.angulismotv.MainActivity
import com.angulismotv.R
import com.angulismotv.UnifiedPlayerActivity
import com.angulismotv.data.LoadResult
import android.widget.Toast
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout
import com.angulismotv.adapters.ChannelsAdapter
import com.angulismotv.models.Channel
import com.angulismotv.models.StreamType
import com.angulismotv.player.StreamUtils
import com.angulismotv.player.applyPlayerSettings
import com.angulismotv.network.HttpClient
import com.google.android.exoplayer2.DefaultLoadControl
import com.google.android.exoplayer2.ExoPlayer
import com.google.android.exoplayer2.MediaItem
import com.google.android.exoplayer2.PlaybackException
import com.google.android.exoplayer2.Player
import com.google.android.exoplayer2.source.dash.DashMediaSource
import com.google.android.exoplayer2.source.hls.HlsMediaSource
import com.google.android.exoplayer2.source.ProgressiveMediaSource
import com.google.android.exoplayer2.ui.PlayerView
import com.google.android.exoplayer2.ext.okhttp.OkHttpDataSource
import com.angulismotv.utils.DeviceHelper
import com.angulismotv.utils.loadChannelLogo
import java.util.Locale

class ChannelsFragment : Fragment() {

    // Views
    private lateinit var channelsRecycler: RecyclerView
    private lateinit var progressBar: ProgressBar
    private lateinit var swipeRefresh: SwipeRefreshLayout
    private lateinit var stateContainer: LinearLayout
    private lateinit var retryButton: TextView
    private lateinit var errorText: TextView
    private lateinit var categoriesContainer: LinearLayout
    private lateinit var searchInput: EditText
    private lateinit var btnSearch: ImageView
    private lateinit var channelsSectionHeader: View
    private lateinit var channelsSearchContainer: View

    // Reproductor integrado móvil
    private lateinit var inlinePlayerContainer: FrameLayout
    private lateinit var inlinePlayerView: PlayerView
    private lateinit var inlineWebView: WebView
    private lateinit var inlineProgressBar: ProgressBar
    private lateinit var inlineErrorText: TextView
    private lateinit var inlineControlsBar: LinearLayout
    private lateinit var inlineTimelineContainer: View
    private lateinit var inlineSeekBar: SeekBar
    private lateinit var inlineTimeCurrent: TextView
    private lateinit var inlineTimeDuration: TextView
    private lateinit var inlineChannelLogo: ImageView
    private lateinit var inlineChannelName: TextView
    private lateinit var inlineBtnPlayPause: ImageButton
    private lateinit var inlineBtnSources: ImageButton
    private lateinit var inlineBtnFullscreen: ImageButton
    private lateinit var inlineBtnClose: ImageButton
    private var inlineExoPlayer: ExoPlayer? = null
    private var inlineChannel: Channel? = null
    private var inlineSourceIndex = 0
    private var inlineGeneration = 0
    private var inlineControlsVisible = false
    private var isLaunchingFullscreen = false
    private val inlineControlsHandler = Handler(Looper.getMainLooper())
    private var hideInlineControlsRunnable: Runnable? = null
    private var inlineTimelineRunnable: Runnable? = null
    private var isInlineUserSeeking = false

    // Adapter y datos
    private lateinit var channelsAdapter: ChannelsAdapter
    private var originalChannels = listOf<Channel>()
    private var filteredChannels = listOf<Channel>()
    private var currentCategory = "todos"
    private var isSearchVisible = false

    // ✅ Lista dinámica de categorías (se genera desde los datos)
    private var categories = mutableListOf<Pair<String, String>>()

    // Mapeo de nombres de categoría para mostrar en español
    private val categoryNames = mapOf(
        "todos" to "Todos",
        "deportes" to "Deportes",
        "noticias" to "Noticias",
        "peliculas" to "Películas",
        "infantiles" to "Infantiles",
        "educativos" to "Educativos",
        "internacionales" to "Internacionales",
        "estilo-vida" to "Estilo de vida",
        "musicales" to "Musicales",
        "documentales" to "Documentales",
        "eventos" to "Eventos"
    )

    // Optimizaciones
    private val searchHandler = Handler(Looper.getMainLooper())
    private var searchRunnable: Runnable? = null
    private val SEARCH_DELAY = 300L

    private var isTV = false

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        return inflater.inflate(R.layout.fragment_channels, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        isTV = DeviceHelper.isTV(requireContext())

        initViews(view)
        setupInlinePlayer()
        setupSearch()
        setupRecyclerView()
        setupStates()
        renderInitialState()

    }

    private fun initViews(view: View) {
        channelsRecycler = view.findViewById(R.id.channels_recycler)
        progressBar = view.findViewById(R.id.progress_bar)
        errorText = view.findViewById(R.id.error_text)
        swipeRefresh = view.findViewById(R.id.swipe_refresh)
        stateContainer = view.findViewById(R.id.state_container)
        retryButton = view.findViewById(R.id.retry_button)
        categoriesContainer = view.findViewById(R.id.categories_container)
        searchInput = view.findViewById(R.id.search_input)
        btnSearch = view.findViewById(R.id.btn_search)
        channelsSectionHeader = view.findViewById(R.id.channels_section_header)
        channelsSearchContainer = view.findViewById(R.id.channels_search_container)
        inlinePlayerContainer = view.findViewById(R.id.inline_player_container)
        inlinePlayerView = view.findViewById(R.id.inline_player_view)
        inlineWebView = view.findViewById(R.id.inline_web_view)
        inlineProgressBar = view.findViewById(R.id.inline_progress_bar)
        inlineErrorText = view.findViewById(R.id.inline_error_text)
        inlineControlsBar = view.findViewById(R.id.inline_controls_bar)
        inlineTimelineContainer = view.findViewById(R.id.inline_timeline_container)
        inlineSeekBar = view.findViewById(R.id.inline_seek_bar)
        inlineTimeCurrent = view.findViewById(R.id.inline_time_current)
        inlineTimeDuration = view.findViewById(R.id.inline_time_duration)
        inlineChannelLogo = view.findViewById(R.id.inline_channel_logo)
        inlineChannelName = view.findViewById(R.id.inline_channel_name)
        inlineBtnPlayPause = view.findViewById(R.id.inline_btn_play_pause)
        inlineBtnSources = view.findViewById(R.id.inline_btn_sources)
        inlineBtnFullscreen = view.findViewById(R.id.inline_btn_fullscreen)
        inlineBtnClose = view.findViewById(R.id.inline_btn_close)
    }

    private fun setupInlinePlayer() {
        if (isTV) {
            inlinePlayerContainer.visibility = View.GONE
            return
        }

        inlinePlayerView.useController = false
        inlinePlayerView.isClickable = true
        inlinePlayerView.setOnClickListener {
            if (inlineControlsVisible) hideInlineControls() else showInlineControlsTemporarily()
        }

        // No consume los toques del reproductor web: sus controles internos siguen funcionando.
        inlineWebView.applyPlayerSettings()
        inlineWebView.setOnTouchListener { _, event ->
            if (event.action == MotionEvent.ACTION_UP) showInlineControlsTemporarily()
            false
        }

        inlineSeekBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onStartTrackingTouch(seekBar: SeekBar?) {
                isInlineUserSeeking = true
                showInlineControlsTemporarily()
            }

            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                if (!fromUser) return
                val duration = inlineExoPlayer?.duration ?: return
                inlineTimeCurrent.text = formatInlineTime(duration * progress.toLong() / 1000L)
            }

            override fun onStopTrackingTouch(seekBar: SeekBar?) {
                val player = inlineExoPlayer
                if (player != null && player.duration > 0) {
                    player.seekTo(player.duration * inlineSeekBar.progress.toLong() / 1000L)
                }
                isInlineUserSeeking = false
                showInlineControlsTemporarily()
            }
        })

        inlineBtnPlayPause.setOnClickListener {
            val player = inlineExoPlayer ?: return@setOnClickListener
            if (player.isPlaying) player.pause() else player.play()
            updateInlinePlayPauseIcon()
            showInlineControlsTemporarily()
        }
        inlineBtnSources.setOnClickListener { showInlineSourcePicker() }
        inlineBtnFullscreen.setOnClickListener { launchInlineFullscreen() }
        inlineBtnClose.setOnClickListener { closeInlinePlayer() }
    }

    private fun showInlinePlayer(channel: Channel, startPlayback: Boolean = true) {
        if (isTV) {
            launchPlayerActivity(channel, fromInline = false)
            return
        }

        // Invalida callbacks tardíos de la fuente anterior antes de cambiar de canal.
        inlineGeneration++
        inlineChannel = channel
        inlineSourceIndex = 0
        inlinePlayerContainer.visibility = View.VISIBLE
        channelsSectionHeader.visibility = View.GONE
        channelsSearchContainer.visibility = View.GONE
        inlineChannelName.text = channel.name
        inlineChannelLogo.loadChannelLogo(channel.name, channel.logo)
        inlineBtnSources.visibility = if ((channel.options?.size ?: 0) > 1) View.VISIBLE else View.GONE
        inlineErrorText.visibility = View.GONE
        inlinePlayerView.visibility = View.GONE
        inlineWebView.visibility = View.GONE
        showInlineControlsTemporarily()

        if (startPlayback) {
            startInlinePlayback(channel, 0)
        } else {
            releaseInlineEngine()
            inlineProgressBar.visibility = View.GONE
        }
    }

    private fun startInlinePlayback(channel: Channel, sourceIndex: Int) {
        if (!isAdded || view == null) return
        inlineGeneration++
        val generation = inlineGeneration
        releaseInlineEngine()
        inlineSourceIndex = sourceIndex
        inlineErrorText.visibility = View.GONE
        inlineProgressBar.visibility = View.VISIBLE

        val options = channel.options.orEmpty()
        val url: String
        val type: String
        if (options.isNotEmpty()) {
            if (sourceIndex !in options.indices) {
                showInlineError("No se pudo reproducir ninguna fuente de este canal.")
                return
            }
            val option = options[sourceIndex]
            url = option.iframe
            type = StreamUtils.resolveType(url, option.streamType)
        } else {
            url = channel.streamUrl.orEmpty()
            type = StreamUtils.resolveType(url, channel.streamType ?: StreamType.AUTO)
        }

        if (url.isBlank()) {
            handleInlineSourceFailure(generation)
            return
        }

        if (type == StreamType.IFRAME) {
            startInlineWebView(url, generation)
        } else {
            startInlineExoPlayer(url, type, generation)
        }
    }

    private fun startInlineExoPlayer(url: String, type: String, generation: Int) {
        inlineWebView.stopLoading()
        inlineWebView.visibility = View.GONE
        inlinePlayerView.visibility = View.VISIBLE
        inlineBtnPlayPause.visibility = View.VISIBLE
        inlineTimelineContainer.visibility = View.GONE

        try {
            val dataSource = OkHttpDataSource.Factory(HttpClient.shared)
                .setUserAgent(HttpClient.USER_AGENT)
            val mediaItem = MediaItem.fromUri(Uri.parse(url))
            val mediaSource = when (type) {
                StreamType.DASH -> DashMediaSource.Factory(dataSource).createMediaSource(mediaItem)
                StreamType.MP4 -> ProgressiveMediaSource.Factory(dataSource).createMediaSource(mediaItem)
                else -> HlsMediaSource.Factory(dataSource)
                    .setAllowChunklessPreparation(true)
                    .createMediaSource(mediaItem)
            }
            val loadControl = DefaultLoadControl.Builder()
                .setBufferDurationsMs(10_000, 45_000, 1_000, 3_000)
                .build()
            val player = ExoPlayer.Builder(requireContext())
                .setLoadControl(loadControl)
                .build()
            inlineExoPlayer = player
            inlinePlayerView.player = player
            inlinePlayerView.useController = false
            player.addListener(object : Player.Listener {
                override fun onPlaybackStateChanged(state: Int) {
                    if (generation != inlineGeneration) return
                    when (state) {
                        Player.STATE_BUFFERING -> inlineProgressBar.visibility = View.VISIBLE
                        Player.STATE_READY -> {
                            inlineProgressBar.visibility = View.GONE
                            inlineErrorText.visibility = View.GONE
                            updateInlinePlayPauseIcon()
                            updateInlineTimeline(player)
                            startInlineTimelineUpdates()
                            showInlineControlsTemporarily()
                        }
                        Player.STATE_ENDED -> inlineProgressBar.visibility = View.GONE
                    }
                }

                override fun onIsPlayingChanged(isPlaying: Boolean) {
                    if (generation == inlineGeneration) updateInlinePlayPauseIcon()
                }

                override fun onPlayerError(error: PlaybackException) {
                    if (generation == inlineGeneration) handleInlineSourceFailure(generation)
                }
            })
            player.setMediaSource(mediaSource)
            player.playWhenReady = true
            player.prepare()
        } catch (error: Exception) {
            android.util.Log.e("InlinePlayer", "No se pudo iniciar la fuente", error)
            handleInlineSourceFailure(generation)
        }
    }

    private fun startInlineWebView(url: String, generation: Int) {
        inlinePlayerView.player = null
        inlinePlayerView.visibility = View.GONE
        inlineWebView.visibility = View.VISIBLE
        inlineBtnPlayPause.visibility = View.GONE
        inlineTimelineContainer.visibility = View.GONE
        stopInlineTimelineUpdates()
        inlineWebView.applyPlayerSettings()
        inlineWebView.isFocusable = true
        inlineWebView.isFocusableInTouchMode = true
        inlineWebView.isClickable = true
        val initialHost = Uri.parse(url).host.orEmpty()

        inlineWebView.webChromeClient = object : WebChromeClient() {
            override fun onPermissionRequest(request: android.webkit.PermissionRequest?) {
                request?.deny()
            }

            override fun onCreateWindow(
                view: WebView?,
                isDialog: Boolean,
                isUserGesture: Boolean,
                resultMsg: android.os.Message?
            ): Boolean = false
        }
        inlineWebView.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView?, finishedUrl: String?) {
                if (generation != inlineGeneration || finishedUrl.isNullOrBlank() || finishedUrl == "about:blank") return
                inlineProgressBar.visibility = View.GONE
                inlineErrorText.visibility = View.GONE
                showInlineControlsTemporarily()
            }

            @android.annotation.TargetApi(android.os.Build.VERSION_CODES.M)
            override fun onReceivedError(
                view: WebView?,
                request: WebResourceRequest?,
                error: android.webkit.WebResourceError?
            ) {
                if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.M && request?.isForMainFrame == true) {
                    if (request.url.toString() != "about:blank") handleInlineSourceFailure(generation)
                }
            }

            @Suppress("DEPRECATION")
            override fun onReceivedError(view: WebView?, code: Int, description: String?, failedUrl: String?) {
                if (android.os.Build.VERSION.SDK_INT < android.os.Build.VERSION_CODES.M &&
                    !failedUrl.isNullOrBlank() && failedUrl != "about:blank") {
                    handleInlineSourceFailure(generation)
                }
            }

            @android.annotation.TargetApi(android.os.Build.VERSION_CODES.M)
            override fun onReceivedHttpError(
                view: WebView?,
                request: WebResourceRequest?,
                errorResponse: android.webkit.WebResourceResponse?
            ) {
                if (request?.isForMainFrame == true && (errorResponse?.statusCode ?: 0) >= 400) {
                    handleInlineSourceFailure(generation)
                }
            }

            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                request ?: return false
                if (!request.isForMainFrame) return false
                if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.N && request.isRedirect) return false
                val host = request.url.host.orEmpty()
                val sameSite = host == initialHost || host.endsWith(".$initialHost")
                return !sameSite
            }
        }
        inlineWebView.loadUrl(url)
    }

    private fun handleInlineSourceFailure(generation: Int) {
        if (generation != inlineGeneration) return
        val channel = inlineChannel ?: return
        val nextIndex = inlineSourceIndex + 1
        if (!channel.options.isNullOrEmpty() && nextIndex < channel.options.size) {
            startInlinePlayback(channel, nextIndex)
        } else {
            showInlineError("No se pudo cargar esta señal. Probá otra fuente o canal.")
        }
    }

    private fun showInlineError(message: String) {
        stopInlineTimelineUpdates()
        inlineProgressBar.visibility = View.GONE
        inlineErrorText.text = message
        inlineErrorText.visibility = View.VISIBLE
        showInlineControlsTemporarily()
    }

    private fun releaseInlineEngine() {
        stopInlineTimelineUpdates()
        inlineTimelineContainer.visibility = View.GONE
        inlineExoPlayer?.run {
            stop()
            clearMediaItems()
            release()
        }
        inlineExoPlayer = null
        if (::inlinePlayerView.isInitialized) inlinePlayerView.player = null
        if (::inlineWebView.isInitialized) {
            inlineWebView.stopLoading()
            inlineWebView.visibility = View.GONE
            inlineWebView.loadUrl("about:blank")
        }
    }

    private fun updateInlineTimeline(player: ExoPlayer) {
        val duration = player.duration
        val canSeek = player.playbackState == Player.STATE_READY && player.isCurrentWindowSeekable && duration > 0L
        if (!canSeek || !inlineControlsVisible) {
            inlineTimelineContainer.visibility = View.GONE
            return
        }
        inlineTimelineContainer.visibility = View.VISIBLE
        inlineSeekBar.max = 1000
        if (!isInlineUserSeeking) {
            inlineSeekBar.progress = ((player.currentPosition.coerceAtLeast(0L) * 1000L) / duration)
                .toInt().coerceIn(0, 1000)
            inlineTimeCurrent.text = formatInlineTime(player.currentPosition)
        }
        inlineTimeDuration.text = formatInlineTime(duration)
    }

    private fun startInlineTimelineUpdates() {
        stopInlineTimelineUpdates()
        inlineTimelineRunnable = object : Runnable {
            override fun run() {
                val player = inlineExoPlayer
                if (player == null || inlineChannel == null || inlinePlayerContainer.visibility != View.VISIBLE) return
                updateInlineTimeline(player)
                inlineControlsHandler.postDelayed(this, 500L)
            }
        }
        inlineControlsHandler.post(inlineTimelineRunnable!!)
    }

    private fun stopInlineTimelineUpdates() {
        inlineTimelineRunnable?.let { inlineControlsHandler.removeCallbacks(it) }
        inlineTimelineRunnable = null
        isInlineUserSeeking = false
    }

    private fun formatInlineTime(positionMs: Long): String {
        val totalSeconds = (positionMs.coerceAtLeast(0L) / 1000L)
        val hours = totalSeconds / 3600L
        val minutes = (totalSeconds % 3600L) / 60L
        val seconds = totalSeconds % 60L
        return if (hours > 0L) String.format(Locale.ROOT, "%d:%02d:%02d", hours, minutes, seconds)
        else String.format(Locale.ROOT, "%02d:%02d", minutes, seconds)
    }

    private fun updateInlinePlayPauseIcon() {
        inlineBtnPlayPause.setImageResource(
            if (inlineExoPlayer?.isPlaying == true) R.drawable.ic_pause else R.drawable.ic_play
        )
    }

    private fun showInlineControlsTemporarily() {
        if (isTV || !::inlineControlsBar.isInitialized || inlinePlayerContainer.visibility != View.VISIBLE) return
        inlineControlsVisible = true
        inlineControlsBar.visibility = View.VISIBLE
        inlineControlsBar.bringToFront()
        inlineExoPlayer?.let { updateInlineTimeline(it) }
        hideInlineControlsRunnable?.let { inlineControlsHandler.removeCallbacks(it) }
        hideInlineControlsRunnable = Runnable { hideInlineControls() }
        inlineControlsHandler.postDelayed(hideInlineControlsRunnable!!, 4_000L)
    }

    private fun hideInlineControls() {
        if (!::inlineControlsBar.isInitialized) return
        inlineControlsVisible = false
        inlineControlsBar.visibility = View.GONE
        inlineTimelineContainer.visibility = View.GONE
        hideInlineControlsRunnable?.let { inlineControlsHandler.removeCallbacks(it) }
        hideInlineControlsRunnable = null
    }

    private fun showInlineSourcePicker() {
        val channel = inlineChannel ?: return
        val options = channel.options.orEmpty()
        if (options.size < 2) return
        androidx.appcompat.app.AlertDialog.Builder(requireContext())
            .setTitle("Seleccionar fuente")
            .setItems(options.map { it.name }.toTypedArray()) { _, which ->
                startInlinePlayback(channel, which)
                showInlineControlsTemporarily()
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    private fun closeInlinePlayer() {
        inlineGeneration++
        hideInlineControls()
        hideInlineControlsRunnable?.let { inlineControlsHandler.removeCallbacks(it) }
        releaseInlineEngine()
        inlinePlayerContainer.visibility = View.GONE
        inlineProgressBar.visibility = View.GONE
        inlineErrorText.visibility = View.GONE
        inlineChannel = null
        channelsSectionHeader.visibility = View.VISIBLE
        channelsSearchContainer.visibility = View.VISIBLE
        currentCategory = currentCategory.ifBlank { "todos" }
    }

    private fun launchInlineFullscreen() {
        val channel = inlineChannel ?: return
        launchPlayerActivity(channel, fromInline = true)
    }

    private fun launchPlayerActivity(channel: Channel, fromInline: Boolean) {
        val channelIndex = originalChannels.indexOfFirst { it.name == channel.name && it.logo == channel.logo }
            .takeIf { it >= 0 } ?: 0
        isLaunchingFullscreen = fromInline
        inlineExoPlayer?.pause()
        inlineWebView.onPause()
        val intent = Intent(requireContext(), UnifiedPlayerActivity::class.java).apply {
            putParcelableArrayListExtra("channels", ArrayList(originalChannels))
            putExtra("channel_index", channelIndex)
            putExtra("channel_name", channel.name)
            putExtra("channel_logo", channel.logo)
            putExtra("stream_url", channel.streamUrl)
            putExtra("stream_type", channel.streamType ?: StreamType.AUTO)
            putExtra("from_inline_player", fromInline)
            putExtra("source_index", inlineSourceIndex)
        }
        startActivity(intent)
        if (!isTV) requireActivity().overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
    }

    private fun maybeOpenFullscreenAfterRotation(newConfig: Configuration) {
        if (isTV || isHidden || newConfig.orientation != Configuration.ORIENTATION_LANDSCAPE) return
        if (inlineChannel == null || inlinePlayerContainer.visibility != View.VISIBLE || isLaunchingFullscreen) return
        launchPlayerActivity(inlineChannel!!, fromInline = true)
    }

    private fun setupSearch() {
        btnSearch.setOnClickListener {
            toggleSearch()
        }

        searchInput.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                searchRunnable?.let { searchHandler.removeCallbacks(it) }
                searchRunnable = Runnable { applyFiltersAndUpdate() }
                searchHandler.postDelayed(searchRunnable!!, SEARCH_DELAY)
            }
            override fun afterTextChanged(s: Editable?) {}
        })
    }

    private fun toggleSearch() {
        isSearchVisible = !isSearchVisible

        if (isSearchVisible) {
            searchInput.visibility = View.VISIBLE
            searchInput.requestFocus()
            if (!isTV) {
                val imm = requireContext().getSystemService(android.content.Context.INPUT_METHOD_SERVICE) as android.view.inputmethod.InputMethodManager
                imm.showSoftInput(searchInput, android.view.inputmethod.InputMethodManager.SHOW_IMPLICIT)
            } else {
                searchInput.startAnimation(AnimationUtils.loadAnimation(requireContext(), android.R.anim.fade_in))
            }
        } else {
            searchInput.visibility = View.GONE
            searchInput.text.clear()
            if (!isTV) {
                val imm = requireContext().getSystemService(android.content.Context.INPUT_METHOD_SERVICE) as android.view.inputmethod.InputMethodManager
                imm.hideSoftInputFromWindow(searchInput.windowToken, 0)
            }
            applyFiltersAndUpdate()
        }
    }

    private fun applyFiltersAndUpdate() {
        if (originalChannels.isEmpty()) return

        val categoryFiltered = if (currentCategory == "todos") {
            originalChannels
        } else {
            originalChannels.filter { it.category == currentCategory }
        }

        val searchQuery = searchInput.text.toString().trim()
        filteredChannels = if (searchQuery.isNotEmpty()) {
            val query = searchQuery.lowercase()
            categoryFiltered.filter { channel ->
                channel.name.lowercase().contains(query)
            }
        } else {
            categoryFiltered
        }

        channelsAdapter.submitList(filteredChannels)

        if (filteredChannels.isEmpty()) {
            showState("No se encontraron canales", isError = false, showRetry = false)
        } else {
            hideState()
        }
    }

    // ✅ Función que genera categorías DINÁMICAMENTE desde los canales
    private fun generateCategoriesFromChannels(channels: List<Channel>) {
        if (channels.isEmpty()) return

        val uniqueCategories = channels.mapNotNull { it.category }
            .filter { it.isNotBlank() && it != "todos" }
            .distinct()
            .sorted()

        categories.clear()
        categories.add("todos" to categoryNames["todos"].orEmpty())

        uniqueCategories.forEach { categoryKey ->
            categories.add(categoryKey to displayCategoryName(categoryKey))
        }

        setupCategories()
    }


    private fun displayCategoryName(categoryKey: String): String {
        categoryNames[categoryKey]?.let { return it }
        val spanishLocale = Locale("es", "AR")
        return categoryKey
            .replace('-', ' ')
            .split(' ')
            .filter { it.isNotBlank() }
            .joinToString(" ") { word ->
                word.lowercase(spanishLocale).replaceFirstChar { first ->
                    if (first.isLowerCase()) first.titlecase(spanishLocale) else first.toString()
                }
            }
    }

    private fun setupCategories() {
        categoriesContainer.removeAllViews()

        if (categories.isEmpty()) {
            // Si no hay categorías, mostrar al menos "todos"
            categories.add("todos" to categoryNames["todos"].orEmpty())
        }

        for ((key, label) in categories) {
            val chip = LayoutInflater.from(requireContext())
                .inflate(R.layout.item_category, categoriesContainer, false) as TextView

            chip.text = label
            chip.tag = key
            chip.isSelected = key == currentCategory

            updateChipStyle(chip, chip.isSelected)

            if (isTV) {
                // El primer chip permite volver al rail principal con la flecha izquierda.
                chip.nextFocusLeftId = if (key == categories.firstOrNull()?.first) R.id.menu_channels else View.NO_ID
                setupTVFocusEffect(chip)
            } else {
                chip.setOnTouchListener { _, _ ->
                    chip.isSelected = true
                    false
                }
            }

            chip.setOnClickListener { selectCategory(key) }
            categoriesContainer.addView(chip)
        }

        if (isTV) {
            categoriesContainer.post {
                val selectedChip = categoriesContainer.findViewWithTag<TextView>(currentCategory)
                selectedChip?.requestFocus()
            }
        }
    }

    private fun updateChipStyle(chip: TextView, isSelected: Boolean) {
        if (isSelected) {
            chip.setBackgroundResource(R.drawable.bg_category_selected)
            chip.setTextColor(ContextCompat.getColor(requireContext(), R.color.text_primary))
        } else {
            chip.setBackgroundResource(R.drawable.bg_category_default)
            chip.setTextColor(ContextCompat.getColor(requireContext(), R.color.text_secondary))
        }
    }

    private fun setupTVFocusEffect(chip: TextView) {
        chip.onFocusChangeListener = View.OnFocusChangeListener { _, hasFocus ->
            // Foco visible sin escalado: evita solapamientos y saltos en TV.
            chip.animate().cancel()
            chip.scaleX = 1f
            chip.scaleY = 1f
            if (hasFocus) {
                val container = chip.parent as? View
                val scroller = container?.parent as? android.widget.HorizontalScrollView
                if (scroller != null) {
                    val leftEdge = scroller.scrollX
                    val rightEdge = leftEdge + scroller.width - scroller.paddingLeft - scroller.paddingRight
                    when {
                        chip.left < leftEdge -> scroller.smoothScrollTo(chip.left, 0)
                        chip.right > rightEdge -> scroller.smoothScrollTo(chip.right - scroller.width + scroller.paddingRight, 0)
                    }
                }
            }
        }
    }

    private fun selectCategory(categoryKey: String) {
        if (currentCategory == categoryKey) return

        currentCategory = categoryKey

        for (i in 0 until categoriesContainer.childCount) {
            val chip = categoriesContainer.getChildAt(i) as TextView
            updateChipStyle(chip, chip.tag == categoryKey)
        }

        applyFiltersAndUpdate()

        if (isSearchVisible) {
            toggleSearch()
        }

        channelsRecycler.smoothScrollToPosition(0)
    }

    private fun setupRecyclerView() {
        channelsRecycler.layoutManager = GridLayoutManager(requireContext(), calculateSpanCount())

        channelsAdapter = ChannelsAdapter { channel, position ->
            openPlayer(channel, position)
        }

        channelsRecycler.adapter = channelsAdapter

        if (isTV) {
            channelsRecycler.isFocusable = true
            channelsRecycler.requestFocus()
        }
    }

    /** Columnas según el ancho disponible: TV por rangos fijos; móvil/tablet una cada ~320dp. */
    private fun calculateSpanCount(): Int {
        val dpWidth = resources.configuration.screenWidthDp
        return if (isTV) {
            when {
                dpWidth >= 1920 -> 6
                dpWidth >= 1280 -> 5
                dpWidth >= 720 -> 4
                else -> 3
            }
        } else {
            (dpWidth / 320).coerceAtLeast(1)
        }
    }

    // MainActivity maneja la rotación sin recrearse: recalculamos la lista y ampliamos el reproductor.
    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        if (::channelsRecycler.isInitialized) {
            (channelsRecycler.layoutManager as? GridLayoutManager)?.spanCount = calculateSpanCount()
        }
        maybeOpenFullscreenAfterRotation(newConfig)
    }

    /** Al crear las vistas: muestra la carga en curso o el último resultado que tenga la activity. */
    private fun renderInitialState() {
        val main = activity as? MainActivity
        val result = main?.getLoadResult()
        if (main == null || main.isLoadingChannels() || result == null) {
            showLoading(true)
        } else {
            applyResult(result)
        }
    }

    private fun setupStates() {
        swipeRefresh.setColorSchemeResources(R.color.accent)
        swipeRefresh.setProgressBackgroundColorSchemeResource(R.color.space_surface_raised)
        swipeRefresh.isEnabled = !isTV // en TV no hay gesto: se usa el botón Reintentar
        swipeRefresh.setOnRefreshListener { (activity as? MainActivity)?.reloadChannels() }
        retryButton.setOnClickListener { (activity as? MainActivity)?.reloadChannels() }
    }

    private fun applyResult(result: LoadResult) {
        originalChannels = result.channels
        currentCategory = "todos"
        showLoading(false)
        swipeRefresh.isRefreshing = false

        if (originalChannels.isEmpty()) {
            filteredChannels = emptyList()
            channelsAdapter.submitList(emptyList())
            categoriesContainer.removeAllViews()
            when {
                result.notConfigured ->
                    showState("Todavía no hay una lista de canales configurada.", isError = false, showRetry = false)
                result.failed ->
                    showState("No se pudo cargar la lista de canales.\nRevisá tu conexión e intentá de nuevo.", isError = true, showRetry = true)
                else ->
                    showState("La lista de canales está vacía.", isError = false, showRetry = true)
            }
        } else {
            generateCategoriesFromChannels(originalChannels)
            applyFiltersAndUpdate()
        }
    }

    private fun showState(message: String, isError: Boolean, showRetry: Boolean) {
        errorText.text = message
        errorText.setTextColor(
            ContextCompat.getColor(requireContext(), if (isError) R.color.error else R.color.text_secondary)
        )
        retryButton.isVisible = showRetry
        stateContainer.isVisible = true
        if (showRetry && isTV) retryButton.requestFocus()
    }

    private fun hideState() {
        stateContainer.isVisible = false
    }

    private fun showLoading(show: Boolean) {
        progressBar.isVisible = show
    }

    /** True si las vistas ya existen (entre onViewCreated y onDestroyView). */
    private fun isViewReady() = view != null && ::progressBar.isInitialized && ::channelsAdapter.isInitialized

    /** La activity avisa que empezó (o se repitió) la carga de la lista. */
    fun onLoadStarted() {
        if (!isViewReady()) return
        hideState()
        if (!swipeRefresh.isRefreshing) showLoading(true)
    }

    /**
     * La activity llama a esto cuando termina de cargar. Si el fragmento todavía no creó sus vistas
     * no hay nada que actualizar: [renderInitialState] leerá el resultado desde la activity al crearlas.
     */
    fun showResult(result: LoadResult) {
        if (!isViewReady()) return
        applyResult(result)
    }

    // En TV, al volver del reproductor el foco regresa al canal que se estaba mirando.
    override fun onResume() {
        super.onResume()
        isLaunchingFullscreen = false
        if (isTV && !isHidden && isViewReady()) restoreTvFocus()
        if (!isTV && !isHidden && ::inlinePlayerContainer.isInitialized && inlineChannel != null &&
            inlinePlayerContainer.visibility == View.VISIBLE) {
            inlineWebView.onResume()
            val player = inlineExoPlayer
            if (player != null) {
                player.play()
            } else if (inlineWebView.visibility != View.VISIBLE) {
                // Si se abrió el reproductor de pantalla completa desde paisaje, reanudamos el mini-player.
                startInlinePlayback(inlineChannel!!, inlineSourceIndex)
            }
        }
    }

    override fun onPause() {
        super.onPause()
        inlineExoPlayer?.pause()
        if (::inlineWebView.isInitialized) inlineWebView.onPause()
    }

    override fun onHiddenChanged(hidden: Boolean) {
        super.onHiddenChanged(hidden)
        if (hidden) {
            inlineExoPlayer?.pause()
            if (::inlineWebView.isInitialized) inlineWebView.onPause()
        } else {
            inlineWebView.onResume()
            inlineExoPlayer?.play()
        }
    }

    private fun restoreTvFocus() {
        val position = channelsAdapter.getLastFocusedPosition()
        if (position < 0 || position >= channelsAdapter.itemCount) return
        channelsRecycler.scrollToPosition(position)
        channelsRecycler.post {
            channelsRecycler.findViewHolderForAdapterPosition(position)?.itemView?.requestFocus()
        }
    }

    private fun openPlayer(channel: Channel, position: Int) {
        if (channel.streamUrl.isNullOrEmpty() && channel.options.isNullOrEmpty()) {
            Toast.makeText(requireContext(), "Este canal no tiene fuentes disponibles", Toast.LENGTH_SHORT).show()
            return
        }

        if (isTV) {
            launchPlayerActivity(channel, fromInline = false)
        } else if (resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE) {
            // Si el móvil ya está en horizontal, abre la pantalla dedicada directamente.
            showInlinePlayer(channel, startPlayback = false)
            launchPlayerActivity(channel, fromInline = true)
        } else {
            // En vertical el canal queda integrado encima de la lista, sin abandonar la pantalla.
            showInlinePlayer(channel)
        }
    }

    override fun onDestroyView() {
        searchRunnable?.let { searchHandler.removeCallbacks(it) }
        hideInlineControlsRunnable?.let { inlineControlsHandler.removeCallbacks(it) }
        stopInlineTimelineUpdates()
        inlineGeneration++
        releaseInlineEngine()
        if (::inlineWebView.isInitialized) {
            inlineWebView.webChromeClient = WebChromeClient()
            inlineWebView.webViewClient = WebViewClient()
            inlineWebView.stopLoading()
            (inlineWebView.parent as? ViewGroup)?.removeView(inlineWebView)
            inlineWebView.removeAllViews()
            inlineWebView.destroy()
        }
        super.onDestroyView()
    }
}