package com.angulismotv

import android.os.Bundle
import android.util.Log
import android.view.KeyEvent
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import com.angulismotv.databinding.ActivityMainBinding
import com.angulismotv.fragments.AgendaFragment
import com.angulismotv.fragments.ChannelsFragment
import com.angulismotv.fragments.ForumFragment
import com.angulismotv.fragments.MulticamFragment
import com.angulismotv.data.ChannelRepository
import com.angulismotv.data.LoadResult
import com.angulismotv.models.Channel
import com.angulismotv.utils.DeviceHelper
import com.angulismotv.utils.UpdateManager
import com.bumptech.glide.Glide
import kotlinx.coroutines.launch

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private var allChannels = listOf<Channel>()
    private var channelsLoading = true
    private var lastLoadResult: LoadResult? = null
    private var isTV = false
    private var sideMenuAnimator: android.animation.ValueAnimator? = null
    private val sideMenuCollapsedWidth get() = (64 * resources.displayMetrics.density).toInt()
    private val sideMenuExpandedWidth get() = (224 * resources.displayMetrics.density).toInt()

    // ── Navegación ──────────────────────────────────────────────────────────
    // Sección activa actual — arranca siempre en Canales
    private var currentNavId: Int = R.id.nav_channels

    // Instancias únicas de cada fragment: se crean una vez y se reusan con
    // show/hide para preservar estado (scroll, datos cargados, etc.)
    private val fragmentChannels by lazy { ChannelsFragment() }
    private val fragmentAgenda   by lazy { AgendaFragment() }
    private val fragmentMulticam by lazy { MulticamFragment() }
    private val fragmentForum    by lazy { ForumFragment() }

    // ────────────────────────────────────────────────────────────────────────

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        isTV = DeviceHelper.isTV(this)

        Glide.with(this)
            .load(R.drawable.logo2)
            .placeholder(android.R.drawable.ic_menu_gallery)
            .error(android.R.drawable.ic_menu_gallery)
            .into(binding.logoImage)

        setupNavigation()
        setupBackHandler()
        loadAllChannels()

        // Check de actualizaciones (silencioso — solo muestra diálogo si hay novedad)
        UpdateManager(this).checkForUpdates(silent = true)
    }

    // ==================== NAVEGACIÓN ====================

    private fun setupNavigation() {
        // Mostrar el fragment inicial sin animación
        supportFragmentManager.beginTransaction()
            .add(R.id.fragment_container, fragmentChannels, TAG_CHANNELS)
            .commit()

        if (isTV) {
            binding.bottomNavigation.visibility = View.GONE
            binding.sideMenu.visibility = View.VISIBLE
            setupSideMenu()
        } else {
            binding.sideMenu.visibility = View.GONE
            binding.bottomNavigation.visibility = View.VISIBLE
            setupBottomNavigation()
        }
    }

    /**
     * Navega a la sección indicada por navId.
     * - Reutiliza instancias existentes (show/hide) en vez de recrear fragments.
     * - En TV colapsa el menú lateral al confirmar la navegación.
     */
    private fun navigateTo(navId: Int) {
        if (navId == currentNavId) {
            // Ya estamos aquí — en TV simplemente cerramos el menú
            if (isTV) collapseSideMenu()
            return
        }

        val target = fragmentForId(navId)
        val transaction = supportFragmentManager.beginTransaction()
            .setCustomAnimations(android.R.anim.fade_in, android.R.anim.fade_out)

        // Ocultar el fragment actual
        supportFragmentManager.findFragmentByTag(tagForId(currentNavId))
            ?.let { transaction.hide(it) }

        // Mostrar (o agregar si es la primera vez) el fragment destino
        if (target.isAdded) {
            transaction.show(target)
        } else {
            transaction.add(R.id.fragment_container, target, tagForId(navId))
        }

        transaction.commit()
        currentNavId = navId

        if (isTV) {
            collapseSideMenu()
            updateSideMenuSelection(navId)
        } else {
            // Sincronizar el ítem seleccionado del BottomNavigation
            if (binding.bottomNavigation.selectedItemId != navId) {
                binding.bottomNavigation.selectedItemId = navId
            }
        }
    }

    private fun fragmentForId(navId: Int): Fragment = when (navId) {
        R.id.nav_channels -> fragmentChannels
        R.id.nav_agenda   -> fragmentAgenda
        R.id.nav_multicam -> fragmentMulticam
        R.id.nav_forum    -> fragmentForum
        else              -> fragmentChannels
    }

    private fun tagForId(navId: Int): String = when (navId) {
        R.id.nav_channels -> TAG_CHANNELS
        R.id.nav_agenda   -> TAG_AGENDA
        R.id.nav_multicam -> TAG_MULTICAM
        R.id.nav_forum    -> TAG_FORUM
        else              -> TAG_CHANNELS
    }

    // ==================== BACK HANDLER ====================

    /**
     * Lógica de back unificada para móvil y TV:
     *
     * 1. Si el fragment visible tiene su propio manejo de back → delegar
     * 2. Si no estamos en Canales → volver a Canales (sección raíz)
     * 3. Si ya estamos en Canales → confirmar salida con diálogo
     *
     * Para TV también se intercepta KEYCODE_BACK en dispatchKeyEvent
     * antes de que cualquier vista lo consuma.
     */
    private fun setupBackHandler() {
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                handleBack()
            }
        })
    }

    private fun handleBack() {
        // 1. Intentar que el fragment activo maneje el back (ej: WebView con historial)
        val activeFragment = supportFragmentManager.findFragmentByTag(tagForId(currentNavId))
        if (activeFragment is BackHandler && activeFragment.handleBack()) return

        // 2. Si el menú lateral de TV está expandido, colapsarlo
        if (isTV && isSideMenuExpanded()) {
            collapseSideMenu()
            return
        }

        // 3. Si no estamos en la sección raíz, volver a Canales
        if (currentNavId != R.id.nav_channels) {
            navigateTo(R.id.nav_channels)
            return
        }

        // 4. Estamos en la raíz → confirmar salida
        showExitDialog()
    }

    private fun showExitDialog() {
        AlertDialog.Builder(this)
            .setTitle("Salir de AngulismoTV")
            .setMessage("¿Querés cerrar la aplicación?")
            .setPositiveButton("Salir") { _, _ -> finish() }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    // ==================== TV KEY DISPATCH ====================

    /**
     * Para TV interceptamos el back a nivel de Activity antes de que
     * cualquier View o Fragment lo consuma — mismo patrón que UnifiedPlayerActivity.
     */
    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        if (!isTV) return super.dispatchKeyEvent(event)
        if (event.action != KeyEvent.ACTION_DOWN) return super.dispatchKeyEvent(event)

        if (event.keyCode == KeyEvent.KEYCODE_BACK) {
            handleBack()
            return true
        }

        return super.dispatchKeyEvent(event)
    }

    // ==================== SIDE MENU (TV) ====================

    private fun setupSideMenu() {
        collapseSideMenu(animate = false)

        setupSideMenuItem(
            container = binding.menuChannels,
            label     = binding.menuChannelsText,
            navId     = R.id.nav_channels
        )
        setupSideMenuItem(
            container = binding.menuAgenda,
            label     = binding.menuAgendaText,
            navId     = R.id.nav_agenda
        )
        setupSideMenuItem(
            container = binding.menuMulticam,
            label     = binding.menuMulticamText,
            navId     = R.id.nav_multicam
        )
        setupSideMenuItem(
            container = binding.menuForum,
            label     = binding.menuForumText,
            navId     = R.id.nav_forum
        )

        // Selección inicial
        updateSideMenuSelection(currentNavId)
    }

    private fun setupSideMenuItem(container: LinearLayout, label: TextView, navId: Int) {
        label.visibility = View.GONE
        container.isFocusable = true
        container.isFocusableInTouchMode = true
        container.minimumHeight = (56 * resources.displayMetrics.density).toInt()
        container.setPadding(0, 0, 0, 0)
        container.gravity = android.view.Gravity.CENTER

        container.setOnFocusChangeListener { _, hasFocus ->
            if (hasFocus) {
                expandSideMenu()
            } else if (!anySideMenuItemFocused()) {
                collapseSideMenu()
            }
            updateSideMenuItemLayout(container, label, hasFocus || anySideMenuItemFocused())
        }

        container.setOnClickListener { navigateTo(navId) }
        updateSideMenuItemLayout(container, label, false)
    }

    /** Mantiene icono y etiqueta en posiciones estables en ambos estados. */
    private fun updateSideMenuItemLayout(container: LinearLayout, label: TextView, expanded: Boolean) {
        val icon = container.getChildAt(0) ?: return
        val iconParams = icon.layoutParams as? LinearLayout.LayoutParams
            ?: LinearLayout.LayoutParams((24 * resources.displayMetrics.density).toInt(), (24 * resources.displayMetrics.density).toInt())
        iconParams.width = (24 * resources.displayMetrics.density).toInt()
        iconParams.height = (24 * resources.displayMetrics.density).toInt()
        iconParams.marginStart = if (expanded) (20 * resources.displayMetrics.density).toInt() else 0
        iconParams.marginEnd = if (expanded) (14 * resources.displayMetrics.density).toInt() else 0
        icon.layoutParams = iconParams
        container.gravity = if (expanded) android.view.Gravity.CENTER_VERTICAL else android.view.Gravity.CENTER
        container.setPadding(0, 0, 0, 0)
        label.visibility = if (expanded) View.VISIBLE else View.GONE
        label.alpha = if (expanded) 1f else 0f
        label.layoutParams = (label.layoutParams as LinearLayout.LayoutParams).also {
            it.width = 0
            it.height = LinearLayout.LayoutParams.WRAP_CONTENT
            it.weight = 1f
            it.marginStart = 0
            it.marginEnd = (12 * resources.displayMetrics.density).toInt()
        }
    }

    private fun updateSideMenuSelection(navId: Int) {
        listOf(
            binding.menuChannels  to R.id.nav_channels,
            binding.menuAgenda    to R.id.nav_agenda,
            binding.menuMulticam  to R.id.nav_multicam,
            binding.menuForum     to R.id.nav_forum,
        ).forEach { (view, id) ->
            view.setBackgroundResource(
                if (id == navId) R.drawable.side_menu_item_bg else 0
            )
        }
    }

    private fun anySideMenuItemFocused(): Boolean {
        return binding.menuChannels.hasFocus()
                || binding.menuAgenda.hasFocus()
                || binding.menuMulticam.hasFocus()
                || binding.menuForum.hasFocus()
    }

    private fun isSideMenuExpanded(): Boolean {
        return binding.sideMenu.width >= sideMenuExpandedWidth - (8 * resources.displayMetrics.density).toInt()
    }

    private fun expandSideMenu() {
        binding.sideMenu.childrenMenuLabels(true)
        animateSideMenuWidth(sideMenuExpandedWidth)
    }

    private fun collapseSideMenu(animate: Boolean = true) {
        binding.sideMenu.childrenMenuLabels(false)
        if (animate) animateSideMenuWidth(sideMenuCollapsedWidth)
        else {
            sideMenuAnimator?.cancel()
            binding.sideMenu.layoutParams = binding.sideMenu.layoutParams.also { it.width = sideMenuCollapsedWidth }
            binding.sideMenu.requestLayout()
        }
    }

    private fun animateSideMenuWidth(targetWidth: Int) {
        val startWidth = if (binding.sideMenu.width > 0) binding.sideMenu.width else sideMenuCollapsedWidth
        if (startWidth == targetWidth) return
        sideMenuAnimator?.cancel()
        sideMenuAnimator = android.animation.ValueAnimator.ofInt(startWidth, targetWidth).apply {
            duration = 180
            interpolator = android.view.animation.DecelerateInterpolator()
            addUpdateListener { anim ->
                binding.sideMenu.layoutParams = binding.sideMenu.layoutParams.also {
                    it.width = anim.animatedValue as Int
                }
            }
            start()
        }
    }

    private fun LinearLayout.childrenMenuLabels(visible: Boolean) {
        val items = listOf(
            binding.menuChannels to binding.menuChannelsText,
            binding.menuAgenda to binding.menuAgendaText,
            binding.menuMulticam to binding.menuMulticamText,
            binding.menuForum to binding.menuForumText
        )
        items.forEach { (item, label) ->
            val expanded = visible && (item.hasFocus() || anySideMenuItemFocused())
            updateSideMenuItemLayout(item, label, expanded)
        }
    }

    // ==================== BOTTOM NAVIGATION (MÓVIL) ====================

    private fun setupBottomNavigation() {
        binding.bottomNavigation.setOnItemSelectedListener { item ->
            // Evitar re-navegación al mismo destino
            if (item.itemId != currentNavId) {
                navigateTo(item.itemId)
            }
            true
        }
    }

    // ==================== DATA LOADING ====================

    private fun loadAllChannels() {
        channelsLoading = true
        fragmentChannels.onLoadStarted()
        lifecycleScope.launch {
            val result = ChannelRepository.loadAll()
            allChannels = result.channels
            lastLoadResult = result
            channelsLoading = false
            fragmentChannels.showResult(result)
            Log.d(TAG, "Canales cargados: ${allChannels.size} (fallo=${result.failed})")
        }
    }

    // ==================== PUBLIC API ====================

    fun getChannels(): List<Channel> = allChannels

    fun isLoadingChannels(): Boolean = channelsLoading

    fun getLoadResult(): LoadResult? = lastLoadResult

    /** Vuelve a pedir la lista de canales (botón Reintentar y deslizar para actualizar). */
    fun reloadChannels() = loadAllChannels()

    // ==================== COMPANION ====================

    companion object {
        private const val TAG          = "MainActivity"
        private const val TAG_CHANNELS = "fragment_channels"
        private const val TAG_AGENDA   = "fragment_agenda"
        private const val TAG_MULTICAM = "fragment_multicam"
        private const val TAG_FORUM    = "fragment_forum"
    }
}

/**
 * Interface que pueden implementar los Fragments para manejar
 * el botón Back internamente (ej: WebView con historial de navegación).
 *
 * Retornar true significa "yo lo manejé, no hagas nada más".
 * Retornar false delega el back a MainActivity.
 */
interface BackHandler {
    fun handleBack(): Boolean
}