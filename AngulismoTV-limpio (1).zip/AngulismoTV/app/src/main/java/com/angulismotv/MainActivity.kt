package com.angulismotv

import android.os.Bundle
import android.util.Log
import android.view.KeyEvent
import android.view.Gravity
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.RecyclerView
import com.angulismotv.databinding.ActivityMainBinding
import com.angulismotv.fragments.AgendaFragment
import com.angulismotv.fragments.ChannelsFragment
import com.angulismotv.data.ChannelRepository
import com.angulismotv.data.LoadResult
import com.angulismotv.models.Channel
import com.angulismotv.utils.DeviceHelper
import com.angulismotv.utils.UpdateManager
import com.bumptech.glide.Glide
import kotlinx.coroutines.launch

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private var allChannels = listOf<Channel>()
    private var channelsLoading = true
    private var lastLoadResult: LoadResult? = null
    private var isTV = false
    private val sideMenuCollapsedWidth: Int get() = dp(72)
    private val sideMenuExpandedWidth: Int get() = dp(232)

    // ── Navegación ──────────────────────────────────────────────────────────
    // Sección activa actual — arranca siempre en Canales
    private var currentNavId: Int = R.id.nav_channels

    // Instancias únicas de cada fragment: se crean una vez y se reusan con
    // show/hide para preservar estado (scroll, datos cargados, etc.)
    private val fragmentChannels by lazy { ChannelsFragment() }
    private val fragmentAgenda   by lazy { AgendaFragment() }

    // ────────────────────────────────────────────────────────────────────────

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        isTV = DeviceHelper.isTV(this)

        Glide.with(this)
            .load(R.drawable.logo2)
            .placeholder(android.R.drawable.ic_menu_gallery)
            .error(android.R.drawable.ic_menu_gallery)
            .into(binding.logoImage)

        setupNavigation()
        setupBackHandler()
        loadAllChannels()

        // Check de actualizaciones (silencioso — solo muestra diálogo si hay novedad)
        UpdateManager(this).checkForUpdates(silent = true)
    }

    // ==================== NAVEGACIÓN ====================

    private fun setupNavigation() {
        // Mostrar el fragment inicial sin animación
        supportFragmentManager.beginTransaction()
            .add(R.id.fragment_container, fragmentChannels, TAG_CHANNELS)
            .commit()

        if (isTV) {
            binding.bottomNavigation.visibility = View.GONE
            binding.sideMenu.visibility = View.VISIBLE
            setMainContentInset(sideMenuCollapsedWidth)

            // La navegación principal queda limitada a Canales y Agenda.
            setupTvHeader()
            setupSideMenu()
        } else {
            binding.sideMenu.visibility = View.GONE
            binding.bottomNavigation.visibility = View.VISIBLE
            setMainContentInset(0)
            setupMobileHeader()
            setupBottomNavigation()
        }
    }

    /**
     * Navega a la sección indicada por navId.
     * - Reutiliza instancias existentes (show/hide) en vez de recrear fragments.
     * - En TV colapsa el menú lateral al confirmar la navegación.
     */
    private fun navigateTo(navId: Int) {
        if (isTV && navId != R.id.nav_channels && navId != R.id.nav_agenda) return
        if (navId == currentNavId) {
            // Confirmar la sección actual también devuelve el foco al contenido.
            if (isTV) {
                focusActiveContent()
                collapseSideMenu()
            }
            return
        }

        val target = fragmentForId(navId)
        val transaction = supportFragmentManager.beginTransaction()
        // Las transiciones se conservan en móvil; en TV se evita que una animación interfiera
        // con el foco del mando y con listas que preservan su posición de scroll.
        if (!isTV) {
            transaction.setCustomAnimations(android.R.anim.fade_in, android.R.anim.fade_out)
        }

        // Ocultar el fragment actual
        supportFragmentManager.findFragmentByTag(tagForId(currentNavId))
            ?.let { transaction.hide(it) }

        // Mostrar (o agregar si es la primera vez) el fragment destino
        if (target.isAdded) {
            transaction.show(target)
        } else {
            transaction.add(R.id.fragment_container, target, tagForId(navId))
        }

        transaction.commit()
        currentNavId = navId

        if (isTV) {
            updateSideMenuSelection(navId)
            collapseSideMenu()
            binding.fragmentContainer.post { focusActiveContent() }
        } else {
            // Sincronizar el ítem seleccionado del BottomNavigation
            if (binding.bottomNavigation.selectedItemId != navId) {
                binding.bottomNavigation.selectedItemId = navId
            }
        }
    }

    private fun fragmentForId(navId: Int): Fragment = when (navId) {
        R.id.nav_channels -> fragmentChannels
        R.id.nav_agenda   -> fragmentAgenda
        else              -> fragmentChannels
    }

    private fun tagForId(navId: Int): String = when (navId) {
        R.id.nav_channels -> TAG_CHANNELS
        R.id.nav_agenda   -> TAG_AGENDA
        else              -> TAG_CHANNELS
    }

    // ==================== BACK HANDLER ====================

    /**
     * Lógica de back unificada para móvil y TV:
     *
     * 1. Si el fragment visible tiene su propio manejo de back → delegar
     * 2. Si no estamos en Canales → volver a Canales (sección raíz)
     * 3. Si ya estamos en Canales → confirmar salida con diálogo
     *
     * Para TV también se intercepta KEYCODE_BACK en dispatchKeyEvent
     * antes de que cualquier vista lo consuma.
     */
    private fun setupBackHandler() {
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                handleBack()
            }
        })
    }

    private fun handleBack() {
        // 1. Intentar que el fragment activo maneje el back (ej: WebView con historial)
        val activeFragment = supportFragmentManager.findFragmentByTag(tagForId(currentNavId))
        if (activeFragment is BackHandler && activeFragment.handleBack()) return

        // 2. Si el menú lateral de TV está expandido, colapsarlo
        if (isTV && isSideMenuExpanded()) {
            focusActiveContent()
            collapseSideMenu()
            return
        }

        // 3. Si no estamos en la sección raíz, volver a Canales
        if (currentNavId != R.id.nav_channels) {
            navigateTo(R.id.nav_channels)
            return
        }

        // 4. Estamos en la raíz → confirmar salida
        showExitDialog()
    }

    private fun showExitDialog() {
        AlertDialog.Builder(this)
            .setTitle("Salir de AngulismoTV")
            .setMessage("¿Querés cerrar la aplicación?")
            .setPositiveButton("Salir") { _, _ -> finish() }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    // ==================== TV KEY DISPATCH ====================

    /**
     * Para TV interceptamos el back a nivel de Activity antes de que
     * cualquier View o Fragment lo consuma — mismo patrón que UnifiedPlayerActivity.
     */
    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        if (!isTV) return super.dispatchKeyEvent(event)
        if (event.action != KeyEvent.ACTION_DOWN) return super.dispatchKeyEvent(event)

        if (event.keyCode == KeyEvent.KEYCODE_BACK) {
            handleBack()
            return true
        }

        // Desde el rail, la flecha derecha entra a la sección actual sin exigir otro OK.
        if (event.keyCode == KeyEvent.KEYCODE_DPAD_RIGHT && anySideMenuItemFocused()) {
            focusActiveContent()
            collapseSideMenu()
            return true
        }

        return super.dispatchKeyEvent(event)
    }

    // ==================== SIDE MENU (TV) ====================

    private fun setupSideMenu() {
        collapseSideMenu(animate = false)

        setupSideMenuItem(binding.menuChannels, binding.menuChannelsText, R.id.nav_channels)
        setupSideMenuItem(binding.menuAgenda, binding.menuAgendaText, R.id.nav_agenda)
        updateSideMenuSelection(currentNavId)
    }

    private fun setupSideMenuItem(container: LinearLayout, label: TextView, navId: Int) {
        label.visibility = View.GONE
        container.isFocusable = true
        container.isFocusableInTouchMode = true
        container.isClickable = true
        container.setOnFocusChangeListener { _, hasFocus ->
            if (hasFocus) {
                expandSideMenu()
                setSideMenuLabelsVisible(true)
            } else {
                // Esperar al siguiente ciclo para no colapsar entre dos opciones del propio rail.
                container.post {
                    if (!anySideMenuItemFocused()) collapseSideMenu()
                }
            }
        }
        container.setOnClickListener { navigateTo(navId) }
    }

    private fun setSideMenuLabelsVisible(visible: Boolean) {
        val showLabels = visible && anySideMenuItemFocused()
        binding.menuChannelsText.visibility = if (showLabels) View.VISIBLE else View.GONE
        binding.menuAgendaText.visibility = if (showLabels) View.VISIBLE else View.GONE
    }

    private fun updateSideMenuSelection(navId: Int) {
        listOf(
            binding.menuChannels to R.id.nav_channels,
            binding.menuAgenda to R.id.nav_agenda
        ).forEach { (view, id) ->
            val selected = id == navId
            view.isSelected = selected
            view.refreshDrawableState()
            val iconSlot = view.getChildAt(0) as? android.widget.FrameLayout
            val icon = iconSlot?.getChildAt(0) as? android.widget.ImageView
            icon?.setColorFilter(
                androidx.core.content.ContextCompat.getColor(
                    this,
                    if (selected) R.color.accent else R.color.text_secondary
                )
            )
        }
    }

    private fun anySideMenuItemFocused(): Boolean =
        binding.menuChannels.hasFocus() || binding.menuAgenda.hasFocus()

    private fun isSideMenuExpanded(): Boolean = binding.sideMenu.layoutParams.width >= sideMenuExpandedWidth

    private fun expandSideMenu() {
        setSideMenuLabelsVisible(true)
        setSideMenuWidth(sideMenuExpandedWidth)
    }

    private fun collapseSideMenu(animate: Boolean = true) {
        // Se conserva el parámetro para las llamadas existentes; el rail ya no anima su ancho.
        setSideMenuLabelsVisible(false)
        setSideMenuWidth(sideMenuCollapsedWidth)
    }

    private fun setSideMenuWidth(width: Int) {
        val params = binding.sideMenu.layoutParams
        if (params.width != width) {
            params.width = width
            binding.sideMenu.layoutParams = params
        }
    }

    private fun setMainContentInset(inset: Int) {
        val params = binding.mainContainer.layoutParams as android.widget.FrameLayout.LayoutParams
        if (params.marginStart != inset) {
            params.marginStart = inset
            binding.mainContainer.layoutParams = params
        }
    }

    private fun setupTvHeader() {
        val params = binding.logoImage.layoutParams as android.widget.FrameLayout.LayoutParams
        params.width = dp(164)
        params.height = dp(42)
        params.gravity = Gravity.START or Gravity.CENTER_VERTICAL
        params.marginStart = dp(24)
        binding.logoImage.layoutParams = params
    }

    private fun setupMobileHeader() {
        val params = binding.logoImage.layoutParams as android.widget.FrameLayout.LayoutParams
        params.width = android.view.ViewGroup.LayoutParams.MATCH_PARENT
        params.height = dp(36)
        params.gravity = Gravity.CENTER
        params.marginStart = 0
        binding.logoImage.layoutParams = params
    }

    private fun focusActiveContent() {
        val activeFragment = supportFragmentManager.findFragmentByTag(tagForId(currentNavId)) ?: return
        activeFragment.view?.post {
            when (currentNavId) {
                R.id.nav_channels -> {
                    // Espera a que RecyclerView tenga sus elementos adjuntos antes de enfocar.
                    // Así se evita dejar el foco en un contenedor vacío al volver desde Agenda.
                    val channelsFragment = activeFragment as? ChannelsFragment
                    if (channelsFragment != null) {
                        channelsFragment.requestTvFocus()
                    } else {
                        activeFragment.view?.findViewById<RecyclerView>(R.id.channels_recycler)?.requestFocus()
                    }
                }
                R.id.nav_agenda -> activeFragment.view?.findViewById<View>(R.id.web_view)?.requestFocus()
            }
        }
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density + 0.5f).toInt()

    // ==================== BOTTOM NAVIGATION (MÓVIL) ====================

    private fun setupBottomNavigation() {
        binding.bottomNavigation.setOnItemSelectedListener { item ->
            // Evitar re-navegación al mismo destino
            if (item.itemId != currentNavId) {
                navigateTo(item.itemId)
            }
            true
        }
    }

    // ==================== DATA LOADING ====================

    private fun loadAllChannels() {
        channelsLoading = true
        fragmentChannels.onLoadStarted()
        lifecycleScope.launch {
            val result = ChannelRepository.loadAll()
            allChannels = result.channels
            lastLoadResult = result
            channelsLoading = false
            fragmentChannels.showResult(result)
            Log.d(TAG, "Canales cargados: ${allChannels.size} (fallo=${result.failed})")
        }
    }

    // ==================== PUBLIC API ====================

    fun getChannels(): List<Channel> = allChannels

    fun isLoadingChannels(): Boolean = channelsLoading

    fun getLoadResult(): LoadResult? = lastLoadResult

    /** Vuelve a pedir la lista de canales (botón Reintentar y deslizar para actualizar). */
    fun reloadChannels() = loadAllChannels()

    // ==================== COMPANION ====================

    companion object {
        private const val TAG          = "MainActivity"
        private const val TAG_CHANNELS = "fragment_channels"
        private const val TAG_AGENDA   = "fragment_agenda"
    }
}

/**
 * Interface que pueden implementar los Fragments para manejar
 * el botón Back internamente (ej: WebView con historial de navegación).
 *
 * Retornar true significa "yo lo manejé, no hagas nada más".
 * Retornar false delega el back a MainActivity.
 */
interface BackHandler {
    fun handleBack(): Boolean
}