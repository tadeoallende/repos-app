package com.angulismotv

import android.animation.ValueAnimator
import android.content.res.ColorStateList
import android.os.Bundle
import android.util.Log
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.view.animation.DecelerateInterpolator
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.animation.doOnEnd
import androidx.core.content.ContextCompat
import androidx.core.view.updateLayoutParams
import androidx.core.widget.ImageViewCompat
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import com.angulismotv.databinding.ActivityMainBinding
import com.angulismotv.fragments.AgendaFragment
import com.angulismotv.fragments.ChannelsFragment
import com.angulismotv.fragments.ChannelsScreen
import com.angulismotv.fragments.ChannelsTvFragment
import com.angulismotv.fragments.RailContent
import com.angulismotv.data.ChannelRepository
import com.angulismotv.data.LoadResult
import com.angulismotv.models.Channel
import com.angulismotv.utils.DeviceHelper
import com.angulismotv.utils.UpdateManager
import com.bumptech.glide.Glide
import kotlinx.coroutines.launch

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private var allChannels = listOf<Channel>()
    private var channelsLoading = true
    private var lastLoadResult: LoadResult? = null
    private var isTV = false

    // ── Navegación ──────────────────────────────────────────────────────────
    // Sección activa actual — arranca siempre en Canales
    private var currentNavId: Int = R.id.nav_channels

    // Instancias únicas de cada fragment: se crean una vez y se reusan con
    // show/hide para preservar estado (scroll, datos cargados, etc.)
    private val fragmentChannels: Fragment by lazy {
        if (isTV) ChannelsTvFragment() else ChannelsFragment()
    }
    private val channelsScreen: ChannelsScreen get() = fragmentChannels as ChannelsScreen
    private val fragmentAgenda   by lazy { AgendaFragment() }

    // ────────────────────────────────────────────────────────────────────────

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        isTV = DeviceHelper.isTV(this)

        Glide.with(this)
            .load(R.drawable.logo2)
            .placeholder(android.R.drawable.ic_menu_gallery)
            .error(android.R.drawable.ic_menu_gallery)
            .into(binding.logoImage)

        setupNavigation()
        setupBackHandler()
        loadAllChannels()

        // Check de actualizaciones (silencioso — solo muestra diálogo si hay novedad)
        UpdateManager(this).checkForUpdates(silent = true)
    }

    // ==================== NAVEGACIÓN ====================

    private fun setupNavigation() {
        // Mostrar el fragment inicial sin animación
        supportFragmentManager.beginTransaction()
            .add(R.id.fragment_container, fragmentChannels, TAG_CHANNELS)
            .commit()

        if (isTV) {
            binding.bottomNavigation.visibility = View.GONE
            binding.sideMenu.visibility = View.VISIBLE
            setupRail()
        } else {
            binding.sideMenu.visibility = View.GONE
            binding.bottomNavigation.visibility = View.VISIBLE
            setupBottomNavigation()
        }
    }

    /**
     * Navega a la sección indicada por navId.
     * - Reutiliza instancias existentes (show/hide) en vez de recrear fragments.
     * - En TV colapsa el menú lateral al confirmar la navegación.
     */
    private fun navigateTo(navId: Int) {
        if (navId == currentNavId) {
            // Ya estamos aquí — en TV se cierra el menú y el foco vuelve al contenido
            if (isTV) {
                collapseRail()
                focusContent()
            }
            return
        }

        val target = fragmentForId(navId)
        val transaction = supportFragmentManager.beginTransaction()
            .setCustomAnimations(android.R.anim.fade_in, android.R.anim.fade_out)

        // Ocultar el fragment actual
        supportFragmentManager.findFragmentByTag(tagForId(currentNavId))
            ?.let { transaction.hide(it) }

        // Mostrar (o agregar si es la primera vez) el fragment destino
        if (target.isAdded) {
            transaction.show(target)
        } else {
            transaction.add(R.id.fragment_container, target, tagForId(navId))
        }

        transaction.commit()
        currentNavId = navId

        if (isTV) {
            collapseRail()
            updateRailSelection()
        } else {
            // Sincronizar el ítem seleccionado del BottomNavigation
            if (binding.bottomNavigation.selectedItemId != navId) {
                binding.bottomNavigation.selectedItemId = navId
            }
        }
    }

    private fun fragmentForId(navId: Int): Fragment = when (navId) {
        R.id.nav_channels -> fragmentChannels
        R.id.nav_agenda   -> fragmentAgenda
        else              -> fragmentChannels
    }

    private fun tagForId(navId: Int): String = when (navId) {
        R.id.nav_channels -> TAG_CHANNELS
        R.id.nav_agenda   -> TAG_AGENDA
        else              -> TAG_CHANNELS
    }

    // ==================== BACK HANDLER ====================

    /**
     * Lógica de back unificada para móvil y TV:
     *
     * 1. Si el fragment visible tiene su propio manejo de back → delegar
     * 2. Si no estamos en Canales → volver a Canales (sección raíz)
     * 3. Si ya estamos en Canales → confirmar salida con diálogo
     *
     * Para TV también se intercepta KEYCODE_BACK en dispatchKeyEvent
     * antes de que cualquier vista lo consuma.
     */
    private fun setupBackHandler() {
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                handleBack()
            }
        })
    }

    private fun handleBack() {
        // 1. Intentar que el fragment activo maneje el back (búsqueda abierta, WebView con historial…)
        val activeFragment = supportFragmentManager.findFragmentByTag(tagForId(currentNavId))
        if (activeFragment is BackHandler && activeFragment.handleBack()) return

        if (isTV) {
            // 2. TV: desde el contenido, Atrás lleva primero al menú lateral
            if (!isRailFocused()) {
                focusRail()
                return
            }
            // 3. Ya en el menú: si no es la sección raíz, volver a Canales; si lo es, salir
            if (currentNavId != R.id.nav_channels) {
                navigateTo(R.id.nav_channels)
                focusRail()
                return
            }
            showExitDialog()
            return
        }

        // Móvil: si no estamos en la sección raíz, volver a Canales; si lo estamos, confirmar salida
        if (currentNavId != R.id.nav_channels) {
            navigateTo(R.id.nav_channels)
            return
        }
        showExitDialog()
    }

    private fun showExitDialog() {
        AlertDialog.Builder(this)
            .setTitle("Salir de AngulismoTV")
            .setMessage("¿Querés cerrar la aplicación?")
            .setPositiveButton("Salir") { _, _ -> finish() }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    // ==================== TV KEY DISPATCH ====================

    /**
     * Para TV interceptamos el back a nivel de Activity antes de que
     * cualquier View o Fragment lo consuma — mismo patrón que UnifiedPlayerActivity.
     */
    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        if (!isTV) return super.dispatchKeyEvent(event)
        if (event.action != KeyEvent.ACTION_DOWN) return super.dispatchKeyEvent(event)

        when (event.keyCode) {
            KeyEvent.KEYCODE_DPAD_LEFT,
            KeyEvent.KEYCODE_DPAD_RIGHT,
            KeyEvent.KEYCODE_DPAD_UP,
            KeyEvent.KEYCODE_DPAD_DOWN,
            KeyEvent.KEYCODE_DPAD_CENTER -> markUserNavigated()
            KeyEvent.KEYCODE_BACK -> {
                handleBack()
                return true
            }
        }
        return super.dispatchKeyEvent(event)
    }

    // ==================== MENÚ LATERAL (TV) ====================

    /**
     * Menú compacto de íconos que se despliega por encima del contenido cuando recibe foco.
     * Solo cambia su propio ancho: el contenido tiene un margen fijo y no se vuelve a medir.
     */
    private class RailItem(
        val container: LinearLayout,
        val icon: ImageView,
        val label: TextView,
        val indicator: View,
        val navId: Int?  // null = acción (Buscar), no una sección
    )

    private lateinit var railItems: List<RailItem>
    private var railExpanded = false
    private var railAnimator: ValueAnimator? = null

    /** Falso hasta la primera tecla del control: evita que el menú se despliegue solo al abrir la app. */
    private var userNavigated = false

    private fun setupRail() {
        val collapsed = resources.getDimensionPixelSize(R.dimen.rail_collapsed)
        binding.mainContainer.updateLayoutParams<ViewGroup.MarginLayoutParams> { marginStart = collapsed }
        binding.headerContainer.visibility = View.GONE
        binding.sideMenu.updateLayoutParams<ViewGroup.LayoutParams> { width = collapsed }

        railItems = listOf(
            RailItem(binding.menuSearch, binding.menuSearchIcon, binding.menuSearchText, binding.menuSearchIndicator, null),
            RailItem(binding.menuChannels, binding.menuChannelsIcon, binding.menuChannelsText, binding.menuChannelsIndicator, R.id.nav_channels),
            RailItem(binding.menuAgenda, binding.menuAgendaIcon, binding.menuAgendaText, binding.menuAgendaIndicator, R.id.nav_agenda)
        )
        railItems.forEach {
            setupRailItem(it)
            it.container.isFocusable = false
            it.container.isFocusableInTouchMode = false
        }
        updateRailSelection()
    }

    /** Se habilita con el primer uso del control remoto (ver [userNavigated]). */
    private fun enableRailFocus() {
        railItems.forEach {
            it.container.isFocusable = true
            it.container.isFocusableInTouchMode = true
        }
    }

    private fun setupRailItem(item: RailItem) {
        item.container.setOnFocusChangeListener { _, hasFocus ->
            if (hasFocus) {
                if (userNavigated) expandRail()
            } else {
                // Al pasar de un ítem a otro hay un instante sin foco: se decide después de que se asiente
                binding.sideMenu.post { if (!isRailFocused()) collapseRail() }
            }
        }

        item.container.setOnClickListener { onRailItemSelected(item) }

        // Derecha en el menú: se pasa al contenido
        item.container.setOnKeyListener { _, keyCode, event ->
            event.action == KeyEvent.ACTION_DOWN && keyCode == KeyEvent.KEYCODE_DPAD_RIGHT && focusContent()
        }
    }

    private fun onRailItemSelected(item: RailItem) {
        val navId = item.navId
        if (navId == null) {
            // Buscar: se muestra la lista de canales y se abre el buscador
            if (currentNavId != R.id.nav_channels) navigateTo(R.id.nav_channels)
            collapseRail()
            binding.sideMenu.post { (fragmentChannels as? ChannelsTvFragment)?.openSearch() }
            return
        }
        navigateTo(navId)
        binding.sideMenu.post { focusContent() }
    }

    private fun updateRailSelection() {
        railItems.forEach { item ->
            val selected = item.navId != null && item.navId == currentNavId
            item.container.isActivated = selected
            item.indicator.visibility = if (selected) View.VISIBLE else View.INVISIBLE
            val tint = ContextCompat.getColor(this, if (selected) R.color.text_primary else R.color.text_secondary)
            ImageViewCompat.setImageTintList(item.icon, ColorStateList.valueOf(tint))
        }
    }

    private fun markUserNavigated() {
        if (userNavigated) return
        userNavigated = true
        enableRailFocus()
    }

    private fun isRailFocused(): Boolean = railItems.any { it.container.hasFocus() }

    private fun expandRail() = animateRail(expand = true)

    private fun collapseRail() = animateRail(expand = false)

    private fun animateRail(expand: Boolean) {
        if (railExpanded == expand) return
        railExpanded = expand

        if (expand) railItems.forEach { it.label.visibility = View.VISIBLE }

        val target = resources.getDimensionPixelSize(if (expand) R.dimen.rail_expanded else R.dimen.rail_collapsed)
        railAnimator?.cancel()
        railAnimator = ValueAnimator.ofInt(binding.sideMenu.width, target).apply {
            duration = RAIL_ANIM_MS
            interpolator = DecelerateInterpolator()
            addUpdateListener { anim ->
                binding.sideMenu.updateLayoutParams<ViewGroup.LayoutParams> { width = anim.animatedValue as Int }
            }
            doOnEnd { if (!railExpanded) railItems.forEach { it.label.visibility = View.GONE } }
            start()
        }
    }

    /** Pasa el foco al contenido de la sección activa (último canal visto o el primero). */
    private fun focusContent(): Boolean {
        val active = supportFragmentManager.findFragmentByTag(tagForId(currentNavId))
        return (active as? RailContent)?.requestContentFocus() ?: false
    }

    // ==================== BOTTOM NAVIGATION (MÓVIL) ====================

    private fun setupBottomNavigation() {
        binding.bottomNavigation.setOnItemSelectedListener { item ->
            // Evitar re-navegación al mismo destino
            if (item.itemId != currentNavId) {
                navigateTo(item.itemId)
            }
            true
        }
    }

    // ==================== DATA LOADING ====================

    private fun loadAllChannels() {
        channelsLoading = true
        channelsScreen.onLoadStarted()
        lifecycleScope.launch {
            val result = ChannelRepository.loadAll(applicationContext)
            allChannels = result.channels
            lastLoadResult = result
            channelsLoading = false
            channelsScreen.showResult(result)
            Log.d(TAG, "Canales cargados: ${allChannels.size} (fallo=${result.failed})")
        }
    }

    // ==================== PUBLIC API ====================

    fun getChannels(): List<Channel> = allChannels

    fun isLoadingChannels(): Boolean = channelsLoading

    fun getLoadResult(): LoadResult? = lastLoadResult

    /** True si ya se usó el control remoto (el foco inicial del contenido no debe pisar esa elección). */
    fun userHasNavigated(): Boolean = userNavigated

    /** Lleva el foco al menú lateral (sale por el borde izquierdo del contenido). */
    fun focusRail() {
        if (!isTV) return
        markUserNavigated()
        railItems.firstOrNull { it.navId == currentNavId }?.container?.requestFocus()
    }

    /** Vuelve a pedir la lista de canales (botón Reintentar y deslizar para actualizar). */
    fun reloadChannels() = loadAllChannels()

    // ==================== COMPANION ====================

    companion object {
        private const val TAG          = "MainActivity"
        private const val RAIL_ANIM_MS = 180L
        private const val TAG_CHANNELS = "fragment_channels"
        private const val TAG_AGENDA   = "fragment_agenda"
    }
}

/**
 * Interface que pueden implementar los Fragments para manejar
 * el botón Back internamente (ej: WebView con historial de navegación).
 *
 * Retornar true significa "yo lo manejé, no hagas nada más".
 * Retornar false delega el back a MainActivity.
 */
interface BackHandler {
    fun handleBack(): Boolean
}