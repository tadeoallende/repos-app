package com.angulismotv.fragments

import com.angulismotv.data.LoadResult

/** Pantalla de canales (móvil o TV): la activity le avisa cómo va la carga de la lista. */
interface ChannelsScreen {
    fun onLoadStarted()
    fun showResult(result: LoadResult)
}

/** Contenido que puede recibir el foco cuando se sale del menú lateral hacia la derecha. */
interface RailContent {
    /** @return true si pudo tomar el foco. */
    fun requestContentFocus(): Boolean
}
