package com.angulismotv

import android.content.pm.ActivityInfo
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.Editable
import android.text.TextWatcher
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.exoplayer2.DefaultLoadControl
import com.google.android.exoplayer2.ExoPlayer
import com.google.android.exoplayer2.MediaItem
import com.google.android.exoplayer2.PlaybackException
import com.google.android.exoplayer2.Player
import com.google.android.exoplayer2.source.dash.DashMediaSource
import com.google.android.exoplayer2.source.ProgressiveMediaSource
import com.google.android.exoplayer2.source.hls.HlsMediaSource
import com.google.android.exoplayer2.ui.PlayerView
import com.angulismotv.adapters.SideChannelsAdapter
import com.angulismotv.player.CastController
import com.angulismotv.player.CastStream
import com.angulismotv.player.StreamUtils
import com.angulismotv.player.WebViewPlayerBridge
import com.angulismotv.player.WebViewScripts
import com.angulismotv.player.applyPlayerSettings
import com.angulismotv.utils.NetworkUtils
import com.angulismotv.utils.loadChannelLogo
import com.angulismotv.adapters.CategoriesAdapter
import com.angulismotv.adapters.ChannelsAdapter
import com.angulismotv.models.Channel
import com.angulismotv.models.StreamType
import com.angulismotv.network.HttpClient
import com.angulismotv.utils.DeviceHelper
import com.google.android.exoplayer2.ext.okhttp.OkHttpDataSource

class UnifiedPlayerActivity : AppCompatActivity() {

    // ==================== VIEWS ====================
    private lateinit var btnMenu: ImageButton
    private lateinit var playerView: PlayerView
    private lateinit var playerContainer: FrameLayout
    private lateinit var webView: WebView
    private lateinit var webViewTouchBlocker: View
    private lateinit var progressBar: ProgressBar
    private lateinit var errorText: TextView
    private lateinit var channelNameOverlay: TextView
    private lateinit var controlsOverlay: View
    private lateinit var bottomControls: View
    private lateinit var btnRewind: ImageButton
    private lateinit var btnForward: ImageButton
    private lateinit var btnPlayPause: ImageButton
    private lateinit var btnClose: ImageButton
    private lateinit var btnOptions: ImageButton
    private lateinit var mediaRouteButton: ImageButton
    private lateinit var channelLogo: ImageView
    private lateinit var channelNameText: TextView

    // Panel lateral
    private lateinit var channelsPanelContainer: LinearLayout
    private lateinit var panelMenuColumn: LinearLayout
    private lateinit var panelContentColumn: LinearLayout
    private lateinit var channelsList: RecyclerView
    private lateinit var sideChannelsAdapter: SideChannelsAdapter
    private lateinit var btnClosePanel: ImageButton
    private lateinit var contentTitle: TextView
    private lateinit var channelsCountText: TextView

    // Búsqueda
    private lateinit var btnSearchTrigger: LinearLayout
    private lateinit var searchInputContainer: View
    private lateinit var menuSearchInput: EditText
    private lateinit var menuSearchResults: RecyclerView
    private lateinit var searchEmptyText: TextView
    private lateinit var searchAdapter: ChannelsAdapter

    // Categorías
    private lateinit var menuCategoriesList: RecyclerView
    private lateinit var categoriesAdapter: CategoriesAdapter

    // TV-only zapping overlay
    private var zappingOverlay: LinearLayout? = null
    private var zappingLogo: ImageView? = null
    private var zappingChannelName: TextView? = null

    // ==================== STATE ====================
    private var exoPlayer: ExoPlayer? = null
    private lateinit var webBridge: WebViewPlayerBridge
    private lateinit var cast: CastController
    private var isTV = false
    private var currentChannel: Channel? = null
    private var controlsVisible = false
    // Conserva el último control enfocado para que el mando no vuelva siempre al inicio.
    private var lastFocusedControlId: Int = View.NO_ID
    private var isPanelOpen = false
    private var currentIsLive = false
    private var streamIsLive = false
    private var currentStreamUrl: String = ""
    private var currentStreamType: String = StreamType.AUTO
    private var isZapping = false
    private var currentCategory = "todos"
    private var isSearchActive = false

    // RECONEXION
    private var playerGeneration = 0
    private var reconnectAttempts = 0
    private val MAX_RECONNECT_ATTEMPTS = 10
    private val RECONNECT_DELAYS = longArrayOf(500, 1_000, 2_000, 3_000, 5_000, 8_000, 12_000)

    // WATCHDOG
    private var watchdogRunnable: Runnable? = null
    private var lastKnownPosition: Long = -1L
    private var frozenPositionCount: Int = 0
    private val WATCHDOG_INTERVAL_MS = 5_000L
    private val FROZEN_TICKS_BEFORE_RECONNECT = 2

    // Channels
    private var allChannels: List<Channel> = emptyList()
    private var currentChannelIndex: Int = 0
    private var currentFilteredChannels: List<Channel> = emptyList()

    // Handlers
    private val mainHandler = Handler(Looper.getMainLooper())
    private var hideControlsRunnable: Runnable? = null
    private var zapRunnable: Runnable? = null
    private var stableStreamRunnable: Runnable? = null
    private var reconnectRunnable: Runnable? = null

    private lateinit var insetsController: WindowInsetsControllerCompat

    // ==================== LIFECYCLE ====================

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (!DeviceHelper.isTV(this)) enableImmersiveFullscreen()
        setContentView(R.layout.activity_unified_player)

        isTV = DeviceHelper.isTV(this)
        bindViews()
        requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE

        webBridge = WebViewPlayerBridge(
            webView = webView,
            handler = mainHandler,
            isIframeActive = { currentStreamType == StreamType.IFRAME },
            onStateChanged = ::updateWebViewControls
        )
        cast = CastController(
            activity = this,
            button = mediaRouteButton,
            handler = mainHandler,
            currentStream = {
                if (currentStreamUrl.isEmpty()) null
                else CastStream(currentStreamUrl, currentStreamType, currentChannel?.name ?: "Canal")
            },
            onCastStarted = { exoPlayer?.pause() }
        )
        cast.setup(isTV)
        setupWebViewForTV()
        setupWebViewTouchBlocker()
        setupSidePanel()
        setupControls()
        loadChannelData()
    }

    override fun onResume() {
        super.onResume()
        if (!isTV) enableImmersiveFullscreen()
        cast.startDiscovery()
        webView.onResume()
        exoPlayer?.let { player ->
            if (!player.isPlaying && player.playbackState == Player.STATE_READY) {
                player.play()
            }
        }
    }

    override fun onPause() {
        super.onPause()
        if (!isZapping) exoPlayer?.pause()
        cast.stopDiscovery()
        webView.onPause()
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus && !isTV) enableImmersiveFullscreen()
    }

    override fun onStop() {
        super.onStop()
        exoPlayer?.pause()
    }

    override fun onDestroy() {
        super.onDestroy()
        playerGeneration++
        mainHandler.removeCallbacksAndMessages(null)
        releasePlayer()

        // Limpiar WebView inmediatamente (no hace operaciones de red)
        webView.apply {
            stopLoading()
            webViewClient = WebViewClient()
            loadUrl("about:blank")
            clearHistory()
            clearCache(true)
            onPause()
            removeAllViews()
            destroy()
        }
    }

    override fun onBackPressed() {
        if (!isTV) super.onBackPressed()
    }

    // ==================== BIND VIEWS ====================

    private fun bindViews() {
        btnMenu = findViewById(R.id.btn_menu)
        playerView = findViewById(R.id.player_view)
        playerContainer = findViewById(R.id.player_container)
        if (isTV) {
            // Superficie de foco de respaldo cuando el stream se reproduce dentro de WebView.
            playerContainer.isFocusable = true
            playerContainer.isFocusableInTouchMode = true
        }
        webView = findViewById(R.id.web_view)
        webViewTouchBlocker = findViewById(R.id.web_view_touch_blocker)
        progressBar = findViewById(R.id.progress_bar)
        errorText = findViewById(R.id.error_text)
        channelNameOverlay = findViewById(R.id.channel_name_overlay)
        controlsOverlay = findViewById(R.id.controls_overlay)
        bottomControls = findViewById(R.id.bottom_controls)
        btnRewind = findViewById(R.id.btn_rewind)
        btnForward = findViewById(R.id.btn_forward)
        btnPlayPause = findViewById(R.id.btn_play_pause)
        btnClose = findViewById(R.id.btn_close_player)
        btnOptions = findViewById(R.id.btn_options)
        mediaRouteButton = findViewById(R.id.media_route_button)
        channelLogo = findViewById(R.id.channel_logo)
        channelNameText = findViewById(R.id.channel_name)
        channelsPanelContainer = findViewById(R.id.channels_panel_container)
        channelsList = findViewById(R.id.channels_list)
        panelMenuColumn = findViewById(R.id.panel_menu_column)
        panelContentColumn = findViewById(R.id.panel_content_column)
        btnClosePanel = findViewById(R.id.btn_close_panel)
        contentTitle = findViewById(R.id.content_title)
        channelsCountText = findViewById(R.id.channels_count)
        btnSearchTrigger = findViewById(R.id.btn_search_trigger)
        searchInputContainer = findViewById(R.id.search_input_container)
        menuSearchInput = findViewById(R.id.menu_search_input)
        menuSearchResults = findViewById(R.id.menu_search_results)
        searchEmptyText = findViewById(R.id.search_empty_text)
        menuCategoriesList = findViewById(R.id.menu_categories_list)

        if (isTV) {
            zappingOverlay = findViewById(R.id.zapping_overlay)
            zappingLogo = findViewById(R.id.zapping_logo)
            zappingChannelName = findViewById(R.id.zapping_channel_name)
        }
    }

    // ==================== FULLSCREEN ====================

    private fun enableImmersiveFullscreen() {
        WindowCompat.setDecorFitsSystemWindows(window, false)
        insetsController = WindowInsetsControllerCompat(window, window.decorView).apply {
            hide(WindowInsetsCompat.Type.systemBars())
            systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        }
        @Suppress("DEPRECATION")
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.R) {
            window.decorView.systemUiVisibility = (
                    View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                            or View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                            or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                            or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                            or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                            or View.SYSTEM_UI_FLAG_FULLSCREEN
                    )
        }
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
    }

    // ==================== WEBVIEW ====================

    private fun setupWebViewForTV() {
        if (!isTV) return
        webView.apply {
            isFocusable = false
            isFocusableInTouchMode = false
            isClickable = false
            isLongClickable = false
            applyPlayerSettings()
        }
    }

    private fun setupWebViewTouchBlocker() {
        webViewTouchBlocker.apply {
            setOnTouchListener { _, event ->
                if (!isTV && event.action == MotionEvent.ACTION_UP) {
                    if (controlsVisible) hideControls() else showControlsTemporarily()
                }
                true
            }
            visibility = View.GONE
        }
    }

    /**
     * Actualiza los controles según el estado del WebView
     */
    private fun updateWebViewControls() {
        runOnUiThread {
            if (currentStreamType == StreamType.IFRAME) {
                if (isTV && webBridge.isControllable) {
                    // TV: Mostrar controles traducidos
                    btnPlayPause.visibility = View.VISIBLE
                    btnPlayPause.setImageResource(if (webBridge.isPlaying) R.drawable.ic_pause else R.drawable.ic_play)

                    val showSeek = webBridge.duration > 0
                    btnRewind.visibility = if (showSeek) View.VISIBLE else View.GONE
                    btnForward.visibility = if (showSeek) View.VISIBLE else View.GONE

                    // Habilitar foco para navegación con D-Pad
                    if (isTV) {
                        btnPlayPause.isFocusable = true
                        btnRewind.isFocusable = showSeek
                        btnForward.isFocusable = showSeek
                    }
                } else if (!isTV) {
                    // Móvil: Ocultar controles nativos, usar los del iframe
                    btnPlayPause.visibility = View.GONE
                    btnRewind.visibility = View.GONE
                    btnForward.visibility = View.GONE
                }

                // Actualizar estado de los botones
                btnOptions.visibility = if (hasMultipleOptions()) View.VISIBLE else View.GONE

                if (isTV) {
                    btnMenu.visibility = View.VISIBLE
                    btnMenu.isFocusable = true
                    btnClose.isFocusable = true
                }
            }
        }
    }

    // ==================== SIDE PANEL ====================

    private fun setupSidePanel() {
        if (!isTV) return
        sideChannelsAdapter = SideChannelsAdapter { channel, position -> selectChannelFromSidePanel(channel, position) }
        categoriesAdapter = CategoriesAdapter { categoryKey -> onCategorySelected(categoryKey) }
        channelsList.apply {
            layoutManager = LinearLayoutManager(this@UnifiedPlayerActivity)
            isFocusable = true
            isFocusableInTouchMode = true
            descendantFocusability = ViewGroup.FOCUS_BEFORE_DESCENDANTS
            adapter = sideChannelsAdapter
        }
        menuCategoriesList.apply {
            layoutManager = LinearLayoutManager(this@UnifiedPlayerActivity)
            adapter = categoriesAdapter
        }
        btnSearchTrigger.apply {
            isFocusable = true
            isFocusableInTouchMode = true
            setOnClickListener { activateSearchMode() }
        }
        btnClosePanel.setOnClickListener { closeSidePanel() }
        setupSearchInput()
    }

    private fun activateSearchMode() {
        isSearchActive = true
        searchInputContainer.visibility = View.VISIBLE
        contentTitle.text = "BUSCAR"
        channelsCountText.text = ""
        categoriesAdapter.clearSelection()
        menuSearchInput.text.clear()
        menuSearchResults.visibility = View.GONE
        searchEmptyText.visibility = View.GONE
        channelsList.visibility = View.VISIBLE
        menuSearchInput.post { menuSearchInput.requestFocus() }
    }

    private fun deactivateSearchMode() {
        if (!isSearchActive) return
        isSearchActive = false
        searchInputContainer.visibility = View.GONE
        menuSearchInput.text.clear()
        menuSearchResults.visibility = View.GONE
        searchEmptyText.visibility = View.GONE
        channelsList.visibility = View.VISIBLE
        updateContentTitle()
        updateCategoriesList()
        updateChannelsList(scrollToSelected = true)
    }

    private fun updateContentTitle() {
        contentTitle.text = if (currentCategory == "todos") "TODOS LOS CANALES" else currentCategory.uppercase()
    }

    private fun setupSearchInput() {
        searchAdapter = ChannelsAdapter { channel, _ ->
            val index = allChannels.indexOfFirst { it.name == channel.name }
            if (index != -1) { deactivateSearchMode(); selectChannelFromSidePanel(channel, index) }
        }
        menuSearchResults.apply {
            layoutManager = LinearLayoutManager(this@UnifiedPlayerActivity)
            adapter = searchAdapter
        }
        menuSearchInput.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: Editable?) {
                val query = s?.toString()?.lowercase()?.trim() ?: ""
                if (query.isNotEmpty()) {
                    val results = allChannels.filter { it.name.lowercase().contains(query) }
                    searchAdapter.submitList(results)
                    channelsList.visibility = View.GONE
                    menuSearchResults.visibility = if (results.isNotEmpty()) View.VISIBLE else View.GONE
                    searchEmptyText.visibility = if (results.isEmpty()) View.VISIBLE else View.GONE
                    channelsCountText.text = results.size.toString()
                    contentTitle.text = "RESULTADOS: \"$query\""
                } else {
                    searchAdapter.submitList(emptyList())
                    menuSearchResults.visibility = View.GONE
                    searchEmptyText.visibility = View.GONE
                    channelsList.visibility = View.VISIBLE
                    contentTitle.text = "BUSCAR"
                    channelsCountText.text = ""
                }
            }
        })
        menuSearchInput.setOnEditorActionListener { _, actionId, _ -> actionId == EditorInfo.IME_ACTION_SEARCH }
    }

    private fun updateCategoriesList() {
        if (!::categoriesAdapter.isInitialized || allChannels.isEmpty()) return
        val uniqueCategories = allChannels.mapNotNull { it.category }.filter { it.isNotBlank() }.distinct().sorted()
        val items = mutableListOf(CategoriesAdapter.CategoryItem("todos", "TODOS", allChannels.size))
        uniqueCategories.forEach { key ->
            items.add(CategoriesAdapter.CategoryItem(key, key.uppercase(), allChannels.count { it.category == key }))
        }
        categoriesAdapter.submitList(items, currentCategory)
    }

    private fun updateChannelsList(scrollToSelected: Boolean = false) {
        if (!::sideChannelsAdapter.isInitialized) return
        currentFilteredChannels = if (currentCategory == "todos") allChannels else allChannels.filter { it.category == currentCategory }
        val selectedInFiltered = currentFilteredChannels.indexOfFirst { it.name == currentChannel?.name }
        sideChannelsAdapter.submitList(currentFilteredChannels, selectedInFiltered)
        channelsCountText.text = "${currentFilteredChannels.size}"
        if (scrollToSelected && selectedInFiltered >= 0) {
            channelsList.post { (channelsList.layoutManager as? LinearLayoutManager)?.scrollToPositionWithOffset(selectedInFiltered, 0) }
        }
    }

    private fun onCategorySelected(categoryKey: String) {
        deactivateSearchMode()
        currentCategory = categoryKey
        updateContentTitle()
        updateCategoriesList()
        updateChannelsList(scrollToSelected = true)
        // Entra en la lista de canales de forma determinista: canal actual si pertenece
        // a esta categoría; de lo contrario, primer canal disponible.
        moveFocusToChannelsList()
    }

    private fun handleBackInPanel(): Boolean {
        return when {
            isSearchActive && menuSearchInput.text.isNotEmpty() -> {
                menuSearchInput.text.clear()
                menuSearchInput.post { menuSearchInput.requestFocus() }
                true
            }
            isSearchActive -> { deactivateSearchMode(); btnSearchTrigger.post { btnSearchTrigger.requestFocus() }; true }
            else -> { closeSidePanel(); true }
        }
    }

    // ==================== CONTROLS ====================

    private fun setupControls() {
        btnClose.setOnClickListener { finish() }

        // Configurar listeners para controles de WebView (TV)
        btnPlayPause.setOnClickListener {
            if (currentStreamType == StreamType.IFRAME && isTV) {
                webBridge.control("toggle")
                resetAutoHideTimer()
            } else if (currentStreamType != StreamType.IFRAME) {
                togglePlayPause()
                resetAutoHideTimer()
            }
        }

        btnRewind.setOnClickListener {
            if (currentStreamType == StreamType.IFRAME && isTV && webBridge.isControllable) {
                val newTime = (webBridge.currentTime - 10).coerceAtLeast(0)
                webBridge.control("seek", newTime.toDouble())
                resetAutoHideTimer()
            } else if (currentStreamType != StreamType.IFRAME) {
                if (!currentIsLive && !streamIsLive) {
                    exoPlayer?.seekTo(((exoPlayer?.currentPosition ?: 0) - 10_000).coerceAtLeast(0))
                    resetAutoHideTimer()
                }
            }
        }

        btnForward.setOnClickListener {
            if (currentStreamType == StreamType.IFRAME && isTV && webBridge.isControllable) {
                val newTime = (webBridge.currentTime + 10).coerceAtMost(webBridge.duration)
                webBridge.control("seek", newTime.toDouble())
                resetAutoHideTimer()
            } else if (currentStreamType != StreamType.IFRAME) {
                if (!currentIsLive && !streamIsLive) {
                    val pos = exoPlayer?.currentPosition ?: 0
                    val dur = exoPlayer?.duration ?: 0
                    if (dur > 0) exoPlayer?.seekTo((pos + 10_000).coerceAtMost(dur))
                    resetAutoHideTimer()
                }
            }
        }

        btnMenu.setOnClickListener { if (isTV) { if (isPanelOpen) closeSidePanel() else openSidePanel() } }
        btnMenu.visibility = View.GONE
        btnOptions.setOnClickListener { showOptionsDialog(currentChannel ?: return@setOnClickListener); resetAutoHideTimer() }

        if (isTV) {
            listOf(btnMenu, btnPlayPause, btnRewind, btnForward, btnOptions, btnClose, mediaRouteButton).forEach { control ->
                control.isFocusable = true
                control.isFocusableInTouchMode = true
                control.isClickable = true
                val size = (48 * resources.displayMetrics.density + 0.5f).toInt()
                control.layoutParams = control.layoutParams.apply { width = size; height = size }
                control.setOnFocusChangeListener { view, hasFocus ->
                    if (hasFocus) {
                        lastFocusedControlId = view.id
                        if (controlsVisible && !isPanelOpen) resetAutoHideTimer()
                    }
                }
            }
            controlsOverlay.visibility = View.GONE
            bottomControls.visibility = View.GONE
            controlsVisible = false
        } else {
            playerView.setOnClickListener {
                if (controlsVisible) hideControls() else showControlsTemporarily()
            }
        }
    }

    private fun togglePlayPause() {
        val player = exoPlayer ?: return
        if (player.isPlaying) {
            player.pause()
            btnPlayPause.setImageResource(R.drawable.ic_play)
        } else {
            player.play()
            btnPlayPause.setImageResource(R.drawable.ic_pause)
        }
    }

    // ==================== TV KEY HANDLING ====================

    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        if (!isTV) return super.dispatchKeyEvent(event)
        if (event.action != KeyEvent.ACTION_DOWN) return super.dispatchKeyEvent(event)
        val handled = handleTVKey(event.keyCode)
        return if (handled) true else super.dispatchKeyEvent(event)
    }

    private fun handleTVKey(keyCode: Int): Boolean {
        return when (keyCode) {
            KeyEvent.KEYCODE_BACK -> when {
                isPanelOpen -> handleBackInPanel()
                controlsVisible -> { hideControls(); true }
                else -> { finish(); true }
            }
            KeyEvent.KEYCODE_DPAD_UP -> when {
                isPanelOpen -> false
                controlsVisible -> { navigateControlsUp(); true }
                !isZapping -> { changeChannel(-1); true }
                else -> true
            }
            KeyEvent.KEYCODE_DPAD_DOWN -> when {
                isPanelOpen -> false
                controlsVisible -> { navigateControlsDown(); true }
                !isZapping -> { changeChannel(1); true }
                else -> true
            }
            KeyEvent.KEYCODE_DPAD_LEFT -> when {
                isPanelOpen -> {
                    if (isRightPanelFocused()) moveFocusToCategoriesPanel()
                    else closeSidePanel()
                    true
                }
                controlsVisible -> { navigateControlsLeft(); true }
                else -> { openSidePanel(); true }
            }
            KeyEvent.KEYCODE_DPAD_RIGHT -> when {
                isPanelOpen -> {
                    if (!isRightPanelFocused()) { moveFocusToChannelsList(); true }
                    else false
                }
                controlsVisible -> { navigateControlsRight(); true }
                else -> { showControls(); true }
            }
            KeyEvent.KEYCODE_DPAD_CENTER, KeyEvent.KEYCODE_ENTER -> when {
                isPanelOpen -> false
                !controlsVisible -> { showControls(); true }
                else -> { activateFocusedControl(); true }
            }
            KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE -> {
                if (currentStreamType == StreamType.IFRAME) {
                    webBridge.control("toggle")
                } else {
                    togglePlayPause()
                }
                true
            }
            KeyEvent.KEYCODE_MEDIA_PLAY -> {
                if (currentStreamType == StreamType.IFRAME) {
                    webBridge.control("play")
                } else {
                    exoPlayer?.play()
                    btnPlayPause.setImageResource(R.drawable.ic_pause)
                }
                true
            }
            KeyEvent.KEYCODE_MEDIA_PAUSE -> {
                if (currentStreamType == StreamType.IFRAME) {
                    webBridge.control("pause")
                } else {
                    exoPlayer?.pause()
                    btnPlayPause.setImageResource(R.drawable.ic_play)
                }
                true
            }
            KeyEvent.KEYCODE_MEDIA_FAST_FORWARD -> { btnForward.performClick(); true }
            KeyEvent.KEYCODE_MEDIA_REWIND -> { btnRewind.performClick(); true }
            else -> false
        }
    }

    private fun isDescendantFocused(view: View): Boolean {
        val focused = currentFocus ?: return false
        var parent = focused.parent
        while (parent != null) {
            if (parent === view) return true
            parent = (parent as? View)?.parent
        }
        return false
    }

    private fun isRightPanelFocused(): Boolean =
        channelsList.hasFocus() || isDescendantFocused(channelsList) ||
            menuSearchResults.hasFocus() || isDescendantFocused(menuSearchResults)

    private fun moveFocusToCategoriesPanel() {
        // Al volver desde canales, retomamos la categoría activa (o el campo de búsqueda).
        if (isSearchActive) {
            menuSearchInput.requestFocus()
            return
        }
        val position = categoriesAdapter.getPositionForKey(currentCategory).let { if (it >= 0) it else 0 }
        menuCategoriesList.post {
            (menuCategoriesList.layoutManager as? LinearLayoutManager)?.scrollToPositionWithOffset(position, 0)
            menuCategoriesList.post {
                val item = menuCategoriesList.findViewHolderForAdapterPosition(position)?.itemView
                if (item?.requestFocus() != true) menuCategoriesList.requestFocus()
            }
        }
    }

    private fun moveFocusToChannelsList() {
        // Si la búsqueda no tuvo coincidencias, el destino accionable sigue siendo el campo.
        if (isSearchActive && searchEmptyText.visibility == View.VISIBLE) {
            menuSearchInput.requestFocus()
            return
        }
        // En modo búsqueda, derecha lleva a los resultados; en navegación normal, a los canales.
        if (isSearchActive && menuSearchResults.visibility == View.VISIBLE) {
            // La búsqueda usa AsyncListDiffer; esperar a que el primer resultado esté adjunto.
            menuSearchResults.post {
                menuSearchResults.post {
                    val item = if (searchAdapter.itemCount > 0) {
                        menuSearchResults.findViewHolderForAdapterPosition(0)?.itemView
                    } else null
                    if (item?.requestFocus() != true) menuSearchResults.requestFocus()
                }
            }
            return
        }

        val selectedInFiltered = currentFilteredChannels.indexOfFirst { it.name == currentChannel?.name }
        val targetPosition = if (selectedInFiltered >= 0) selectedInFiltered else 0
        channelsList.post {
            val lm = channelsList.layoutManager as? LinearLayoutManager
            lm?.scrollToPositionWithOffset(targetPosition, 0)
            channelsList.post {
                val item = channelsList.findViewHolderForAdapterPosition(targetPosition)?.itemView
                if (item?.requestFocus() != true) channelsList.requestFocus()
            }
        }
    }

    private fun activateFocusedControl() {
        when (currentFocus?.id) {
            R.id.btn_menu -> btnMenu.performClick()
            R.id.btn_play_pause -> btnPlayPause.performClick()
            R.id.btn_rewind -> btnRewind.performClick()
            R.id.btn_forward -> btnForward.performClick()
            R.id.btn_options -> btnOptions.performClick()
            R.id.btn_close_player -> btnClose.performClick()
            else -> requestPreferredControlFocus()
        }
    }

    private fun visibleControls() = listOf(btnMenu, btnRewind, btnPlayPause, btnForward, btnOptions, btnClose).filter { it.visibility == View.VISIBLE && it.isFocusable }

    /** Prioriza el control que el usuario estaba usando; si desapareció para esta fuente,
     * elige uno visible y enfocable como destino seguro. */
    private fun requestPreferredControlFocus() {
        if (!isTV || !controlsVisible || isPanelOpen) return
        val controls = visibleControls()
        if (controls.isEmpty()) {
            playerContainer.requestFocus()
            return
        }
        val preferred = controls.firstOrNull { it.id == lastFocusedControlId } ?: controls.first()
        preferred.requestFocus()
    }
    private fun navigateControlsRight() {
        val controls = visibleControls()
        if (controls.isEmpty()) return
        val index = controls.indexOfFirst { it.hasFocus() }
        controls.getOrNull(if (index < 0) 0 else (index + 1).coerceAtMost(controls.lastIndex))?.requestFocus()
        resetAutoHideTimer()
    }

    private fun navigateControlsLeft() {
        val controls = visibleControls()
        if (controls.isEmpty()) return
        val index = controls.indexOfFirst { it.hasFocus() }
        controls.getOrNull(if (index < 0) 0 else (index - 1).coerceAtLeast(0))?.requestFocus()
        resetAutoHideTimer()
    }

    private fun navigateControlsUp() = navigateControlsLeft()
    private fun navigateControlsDown() = navigateControlsRight()

    // ==================== CHANNEL SELECTION ====================

    private fun selectChannelFromSidePanel(channel: Channel, position: Int) {
        val globalIndex = allChannels.indexOfFirst { it.name == channel.name }
        if (globalIndex == currentChannelIndex) { closeSidePanel(); return }
        closeSidePanel()
        if (!isZapping) zapTo(globalIndex, channel)
    }

    private fun changeChannel(delta: Int) {
        if (allChannels.isEmpty() || isZapping) return
        zapTo((currentChannelIndex + delta).mod(allChannels.size), allChannels[(currentChannelIndex + delta).mod(allChannels.size)])
    }

    private fun zapTo(index: Int, channel: Channel) {
        isZapping = true
        playerGeneration++
        reconnectAttempts = 0
        reconnectRunnable?.let { mainHandler.removeCallbacks(it) }
        reconnectRunnable = null
        stableStreamRunnable?.let { mainHandler.removeCallbacks(it) }

        releasePlayer()

        // Resetear completamente el WebView
        webView.apply {
            stopLoading()
            loadUrl("about:blank")
            clearHistory()
            // Eliminar el bridge anterior si existe
            webBridge.detach()
        }
        webView.visibility = View.GONE

        // Configurar bloqueo táctil según dispositivo
        if (isTV) {
            webViewTouchBlocker.visibility = View.VISIBLE
            lockWebViewFocus()
        } else {
            // Móvil: SIN BLOQUEO TÁCTIL para usar controles del iframe
            webViewTouchBlocker.visibility = View.GONE
            webView.isClickable = true
            webView.isFocusable = true
            webView.isFocusableInTouchMode = true
        }

        // Resetear estado del WebView
        webBridge.reset()
        webBridge.stopMonitor()

        progressBar.visibility = View.VISIBLE
        errorText.visibility = View.GONE

        if (isTV) showZappingOverlay(channel) else showChannelChangeOverlay(channel.name)

        zapRunnable?.let { mainHandler.removeCallbacks(it) }
        zapRunnable = Runnable {
            zappingOverlay?.visibility = View.GONE
            currentChannelIndex = index
            currentChannel = channel
            loadChannelInfo(channel)
            playFirstValidOption(channel)
            mainHandler.postDelayed({ isZapping = false }, 200)
        }
        mainHandler.postDelayed(zapRunnable!!, 300L)
    }

    // ==================== ZAPPING OVERLAY ====================

    private fun showZappingOverlay(channel: Channel) {
        val overlay = zappingOverlay ?: return
        overlay.visibility = View.VISIBLE
        zappingChannelName?.text = channel.name
        zappingLogo?.loadChannelLogo(channel.name, channel.logo)
        overlay.removeCallbacks(hideZappingRunnable)
        overlay.postDelayed(hideZappingRunnable, 2_000)
    }

    private val hideZappingRunnable = Runnable { zappingOverlay?.visibility = View.GONE }

    private fun showChannelChangeOverlay(name: String) {
        channelNameOverlay.text = name
        channelNameOverlay.visibility = View.VISIBLE
        channelNameOverlay.removeCallbacks(null)
        channelNameOverlay.postDelayed({ channelNameOverlay.visibility = View.GONE }, 1_500)
    }

    // ==================== CHANNEL INFO ====================

    private fun loadChannelInfo(channel: Channel) {
        channelNameText.text = channel.name
        channelLogo.loadChannelLogo(channel.name, channel.logo)
    }

    // ==================== PLAYBACK ====================

    private var currentOptionIndex: Int = 0

    private fun playFirstValidOption(channel: Channel) {
        errorText.visibility = View.GONE
        currentOptionIndex = 0
        if (!channel.options.isNullOrEmpty()) {
            tryOption(channel, 0)
        } else {
            val url = channel.streamUrl ?: ""
            val type = channel.streamType ?: StreamType.AUTO
            if (url.isNotEmpty()) {
                currentStreamUrl = url
                currentStreamType = type
                playStream(url, type)
            } else {
                showError("No hay fuentes disponibles")
            }
        }
    }

    private fun tryOption(channel: Channel, optionIndex: Int) {
        val options = channel.options ?: return
        if (optionIndex >= options.size) {
            showError("No se pudo reproducir con ninguna fuente disponible")
            return
        }

        val option = options[optionIndex]
        val url = option.iframe
        val type = StreamUtils.resolveType(url, option.streamType)
        if (url.isEmpty()) {
            tryOption(channel, optionIndex + 1)
            return
        }

        currentStreamUrl = url
        currentStreamType = type
        currentOptionIndex = optionIndex
        android.util.Log.d("OPTION_TRY", "Intentando opción ${optionIndex + 1}/${options.size}: ${option.name} — $url")

        playStream(url, type)
        updateControlsVisibility()

        scheduleOptionFallback(channel, optionIndex)
    }

    private var optionFallbackRunnable: Runnable? = null

    private fun scheduleOptionFallback(channel: Channel, optionIndex: Int) {
        optionFallbackRunnable?.let { mainHandler.removeCallbacks(it) }
        val gen = playerGeneration
        optionFallbackRunnable = Runnable {
            if (playerGeneration != gen || isZapping) return@Runnable
            val player = exoPlayer
            if (player == null || player.playbackState == Player.STATE_IDLE || player.playbackState == Player.STATE_BUFFERING) {
                android.util.Log.w("OPTION_FALLBACK", "Opción ${optionIndex + 1} tardó demasiado, probando la siguiente")
                val nextIndex = optionIndex + 1
                if (nextIndex < (channel.options?.size ?: 0)) {
                    releasePlayer()
                    tryOption(channel, nextIndex)
                }
            }
        }
        mainHandler.postDelayed(optionFallbackRunnable!!, 12_000)
    }

    private fun cancelOptionFallback() {
        optionFallbackRunnable?.let { mainHandler.removeCallbacks(it) }
        optionFallbackRunnable = null
    }

    private fun playStream(url: String, type: String) {
        when (type) {
            StreamType.IFRAME -> showWebView(url)
            StreamType.HLS, StreamType.DASH, StreamType.MP4 -> showExoPlayer(url, type)
            else -> showExoPlayer(url, StreamType.HLS)
        }
    }

    // ==================== WATCHDOG ====================

    private fun startWatchdog(generation: Int) {
        stopWatchdog()
        watchdogRunnable = object : Runnable {
            override fun run() {
                if (playerGeneration != generation || isZapping) return
                val player = exoPlayer ?: return

                if (player.playbackState == Player.STATE_BUFFERING) {
                    frozenPositionCount++
                    if (frozenPositionCount >= 3) {
                        frozenPositionCount = 0
                        scheduleReconnect(currentStreamUrl, currentStreamType, generation)
                        return
                    }
                    mainHandler.postDelayed(this, WATCHDOG_INTERVAL_MS)
                    return
                }

                if (!player.isPlaying) {
                    mainHandler.postDelayed(this, WATCHDOG_INTERVAL_MS)
                    return
                }

                val pos = player.currentPosition
                if (pos == lastKnownPosition && lastKnownPosition >= 0) {
                    frozenPositionCount++
                    if (frozenPositionCount >= FROZEN_TICKS_BEFORE_RECONNECT) {
                        frozenPositionCount = 0
                        lastKnownPosition = -1L
                        scheduleReconnect(currentStreamUrl, currentStreamType, generation)
                        return
                    }
                } else {
                    frozenPositionCount = 0
                    lastKnownPosition = pos
                }
                mainHandler.postDelayed(this, WATCHDOG_INTERVAL_MS)
            }
        }
        mainHandler.postDelayed(watchdogRunnable!!, WATCHDOG_INTERVAL_MS)
    }

    private fun stopWatchdog() {
        watchdogRunnable?.let { mainHandler.removeCallbacks(it) }
        watchdogRunnable = null
        lastKnownPosition = -1L
        frozenPositionCount = 0
    }

    // ==================== EXO PLAYER ====================

    private fun showExoPlayer(url: String, type: String) {
        stableStreamRunnable?.let { mainHandler.removeCallbacks(it) }
        stopWatchdog()
        releasePlayer()

        val myGeneration = playerGeneration

        playerView.visibility = View.VISIBLE
        webView.visibility = View.GONE
        webViewTouchBlocker.visibility = View.GONE
        progressBar.visibility = View.VISIBLE
        errorText.visibility = View.GONE
        currentIsLive = false
        streamIsLive = false
        currentStreamType = type

        if (isTV) {
            playerView.isFocusable = true
            playerView.isFocusableInTouchMode = true
            playerView.requestFocus()
            lockWebViewFocus()
        }

        val loadControl = DefaultLoadControl.Builder()
            .setBufferDurationsMs(15_000, 60_000, 1_500, 5_000)
            .build()

        val dataSource = OkHttpDataSource.Factory(HttpClient.shared)
            .setUserAgent(HttpClient.USER_AGENT)

        val mediaItem = MediaItem.fromUri(Uri.parse(url))

        val mediaSource = when (type) {
            StreamType.DASH -> DashMediaSource.Factory(dataSource).createMediaSource(mediaItem)
            StreamType.MP4 -> ProgressiveMediaSource.Factory(dataSource).createMediaSource(mediaItem)
            else -> {
                HlsMediaSource.Factory(dataSource)
                    .setAllowChunklessPreparation(true)
                    .createMediaSource(mediaItem)
            }
        }

        exoPlayer = ExoPlayer.Builder(this)
            .setLoadControl(loadControl)
            .build()
            .also { player ->
                player.setMediaSource(mediaSource)
                player.prepare()
                player.playWhenReady = true
                playerView.player = player
                playerView.useController = false

                player.addListener(object : Player.Listener {
                    override fun onPlaybackStateChanged(state: Int) {
                        if (playerGeneration != myGeneration) return
                        when (state) {
                            Player.STATE_BUFFERING -> {
                                progressBar.visibility = View.VISIBLE
                                errorText.visibility = View.GONE
                            }
                            Player.STATE_READY -> {
                                progressBar.visibility = View.GONE
                                errorText.visibility = View.GONE
                                currentIsLive = player.isCurrentWindowLive
                                streamIsLive = player.isCurrentWindowLive || player.duration == -1L
                                reconnectAttempts = 0
                                updateControlsVisibility()
                                if (!isTV) showControlsTemporarily()

                                stableStreamRunnable?.let { mainHandler.removeCallbacks(it) }
                                stableStreamRunnable = Runnable {
                                    if (playerGeneration == myGeneration) { reconnectAttempts = 0; errorText.visibility = View.GONE }
                                }
                                mainHandler.postDelayed(stableStreamRunnable!!, 8_000)
                                cancelOptionFallback()
                                startWatchdog(myGeneration)
                            }
                            Player.STATE_ENDED -> {
                                stableStreamRunnable?.let { mainHandler.removeCallbacks(it) }
                                stopWatchdog()
                                if (type == StreamType.HLS || type == StreamType.DASH || currentIsLive || streamIsLive) {
                                    progressBar.visibility = View.VISIBLE
                                    errorText.visibility = View.GONE
                                    scheduleReconnect(url, type, myGeneration)
                                }
                            }
                            else -> {}
                        }
                    }

                    override fun onIsPlayingChanged(isPlaying: Boolean) {
                        if (playerGeneration != myGeneration) return
                        btnPlayPause.setImageResource(if (isPlaying) R.drawable.ic_pause else R.drawable.ic_play)
                    }

                    override fun onPlayerError(error: PlaybackException) {
                        if (playerGeneration != myGeneration) return
                        stableStreamRunnable?.let { mainHandler.removeCallbacks(it) }
                        stopWatchdog()
                        if (isZapping) return

                        when (type) {
                            StreamType.HLS, StreamType.DASH -> {
                                progressBar.visibility = View.VISIBLE
                                errorText.visibility = View.GONE
                                scheduleReconnect(url, type, myGeneration)
                            }
                            StreamType.MP4 -> {
                                showError("Error al reproducir. Verificá tu conexión.")
                            }
                            else -> {
                                progressBar.visibility = View.VISIBLE
                                errorText.visibility = View.GONE
                                scheduleReconnect(url, type, myGeneration)
                            }
                        }
                    }
                })
            }
    }

    // ==================== RECONEXION ====================

    private fun scheduleReconnect(url: String, type: String, generation: Int) {
        if (generation != playerGeneration || isZapping) return

        reconnectAttempts++

        if (reconnectAttempts > MAX_RECONNECT_ATTEMPTS) {
            if (type == StreamType.HLS || type == StreamType.DASH) {
                reconnectAttempts = 1
            } else {
                showError("No se pudo reconectar después de varios intentos")
                reconnectAttempts = 0
                return
            }
        }

        val delay = RECONNECT_DELAYS[(reconnectAttempts - 1).coerceAtMost(RECONNECT_DELAYS.size - 1)]
        progressBar.visibility = View.VISIBLE
        errorText.visibility = View.GONE

        reconnectRunnable?.let { mainHandler.removeCallbacks(it) }
        reconnectRunnable = Runnable {
            if (playerGeneration != generation || isZapping) return@Runnable
            if (!NetworkUtils.isAvailable(this)) { scheduleReconnect(url, type, generation); return@Runnable }
            releasePlayer()
            showExoPlayer(url, type)
        }
        mainHandler.postDelayed(reconnectRunnable!!, delay)
    }

    // ==================== WEBVIEW (IFRAME) ====================

    /**
     * Muestra el WebView con soporte para control híbrido:
     * - TV: Controles nativos traducidos al iframe
     * - Móvil: Sin bloqueo táctil, controles nativos del iframe
     */
    private fun showWebView(url: String) {
        val initialHost = Uri.parse(url).host.orEmpty()
        releasePlayer()
        playerView.visibility = View.GONE
        webBridge.stopMonitor()

        // Resetear estado del WebView
        webBridge.reset()

        // Configurar WebView
        webView.applyPlayerSettings()

        // Reset completo del WebView
        webView.apply {
            stopLoading()
            clearHistory()
            loadUrl("about:blank")
            // Remover interface anterior si existe
            webBridge.detach()
        }

        webView.visibility = View.VISIBLE

        // Configurar bloqueo táctil según dispositivo
        if (isTV) {
            webViewTouchBlocker.visibility = View.VISIBLE
            lockWebViewFocus()
            // playerView actúa como proxy de foco para TV
            playerView.visibility = View.INVISIBLE
            playerView.isFocusable = true
            playerView.isFocusableInTouchMode = true
            playerView.requestFocus()
        } else {
            // MÓVIL: SIN BLOQUEO TÁCTIL - usuario interactúa directamente con el iframe
            webViewTouchBlocker.visibility = View.GONE
            webView.isClickable = true
            webView.isFocusable = true
            webView.isFocusableInTouchMode = true
        }

        progressBar.visibility = View.VISIBLE
        currentIsLive = false
        streamIsLive = false
        currentStreamType = StreamType.IFRAME

        updateControlsVisibility()
        if (!isTV) showControlsTemporarily()

        webView.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView?, url: String?) {
                view?.loadUrl("javascript:${WebViewScripts.FULLSCREEN}")
                progressBar.visibility = View.GONE

                webBridge.attach()
                webBridge.injectScript()

                if (isTV) {
                    webBridge.detectAfterLoad()
                    lockWebViewFocus()
                    playerView.isFocusable = true
                    playerView.requestFocus()
                }
            }

            override fun onReceivedError(view: WebView?, code: Int, desc: String?, url: String?) {
                progressBar.visibility = View.GONE
            }

            override fun onReceivedSslError(view: WebView?, handler: android.webkit.SslErrorHandler?, error: android.net.http.SslError?) {
                handler?.cancel()
            }

            override fun shouldOverrideUrlLoading(
                view: WebView?,
                request: android.webkit.WebResourceRequest?
            ): Boolean {
                request ?: return false
                if (!request.isForMainFrame) return false
                // Redirecciones del servidor: se permiten (el primer salto ya pasó el filtro)
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N && request.isRedirect) return false
                // Solo se permite navegar dentro del mismo sitio del embed (anti-popups/publicidad)
                val host = request.url.host.orEmpty()
                val sameSite = host == initialHost || host.endsWith(".$initialHost")
                if (!sameSite) android.util.Log.d("WebView", "BLOQUEADO: ${request.url}")
                return !sameSite
            }
        }

        webView.webChromeClient = object : android.webkit.WebChromeClient() {
            override fun onPermissionRequest(request: android.webkit.PermissionRequest?) {
                request?.deny()
            }

            override fun onShowCustomView(view: View?, callback: android.webkit.WebChromeClient.CustomViewCallback?) {
                view?.let {
                    (window.decorView as? android.widget.FrameLayout)?.addView(
                        it, android.widget.FrameLayout.LayoutParams(
                            android.widget.FrameLayout.LayoutParams.MATCH_PARENT,
                            android.widget.FrameLayout.LayoutParams.MATCH_PARENT
                        )
                    )
                }
            }

            override fun onHideCustomView() {
                (window.decorView as? android.widget.FrameLayout)?.let { frame ->
                    if (frame.childCount > 1) frame.removeViewAt(frame.childCount - 1)
                }
            }

            override fun onCreateWindow(
                view: WebView?,
                isDialog: Boolean,
                isUserGesture: Boolean,
                resultMsg: android.os.Message?
            ): Boolean {
                android.util.Log.d("WebView", "POPUP BLOQUEADO (isDialog=$isDialog, isUserGesture=$isUserGesture)")
                return false
            }

            override fun onConsoleMessage(consoleMessage: android.webkit.ConsoleMessage?): Boolean {
                android.util.Log.d("WebView", "${consoleMessage?.message()} -- ${consoleMessage?.sourceId()}:${consoleMessage?.lineNumber()}")
                return true
            }
        }

        // Cargar URL
        webView.loadUrl(url)
    }

    // ==================== PLAYER RELEASE ====================

    private fun releasePlayer() {
        stopWatchdog()
        cancelOptionFallback()
        webBridge.stopMonitor()
        exoPlayer?.run { stop(); clearMediaItems(); release() }
        exoPlayer = null
    }

    // ==================== SIDE PANEL ====================

    private fun openSidePanel() {
        if (!isTV || isPanelOpen) return
        if (!::sideChannelsAdapter.isInitialized || !::categoriesAdapter.isInitialized) return
        isPanelOpen = true
        val screenWidth = window.decorView.width.takeIf { it > 0 } ?: resources.displayMetrics.widthPixels
        val density = resources.displayMetrics.density
        val minListWidth = (280 * density).toInt()
        val maxListWidth = (420 * density).toInt()
        val menuWidth = panelMenuColumn.layoutParams.width.takeIf { it > 0 }
            ?: (196 * density).toInt()
        val minPlayerWidth = (360 * density).toInt()
        val desiredListWidth = (screenWidth * 0.27f).toInt()
            .coerceIn(minListWidth, maxListWidth)
        // Mantiene juntos el menú de categorías y la lista de canales a la izquierda.
        // El player ocupa el ancho restante gracias al layout_weight del contenedor horizontal.
        val maxListWidthForScreen = (screenWidth - menuWidth - minPlayerWidth)
            .coerceAtLeast((220 * density).toInt())
        val listWidth = desiredListWidth.coerceAtMost(maxListWidthForScreen)
        channelsPanelContainer.layoutParams = channelsPanelContainer.layoutParams.apply {
            width = menuWidth + listWidth
        }
        channelsPanelContainer.visibility = View.VISIBLE
        if (allChannels.isNotEmpty()) {
            updateCategoriesList()
            updateChannelsList(scrollToSelected = true)
            updateContentTitle()
        }
        btnSearchTrigger.post { btnSearchTrigger.requestFocus() }
    }

    private fun closeSidePanel() {
        if (!isTV || !isPanelOpen) return
        deactivateSearchMode()
        channelsPanelContainer.layoutParams = channelsPanelContainer.layoutParams.apply { width = 0 }
        channelsPanelContainer.visibility = View.GONE
        isPanelOpen = false
        restorePlayerFocus()
        // Si el panel quedó abierto más de cinco segundos, el temporizador anterior pudo vencer.
        // Al volver al vídeo lo reiniciamos para que los controles sigan ocultándose correctamente.
        if (controlsVisible) resetAutoHideTimer()
    }

    private fun restorePlayerFocus() {
        if (!isTV) return
        playerContainer.post {
            when {
                controlsVisible && bottomControls.visibility == View.VISIBLE -> {
                    requestPreferredControlFocus()
                }
                playerView.visibility == View.VISIBLE -> {
                    playerView.isFocusable = true
                    playerView.requestFocus()
                }
                else -> playerContainer.requestFocus()
            }
        }
    }

    // ==================== CONTROLS VISIBILITY ====================

    private fun resetAutoHideTimer() {
        hideControlsRunnable?.let { mainHandler.removeCallbacks(it) }
        hideControlsRunnable = Runnable { if (controlsVisible && !isPanelOpen) hideControls() }
        mainHandler.postDelayed(hideControlsRunnable!!, 5_000)
    }

    private fun showControls() {
        updateControlsVisibility()
        if (currentStreamType != StreamType.IFRAME) controlsOverlay.visibility = View.VISIBLE
        bottomControls.visibility = View.VISIBLE
        controlsVisible = true
        if (isTV) requestPreferredControlFocus()
        resetAutoHideTimer()
    }

    private fun showControlsTemporarily() {
        updateControlsVisibility()
        controlsVisible = true
        if (currentStreamType != StreamType.IFRAME) controlsOverlay.visibility = View.VISIBLE
        bottomControls.visibility = View.VISIBLE
        resetAutoHideTimer()
    }

    private fun hideControls() {
        controlsOverlay.visibility = View.GONE
        bottomControls.visibility = View.GONE
        controlsVisible = false
        hideControlsRunnable?.let { mainHandler.removeCallbacks(it) }
        if (isTV) restorePlayerFocus()
    }

    private fun updateControlsVisibility() {
        mediaRouteButton.visibility = if (!isTV && currentStreamType != StreamType.IFRAME) View.VISIBLE else View.GONE

        if (currentStreamType == StreamType.IFRAME) {
            if (isTV) {
                // TV: Mostrar controles si se detectó reproductor en el iframe
                if (webBridge.isControllable) {
                    btnPlayPause.visibility = View.VISIBLE
                    btnPlayPause.setImageResource(if (webBridge.isPlaying) R.drawable.ic_pause else R.drawable.ic_play)

                    val showSeek = webBridge.duration > 0
                    btnRewind.visibility = if (showSeek) View.VISIBLE else View.GONE
                    btnForward.visibility = if (showSeek) View.VISIBLE else View.GONE

                    // Actualizar foco para navegación D-Pad
                    btnPlayPause.isFocusable = true
                    btnRewind.isFocusable = showSeek
                    btnForward.isFocusable = showSeek
                } else {
                    // No se detectó reproductor: ocultar controles de reproducción
                    btnPlayPause.visibility = View.GONE
                    btnRewind.visibility = View.GONE
                    btnForward.visibility = View.GONE
                }
            } else {
                // MÓVIL: Ocultar controles nativos, usar los del iframe
                btnPlayPause.visibility = View.GONE
                btnRewind.visibility = View.GONE
                btnForward.visibility = View.GONE
                // El bloqueo táctil ya está desactivado en showWebView
            }
        } else {
            // Comportamiento normal para ExoPlayer
            btnPlayPause.visibility = View.VISIBLE
            val showSeek = !currentIsLive && !streamIsLive
            btnRewind.visibility = if (showSeek) View.VISIBLE else View.GONE
            btnForward.visibility = if (showSeek) View.VISIBLE else View.GONE
        }

        btnOptions.visibility = if (hasMultipleOptions()) View.VISIBLE else View.GONE

        if (isTV) {
            btnMenu.visibility = View.VISIBLE
            btnMenu.isFocusable = true
            listOf(btnPlayPause, btnRewind, btnForward, btnOptions).forEach {
                it.isFocusable = it.visibility == View.VISIBLE
            }
            btnClose.isFocusable = true
        }
    }

    private fun hasMultipleOptions() = (currentChannel?.options?.size ?: 0) > 1

    // ==================== DATA LOADING ====================

    private fun loadChannelData() {
        @Suppress("UNCHECKED_CAST")
        allChannels = intent.getParcelableArrayListExtra("channels") ?: emptyList()
        currentChannelIndex = intent.getIntExtra("channel_index", 0)
        currentFilteredChannels = allChannels
        if (allChannels.isNotEmpty() && currentChannelIndex < allChannels.size) {
            currentChannel = allChannels[currentChannelIndex]
            loadChannelInfo(currentChannel!!)
            playFirstValidOption(currentChannel!!)
        } else {
            showError("No hay canales disponibles")
        }
    }

    // ==================== OPTIONS DIALOG ====================

    private fun showOptionsDialog(channel: Channel) {
        val options = channel.options ?: run { showError("No hay opciones disponibles"); return }
        if (options.isEmpty()) { showError("No hay opciones disponibles"); return }
        AlertDialog.Builder(this)
            .setTitle("Seleccionar fuente — ${channel.name}")
            .setItems(options.map { it.name }.toTypedArray()) { _, which ->
                playerGeneration++
                reconnectAttempts = 0
                reconnectRunnable?.let { mainHandler.removeCallbacks(it) }
                reconnectRunnable = null
                val url = options[which].iframe
                val type = StreamUtils.resolveType(url, options[which].streamType)
                currentStreamUrl = url
                currentStreamType = type
                currentChannel = channel
                loadChannelInfo(channel)
                playStream(url, type)
                updateControlsVisibility()
                hideControls()
            }
            .setNegativeButton("Cancelar") { _, _ -> if (currentStreamUrl.isEmpty()) finish() }
            .setCancelable(true)
            .show()
    }

    // ==================== HELPERS ====================

    private fun lockWebViewFocus() {
        if (!isTV) return
        webView.apply { isFocusable = false; isFocusableInTouchMode = false; isClickable = false; clearFocus() }
    }

    private fun showError(message: String) {
        progressBar.visibility = View.GONE
        errorText.text = message
        errorText.visibility = View.VISIBLE
        updateControlsVisibility()
    }
}
