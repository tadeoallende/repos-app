package com.angulismotv

import android.content.pm.ActivityInfo
import android.content.res.Configuration
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.Editable
import android.text.TextWatcher
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.SeekBar
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.exoplayer2.DefaultLoadControl
import com.google.android.exoplayer2.ExoPlayer
import com.google.android.exoplayer2.MediaItem
import com.google.android.exoplayer2.PlaybackException
import com.google.android.exoplayer2.Player
import com.google.android.exoplayer2.source.dash.DashMediaSource
import com.google.android.exoplayer2.source.ProgressiveMediaSource
import com.google.android.exoplayer2.source.hls.HlsMediaSource
import com.google.android.exoplayer2.ui.PlayerView
import com.angulismotv.adapters.SideChannelsAdapter
import com.angulismotv.player.CastController
import com.angulismotv.player.CastStream
import com.angulismotv.player.StreamUtils
import com.angulismotv.player.WebViewPlayerBridge
import com.angulismotv.player.WebViewScripts
import com.angulismotv.player.applyPlayerSettings
import com.angulismotv.utils.NetworkUtils
import com.angulismotv.utils.loadChannelLogo
import com.angulismotv.adapters.CategoriesAdapter
import com.angulismotv.adapters.ChannelsAdapter
import com.angulismotv.models.Channel
import com.angulismotv.models.StreamType
import com.angulismotv.network.HttpClient
import com.angulismotv.utils.DeviceHelper
import com.google.android.exoplayer2.ext.okhttp.OkHttpDataSource

class UnifiedPlayerActivity : AppCompatActivity() {

    // ==================== VIEWS ====================
    private lateinit var btnMenu: ImageButton
    private lateinit var playerView: PlayerView
    private lateinit var playerContainer: FrameLayout
    private lateinit var webView: WebView
    private lateinit var webViewTouchBlocker: View
    private lateinit var progressBar: ProgressBar
    private lateinit var errorText: TextView
    private lateinit var controlsOverlay: View
    private lateinit var bottomControls: View
    private lateinit var btnRewind: ImageButton
    private lateinit var btnForward: ImageButton
    private lateinit var btnPlayPause: ImageButton
    private lateinit var btnClose: ImageButton
    private lateinit var btnOptions: ImageButton
    private lateinit var mediaRouteButton: ImageButton
    private lateinit var channelLogo: ImageView
    private lateinit var channelNameText: TextView
    private lateinit var channelCategoryText: TextView
    private lateinit var playerControlsMainRow: LinearLayout
    private lateinit var playerActionGroupsRow: LinearLayout
    private lateinit var playerChannelIdentity: LinearLayout
    private lateinit var playerTransportControls: LinearLayout
    private lateinit var playerUtilityControls: LinearLayout
    private lateinit var playerTimelineContainer: View
    private lateinit var playerSeekBar: SeekBar
    private lateinit var playerTimeCurrent: TextView
    private lateinit var playerTimeDuration: TextView
    private var isUserSeekingTimeline = false
    private var timelineUpdateRunnable: Runnable? = null

    // Panel lateral
    private lateinit var channelsPanelContainer: LinearLayout
    private lateinit var panelMenuColumn: LinearLayout
    private lateinit var panelContentColumn: LinearLayout
    private lateinit var channelsList: RecyclerView
    private lateinit var sideChannelsAdapter: SideChannelsAdapter
    private lateinit var btnClosePanel: ImageButton
    private lateinit var contentTitle: TextView
    private lateinit var channelsCountText: TextView
    private lateinit var btnAllChannels: LinearLayout
    private lateinit var allChannelsMarker: View
    private lateinit var allChannelsIcon: ImageView
    private lateinit var allChannelsText: TextView

    // Búsqueda
    private lateinit var btnSearchTrigger: LinearLayout
    private lateinit var searchTriggerText: TextView
    private lateinit var searchInputContainer: View
    private lateinit var menuSearchInput: EditText
    private lateinit var menuSearchResults: RecyclerView
    private lateinit var searchEmptyText: TextView
    private lateinit var searchAdapter: ChannelsAdapter

    // Categorías
    private lateinit var menuCategoriesList: RecyclerView
    private lateinit var categoriesAdapter: CategoriesAdapter

    // Minimal channel identity shown briefly while zapping on TV and mobile.
    private var zappingOverlay: LinearLayout? = null
    private var zappingLogo: ImageView? = null
    private var zappingChannelName: TextView? = null

    // ==================== STATE ====================
    private var exoPlayer: ExoPlayer? = null
    private lateinit var webBridge: WebViewPlayerBridge
    private lateinit var cast: CastController
    private var isTV = false
    private var currentChannel: Channel? = null
    private var controlsVisible = false
    // Conserva el último control enfocado para que el mando no vuelva siempre al inicio.
    private var lastFocusedControlId: Int = View.NO_ID
    private var isPanelOpen = false
    private var currentIsLive = false
    private var streamIsLive = false
    private var currentStreamUrl: String = ""
    private var currentStreamType: String = StreamType.AUTO
    private var isZapping = false
    private var currentCategory = "todos"
    private var isSearchActive = false

    // RECONEXION
    private var playerGeneration = 0
    private var reconnectAttempts = 0
    private val MAX_RECONNECT_ATTEMPTS = 10
    private val RECONNECT_DELAYS = longArrayOf(500, 1_000, 2_000, 3_000, 5_000, 8_000, 12_000)

    // WATCHDOG
    private var watchdogRunnable: Runnable? = null
    private var lastKnownPosition: Long = -1L
    private var frozenPositionCount: Int = 0
    private val WATCHDOG_INTERVAL_MS = 5_000L
    private val FROZEN_TICKS_BEFORE_RECONNECT = 2

    // Channels
    private var allChannels: List<Channel> = emptyList()
    private var currentChannelIndex: Int = 0
    private var currentFilteredChannels: List<Channel> = emptyList()

    // Handlers
    private val mainHandler = Handler(Looper.getMainLooper())
    private var hideControlsRunnable: Runnable? = null
    private var zapRunnable: Runnable? = null
    private var stableStreamRunnable: Runnable? = null
    private var reconnectRunnable: Runnable? = null
    // Identifica la carga vigente del WebView e invalida callbacks de fuentes anteriores.
    private var webLoadGeneration = 0
    private var webCustomView: View? = null
    private var webCustomViewCallback: android.webkit.WebChromeClient.CustomViewCallback? = null

    private lateinit var insetsController: WindowInsetsControllerCompat

    // ==================== LIFECYCLE ====================

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (!DeviceHelper.isTV(this)) enableImmersiveFullscreen()
        setContentView(R.layout.activity_unified_player)

        isTV = DeviceHelper.isTV(this)
        bindViews()
        updateControlLayoutForConfiguration()
        // La TV sigue fija en horizontal. En móvil dejamos que el sensor gestione la rotación,
        // para poder volver al mini-player cuando el usuario regresa a vertical.
        requestedOrientation = when {
            isTV -> ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
            intent.getBooleanExtra("force_landscape_fullscreen", false) -> ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
            else -> ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
        }

        webBridge = WebViewPlayerBridge(
            webView = webView,
            handler = mainHandler,
            isIframeActive = { currentStreamType == StreamType.IFRAME },
            onStateChanged = ::updateWebViewControls
        )
        cast = CastController(
            activity = this,
            button = mediaRouteButton,
            handler = mainHandler,
            currentStream = {
                if (currentStreamUrl.isEmpty()) null
                else CastStream(currentStreamUrl, currentStreamType, currentChannel?.name ?: "Canal")
            },
            onCastStarted = { exoPlayer?.pause() }
        )
        cast.setup(isTV)
        setupWebViewForTV()
        setupWebViewTouchBlocker()
        setupSidePanel()
        setupControls()
        loadChannelData()
    }

    override fun onResume() {
        super.onResume()
        if (!isTV) enableImmersiveFullscreen()
        cast.startDiscovery()
        webView.onResume()
        exoPlayer?.let { player ->
            if (!player.isPlaying && player.playbackState == Player.STATE_READY) {
                player.play()
            }
        }
    }

    override fun onPause() {
        super.onPause()
        if (!isZapping) exoPlayer?.pause()
        cast.stopDiscovery()
        webView.onPause()
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus && !isTV) enableImmersiveFullscreen()
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        updateControlLayoutForConfiguration()
        if (!isTV && intent.getBooleanExtra("from_inline_player", false) &&
            newConfig.orientation == Configuration.ORIENTATION_PORTRAIT) {
            // Al volver físicamente a vertical, regresa al mini-player que permanece en Canales.
            finish()
            overridePendingTransition(0, 0)
        } else if (!isTV) {
            enableImmersiveFullscreen()
        }
    }

    /** Adapta el overlay al ancho disponible: en vertical los datos y acciones se apilan. */
    private fun updateControlLayoutForConfiguration() {
        if (!::playerControlsMainRow.isInitialized) return
        val compactPortrait = !isTV && resources.configuration.orientation == Configuration.ORIENTATION_PORTRAIT
        val identityParams = playerChannelIdentity.layoutParams as LinearLayout.LayoutParams
        val actionParams = playerActionGroupsRow.layoutParams as LinearLayout.LayoutParams
        val transportParams = playerTransportControls.layoutParams as LinearLayout.LayoutParams
        val utilityParams = playerUtilityControls.layoutParams as LinearLayout.LayoutParams

        if (compactPortrait) {
            playerControlsMainRow.orientation = LinearLayout.VERTICAL
            identityParams.width = ViewGroup.LayoutParams.MATCH_PARENT
            identityParams.weight = 0f
            identityParams.marginEnd = 0
            playerChannelIdentity.layoutParams = identityParams
            actionParams.width = ViewGroup.LayoutParams.MATCH_PARENT
            actionParams.height = ViewGroup.LayoutParams.WRAP_CONTENT
            playerActionGroupsRow.layoutParams = actionParams
            transportParams.marginStart = 0
            playerTransportControls.layoutParams = transportParams
            utilityParams.marginStart = dp(8)
            playerUtilityControls.layoutParams = utilityParams
            bottomControls.setPadding(dp(16), dp(10), dp(16), dp(12))
        } else {
            playerControlsMainRow.orientation = LinearLayout.HORIZONTAL
            identityParams.width = 0
            identityParams.weight = 1f
            identityParams.marginEnd = 0
            playerChannelIdentity.layoutParams = identityParams
            actionParams.width = ViewGroup.LayoutParams.WRAP_CONTENT
            actionParams.height = ViewGroup.LayoutParams.WRAP_CONTENT
            playerActionGroupsRow.layoutParams = actionParams
            transportParams.marginStart = dp(12)
            playerTransportControls.layoutParams = transportParams
            utilityParams.marginStart = dp(12)
            playerUtilityControls.layoutParams = utilityParams
            bottomControls.setPadding(dp(22), dp(10), dp(22), dp(12))
        }
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density + 0.5f).toInt()

    override fun onStop() {
        super.onStop()
        exoPlayer?.pause()
    }

    override fun onDestroy() {
        playerGeneration++
        webLoadGeneration++
        mainHandler.removeCallbacksAndMessages(null)
        stopTimelineUpdates()
        releasePlayer()
        webCustomView?.let { custom -> (custom.parent as? ViewGroup)?.removeView(custom) }
        webCustomView = null
        val hiddenViewCallback = webCustomViewCallback
        webCustomViewCallback = null
        hiddenViewCallback?.onCustomViewHidden()

        // Limpiar WebView inmediatamente (no hace operaciones de red)
        webView.apply {
            stopLoading()
            webViewClient = WebViewClient()
            loadUrl("about:blank")
            clearHistory()
            clearCache(true)
            onPause()
            removeAllViews()
            destroy()
        }
        super.onDestroy()
    }

    override fun onBackPressed() {
        if (!isTV) super.onBackPressed()
    }

    // ==================== BIND VIEWS ====================

    private fun bindViews() {
        btnMenu = findViewById(R.id.btn_menu)
        playerView = findViewById(R.id.player_view)
        playerContainer = findViewById(R.id.player_container)
        if (isTV) {
            // Superficie de foco de respaldo cuando el stream se reproduce dentro de WebView.
            playerContainer.isFocusable = true
            playerContainer.isFocusableInTouchMode = true
        }
        webView = findViewById(R.id.web_view)
        webViewTouchBlocker = findViewById(R.id.web_view_touch_blocker)
        progressBar = findViewById(R.id.progress_bar)
        errorText = findViewById(R.id.error_text)
        controlsOverlay = findViewById(R.id.controls_overlay)
        bottomControls = findViewById(R.id.bottom_controls)
        btnRewind = findViewById(R.id.btn_rewind)
        btnForward = findViewById(R.id.btn_forward)
        btnPlayPause = findViewById(R.id.btn_play_pause)
        btnClose = findViewById(R.id.btn_close_player)
        btnOptions = findViewById(R.id.btn_options)
        mediaRouteButton = findViewById(R.id.media_route_button)
        channelLogo = findViewById(R.id.channel_logo)
        channelNameText = findViewById(R.id.channel_name)
        channelCategoryText = findViewById(R.id.channel_category)
        playerControlsMainRow = findViewById(R.id.player_controls_main_row)
        playerActionGroupsRow = findViewById(R.id.player_action_groups_row)
        playerChannelIdentity = findViewById(R.id.player_channel_identity)
        playerTransportControls = findViewById(R.id.player_transport_controls)
        playerUtilityControls = findViewById(R.id.player_utility_controls)
        playerTimelineContainer = findViewById(R.id.player_timeline_container)
        playerSeekBar = findViewById(R.id.player_seek_bar)
        playerTimeCurrent = findViewById(R.id.player_time_current)
        playerTimeDuration = findViewById(R.id.player_time_duration)
        channelsPanelContainer = findViewById(R.id.channels_panel_container)
        channelsList = findViewById(R.id.channels_list)
        panelMenuColumn = findViewById(R.id.panel_menu_column)
        panelContentColumn = findViewById(R.id.panel_content_column)
        btnClosePanel = findViewById(R.id.btn_close_panel)
        contentTitle = findViewById(R.id.content_title)
        channelsCountText = findViewById(R.id.channels_count)
        btnAllChannels = findViewById(R.id.btn_all_channels)
        allChannelsMarker = findViewById(R.id.all_channels_marker)
        allChannelsIcon = findViewById(R.id.all_channels_icon)
        allChannelsText = findViewById(R.id.all_channels_text)
        btnSearchTrigger = findViewById(R.id.btn_search_trigger)
        searchTriggerText = findViewById(R.id.search_trigger_text)
        searchInputContainer = findViewById(R.id.search_input_container)
        menuSearchInput = findViewById(R.id.menu_search_input)
        menuSearchResults = findViewById(R.id.menu_search_results)
        searchEmptyText = findViewById(R.id.search_empty_text)
        menuCategoriesList = findViewById(R.id.menu_categories_list)

        zappingOverlay = findViewById(R.id.zapping_overlay)
        zappingLogo = findViewById(R.id.zapping_logo)
        zappingChannelName = findViewById(R.id.zapping_channel_name)
    }

    // ==================== FULLSCREEN ====================

    private fun enableImmersiveFullscreen() {
        WindowCompat.setDecorFitsSystemWindows(window, false)
        insetsController = WindowInsetsControllerCompat(window, window.decorView).apply {
            hide(WindowInsetsCompat.Type.systemBars())
            systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        }
        @Suppress("DEPRECATION")
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.R) {
            window.decorView.systemUiVisibility = (
                    View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                            or View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                            or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                            or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                            or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                            or View.SYSTEM_UI_FLAG_FULLSCREEN
                    )
        }
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
    }

    // ==================== WEBVIEW ====================

    private fun setupWebViewForTV() {
        if (!isTV) return
        webView.apply {
            isFocusable = false
            isFocusableInTouchMode = false
            isClickable = false
            isLongClickable = false
            applyPlayerSettings()
        }
    }

    private fun setupWebViewTouchBlocker() {
        webViewTouchBlocker.apply {
            setOnTouchListener { _, event ->
                if (!isTV && event.action == MotionEvent.ACTION_UP) {
                    if (controlsVisible) hideControls() else showControlsTemporarily()
                }
                true
            }
            visibility = View.GONE
        }
    }

    /**
     * Actualiza los controles según el estado del WebView
     */
    private fun updateWebViewControls() {
        runOnUiThread {
            if (currentStreamType == StreamType.IFRAME) {
                if (isTV && webBridge.isControllable) {
                    // TV: Mostrar controles traducidos
                    btnPlayPause.visibility = View.VISIBLE
                    updatePlayPauseButton(webBridge.isPlaying)

                    val showSeek = webBridge.duration > 0
                    btnRewind.visibility = if (showSeek) View.VISIBLE else View.GONE
                    btnForward.visibility = if (showSeek) View.VISIBLE else View.GONE

                    // Habilitar foco para navegación con D-Pad
                    if (isTV) {
                        btnPlayPause.isFocusable = true
                        btnRewind.isFocusable = showSeek
                        btnForward.isFocusable = showSeek
                    }
                } else if (!isTV) {
                    // Móvil: Ocultar controles nativos, usar los del iframe
                    btnPlayPause.visibility = View.GONE
                    btnRewind.visibility = View.GONE
                    btnForward.visibility = View.GONE
                }

                // Actualizar estado de los botones
                btnOptions.visibility = if (hasMultipleOptions()) View.VISIBLE else View.GONE

                if (isTV) {
                    btnMenu.visibility = View.VISIBLE
                    btnMenu.isFocusable = true
                    btnClose.isFocusable = true
                }
                if (controlsVisible) {
                    bottomControls.visibility = View.VISIBLE
                    bottomControls.bringToFront()
                }
                updateControlFocusOrder()
            }
        }
    }

    // ==================== SIDE PANEL ====================

    private fun setupSidePanel() {
        if (!isTV) return
        sideChannelsAdapter = SideChannelsAdapter { channel, position -> selectChannelFromSidePanel(channel, position) }
        categoriesAdapter = CategoriesAdapter { categoryKey -> onCategorySelected(categoryKey) }
        channelsList.apply {
            layoutManager = LinearLayoutManager(this@UnifiedPlayerActivity)
            isFocusable = true
            isFocusableInTouchMode = true
            descendantFocusability = ViewGroup.FOCUS_BEFORE_DESCENDANTS
            adapter = sideChannelsAdapter
        }
        menuCategoriesList.apply {
            layoutManager = LinearLayoutManager(this@UnifiedPlayerActivity)
            adapter = categoriesAdapter
        }
        btnAllChannels.apply {
            isFocusable = true
            isFocusableInTouchMode = true
            isClickable = true
            setOnClickListener { showAllChannels() }
        }
        btnSearchTrigger.apply {
            isFocusable = true
            isFocusableInTouchMode = true
            setOnClickListener { activateSearchMode() }
        }
        btnClosePanel.setOnClickListener { closeSidePanel() }
        setupSearchInput()
    }

    private fun activateSearchMode() {
        isSearchActive = true
        searchInputContainer.visibility = View.VISIBLE
        contentTitle.text = "BUSCAR"
        channelsCountText.text = ""
        categoriesAdapter.clearSelection()
        menuSearchInput.text.clear()
        menuSearchResults.visibility = View.GONE
        searchEmptyText.visibility = View.GONE
        channelsList.visibility = View.VISIBLE
        updateAllChannelsSelection()
        menuSearchInput.post { menuSearchInput.requestFocus() }
    }

    private fun deactivateSearchMode() {
        if (!isSearchActive) return
        isSearchActive = false
        searchInputContainer.visibility = View.GONE
        menuSearchInput.text.clear()
        menuSearchResults.visibility = View.GONE
        searchEmptyText.visibility = View.GONE
        channelsList.visibility = View.VISIBLE
        updateContentTitle()
        updateCategoriesList()
        updateChannelsList(scrollToSelected = true)
        updateAllChannelsSelection()
    }

    private fun updateContentTitle() {
        contentTitle.text = if (currentCategory.equals("todos", ignoreCase = true)) {
            "Todos los canales"
        } else {
            formatCategoryLabel(currentCategory)
        }
    }

    private fun setupSearchInput() {
        searchAdapter = ChannelsAdapter { channel, _ ->
            val index = allChannels.indexOfFirst { it.name == channel.name }
            if (index != -1) { deactivateSearchMode(); selectChannelFromSidePanel(channel, index) }
        }
        menuSearchResults.apply {
            layoutManager = LinearLayoutManager(this@UnifiedPlayerActivity)
            adapter = searchAdapter
        }
        menuSearchInput.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: Editable?) {
                val query = s?.toString()?.lowercase()?.trim() ?: ""
                if (query.isNotEmpty()) {
                    val results = allChannels.filter { it.name.lowercase().contains(query) }
                    searchAdapter.submitList(results)
                    channelsList.visibility = View.GONE
                    menuSearchResults.visibility = if (results.isNotEmpty()) View.VISIBLE else View.GONE
                    searchEmptyText.visibility = if (results.isEmpty()) View.VISIBLE else View.GONE
                    channelsCountText.text = results.size.toString()
                    contentTitle.text = "RESULTADOS: \"$query\""
                } else {
                    searchAdapter.submitList(emptyList())
                    menuSearchResults.visibility = View.GONE
                    searchEmptyText.visibility = View.GONE
                    channelsList.visibility = View.VISIBLE
                    contentTitle.text = "BUSCAR"
                    channelsCountText.text = ""
                }
            }
        })
        menuSearchInput.setOnEditorActionListener { _, actionId, _ -> actionId == EditorInfo.IME_ACTION_SEARCH }
    }

    private fun updateCategoriesList() {
        if (!::categoriesAdapter.isInitialized || allChannels.isEmpty()) return
        // «Lista de canales» es una acción fija; la lista dinámica solo contiene categorías reales.
        val uniqueCategories = allChannels.mapNotNull { it.category?.trim() }
            .filter { it.isNotBlank() && !it.equals("todos", ignoreCase = true) }
            .distinctBy { it.lowercase() }
            .sortedBy { it.lowercase() }
        val items = uniqueCategories.map { key ->
            CategoriesAdapter.CategoryItem(
                key = key,
                name = formatCategoryLabel(key),
                count = allChannels.count { it.category.equals(key, ignoreCase = true) }
            )
        }
        val selected = if (currentCategory.equals("todos", ignoreCase = true)) "" else currentCategory
        categoriesAdapter.submitList(items, selected)
        updateAllChannelsSelection()
    }

    private fun updateChannelsList(scrollToSelected: Boolean = false) {
        if (!::sideChannelsAdapter.isInitialized) return
        currentFilteredChannels = if (currentCategory.equals("todos", ignoreCase = true)) {
            allChannels
        } else {
            allChannels.filter { it.category.equals(currentCategory, ignoreCase = true) }
        }
        val selectedInFiltered = currentFilteredChannels.indexOfFirst { it.name == currentChannel?.name }
        sideChannelsAdapter.submitList(currentFilteredChannels, selectedInFiltered)
        channelsCountText.text = "${currentFilteredChannels.size}"
        if (scrollToSelected && selectedInFiltered >= 0) {
            channelsList.post { (channelsList.layoutManager as? LinearLayoutManager)?.scrollToPositionWithOffset(selectedInFiltered, 0) }
        }
    }

    private fun onCategorySelected(categoryKey: String) {
        deactivateSearchMode()
        currentCategory = categoryKey
        updateContentTitle()
        updateCategoriesList()
        updateChannelsList(scrollToSelected = true)
        updateAllChannelsSelection()
        // Entra en la lista de canales de forma determinista: canal actual si pertenece
        // a esta categoría; de lo contrario, primer canal disponible.
        moveFocusToChannelsList()
    }

    /** Selecciona la vista completa de canales, acción fija equivalente a «Lista de canales». */
    private fun showAllChannels() {
        if (isSearchActive) deactivateSearchMode()
        currentCategory = "todos"
        updateContentTitle()
        updateCategoriesList()
        updateChannelsList(scrollToSelected = true)
        updateAllChannelsSelection()
        moveFocusToChannelsList()
    }

    private fun updateAllChannelsSelection() {
        if (!::btnAllChannels.isInitialized) return
        val selected = !isSearchActive && currentCategory.equals("todos", ignoreCase = true)
        btnAllChannels.isSelected = selected
        btnAllChannels.refreshDrawableState()
        btnAllChannels.setBackgroundResource(
            if (selected) R.drawable.side_category_item_selected
            else R.drawable.side_menu_item_bg
        )
        allChannelsMarker.visibility = if (selected) View.VISIBLE else View.INVISIBLE
        val accent = androidx.core.content.ContextCompat.getColor(this, R.color.accent)
        val primary = androidx.core.content.ContextCompat.getColor(this, R.color.text_primary)
        val secondary = androidx.core.content.ContextCompat.getColor(this, R.color.text_secondary)
        allChannelsIcon.setColorFilter(if (selected) accent else secondary)
        allChannelsText.setTextColor(if (selected) accent else primary)
        btnAllChannels.contentDescription = if (selected) {
            "Lista de canales, seleccionada"
        } else {
            "Lista de canales"
        }
    }

    /** Convierte «estilo-de-vida» en «Estilo de vida» sin alterar la clave de categoría. */
    private fun formatCategoryLabel(raw: String): String = raw
        .trim()
        .replace('-', ' ')
        .replace('_', ' ')
        .split(Regex("\\s+"))
        .filter { it.isNotBlank() }
        .joinToString(" ") { word -> word.lowercase().replaceFirstChar { it.uppercase() } }

    private fun handleBackInPanel(): Boolean {
        return when {
            isSearchActive && menuSearchInput.text.isNotEmpty() -> {
                menuSearchInput.text.clear()
                menuSearchInput.post { menuSearchInput.requestFocus() }
                true
            }
            isSearchActive -> { deactivateSearchMode(); btnSearchTrigger.post { btnSearchTrigger.requestFocus() }; true }
            else -> { closeSidePanel(); true }
        }
    }

    // ==================== CONTROLS ====================

    private fun setupControls() {
        btnClose.setOnClickListener { finish() }
        playerSeekBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onStartTrackingTouch(seekBar: SeekBar?) {
                isUserSeekingTimeline = true
                resetAutoHideTimer()
            }

            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                if (!fromUser) return
                val duration = exoPlayer?.duration ?: return
                playerTimeCurrent.text = formatPlayerTime(duration * progress.toLong() / 1000L)
            }

            override fun onStopTrackingTouch(seekBar: SeekBar?) {
                val player = exoPlayer
                if (player != null && player.duration > 0L && player.isCurrentWindowSeekable) {
                    player.seekTo(player.duration * playerSeekBar.progress.toLong() / 1000L)
                }
                isUserSeekingTimeline = false
                updatePlayerTimeline()
                resetAutoHideTimer()
            }
        })

        // Configurar listeners para controles de WebView (TV)
        btnPlayPause.setOnClickListener {
            if (currentStreamType == StreamType.IFRAME && isTV) {
                webBridge.control("toggle")
                resetAutoHideTimer()
            } else if (currentStreamType != StreamType.IFRAME) {
                togglePlayPause()
                resetAutoHideTimer()
            }
        }

        btnRewind.setOnClickListener {
            if (currentStreamType == StreamType.IFRAME && isTV && webBridge.isControllable) {
                val newTime = (webBridge.currentTime - 10).coerceAtLeast(0)
                webBridge.control("seek", newTime.toDouble())
                resetAutoHideTimer()
            } else if (currentStreamType != StreamType.IFRAME) {
                if (!currentIsLive && !streamIsLive) {
                    exoPlayer?.seekTo(((exoPlayer?.currentPosition ?: 0) - 10_000).coerceAtLeast(0))
                    resetAutoHideTimer()
                }
            }
        }

        btnForward.setOnClickListener {
            if (currentStreamType == StreamType.IFRAME && isTV && webBridge.isControllable) {
                val newTime = (webBridge.currentTime + 10).coerceAtMost(webBridge.duration)
                webBridge.control("seek", newTime.toDouble())
                resetAutoHideTimer()
            } else if (currentStreamType != StreamType.IFRAME) {
                if (!currentIsLive && !streamIsLive) {
                    val pos = exoPlayer?.currentPosition ?: 0
                    val dur = exoPlayer?.duration ?: 0
                    if (dur > 0) exoPlayer?.seekTo((pos + 10_000).coerceAtMost(dur))
                    resetAutoHideTimer()
                }
            }
        }

        btnMenu.setOnClickListener { if (isTV) { if (isPanelOpen) closeSidePanel() else openSidePanel() } }
        btnMenu.visibility = View.GONE
        btnOptions.setOnClickListener { showOptionsDialog(currentChannel ?: return@setOnClickListener); resetAutoHideTimer() }

        if (isTV) {
            listOf(btnMenu, btnPlayPause, btnRewind, btnForward, btnOptions, btnClose, mediaRouteButton).forEach { control ->
                control.isFocusable = true
                control.isFocusableInTouchMode = true
                control.isClickable = true
                val size = (48 * resources.displayMetrics.density + 0.5f).toInt()
                control.layoutParams = control.layoutParams.apply { width = size; height = size }
                control.setOnFocusChangeListener { view, hasFocus ->
                    if (hasFocus) {
                        lastFocusedControlId = view.id
                        if (controlsVisible && !isPanelOpen) resetAutoHideTimer()
                    }
                }
            }
            controlsOverlay.visibility = View.GONE
            bottomControls.visibility = View.GONE
            controlsVisible = false
        } else {
            playerView.setOnClickListener {
                if (controlsVisible) hideControls() else showControlsTemporarily()
            }
        }
    }

    private fun togglePlayPause() {
        val player = exoPlayer ?: return
        if (player.isPlaying) {
            player.pause()
            updatePlayPauseButton(false)
        } else {
            player.play()
            updatePlayPauseButton(true)
        }
    }

    /** Mantiene icono y etiqueta accesible sincronizados con la acción disponible. */
    private fun updatePlayPauseButton(isPlaying: Boolean) {
        btnPlayPause.setImageResource(if (isPlaying) R.drawable.ic_pause else R.drawable.ic_play)
        btnPlayPause.contentDescription = if (isPlaying) "Pausar" else "Reproducir"
    }

    // ==================== TV KEY HANDLING ====================

    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        if (!isTV) return super.dispatchKeyEvent(event)
        if (event.action != KeyEvent.ACTION_DOWN) return super.dispatchKeyEvent(event)
        val handled = handleTVKey(event.keyCode)
        return if (handled) true else super.dispatchKeyEvent(event)
    }

    private fun handleTVKey(keyCode: Int): Boolean {
        return when (keyCode) {
            KeyEvent.KEYCODE_BACK -> when {
                isPanelOpen -> handleBackInPanel()
                controlsVisible -> { hideControls(); true }
                else -> { finish(); true }
            }
            KeyEvent.KEYCODE_DPAD_UP -> when {
                isPanelOpen -> handlePanelVerticalFocus(keyCode)
                controlsVisible -> { navigateControlsUp(); true }
                !isZapping -> { changeChannel(-1); true }
                else -> true
            }
            KeyEvent.KEYCODE_DPAD_DOWN -> when {
                isPanelOpen -> handlePanelVerticalFocus(keyCode)
                controlsVisible -> { navigateControlsDown(); true }
                !isZapping -> { changeChannel(1); true }
                else -> true
            }
            KeyEvent.KEYCODE_DPAD_LEFT -> when {
                isPanelOpen -> {
                    if (isRightPanelFocused()) moveFocusToCategoriesPanel()
                    else closeSidePanel()
                    true
                }
                controlsVisible -> { navigateControlsLeft(); true }
                else -> { openSidePanel(); true }
            }
            KeyEvent.KEYCODE_DPAD_RIGHT -> when {
                isPanelOpen -> {
                    if (currentFocus?.id == R.id.btn_search_trigger) {
                        activateSearchMode()
                        true
                    } else if (currentFocus?.id == R.id.btn_close_panel) {
                        closeSidePanel()
                        true
                    } else if (!isRightPanelFocused()) {
                        // Categorías/buscador -> lista. Desde la lista, volver al vídeo
                        // cerrando el panel evita que el foco se escape a controles de fondo.
                        moveFocusToChannelsList()
                        true
                    } else {
                        closeSidePanel()
                        true
                    }
                }
                controlsVisible -> { navigateControlsRight(); true }
                else -> { showControls(); true }
            }
            KeyEvent.KEYCODE_DPAD_CENTER, KeyEvent.KEYCODE_ENTER -> when {
                isPanelOpen -> false
                !controlsVisible -> { showControls(); true }
                else -> { activateFocusedControl(); true }
            }
            KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE -> {
                if (currentStreamType == StreamType.IFRAME) {
                    webBridge.control("toggle")
                } else {
                    togglePlayPause()
                }
                true
            }
            KeyEvent.KEYCODE_MEDIA_PLAY -> {
                if (currentStreamType == StreamType.IFRAME) {
                    webBridge.control("play")
                } else {
                    exoPlayer?.play()
                    updatePlayPauseButton(true)
                }
                true
            }
            KeyEvent.KEYCODE_MEDIA_PAUSE -> {
                if (currentStreamType == StreamType.IFRAME) {
                    webBridge.control("pause")
                } else {
                    exoPlayer?.pause()
                    updatePlayPauseButton(false)
                }
                true
            }
            KeyEvent.KEYCODE_MEDIA_FAST_FORWARD -> { btnForward.performClick(); true }
            KeyEvent.KEYCODE_MEDIA_REWIND -> { btnRewind.performClick(); true }
            else -> false
        }
    }

    private fun isDescendantFocused(view: View): Boolean {
        val focused = currentFocus ?: return false
        var parent = focused.parent
        while (parent != null) {
            if (parent === view) return true
            parent = (parent as? View)?.parent
        }
        return false
    }

    private fun isRightPanelFocused(): Boolean =
        channelsList.hasFocus() || isDescendantFocused(channelsList) ||
            menuSearchResults.hasFocus() || isDescendantFocused(menuSearchResults)

    private fun moveFocusToCategoriesPanel() {
        // Al volver desde canales, retomamos la categoría activa (o el campo de búsqueda).
        if (isSearchActive) {
            menuSearchInput.requestFocus()
            return
        }
        if (currentCategory.equals("todos", ignoreCase = true)) {
            btnAllChannels.requestFocus()
            return
        }
        val position = categoriesAdapter.getPositionForKey(currentCategory)
        if (position < 0) {
            btnAllChannels.requestFocus()
            return
        }
        menuCategoriesList.post {
            (menuCategoriesList.layoutManager as? LinearLayoutManager)?.scrollToPositionWithOffset(position, 0)
            menuCategoriesList.post {
                val item = menuCategoriesList.findViewHolderForAdapterPosition(position)?.itemView
                if (item?.requestFocus() != true) menuCategoriesList.requestFocus()
            }
        }
    }

    private fun moveFocusToChannelsList() {
        // Si la búsqueda no tuvo coincidencias, el destino accionable sigue siendo el campo.
        if (isSearchActive && searchEmptyText.visibility == View.VISIBLE) {
            menuSearchInput.requestFocus()
            return
        }
        // En modo búsqueda, derecha lleva a los resultados; en navegación normal, a los canales.
        if (isSearchActive && menuSearchResults.visibility == View.VISIBLE) {
            // La búsqueda usa AsyncListDiffer; esperar a que el primer resultado esté adjunto.
            menuSearchResults.post {
                menuSearchResults.post {
                    val item = if (searchAdapter.itemCount > 0) {
                        menuSearchResults.findViewHolderForAdapterPosition(0)?.itemView
                    } else null
                    if (item?.requestFocus() != true) menuSearchResults.requestFocus()
                }
            }
            return
        }

        val selectedInFiltered = currentFilteredChannels.indexOfFirst { it.name == currentChannel?.name }
        val targetPosition = if (selectedInFiltered >= 0) selectedInFiltered else 0
        channelsList.post {
            val lm = channelsList.layoutManager as? LinearLayoutManager
            lm?.scrollToPositionWithOffset(targetPosition, 0)
            channelsList.post {
                val item = channelsList.findViewHolderForAdapterPosition(targetPosition)?.itemView
                if (item?.requestFocus() != true) channelsList.requestFocus()
            }
        }
    }

    /** Foco vertical explícito para que las acciones fijas formen parte del mismo rail. */
    private fun handlePanelVerticalFocus(keyCode: Int): Boolean {
        val focused = currentFocus ?: return false
        return when {
            focused.id == R.id.btn_search_trigger && keyCode == KeyEvent.KEYCODE_DPAD_DOWN -> {
                btnAllChannels.requestFocus()
                true
            }
            focused.id == R.id.btn_all_channels && keyCode == KeyEvent.KEYCODE_DPAD_UP -> {
                btnSearchTrigger.requestFocus()
                true
            }
            focused.id == R.id.btn_all_channels && keyCode == KeyEvent.KEYCODE_DPAD_DOWN -> {
                focusFirstCategory()
                true
            }
            focused.id == R.id.btn_close_panel && keyCode == KeyEvent.KEYCODE_DPAD_DOWN -> {
                btnSearchTrigger.requestFocus()
                true
            }
            focused.id == R.id.btn_search_trigger && keyCode == KeyEvent.KEYCODE_DPAD_UP -> {
                btnClosePanel.requestFocus()
                true
            }
            else -> false
        }
    }

    private fun focusFirstCategory() {
        if (categoriesAdapter.itemCount == 0) {
            moveFocusToChannelsList()
            return
        }
        menuCategoriesList.post {
            (menuCategoriesList.layoutManager as? LinearLayoutManager)?.scrollToPositionWithOffset(0, 0)
            menuCategoriesList.post {
                val first = menuCategoriesList.findViewHolderForAdapterPosition(0)?.itemView
                if (first?.requestFocus() != true) menuCategoriesList.requestFocus()
            }
        }
    }

    private fun activateFocusedControl() {
        when (currentFocus?.id) {
            R.id.btn_menu -> btnMenu.performClick()
            R.id.btn_play_pause -> btnPlayPause.performClick()
            R.id.btn_rewind -> btnRewind.performClick()
            R.id.btn_forward -> btnForward.performClick()
            R.id.btn_options -> btnOptions.performClick()
            R.id.btn_close_player -> btnClose.performClick()
            else -> requestPreferredControlFocus()
        }
    }

    /**
     * Orden real de izquierda a derecha según activity_unified_player.xml.
     * btnMenu está después de los controles de transporte; ponerlo al principio hacía
     * que el D-pad saltara visualmente ese botón al avanzar desde Adelantar.
     */
    private fun visibleControls(): List<View> = listOf(
        btnRewind,
        btnPlayPause,
        btnForward,
        btnMenu,
        mediaRouteButton,
        btnOptions,
        btnClose
    ).filter { it.visibility == View.VISIBLE && it.isFocusable && it.isEnabled }

    /** Asegura el mismo orden en el foco nativo cuando Android no usa el dispatch manual. */
    private fun updateControlFocusOrder() {
        if (!isTV) return
        val controls = visibleControls()
        controls.forEachIndexed { index, control ->
            control.nextFocusLeftId = controls.getOrNull(index - 1)?.id ?: View.NO_ID
            control.nextFocusRightId = controls.getOrNull(index + 1)?.id ?: View.NO_ID
        }
    }

    /** Prioriza el control que el usuario estaba usando; si desapareció para esta fuente,
     * elige uno visible y enfocable como destino seguro. */
    private fun requestPreferredControlFocus() {
        if (!isTV || !controlsVisible || isPanelOpen) return
        val controls = visibleControls()
        if (controls.isEmpty()) {
            playerContainer.requestFocus()
            return
        }
        val preferred = controls.firstOrNull { it.id == lastFocusedControlId } ?: controls.first()
        preferred.requestFocus()
    }
    private fun navigateControlsRight() {
        val controls = visibleControls()
        if (controls.isEmpty()) return
        val index = controls.indexOfFirst { it.hasFocus() }
        controls.getOrNull(if (index < 0) 0 else (index + 1).coerceAtMost(controls.lastIndex))?.requestFocus()
        resetAutoHideTimer()
    }

    private fun navigateControlsLeft() {
        val controls = visibleControls()
        if (controls.isEmpty()) return
        val index = controls.indexOfFirst { it.hasFocus() }
        controls.getOrNull(if (index < 0) 0 else (index - 1).coerceAtLeast(0))?.requestFocus()
        resetAutoHideTimer()
    }

    private fun navigateControlsUp() = navigateControlsLeft()
    private fun navigateControlsDown() = navigateControlsRight()

    // ==================== CHANNEL SELECTION ====================

    private fun selectChannelFromSidePanel(channel: Channel, position: Int) {
        val globalIndex = allChannels.indexOfFirst { it.name == channel.name }
        if (globalIndex == currentChannelIndex) { closeSidePanel(); return }
        closeSidePanel()
        if (!isZapping) zapTo(globalIndex, channel)
    }

    private fun changeChannel(delta: Int) {
        if (allChannels.isEmpty() || isZapping) return
        zapTo((currentChannelIndex + delta).mod(allChannels.size), allChannels[(currentChannelIndex + delta).mod(allChannels.size)])
    }

    private fun zapTo(index: Int, channel: Channel) {
        isZapping = true
        playerGeneration++
        webLoadGeneration++
        reconnectAttempts = 0
        reconnectRunnable?.let { mainHandler.removeCallbacks(it) }
        reconnectRunnable = null
        stableStreamRunnable?.let { mainHandler.removeCallbacks(it) }

        releasePlayer()

        // Resetear completamente el WebView
        webView.apply {
            stopLoading()
            loadUrl("about:blank")
            clearHistory()
            // Eliminar el bridge anterior si existe
            webBridge.detach()
        }
        webView.visibility = View.GONE

        // Configurar bloqueo táctil según dispositivo
        if (isTV) {
            webViewTouchBlocker.visibility = View.VISIBLE
            lockWebViewFocus()
        } else {
            // Móvil: SIN BLOQUEO TÁCTIL para usar controles del iframe
            webViewTouchBlocker.visibility = View.GONE
            webView.isClickable = true
            webView.isFocusable = true
            webView.isFocusableInTouchMode = true
        }

        // Resetear estado del WebView
        webBridge.reset()
        webBridge.stopMonitor()

        progressBar.visibility = View.VISIBLE
        errorText.visibility = View.GONE

        showZappingOverlay(channel)

        zapRunnable?.let { mainHandler.removeCallbacks(it) }
        zapRunnable = Runnable {
            currentChannelIndex = index
            currentChannel = channel
            loadChannelInfo(channel)
            playFirstValidOption(channel)
            mainHandler.postDelayed({ isZapping = false }, 200)
        }
        mainHandler.postDelayed(zapRunnable!!, 300L)
    }

    // ==================== ZAPPING OVERLAY ====================

    private fun showZappingOverlay(channel: Channel) {
        val overlay = zappingOverlay ?: return
        overlay.visibility = View.VISIBLE
        // Keep the transient identity above any visible player controls without capturing focus.
        overlay.bringToFront()
        zappingChannelName?.apply {
            text = channel.name
            // Keep the transient label inside the viewport on narrow phones and TV screens.
            val maxNameWidthDp = if (isTV) 480 else 220
            maxWidth = (maxNameWidthDp * resources.displayMetrics.density).toInt()
        }
        zappingLogo?.loadChannelLogo(channel.name, channel.logo)
        overlay.removeCallbacks(hideZappingRunnable)
        overlay.postDelayed(hideZappingRunnable, 2_000)
    }

    private val hideZappingRunnable = Runnable { zappingOverlay?.visibility = View.GONE }

    // ==================== CHANNEL INFO ====================

    private fun loadChannelInfo(channel: Channel) {
        channelNameText.text = channel.name
        channelLogo.loadChannelLogo(channel.name, channel.logo)
        val categoryLabel = channel.category.trim().takeIf {
            it.isNotBlank() && !it.equals("todos", ignoreCase = true)
        }?.let(::formatCategoryLabel).orEmpty()
        channelCategoryText.text = categoryLabel
        channelCategoryText.visibility = if (categoryLabel.isBlank()) View.GONE else View.VISIBLE
    }

    // ==================== PLAYBACK ====================

    private var currentOptionIndex: Int = 0

    private fun playFirstValidOption(channel: Channel) {
        errorText.visibility = View.GONE
        currentOptionIndex = 0
        if (!channel.options.isNullOrEmpty()) {
            tryOption(channel, 0)
        } else {
            val url = channel.streamUrl ?: ""
            val type = StreamUtils.resolveType(url, channel.streamType ?: StreamType.AUTO)
            if (url.isNotEmpty()) {
                currentStreamUrl = url
                currentStreamType = type
                playStream(url, type)
            } else {
                showError("No hay fuentes disponibles")
            }
        }
    }

    private fun tryOption(channel: Channel, optionIndex: Int) {
        val options = channel.options ?: return
        if (optionIndex >= options.size) {
            showError("No se pudo reproducir con ninguna fuente disponible")
            return
        }

        val option = options[optionIndex]
        val url = option.iframe
        val type = StreamUtils.resolveType(url, option.streamType)
        if (url.isEmpty()) {
            tryOption(channel, optionIndex + 1)
            return
        }

        currentStreamUrl = url
        currentStreamType = type
        currentOptionIndex = optionIndex
        android.util.Log.d("OPTION_TRY", "Intentando opción ${optionIndex + 1}/${options.size}: ${option.name} — $url")

        playStream(url, type)
        updateControlsVisibility()

        scheduleOptionFallback(channel, optionIndex)
    }

    private var optionFallbackRunnable: Runnable? = null

    private fun scheduleOptionFallback(channel: Channel, optionIndex: Int) {
        cancelOptionFallback()
        val option = channel.options?.getOrNull(optionIndex) ?: return
        val optionType = StreamUtils.resolveType(option.iframe, option.streamType)

        // Un iframe no utiliza ExoPlayer. Que exoPlayer sea null no significa que esa fuente
        // haya fallado: algunas páginas tardan en iniciar el vídeo y no exponen su estado.
        // En ese caso el respaldo automático se ejecuta solo ante un error real de carga.
        if (optionType == StreamType.IFRAME) return

        val gen = playerGeneration
        optionFallbackRunnable = Runnable {
            if (playerGeneration != gen || isZapping) return@Runnable
            if (currentChannel != channel || currentOptionIndex != optionIndex) return@Runnable
            val player = exoPlayer
            if (player == null || player.playbackState == Player.STATE_IDLE || player.playbackState == Player.STATE_BUFFERING) {
                android.util.Log.w("OPTION_FALLBACK", "Opción ${optionIndex + 1} tardó demasiado, probando la siguiente")
                val nextIndex = optionIndex + 1
                if (nextIndex < (channel.options?.size ?: 0)) {
                    releasePlayer()
                    tryOption(channel, nextIndex)
                }
            }
        }
        mainHandler.postDelayed(optionFallbackRunnable!!, 12_000)
    }

    private fun cancelOptionFallback() {
        optionFallbackRunnable?.let { mainHandler.removeCallbacks(it) }
        optionFallbackRunnable = null
    }

    private fun playStream(url: String, type: String) {
        when (type) {
            StreamType.IFRAME -> showWebView(url)
            StreamType.HLS, StreamType.DASH, StreamType.MP4 -> showExoPlayer(url, type)
            else -> showExoPlayer(url, StreamType.HLS)
        }
    }

    // ==================== WATCHDOG ====================

    private fun startWatchdog(generation: Int) {
        stopWatchdog()
        watchdogRunnable = object : Runnable {
            override fun run() {
                if (playerGeneration != generation || isZapping) return
                val player = exoPlayer ?: return

                if (player.playbackState == Player.STATE_BUFFERING) {
                    frozenPositionCount++
                    if (frozenPositionCount >= 3) {
                        frozenPositionCount = 0
                        scheduleReconnect(currentStreamUrl, currentStreamType, generation)
                        return
                    }
                    mainHandler.postDelayed(this, WATCHDOG_INTERVAL_MS)
                    return
                }

                if (!player.isPlaying) {
                    mainHandler.postDelayed(this, WATCHDOG_INTERVAL_MS)
                    return
                }

                val pos = player.currentPosition
                if (pos == lastKnownPosition && lastKnownPosition >= 0) {
                    frozenPositionCount++
                    if (frozenPositionCount >= FROZEN_TICKS_BEFORE_RECONNECT) {
                        frozenPositionCount = 0
                        lastKnownPosition = -1L
                        scheduleReconnect(currentStreamUrl, currentStreamType, generation)
                        return
                    }
                } else {
                    frozenPositionCount = 0
                    lastKnownPosition = pos
                }
                mainHandler.postDelayed(this, WATCHDOG_INTERVAL_MS)
            }
        }
        mainHandler.postDelayed(watchdogRunnable!!, WATCHDOG_INTERVAL_MS)
    }

    private fun stopWatchdog() {
        watchdogRunnable?.let { mainHandler.removeCallbacks(it) }
        watchdogRunnable = null
        lastKnownPosition = -1L
        frozenPositionCount = 0
    }

    // ==================== EXO PLAYER ====================

    private fun showExoPlayer(url: String, type: String) {
        // Evita que una respuesta tardía de una navegación WebView previa cambie la UI actual.
        playerTimelineContainer.visibility = View.GONE
        stopTimelineUpdates()
        webLoadGeneration++
        stableStreamRunnable?.let { mainHandler.removeCallbacks(it) }
        stopWatchdog()
        releasePlayer()

        val myGeneration = playerGeneration

        playerView.visibility = View.VISIBLE
        webView.visibility = View.GONE
        webViewTouchBlocker.visibility = View.GONE
        progressBar.visibility = View.VISIBLE
        errorText.visibility = View.GONE
        currentIsLive = false
        streamIsLive = false
        currentStreamType = type

        if (isTV) {
            playerView.isFocusable = true
            playerView.isFocusableInTouchMode = true
            playerView.requestFocus()
            lockWebViewFocus()
        }

        val loadControl = DefaultLoadControl.Builder()
            .setBufferDurationsMs(15_000, 60_000, 1_500, 5_000)
            .build()

        val dataSource = OkHttpDataSource.Factory(HttpClient.shared)
            .setUserAgent(HttpClient.USER_AGENT)

        val mediaItem = MediaItem.fromUri(Uri.parse(url))

        val mediaSource = when (type) {
            StreamType.DASH -> DashMediaSource.Factory(dataSource).createMediaSource(mediaItem)
            StreamType.MP4 -> ProgressiveMediaSource.Factory(dataSource).createMediaSource(mediaItem)
            else -> {
                HlsMediaSource.Factory(dataSource)
                    .setAllowChunklessPreparation(true)
                    .createMediaSource(mediaItem)
            }
        }

        exoPlayer = ExoPlayer.Builder(this)
            .setLoadControl(loadControl)
            .build()
            .also { player ->
                player.setMediaSource(mediaSource)
                player.prepare()
                player.playWhenReady = true
                playerView.player = player
                playerView.useController = false

                player.addListener(object : Player.Listener {
                    override fun onPlaybackStateChanged(state: Int) {
                        if (playerGeneration != myGeneration) return
                        when (state) {
                            Player.STATE_BUFFERING -> {
                                progressBar.visibility = View.VISIBLE
                                errorText.visibility = View.GONE
                            }
                            Player.STATE_READY -> {
                                progressBar.visibility = View.GONE
                                errorText.visibility = View.GONE
                                currentIsLive = player.isCurrentWindowLive
                                streamIsLive = player.isCurrentWindowLive || player.duration == -1L
                                reconnectAttempts = 0
                                updateControlsVisibility()
                                if (!isTV) {
                                    showControlsTemporarily()
                                    startTimelineUpdates()
                                }

                                stableStreamRunnable?.let { mainHandler.removeCallbacks(it) }
                                stableStreamRunnable = Runnable {
                                    if (playerGeneration == myGeneration) { reconnectAttempts = 0; errorText.visibility = View.GONE }
                                }
                                mainHandler.postDelayed(stableStreamRunnable!!, 8_000)
                                cancelOptionFallback()
                                startWatchdog(myGeneration)
                            }
                            Player.STATE_ENDED -> {
                                stableStreamRunnable?.let { mainHandler.removeCallbacks(it) }
                                stopWatchdog()
                                if (type == StreamType.HLS || type == StreamType.DASH || currentIsLive || streamIsLive) {
                                    progressBar.visibility = View.VISIBLE
                                    errorText.visibility = View.GONE
                                    scheduleReconnect(url, type, myGeneration)
                                }
                            }
                            else -> {}
                        }
                    }

                    override fun onIsPlayingChanged(isPlaying: Boolean) {
                        if (playerGeneration != myGeneration) return
                        updatePlayPauseButton(isPlaying)
                    }

                    override fun onPlayerError(error: PlaybackException) {
                        if (playerGeneration != myGeneration) return
                        stableStreamRunnable?.let { mainHandler.removeCallbacks(it) }
                        stopWatchdog()
                        if (isZapping) return

                        when (type) {
                            StreamType.HLS, StreamType.DASH -> {
                                progressBar.visibility = View.VISIBLE
                                errorText.visibility = View.GONE
                                scheduleReconnect(url, type, myGeneration)
                            }
                            StreamType.MP4 -> {
                                showError("Error al reproducir. Verificá tu conexión.")
                            }
                            else -> {
                                progressBar.visibility = View.VISIBLE
                                errorText.visibility = View.GONE
                                scheduleReconnect(url, type, myGeneration)
                            }
                        }
                    }
                })
            }
    }

    // ==================== RECONEXION ====================

    private fun scheduleReconnect(url: String, type: String, generation: Int) {
        if (generation != playerGeneration || isZapping) return

        reconnectAttempts++

        if (reconnectAttempts > MAX_RECONNECT_ATTEMPTS) {
            if (type == StreamType.HLS || type == StreamType.DASH) {
                reconnectAttempts = 1
            } else {
                showError("No se pudo reconectar después de varios intentos")
                reconnectAttempts = 0
                return
            }
        }

        val delay = RECONNECT_DELAYS[(reconnectAttempts - 1).coerceAtMost(RECONNECT_DELAYS.size - 1)]
        progressBar.visibility = View.VISIBLE
        errorText.visibility = View.GONE

        reconnectRunnable?.let { mainHandler.removeCallbacks(it) }
        reconnectRunnable = Runnable {
            if (playerGeneration != generation || isZapping) return@Runnable
            if (!NetworkUtils.isAvailable(this)) { scheduleReconnect(url, type, generation); return@Runnable }
            releasePlayer()
            showExoPlayer(url, type)
        }
        mainHandler.postDelayed(reconnectRunnable!!, delay)
    }

    // ==================== WEBVIEW (IFRAME) ====================

    /**
     * Muestra el WebView con soporte para control híbrido:
     * - TV: Controles nativos traducidos al iframe
     * - Móvil: Sin bloqueo táctil, controles nativos del iframe
     */
    private fun showWebView(url: String) {
        val initialHost = Uri.parse(url).host.orEmpty()
        val thisWebLoad = ++webLoadGeneration
        releasePlayer()
        playerView.visibility = View.GONE
        playerTimelineContainer.visibility = View.GONE
        stopTimelineUpdates()
        webBridge.stopMonitor()

        // Resetear estado del WebView
        webBridge.reset()

        // Configurar WebView
        webView.applyPlayerSettings()

        // Reset completo del WebView
        webView.apply {
            stopLoading()
            clearHistory()
            loadUrl("about:blank")
            // Remover interface anterior si existe
            webBridge.detach()
        }

        webView.visibility = View.VISIBLE

        // Configurar bloqueo táctil según dispositivo
        if (isTV) {
            webViewTouchBlocker.visibility = View.VISIBLE
            lockWebViewFocus()
            // playerView actúa como proxy de foco para TV
            playerView.visibility = View.INVISIBLE
            playerView.isFocusable = true
            playerView.isFocusableInTouchMode = true
            playerView.requestFocus()
        } else {
            // MÓVIL: SIN BLOQUEO TÁCTIL - usuario interactúa directamente con el iframe
            webViewTouchBlocker.visibility = View.GONE
            webView.isClickable = true
            webView.isFocusable = true
            webView.isFocusableInTouchMode = true
        }

        progressBar.visibility = View.VISIBLE
        currentIsLive = false
        streamIsLive = false
        currentStreamType = StreamType.IFRAME

        updateControlsVisibility()
        if (!isTV) showControlsTemporarily()

        webView.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView?, url: String?) {
                if (thisWebLoad != webLoadGeneration || url.isNullOrBlank() || url == "about:blank") return
                view?.loadUrl("javascript:${WebViewScripts.FULLSCREEN}")
                progressBar.visibility = View.GONE

                webBridge.attach()
                webBridge.injectScript()

                if (isTV) {
                    webBridge.detectAfterLoad()
                    lockWebViewFocus()
                    playerView.isFocusable = true
                    playerView.requestFocus()
                    // El WebView no genera el mismo evento de interacción que PlayerView.
                    showControlsTemporarily()
                } else {
                    // La carga web puede tardar más que el auto-ocultado inicial. Volvemos a
                    // mostrar la barra cuando el contenido realmente terminó de cargar.
                    showControlsTemporarily()
                }
            }

            @android.annotation.TargetApi(Build.VERSION_CODES.M)
            override fun onReceivedError(
                view: WebView?,
                request: android.webkit.WebResourceRequest?,
                error: android.webkit.WebResourceError?
            ) {
                val failedRequest = request ?: return
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && failedRequest.isForMainFrame) {
                    val failedUrl = failedRequest.url.toString()
                    if (failedUrl != "about:blank") {
                        handleWebViewMainFrameError(thisWebLoad, failedUrl, error?.description?.toString())
                    }
                }
            }

            @Suppress("DEPRECATION")
            override fun onReceivedError(view: WebView?, code: Int, desc: String?, url: String?) {
                // API 21–22 no dispone de WebResourceRequest.isForMainFrame.
                if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M && !url.isNullOrBlank() && url != "about:blank") {
                    handleWebViewMainFrameError(thisWebLoad, url, desc)
                }
            }

            @android.annotation.TargetApi(Build.VERSION_CODES.M)
            override fun onReceivedHttpError(
                view: WebView?,
                request: android.webkit.WebResourceRequest?,
                errorResponse: android.webkit.WebResourceResponse?
            ) {
                val failedRequest = request ?: return
                val statusCode = errorResponse?.statusCode ?: 0
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && failedRequest.isForMainFrame && statusCode >= 400) {
                    handleWebViewMainFrameError(
                        thisWebLoad,
                        failedRequest.url.toString(),
                        "HTTP $statusCode"
                    )
                }
            }

            override fun onReceivedSslError(view: WebView?, handler: android.webkit.SslErrorHandler?, error: android.net.http.SslError?) {
                handler?.cancel()
            }

            override fun shouldOverrideUrlLoading(
                view: WebView?,
                request: android.webkit.WebResourceRequest?
            ): Boolean {
                request ?: return false
                if (!request.isForMainFrame) return false
                // Redirecciones del servidor: se permiten (el primer salto ya pasó el filtro)
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N && request.isRedirect) return false
                // Solo se permite navegar dentro del mismo sitio del embed (anti-popups/publicidad)
                val host = request.url.host.orEmpty()
                val sameSite = host == initialHost || host.endsWith(".$initialHost")
                if (!sameSite) android.util.Log.d("WebView", "BLOQUEADO: ${request.url}")
                return !sameSite
            }
        }

        webView.webChromeClient = object : android.webkit.WebChromeClient() {
            override fun onPermissionRequest(request: android.webkit.PermissionRequest?) {
                request?.deny()
            }

            override fun onShowCustomView(view: View?, callback: android.webkit.WebChromeClient.CustomViewCallback?) {
                val custom = view ?: return
                // El vídeo a pantalla completa se aloja dentro del contenedor del reproductor,
                // no por encima de toda la Activity: así nuestra barra puede seguir por delante.
                webCustomView?.let { old -> (old.parent as? ViewGroup)?.removeView(old) }
                webCustomView = custom
                webCustomViewCallback = callback
                (custom.parent as? ViewGroup)?.removeView(custom)
                playerContainer.addView(custom, FrameLayout.LayoutParams(
                    FrameLayout.LayoutParams.MATCH_PARENT,
                    FrameLayout.LayoutParams.MATCH_PARENT
                ))
                custom.bringToFront()
                controlsOverlay.bringToFront()
                bottomControls.bringToFront()
                showControlsTemporarily()
            }

            override fun onHideCustomView() {
                webCustomView?.let { custom -> (custom.parent as? ViewGroup)?.removeView(custom) }
                webCustomView = null
                val hiddenViewCallback = webCustomViewCallback
                webCustomViewCallback = null
                hiddenViewCallback?.onCustomViewHidden()
                if (!isTV) showControlsTemporarily()
            }

            override fun onCreateWindow(
                view: WebView?,
                isDialog: Boolean,
                isUserGesture: Boolean,
                resultMsg: android.os.Message?
            ): Boolean {
                android.util.Log.d("WebView", "POPUP BLOQUEADO (isDialog=$isDialog, isUserGesture=$isUserGesture)")
                return false
            }

            override fun onConsoleMessage(consoleMessage: android.webkit.ConsoleMessage?): Boolean {
                android.util.Log.d("WebView", "${consoleMessage?.message()} -- ${consoleMessage?.sourceId()}:${consoleMessage?.lineNumber()}")
                return true
            }
        }

        // Cargar URL
        webView.loadUrl(url)
    }

    /** Un error de la página principal sí permite probar la siguiente fuente del canal. */
    private fun handleWebViewMainFrameError(loadGeneration: Int, failedUrl: String?, description: String?) {
        if (loadGeneration != webLoadGeneration || currentStreamType != StreamType.IFRAME) return
        if (failedUrl == "about:blank") return

        android.util.Log.w("WebView", "Falló la carga de la fuente: ${description ?: failedUrl.orEmpty()}")
        progressBar.visibility = View.GONE
        // Invalida eventos duplicados/tardíos de esta misma navegación.
        webLoadGeneration++

        val channel = currentChannel
        val nextIndex = currentOptionIndex + 1
        if (channel != null && nextIndex < (channel.options?.size ?: 0)) {
            android.util.Log.w("OPTION_FALLBACK", "Falló la carga del iframe; probando opción ${nextIndex + 1}")
            tryOption(channel, nextIndex)
        } else {
            showError("No se pudo cargar esta fuente. Revisá tu conexión o probá otra opción.")
        }
    }

    // ==================== PLAYER RELEASE ====================

    private fun releasePlayer() {
        stopWatchdog()
        cancelOptionFallback()
        webBridge.stopMonitor()
        exoPlayer?.run { stop(); clearMediaItems(); release() }
        exoPlayer = null
    }

    // ==================== SIDE PANEL ====================

    private fun openSidePanel() {
        if (!isTV || isPanelOpen) return
        if (!::sideChannelsAdapter.isInitialized || !::categoriesAdapter.isInitialized) return
        isPanelOpen = true
        val screenWidthPx = window.decorView.width.takeIf { it > 0 }
            ?: resources.displayMetrics.widthPixels
        val density = resources.displayMetrics.density
        val screenWidthDp = screenWidthPx / density

        // El panel se adapta a la resolución real. En pantallas estrechas se reducen las
        // dos columnas para no ocultar el reproductor ni forzar ancho fuera de la pantalla.
        val menuWidthDp = when {
            screenWidthDp < 420f -> 120
            screenWidthDp < 600f -> 144
            screenWidthDp < 900f -> 168
            else -> 208
        }
        // Evita que las acciones fijas se corten en televisores de baja resolución.
        searchTriggerText.text = if (screenWidthDp < 600f) "Buscar" else "Buscar canales"
        allChannelsText.text = if (screenWidthDp < 600f) "Canales" else "Lista de canales"
        val minListWidthDp = when {
            screenWidthDp < 420f -> 96
            screenWidthDp < 600f -> 140
            screenWidthDp < 900f -> 160
            else -> 240
        }
        val maxListWidthDp = when {
            screenWidthDp < 600f -> 220
            screenWidthDp < 900f -> 300
            else -> 420
        }
        val minPlayerWidthDp = when {
            screenWidthDp < 420f -> 104
            screenWidthDp < 600f -> 150
            screenWidthDp < 760f -> 180
            screenWidthDp < 1_000f -> 260
            else -> 360
        }
        val maxListWidthForScreenDp = (screenWidthDp - menuWidthDp - minPlayerWidthDp)
            .coerceAtLeast(minListWidthDp.toFloat())
            .coerceAtMost((screenWidthDp - menuWidthDp).coerceAtLeast(0f))
        val desiredListWidthDp = (screenWidthDp * 0.27f)
            .coerceIn(minListWidthDp.toFloat(), maxListWidthDp.toFloat())
        val listWidthDp = desiredListWidthDp.coerceAtMost(maxListWidthForScreenDp)
        val menuWidthPx = (menuWidthDp * density + 0.5f).toInt()
        val listWidthPx = (listWidthDp * density + 0.5f).toInt()

        panelMenuColumn.layoutParams = panelMenuColumn.layoutParams.apply {
            width = menuWidthPx
        }
        channelsPanelContainer.layoutParams = channelsPanelContainer.layoutParams.apply {
            width = menuWidthPx + listWidthPx
        }
        channelsPanelContainer.visibility = View.VISIBLE
        if (allChannels.isNotEmpty()) {
            updateCategoriesList()
            updateChannelsList(scrollToSelected = true)
            updateContentTitle()
            // Al abrir el panel, el foco va al canal actual (o al primero disponible).
            // La búsqueda queda a un movimiento arriba para no sumar pasos al zapping.
            moveFocusToChannelsList()
        } else {
            // Si los datos aún no llegaron, el buscador es un destino enfocable estable.
            btnSearchTrigger.post { btnSearchTrigger.requestFocus() }
        }
    }

    private fun closeSidePanel() {
        if (!isTV || !isPanelOpen) return
        deactivateSearchMode()
        channelsPanelContainer.layoutParams = channelsPanelContainer.layoutParams.apply { width = 0 }
        channelsPanelContainer.visibility = View.GONE
        isPanelOpen = false
        restorePlayerFocus()
        // Si el panel quedó abierto más de cinco segundos, el temporizador anterior pudo vencer.
        // Al volver al vídeo lo reiniciamos para que los controles sigan ocultándose correctamente.
        if (controlsVisible) resetAutoHideTimer()
    }

    private fun restorePlayerFocus() {
        if (!isTV) return
        playerContainer.post {
            when {
                controlsVisible && bottomControls.visibility == View.VISIBLE -> {
                    requestPreferredControlFocus()
                }
                playerView.visibility == View.VISIBLE -> {
                    playerView.isFocusable = true
                    playerView.requestFocus()
                }
                else -> playerContainer.requestFocus()
            }
        }
    }

    // ==================== CONTROLS VISIBILITY ====================

    private fun resetAutoHideTimer() {
        hideControlsRunnable?.let { mainHandler.removeCallbacks(it) }
        hideControlsRunnable = Runnable { if (controlsVisible && !isPanelOpen) hideControls() }
        mainHandler.postDelayed(hideControlsRunnable!!, 5_000)
    }

    private fun showControls() {
        updateControlsVisibility()
        // El panel de controles es independiente del motor de vídeo: también debe aparecer
        // sobre WebView/iframe, aunque ese reproductor no exponga controles de transporte.
        controlsOverlay.visibility = View.VISIBLE
        bottomControls.visibility = View.VISIBLE
        bottomControls.bringToFront()
        controlsVisible = true
        updatePlayerTimeline()
        if (isTV) requestPreferredControlFocus()
        resetAutoHideTimer()
    }

    private fun showControlsTemporarily() {
        updateControlsVisibility()
        controlsOverlay.visibility = View.VISIBLE
        bottomControls.visibility = View.VISIBLE
        bottomControls.bringToFront()
        controlsVisible = true
        updatePlayerTimeline()
        if (!isTV) startTimelineUpdates()
        resetAutoHideTimer()
    }

    private fun hideControls() {
        controlsOverlay.visibility = View.GONE
        bottomControls.visibility = View.GONE
        controlsVisible = false
        playerTimelineContainer.visibility = View.GONE
        stopTimelineUpdates()
        hideControlsRunnable?.let { mainHandler.removeCallbacks(it) }
        if (isTV) restorePlayerFocus()
    }

    private fun updatePlayerTimeline() {
        if (isTV || currentStreamType == StreamType.IFRAME || !controlsVisible) {
            playerTimelineContainer.visibility = View.GONE
            return
        }
        val player = exoPlayer ?: run {
            playerTimelineContainer.visibility = View.GONE
            return
        }
        val duration = player.duration
        val canSeek = player.playbackState == Player.STATE_READY && player.isCurrentWindowSeekable && duration > 0L
        if (!canSeek) {
            playerTimelineContainer.visibility = View.GONE
            return
        }
        playerTimelineContainer.visibility = View.VISIBLE
        playerSeekBar.max = 1000
        if (!isUserSeekingTimeline) {
            playerSeekBar.progress = ((player.currentPosition.coerceAtLeast(0L) * 1000L) / duration)
                .toInt().coerceIn(0, 1000)
            playerTimeCurrent.text = formatPlayerTime(player.currentPosition)
        }
        playerTimeDuration.text = formatPlayerTime(duration)
    }

    private fun startTimelineUpdates() {
        if (isTV) return
        stopTimelineUpdates()
        timelineUpdateRunnable = object : Runnable {
            override fun run() {
                updatePlayerTimeline()
                if (controlsVisible && exoPlayer != null) mainHandler.postDelayed(this, 500L)
            }
        }
        mainHandler.post(timelineUpdateRunnable!!)
    }

    private fun stopTimelineUpdates() {
        timelineUpdateRunnable?.let { mainHandler.removeCallbacks(it) }
        timelineUpdateRunnable = null
        isUserSeekingTimeline = false
    }

    private fun formatPlayerTime(positionMs: Long): String {
        val totalSeconds = positionMs.coerceAtLeast(0L) / 1000L
        val hours = totalSeconds / 3600L
        val minutes = (totalSeconds % 3600L) / 60L
        val seconds = totalSeconds % 60L
        return if (hours > 0L) String.format(java.util.Locale.ROOT, "%d:%02d:%02d", hours, minutes, seconds)
        else String.format(java.util.Locale.ROOT, "%02d:%02d", minutes, seconds)
    }

    private fun updateControlsVisibility() {
        mediaRouteButton.visibility = if (
            !isTV && currentStreamType != StreamType.IFRAME && cast.isConfigured
        ) View.VISIBLE else View.GONE

        if (currentStreamType == StreamType.IFRAME) {
            if (isTV) {
                // TV: Mostrar controles si se detectó reproductor en el iframe
                if (webBridge.isControllable) {
                    btnPlayPause.visibility = View.VISIBLE
                    updatePlayPauseButton(webBridge.isPlaying)

                    val showSeek = webBridge.duration > 0
                    btnRewind.visibility = if (showSeek) View.VISIBLE else View.GONE
                    btnForward.visibility = if (showSeek) View.VISIBLE else View.GONE

                    // Actualizar foco para navegación D-Pad
                    btnPlayPause.isFocusable = true
                    btnRewind.isFocusable = showSeek
                    btnForward.isFocusable = showSeek
                } else {
                    // No se detectó reproductor: ocultar controles de reproducción
                    btnPlayPause.visibility = View.GONE
                    btnRewind.visibility = View.GONE
                    btnForward.visibility = View.GONE
                }
            } else {
                // MÓVIL: Ocultar controles nativos, usar los del iframe
                btnPlayPause.visibility = View.GONE
                btnRewind.visibility = View.GONE
                btnForward.visibility = View.GONE
                // El bloqueo táctil ya está desactivado en showWebView
            }
        } else {
            // Comportamiento normal para ExoPlayer
            btnPlayPause.visibility = View.VISIBLE
            val showSeek = !currentIsLive && !streamIsLive
            btnRewind.visibility = if (showSeek) View.VISIBLE else View.GONE
            btnForward.visibility = if (showSeek) View.VISIBLE else View.GONE
        }

        btnOptions.visibility = if (hasMultipleOptions()) View.VISIBLE else View.GONE

        if (isTV) {
            btnMenu.visibility = View.VISIBLE
            btnMenu.isFocusable = true
            listOf(btnPlayPause, btnRewind, btnForward, btnOptions).forEach {
                it.isFocusable = it.visibility == View.VISIBLE
            }
            btnClose.isFocusable = true
            mediaRouteButton.isFocusable = mediaRouteButton.visibility == View.VISIBLE
            updateControlFocusOrder()
        }
    }

    private fun hasMultipleOptions() = (currentChannel?.options?.size ?: 0) > 1

    // ==================== DATA LOADING ====================

    private fun loadChannelData() {
        @Suppress("UNCHECKED_CAST")
        allChannels = intent.getParcelableArrayListExtra("channels") ?: emptyList()
        currentChannelIndex = intent.getIntExtra("channel_index", 0)
        currentFilteredChannels = allChannels
        if (allChannels.isNotEmpty() && currentChannelIndex in allChannels.indices) {
            currentChannel = allChannels[currentChannelIndex]
            loadChannelInfo(currentChannel!!)
            val requestedSourceIndex = intent.getIntExtra("source_index", 0)
            if (!currentChannel!!.options.isNullOrEmpty() && requestedSourceIndex in currentChannel!!.options!!.indices) {
                tryOption(currentChannel!!, requestedSourceIndex)
            } else {
                playFirstValidOption(currentChannel!!)
            }
        } else {
            showError("No hay canales disponibles")
        }
    }

    // ==================== OPTIONS DIALOG ====================

    private fun showOptionsDialog(channel: Channel) {
        val options = channel.options ?: run { showError("No hay opciones disponibles"); return }
        if (options.isEmpty()) { showError("No hay opciones disponibles"); return }
        AlertDialog.Builder(this)
            .setTitle("Seleccionar fuente — ${channel.name}")
            .setItems(options.map { it.name }.toTypedArray()) { _, which ->
                playerGeneration++
                reconnectAttempts = 0
                reconnectRunnable?.let { mainHandler.removeCallbacks(it) }
                reconnectRunnable = null
                val url = options[which].iframe
                val type = StreamUtils.resolveType(url, options[which].streamType)
                currentStreamUrl = url
                currentStreamType = type
                currentOptionIndex = which
                currentChannel = channel
                loadChannelInfo(channel)
                playStream(url, type)
                updateControlsVisibility()
                hideControls()
            }
            .setNegativeButton("Cancelar") { _, _ -> if (currentStreamUrl.isEmpty()) finish() }
            .setCancelable(true)
            .show()
    }

    // ==================== HELPERS ====================

    private fun lockWebViewFocus() {
        if (!isTV) return
        webView.apply { isFocusable = false; isFocusableInTouchMode = false; isClickable = false; clearFocus() }
    }

    private fun showError(message: String) {
        progressBar.visibility = View.GONE
        errorText.text = message
        errorText.visibility = View.VISIBLE
        updateControlsVisibility()
    }
}
