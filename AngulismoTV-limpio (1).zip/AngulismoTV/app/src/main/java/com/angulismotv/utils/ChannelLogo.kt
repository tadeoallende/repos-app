package com.angulismotv.utils

import android.graphics.Canvas
import android.graphics.ColorFilter
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.widget.ImageView
import com.bumptech.glide.Glide
import com.bumptech.glide.load.resource.bitmap.RoundedCorners
import kotlin.math.min

/**
 * Logo de reemplazo para canales sin imagen (o mientras carga / si falla): cuadrado redondeado con
 * las iniciales del canal sobre un azul de la paleta. El color depende del nombre, así que cada
 * canal siempre se ve igual. Solo dibuja formas planas, sin bitmaps.
 */
class InitialsDrawable(name: String) : Drawable() {

    private val initials = initialsOf(name)

    private val backgroundPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = PALETTE[(name.lowercase().hashCode() and Int.MAX_VALUE) % PALETTE.size]
    }

    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = TEXT_COLOR
        typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        textAlign = Paint.Align.CENTER
    }

    private val rect = RectF()

    override fun draw(canvas: Canvas) {
        val b = bounds
        if (b.isEmpty) return
        val size = min(b.width(), b.height()).toFloat()
        rect.set(b)
        canvas.drawRoundRect(rect, size * CORNER_RATIO, size * CORNER_RATIO, backgroundPaint)

        textPaint.textSize = size * TEXT_RATIO
        val baseline = b.exactCenterY() - (textPaint.descent() + textPaint.ascent()) / 2f
        canvas.drawText(initials, b.exactCenterX(), baseline, textPaint)
    }

    // Tamaño propio para que se vea bien incluso en un ImageView con wrap_content
    override fun getIntrinsicWidth(): Int = INTRINSIC_SIZE
    override fun getIntrinsicHeight(): Int = INTRINSIC_SIZE

    override fun setAlpha(alpha: Int) {
        backgroundPaint.alpha = alpha
        textPaint.alpha = alpha
        invalidateSelf()
    }

    override fun setColorFilter(colorFilter: ColorFilter?) {
        backgroundPaint.colorFilter = colorFilter
        textPaint.colorFilter = colorFilter
        invalidateSelf()
    }

    @Deprecated("Deprecated in Java")
    override fun getOpacity(): Int = PixelFormat.TRANSLUCENT

    private companion object {
        const val INTRINSIC_SIZE = 128
        const val CORNER_RATIO = 0.22f
        const val TEXT_RATIO = 0.38f
        const val TEXT_COLOR = 0xFFE8ECF8.toInt()

        // Azules y violetas oscuros de la paleta Medianoche
        val PALETTE = intArrayOf(
            0xFF2B3580.toInt(), 0xFF3A4690.toInt(), 0xFF2E4A7D.toInt(),
            0xFF37306E.toInt(), 0xFF1F5C7A.toInt(), 0xFF4A3A8C.toInt()
        )

        /** Hasta dos letras: "DW Español" → "DE", "Chaco TV" → "CT", "France 24 English" → "FE". */
        fun initialsOf(name: String): String {
            val words = name.split(Regex("[^\\p{L}\\p{N}]+")).filter { it.isNotEmpty() }
            val wordsWithLetters = words.filter { it.first().isLetter() }.ifEmpty { words }
            return when {
                wordsWithLetters.isEmpty() -> "?"
                wordsWithLetters.size == 1 -> wordsWithLetters[0].take(2)
                else -> "${wordsWithLetters[0].first()}${wordsWithLetters[1].first()}"
            }.uppercase()
        }
    }
}

/**
 * Carga el logo de un canal. Si no tiene URL, o mientras carga o si falla, muestra [InitialsDrawable].
 */
fun ImageView.loadChannelLogo(name: String, url: String?, cornerRadiusPx: Int = 0) {
    val fallback = InitialsDrawable(name)
    if (url.isNullOrBlank()) {
        Glide.with(context).clear(this)
        setImageDrawable(fallback)
        return
    }
    val request = Glide.with(context).load(url).placeholder(fallback).error(fallback)
    val finalRequest = if (cornerRadiusPx > 0) request.transform(RoundedCorners(cornerRadiusPx)) else request
    finalRequest.into(this)
}
