package com.angulismotv.player

import com.angulismotv.models.StreamType

object StreamUtils {

    /** Deduce el tipo de stream por la extensión de la URL cuando no viene indicado. */
    fun resolveType(url: String, providedType: String?): String {
        if (providedType != null && providedType.isNotEmpty() && providedType != StreamType.AUTO) return providedType
        return when {
            url.isEmpty() -> StreamType.AUTO
            url.contains(".mpd", ignoreCase = true) -> StreamType.DASH
            url.contains(".m3u8", ignoreCase = true) || url.contains(".m3u", ignoreCase = true) -> StreamType.HLS
            url.contains(".mp4", ignoreCase = true) ||
                url.contains(".mkv", ignoreCase = true) ||
                url.contains(".avi", ignoreCase = true) -> StreamType.MP4
            url.contains("youtube.com/embed") || url.contains("youtu.be") -> StreamType.IFRAME
            else -> StreamType.HLS
        }
    }
}
