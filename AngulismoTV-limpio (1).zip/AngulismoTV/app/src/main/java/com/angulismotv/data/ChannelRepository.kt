package com.angulismotv.data

import android.content.Context
import android.util.Log
import com.angulismotv.BuildConfig
import com.angulismotv.models.Channel
import com.angulismotv.network.HttpClient
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.withContext
import okhttp3.Request
import java.io.File
import java.util.concurrent.TimeUnit

/** Resultado de cargar la lista: los canales y por qué puede estar vacía. */
data class LoadResult(
    val channels: List<Channel>,
    val failed: Boolean = false,
    val notConfigured: Boolean = false,
    /** True si no hubo red y se muestra la última lista guardada. */
    val fromCache: Boolean = false
)

/**
 * Carga la lista de canales desde las URLs configuradas en `local.properties`
 * (CHANNELS_URL y EVENTS_URL). Si una URL está vacía simplemente se omite.
 *
 * Cada lista descargada correctamente se guarda en el almacenamiento interno; si después falla la
 * red (o el servidor devuelve algo roto), se usa esa copia en vez de dejar la pantalla vacía.
 */
object ChannelRepository {

    private const val TAG = "ChannelRepository"
    private const val TIMEOUT_SECONDS = 10L

    private class Loaded(val channels: List<Channel>, val fromCache: Boolean)

    /** Devuelve canales directos + eventos. Nunca lanza: informa el estado en [LoadResult]. */
    suspend fun loadAll(context: Context): LoadResult = coroutineScope {
        if (BuildConfig.CHANNELS_URL.isBlank() && BuildConfig.EVENTS_URL.isBlank()) {
            return@coroutineScope LoadResult(emptyList(), notConfigured = true)
        }
        val dir = context.applicationContext.filesDir
        val direct = async { load(BuildConfig.CHANNELS_URL, "todos", dir) }
        val events = async { load(BuildConfig.EVENTS_URL, "deportes", dir) }
        val results = listOf(direct.await(), events.await())

        val loaded = results.mapNotNull { it.getOrNull() }
        val channels = loaded.flatMap { it.channels }.mapIndexed { index, channel -> channel.copy(number = index + 1) }
        LoadResult(
            channels = channels,
            failed = channels.isEmpty() && results.any { it.isFailure },
            fromCache = loaded.any { it.fromCache && it.channels.isNotEmpty() }
        )
    }

    private suspend fun load(url: String, defaultCategory: String, dir: File): Result<Loaded> {
        if (url.isBlank()) return Result.success(Loaded(emptyList(), fromCache = false))
        return withContext(Dispatchers.IO) {
            runCatching { Loaded(fetch(url, defaultCategory, dir), fromCache = false) }
                .recoverCatching { error ->
                    Log.w(TAG, "No se pudo cargar $url: ${error.message}")
                    val cached = readCache(dir, url, defaultCategory) ?: throw error
                    Log.i(TAG, "Usando la lista guardada (${cached.size} canales)")
                    Loaded(cached, fromCache = true)
                }
        }
    }

    private fun fetch(url: String, defaultCategory: String, dir: File): List<Channel> {
        val client = HttpClient.shared.newBuilder().callTimeout(TIMEOUT_SECONDS, TimeUnit.SECONDS).build()
        val request = Request.Builder().url(url).header("Accept", "application/json").build()
        val body = client.newCall(request).execute().use { response ->
            check(response.isSuccessful) { "HTTP ${response.code}" }
            response.body?.string() ?: error("Respuesta vacía")
        }
        val channels = ChannelParser.parse(body, defaultCategory) // lanza si el JSON es inválido
        // Solo se guarda una copia válida y con contenido: nunca se pisa una buena con una rota o vacía
        if (channels.isNotEmpty()) writeCache(dir, url, body)
        return channels
    }

    // ---------- Caché ----------

    private fun cacheFile(dir: File, url: String) =
        File(dir, "channels_${Integer.toHexString(url.hashCode())}.json")

    private fun writeCache(dir: File, url: String, body: String) {
        runCatching {
            val target = cacheFile(dir, url)
            val temp = File(dir, target.name + ".tmp")
            temp.writeText(body)
            if (!temp.renameTo(target)) {
                target.writeText(body)
                temp.delete()
            }
        }.onFailure { Log.w(TAG, "No se pudo guardar la lista: ${it.message}") }
    }

    private fun readCache(dir: File, url: String, defaultCategory: String): List<Channel>? =
        runCatching {
            val file = cacheFile(dir, url)
            if (file.exists()) ChannelParser.parse(file.readText(), defaultCategory) else null
        }.getOrNull()?.takeIf { it.isNotEmpty() }
}
