package com.angulismotv.data

import android.util.Log
import com.angulismotv.BuildConfig
import com.angulismotv.models.Channel
import com.angulismotv.models.StreamOption
import com.angulismotv.models.StreamType
import com.angulismotv.network.HttpClient
import com.google.gson.Gson
import com.google.gson.annotations.SerializedName
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.withContext
import okhttp3.Request

/** Resultado de cargar la lista: los canales y por qué puede estar vacía. */
data class LoadResult(
    val channels: List<Channel>,
    val failed: Boolean = false,
    val notConfigured: Boolean = false
)

/**
 * Carga la lista de canales desde las URLs configuradas en `local.properties`
 * (CHANNELS_URL y EVENTS_URL). Si una URL está vacía simplemente se omite.
 */
object ChannelRepository {

    private const val TAG = "ChannelRepository"
    private val gson = Gson()

    // DTOs: todo nullable porque Gson ignora los valores por defecto de Kotlin.
    private data class Response(val channels: List<ChannelDto>?)

    private data class ChannelDto(
        val name: String?,
        val logo: String?,
        val streamUrl: String?,
        val streamType: String?,
        val show: Boolean?,
        val category: String?,
        val options: List<OptionDto>?
    )

    private data class OptionDto(
        val name: String?,
        @SerializedName("iframe") val url: String?,
        val streamType: String?
    )

    /**
     * Devuelve canales directos + eventos. Nunca lanza: informa el estado en [LoadResult] para que
     * la pantalla pueda distinguir "sin configurar", "falló la carga" y "lista vacía".
     */
    suspend fun loadAll(): LoadResult = coroutineScope {
        if (BuildConfig.CHANNELS_URL.isBlank() && BuildConfig.EVENTS_URL.isBlank()) {
            return@coroutineScope LoadResult(emptyList(), notConfigured = true)
        }
        val direct = async { load(BuildConfig.CHANNELS_URL, defaultCategory = "todos") }
        val events = async { load(BuildConfig.EVENTS_URL, defaultCategory = "deportes") }
        val results = listOf(direct.await(), events.await())
        val channels = results.flatMap { it.getOrDefault(emptyList()) }
        LoadResult(channels, failed = channels.isEmpty() && results.any { it.isFailure })
    }

    private suspend fun load(url: String, defaultCategory: String): Result<List<Channel>> {
        if (url.isBlank()) return Result.success(emptyList())
        return withContext(Dispatchers.IO) {
            runCatching {
                val request = Request.Builder().url(url).header("Accept", "application/json").build()
                HttpClient.shared.newCall(request).execute().use { response ->
                    check(response.isSuccessful) { "HTTP ${response.code}" }
                    val body = response.body?.charStream() ?: error("Respuesta vacía")
                    gson.fromJson(body, Response::class.java)
                        ?.channels.orEmpty()
                        .mapNotNull { it.toChannel(defaultCategory) }
                }
            }.onFailure { Log.w(TAG, "No se pudo cargar $url: ${it.message}") }
        }
    }

    private fun ChannelDto.toChannel(defaultCategory: String): Channel? {
        if (show == false) return null
        val options = options.orEmpty()
            .filter { !it.url.isNullOrBlank() }
            .map { StreamOption(it.name ?: "Opción", it.url!!, it.streamType ?: StreamType.IFRAME) }
        if (streamUrl.isNullOrBlank() && options.isEmpty()) return null
        return Channel(
            name = name ?: "Sin nombre",
            logo = logo.orEmpty(),
            streamUrl = streamUrl?.takeIf { it.isNotBlank() },
            streamType = streamType ?: StreamType.HLS,
            options = options.ifEmpty { null },
            category = category ?: defaultCategory
        )
    }
}
