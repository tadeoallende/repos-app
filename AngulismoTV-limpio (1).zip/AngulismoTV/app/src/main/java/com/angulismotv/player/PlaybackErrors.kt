package com.angulismotv.player

import com.google.android.exoplayer2.PlaybackException
import com.google.android.exoplayer2.upstream.HttpDataSource

/**
 * @param message texto para mostrarle al usuario.
 * @param permanent true si reintentar la misma dirección probablemente no sirva (canal caído,
 *   formato inválido, dispositivo sin soporte); false si es un corte pasajero (red, servidor, etc.).
 */
data class PlaybackProblem(val message: String, val permanent: Boolean)

/** Traduce los errores de ExoPlayer a mensajes claros y decide cómo reaccionar. */
object PlaybackErrors {

    fun fromException(error: PlaybackException): PlaybackProblem =
        classify(error.errorCode, httpStatusOf(error))

    fun classify(errorCode: Int, httpStatus: Int? = null): PlaybackProblem {
        if (httpStatus != null) {
            when (httpStatus) {
                401, 403 -> return PlaybackProblem(
                    "El canal no está disponible desde tu ubicación o requiere permiso (error $httpStatus).", true
                )
                404, 410 -> return PlaybackProblem(
                    "El canal ya no está disponible en esa dirección (error $httpStatus).", true
                )
                408, 429 -> return PlaybackProblem(
                    "El servidor del canal está saturado (error $httpStatus).", false
                )
                in 400..499 -> return PlaybackProblem(
                    "El servidor rechazó la solicitud (error $httpStatus).", true
                )
                in 500..599 -> return PlaybackProblem(
                    "El servidor del canal no responde (error $httpStatus).", false
                )
            }
        }

        return when (errorCode) {
            PlaybackException.ERROR_CODE_BEHIND_LIVE_WINDOW ->
                PlaybackProblem("Retomando la transmisión en vivo…", false)

            PlaybackException.ERROR_CODE_IO_NETWORK_CONNECTION_FAILED,
            PlaybackException.ERROR_CODE_IO_NETWORK_CONNECTION_TIMEOUT ->
                PlaybackProblem("No se pudo conectar con el canal. Verificá tu conexión a internet.", false)

            PlaybackException.ERROR_CODE_IO_FILE_NOT_FOUND ->
                PlaybackProblem("No se encontró la transmisión en esa dirección.", true)

            PlaybackException.ERROR_CODE_IO_CLEARTEXT_NOT_PERMITTED ->
                PlaybackProblem("El sistema bloqueó una conexión no segura.", true)

            PlaybackException.ERROR_CODE_IO_INVALID_HTTP_CONTENT_TYPE ->
                PlaybackProblem("La dirección no devuelve una transmisión de video.", true)

            PlaybackException.ERROR_CODE_PARSING_CONTAINER_MALFORMED,
            PlaybackException.ERROR_CODE_PARSING_MANIFEST_MALFORMED,
            PlaybackException.ERROR_CODE_PARSING_CONTAINER_UNSUPPORTED,
            PlaybackException.ERROR_CODE_PARSING_MANIFEST_UNSUPPORTED ->
                PlaybackProblem("La señal no tiene un formato de video válido.", true)

            PlaybackException.ERROR_CODE_DECODER_INIT_FAILED,
            PlaybackException.ERROR_CODE_DECODING_FAILED,
            PlaybackException.ERROR_CODE_DECODING_FORMAT_EXCEEDS_CAPABILITIES,
            PlaybackException.ERROR_CODE_DECODING_FORMAT_UNSUPPORTED ->
                PlaybackProblem("Tu dispositivo no puede reproducir el formato de esta señal.", true)

            else -> PlaybackProblem("Error de reproducción. Reintentando…", false)
        }
    }

    /** El código HTTP viene en la causa del error (puede estar varios niveles adentro). */
    private fun httpStatusOf(error: Throwable): Int? {
        var cause: Throwable? = error
        var depth = 0
        while (cause != null && depth < 8) {
            if (cause is HttpDataSource.InvalidResponseCodeException) return cause.responseCode
            cause = cause.cause
            depth++
        }
        return null
    }
}
