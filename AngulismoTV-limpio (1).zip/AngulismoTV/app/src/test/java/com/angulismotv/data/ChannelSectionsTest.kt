package com.angulismotv.data

import com.angulismotv.models.Channel
import org.junit.Assert.assertEquals
import org.junit.Test

class ChannelSectionsTest {

    private fun channel(name: String, category: String) = Channel(name = name, streamUrl = "https://x/$name.m3u8", category = category)

    @Test
    fun `las secciones siguen el orden de aparicion de cada categoria`() {
        val sections = ChannelSections.group(
            listOf(
                channel("A", "noticias"),
                channel("B", "internacionales"),
                channel("C", "noticias"),
                channel("D", "argentina")
            )
        )

        assertEquals(listOf("noticias", "internacionales", "argentina"), sections.map { it.category })
        assertEquals(listOf("A", "C"), sections[0].channels.map { it.name })
        assertEquals(listOf("B"), sections[1].channels.map { it.name })
    }

    @Test
    fun `unifica mayusculas y espacios y manda lo vacio a todos`() {
        val sections = ChannelSections.group(
            listOf(channel("A", "Noticias"), channel("B", " noticias "), channel("C", ""))
        )

        assertEquals(listOf("noticias", "todos"), sections.map { it.category })
        assertEquals(2, sections[0].channels.size)
    }

    @Test
    fun `una lista vacia no genera secciones`() {
        assertEquals(0, ChannelSections.group(emptyList()).size)
    }
}
