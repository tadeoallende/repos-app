package com.angulismotv.data

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertThrows
import org.junit.Test

class ChannelParserTest {

    @Test
    fun `lee canales con una fuente y con varias opciones`() {
        val json = """
            {"channels":[
              {"name":"A","logo":"l.png","streamUrl":"https://x/a.m3u8","streamType":"hls","category":"noticias"},
              {"name":"B","options":[
                {"name":"O1","iframe":"https://x/b.m3u8","streamType":"hls"},
                {"name":"vacía","iframe":""}
              ]}
            ]}
        """.trimIndent()

        val channels = ChannelParser.parse(json, "todos")

        assertEquals(2, channels.size)

        val a = channels[0]
        assertEquals("A", a.name)
        assertEquals("l.png", a.logo)
        assertEquals("https://x/a.m3u8", a.streamUrl)
        assertEquals("noticias", a.category)

        val b = channels[1]
        assertEquals("todos", b.category) // categoría por defecto
        assertEquals("", b.logo)
        assertNull(b.streamUrl)
        assertEquals(1, b.options!!.size) // la opción sin URL se descarta
        assertEquals("https://x/b.m3u8", b.options!![0].iframe)
        assertEquals("hls", b.options!![0].streamType)
    }

    @Test
    fun `descarta canales ocultos y sin fuentes`() {
        val json = """
            {"channels":[
              {"name":"Oculto","streamUrl":"https://x/c.m3u8","show":false},
              {"name":"Sin fuente"},
              {"name":"Opciones vacías","options":[]},
              {"name":"Bueno","streamUrl":"https://x/ok.m3u8"}
            ]}
        """.trimIndent()

        val channels = ChannelParser.parse(json, "todos")

        assertEquals(listOf("Bueno"), channels.map { it.name })
    }

    @Test
    fun `completa datos faltantes con valores por defecto`() {
        val channels = ChannelParser.parse("""{"channels":[{"streamUrl":"https://x/a.m3u8"}]}""", "deportes")

        assertEquals("Sin nombre", channels[0].name)
        assertEquals("hls", channels[0].streamType)
        assertEquals("deportes", channels[0].category)
    }

    @Test
    fun `ignora entradas nulas dentro de la lista`() {
        val json = """{"channels":[null,{"name":"A","streamUrl":"https://x/a.m3u8"}]}"""

        assertEquals(1, ChannelParser.parse(json, "todos").size)
    }

    @Test
    fun `una lista vacia es valida`() {
        assertEquals(0, ChannelParser.parse("""{"channels":[]}""", "todos").size)
    }

    @Test
    fun `texto vacio o sin lista de canales lanza error`() {
        assertThrows(IllegalArgumentException::class.java) { ChannelParser.parse("  \n", "todos") }
        assertThrows(IllegalArgumentException::class.java) { ChannelParser.parse("""{"foo":1}""", "todos") }
    }

    @Test
    fun `json cortado o invalido lanza error`() {
        assertThrows(IllegalArgumentException::class.java) {
            ChannelParser.parse("""{"channels": [ {"name": """, "todos")
        }
    }
}
