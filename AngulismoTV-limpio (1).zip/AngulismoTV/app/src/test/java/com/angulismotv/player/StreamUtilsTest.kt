package com.angulismotv.player

import org.junit.Assert.assertEquals
import org.junit.Test

class StreamUtilsTest {

    @Test
    fun `deduce el tipo por la extension`() {
        assertEquals("hls", StreamUtils.resolveType("https://a/b.m3u8", null))
        assertEquals("hls", StreamUtils.resolveType("https://a/b.M3U8?token=1", "auto"))
        assertEquals("dash", StreamUtils.resolveType("https://a/b.mpd", null))
        assertEquals("mp4", StreamUtils.resolveType("https://a/b.mp4", null))
        assertEquals("iframe", StreamUtils.resolveType("https://www.youtube.com/embed/live_stream?channel=X", null))
    }

    @Test
    fun `respeta el tipo indicado y usa hls si no puede deducirlo`() {
        assertEquals("dash", StreamUtils.resolveType("https://a/b.m3u8", "dash"))
        assertEquals("hls", StreamUtils.resolveType("https://a/stream", null))
    }

    @Test
    fun `url vacia queda en auto`() {
        assertEquals("auto", StreamUtils.resolveType("", null))
    }
}
