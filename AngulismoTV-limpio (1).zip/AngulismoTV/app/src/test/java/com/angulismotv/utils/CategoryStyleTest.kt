package com.angulismotv.utils

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotEquals
import org.junit.Test

class CategoryStyleTest {

    @Test
    fun `las categorias conocidas tienen su propio color`() {
        assertNotEquals(CategoryStyle.of("noticias").tile, CategoryStyle.of("internacionales").tile)
        assertEquals(CategoryStyle.of("noticias"), CategoryStyle.of(" Noticias "))
    }

    @Test
    fun `una categoria desconocida siempre recibe el mismo color`() {
        assertEquals(CategoryStyle.of("cocina"), CategoryStyle.of("cocina"))
        assertEquals(CategoryStyle.of("cocina"), CategoryStyle.of("COCINA"))
    }

    @Test
    fun `el nombre para mostrar es legible`() {
        assertEquals("Noticias", CategoryStyle.displayName("noticias"))
        assertEquals("Películas", CategoryStyle.displayName("peliculas"))
        assertEquals("Estilo de vida", CategoryStyle.displayName("estilo-vida"))
        assertEquals("Mi categoria", CategoryStyle.displayName("mi-categoria"))
        assertEquals("Canales", CategoryStyle.displayName("  "))
    }
}
