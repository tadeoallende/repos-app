package com.angulismotv.player

import com.google.android.exoplayer2.PlaybackException
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class PlaybackErrorsTest {

    private val badStatus = PlaybackException.ERROR_CODE_IO_BAD_HTTP_STATUS

    @Test
    fun `canal caido o prohibido es permanente y muestra el codigo`() {
        val notFound = PlaybackErrors.classify(badStatus, 404)
        assertTrue(notFound.permanent)
        assertTrue(notFound.message.contains("404"))

        assertTrue(PlaybackErrors.classify(badStatus, 403).permanent)
        assertTrue(PlaybackErrors.classify(badStatus, 410).permanent)
    }

    @Test
    fun `servidor saturado o caido es pasajero`() {
        assertFalse(PlaybackErrors.classify(badStatus, 503).permanent)
        assertFalse(PlaybackErrors.classify(badStatus, 500).permanent)
        assertFalse(PlaybackErrors.classify(badStatus, 429).permanent)
        assertFalse(PlaybackErrors.classify(badStatus, 408).permanent)
    }

    @Test
    fun `problemas de red y ventana en vivo son pasajeros`() {
        assertFalse(PlaybackErrors.classify(PlaybackException.ERROR_CODE_IO_NETWORK_CONNECTION_FAILED).permanent)
        assertFalse(PlaybackErrors.classify(PlaybackException.ERROR_CODE_IO_NETWORK_CONNECTION_TIMEOUT).permanent)
        assertFalse(PlaybackErrors.classify(PlaybackException.ERROR_CODE_BEHIND_LIVE_WINDOW).permanent)
    }

    @Test
    fun `formato invalido o decodificador sin soporte es permanente`() {
        assertTrue(PlaybackErrors.classify(PlaybackException.ERROR_CODE_PARSING_MANIFEST_MALFORMED).permanent)
        assertTrue(PlaybackErrors.classify(PlaybackException.ERROR_CODE_PARSING_CONTAINER_MALFORMED).permanent)
        assertTrue(PlaybackErrors.classify(PlaybackException.ERROR_CODE_DECODING_FORMAT_UNSUPPORTED).permanent)
        assertTrue(PlaybackErrors.classify(PlaybackException.ERROR_CODE_DECODER_INIT_FAILED).permanent)
    }

    @Test
    fun `un error desconocido se reintenta y siempre trae mensaje`() {
        val problem = PlaybackErrors.classify(PlaybackException.ERROR_CODE_UNSPECIFIED)

        assertFalse(problem.permanent)
        assertTrue(problem.message.isNotBlank())
    }

    @Test
    fun `el codigo http tiene prioridad sobre el codigo de error`() {
        assertEquals(true, PlaybackErrors.classify(PlaybackException.ERROR_CODE_IO_NETWORK_CONNECTION_FAILED, 404).permanent)
    }
}
