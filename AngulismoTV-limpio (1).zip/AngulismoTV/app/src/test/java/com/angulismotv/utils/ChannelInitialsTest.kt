package com.angulismotv.utils

import org.junit.Assert.assertEquals
import org.junit.Test

class ChannelInitialsTest {

    @Test
    fun `toma la inicial de las dos primeras palabras`() {
        assertEquals("DE", channelInitials("DW Español"))
        assertEquals("CT", channelInitials("Chaco TV"))
        assertEquals("AJ", channelInitials("Al Jazeera English"))
    }

    @Test
    fun `ignora los numeros si hay palabras con letras`() {
        assertEquals("FE", channelInitials("France 24 English"))
        assertEquals("CA", channelInitials("Canal 26"))
    }

    @Test
    fun `una sola palabra usa sus dos primeras letras`() {
        assertEquals("TE", channelInitials("teleSUR"))
        assertEquals("A", channelInitials("A"))
    }

    @Test
    fun `casos limite`() {
        assertEquals("24", channelInitials("24"))
        assertEquals("?", channelInitials(""))
        assertEquals("?", channelInitials("  --  "))
    }
}
