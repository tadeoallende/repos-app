# Modelos que Gson (de)serializa por reflexión
-keepclassmembers class com.angulismotv.data.ChannelParser$* { <fields>; }
-keep class com.angulismotv.models.** { *; }
-keepattributes Signature, *Annotation*

# Métodos expuestos al JavaScript del WebView
-keepclassmembers class * {
    @android.webkit.JavascriptInterface <methods>;
}
