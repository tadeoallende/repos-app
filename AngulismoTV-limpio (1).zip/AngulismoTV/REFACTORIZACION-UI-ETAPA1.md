# AngulismoTV — Refactorización de interfaz (etapa TV + reproductor)

## Alcance de esta entrega

- La navegación principal de Android TV muestra únicamente **Canales** y **Agenda**. Multicam y Foro siguen disponibles en el menú móvil.
- El rail lateral de TV parte de 72 dp y se amplía a 232 dp al recibir foco. El icono ocupa siempre una columna fija de 72 dp; las etiquetas aparecen al lado sin reacomodar el icono.
- El rail se superpone al contenido en lugar de empujarlo, y el ancho se cambia de forma inmediata para evitar carreras entre animaciones y cambios de foco.
- El encabezado de TV alinea la marca a la izquierda; el encabezado móvil conserva la composición centrada.
- En el reproductor, el vídeo/iframe permanece a pantalla completa y el panel de categorías + canales se muestra por encima. Al abrirlo ya no se redimensiona el vídeo.
- El foco de tarjetas y categorías usa los selectores existentes, sin escalado de elementos que pueda solaparse con las tarjetas vecinas.
- Se preserva la lógica existente de carga de canales, filtros, cambio de canal, opciones de stream, WebView/ExoPlayer, Cast, reconexión y manejo de errores.

## Probar antes de distribuir

1. Compilar `:app:assembleDebug`.
2. En TV, comprobar foco inicial, expansión del rail, recorrido arriba/abajo, OK para Canales/Agenda, derecha para entrar al contenido y Back.
3. Abrir el reproductor, abrir/cerrar el panel, moverse entre categorías y canales, cambiar de canal y probar una fuente tipo iframe y una fuente nativa si están disponibles.
4. En móvil, revisar cabecera centrada, navegación inferior, buscador, categorías y controles del reproductor.

Esta entrega no se presenta como compilada ni probada en hardware físico hasta completar esas comprobaciones.
