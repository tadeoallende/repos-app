# AngulismoTV — rediseño visual y revisión de foco

## Cambios aplicados

- Fondo espacial con un brillo nebuloso cian/azul de baja opacidad hecho con drawables XML estáticos. No incorpora imágenes de fondo, blur, partículas ni animaciones permanentes.
- Rail lateral opaco al expandirse, para evitar que se transparenten textos y tarjetas detrás de la navegación.
- Estados combinados de sección activa + foco en el rail de Android TV.
- Eliminación de escalado y elevación animada de las filas de categorías/canales. El foco se indica con el selector de fondo, evitando solapamientos y movimientos al navegar con D-pad.
- Apertura del panel del reproductor con el foco en el canal actual (o en el primer canal disponible); el buscador sigue accesible desde el panel.
- Recuperación del foco al volver a Canales: se reutiliza la última posición válida y se espera a que RecyclerView adjunte el elemento antes de solicitar foco. Si la lista está vacía, se usa un destino alternativo enfocable.
- Ancho de las columnas de categorías/canales adaptado a la pantalla para reservar espacio para el reproductor y evitar que el panel sobrepase el ancho disponible.
- Cambios entre secciones sin fade en Android TV para reducir parpadeos y carreras de foco; las transiciones móviles se conservan.

## Verificaciones realizadas

- 61 archivos XML analizados correctamente.
- 0 referencias de recursos XML sin resolver.
- 0 referencias `R.id` en Kotlin sin definición en los XML del proyecto.
- Revisión estática de las rutas de foco: apertura del panel, salto entre categorías y canales, cierre del panel, retorno al reproductor y regreso desde Agenda a Canales.
- Comprobación matemática del reparto de ancho del panel para anchos representativos de pantalla.

## Limitación de verificación

No fue posible ejecutar `assembleDebug` en este entorno: el Gradle Wrapper necesita descargar Gradle 8.13 desde `services.gradle.org`, pero la conexión DNS no está disponible; tampoco hay un Android SDK instalado en el entorno. Por tanto, las comprobaciones son estáticas y no sustituyen una compilación ni una prueba en emulador/Android TV físico. El código de reproducción y los flujos de datos no se reescribieron.

## Prueba recomendada en dispositivo

1. Abrir un canal y abrir/cerrar el panel varias veces con el mando.
2. Navegar izquierda/derecha entre categorías y canales, y arriba/abajo dentro de las listas.
3. Cambiar de categoría, seleccionar otro canal y confirmar que el foco regresa al video.
4. Volver a Canales desde Agenda y confirmar que el foco cae en un canal visible.
5. Repetir en una TV de 720p y otra de 1080p/4K, además de validar la navegación táctil en móvil.
