# AngulismoTV — refactorización visual por etapas

## Etapa 1 incluida en esta versión

- Menú lateral de Android TV con anchos fijos en dp: 64dp colapsado y 224dp expandido, en lugar de porcentajes del ancho de pantalla.
- Elementos de navegación con altura uniforme, iconos centrados cuando está colapsado y etiquetas alineadas cuando está expandido.
- Animación de ancho cancelable para evitar que varias animaciones compitan al mover el foco rápidamente.
- Encabezado principal un poco más espacioso.
- Botones del reproductor con áreas de interacción mayores y barra inferior con más aire. No se reemplazó el motor de reproducción ni la lógica de streams.

## Etapas siguientes recomendadas

1. Probar el menú con control remoto real y ajustar el recorrido del foco según el dispositivo.
2. Revisar visualmente Canales, estados vacíos/errores, categorías y tarjetas con capturas de TV y móvil.
3. Refactorizar el reproductor por responsabilidades (controles, panel de canales, estados de reproducción) sin cambiar el comportamiento de ExoPlayer/WebView/Cast.
4. Validar orientación, gestos, foco, accesibilidad y tamaños en TV y celular.

## Validación

Se intentó ejecutar `:app:assembleDebug`, pero el entorno no pudo descargar Gradle por falta de conexión a `services.gradle.org`. La compilación queda pendiente de validación en Android Studio o GitHub Actions.
