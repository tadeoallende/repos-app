# Rediseño de la pantalla de TV de AngulismoTV

## Cambios incluidos

- Reorganización de la pantalla del reproductor para Android TV en tres zonas: categorías a la izquierda, reproducción al centro y canales a la derecha.
- Cabecera compacta de AngulismoTV con estado de TV en vivo.
- El selector de categorías y canales se abre al entrar al reproductor en TV. La selección de otro canal mantiene visibles los paneles para facilitar el zapping.
- Barra de controles compacta visible mientras está abierto el selector.
- Filas de canales algo más compactas y con logos alineados para mostrar más señales sin perder legibilidad.
- Iconos diferentes para categorías habituales, manteniendo las categorías reales recibidas desde los datos de canales.
- Fondo espacial con gradientes estáticos azulados y violetas; no se añadieron animaciones de partículas, desenfoques ni dependencias nuevas.
- En móviles se conserva el reproductor a pantalla completa y se oculta la cabecera exclusiva de TV.

## Archivo más relevante

`app/src/main/res/layout/activity_unified_player.xml`

La lógica de los motores ExoPlayer/WebView, las fuentes alternativas, el control con mando y Cast se mantienen en el proyecto. También se modificó `UnifiedPlayerActivity.kt` para manejar el nuevo ancho de los paneles.

## Verificación

Se validó que los XML sean bien formados y que los IDs usados por `UnifiedPlayerActivity` sigan existiendo. No se pudo ejecutar `assembleDebug` en este entorno porque Gradle necesita descargar la distribución 8.13 y no hay conexión a `services.gradle.org`.

Para compilar en Windows desde Android Studio o una terminal con acceso a Gradle:

```bat
gradlew.bat :app:assembleDebug
```
