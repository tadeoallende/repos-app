# AngulismoTV — Etapa 33: separar la cola de zapping

## Cambios
- Se extrajo la acumulación de pulsaciones CH+/CH- a `ChannelZappingQueue`, una clase Kotlin sin dependencias Android.
- `UnifiedPlayerActivity` delega en esa clase la acumulación, consumo y limpieza del desplazamiento pendiente; sigue siendo responsable de iniciar la transición y actualizar la interfaz.
- Se agregaron pruebas unitarias para pulsaciones rápidas, cancelación de direcciones opuestas, normalización circular, consumo único y catálogo vacío.

## Validación
- Las pruebas se escribieron usando el estilo JUnit ya presente en el proyecto.
- ZIP verificado por integridad y XML revisados.
- No fue posible ejecutar las pruebas: el wrapper necesita descargar Gradle 8.13 y el entorno no resuelve `services.gradle.org`. Las pruebas están agregadas pero su ejecución sigue pendiente.
