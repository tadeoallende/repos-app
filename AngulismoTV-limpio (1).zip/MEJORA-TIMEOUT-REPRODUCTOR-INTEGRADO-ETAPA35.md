# AngulismoTV — Etapa 35: timeout de inicio en el reproductor integrado

## Problema
En `ChannelsFragment`, el reproductor nativo integrado mostraba el indicador de carga durante `STATE_BUFFERING`, pero no tenía un límite de tiempo para una fuente que nunca llegara a `STATE_READY`. Una fuente que se quedara colgada sin emitir `onPlayerError` podía dejar el reproductor en carga indefinidamente.

## Cambio
- Se agregó un timeout de inicio de 12 segundos para el motor nativo integrado.
- El timeout se cancela al llegar a `READY`, ante un error, al liberar el motor, al pausar/ocultar el fragmento o al transferir el reproductor a pantalla completa.
- Al volver a primer plano o mostrar el fragmento, se vuelve a programar si el reproductor continúa sin estar listo.
- Si vence mientras el mismo reproductor y la misma generación siguen activos, se libera el motor y se muestra un error con la opción de recargar o elegir otra fuente manualmente. No se cambia de fuente por cuenta propia.
- Se registra el tipo y el host de la fuente para ayudar a diagnosticar el problema sin volcar la URL completa.

## Validación
- Revisado el control de generación/identidad para ignorar temporizadores obsoletos.
- ZIP comprobado por integridad y XML revisados.
- No se afirma compilación ni prueba en dispositivo: Gradle 8.13 no pudo descargarse en este entorno; hace falta probar tanto una fuente que llega a `READY` como otra que queda bloqueada en carga.
