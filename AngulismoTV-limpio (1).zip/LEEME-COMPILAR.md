# Compilar sin Android Studio

1. Creá un repositorio en GitHub (puede ser privado) y subí esta carpeta.
   `local.properties`, los `.apk`, los `.jks` y los tokens ya están excluidos por `.gitignore`.
2. Entrá a la pestaña **Actions**: el workflow **Build** corre solo en cada push (o con *Run workflow*).
3. Si compila bien, al final aparece el artefacto **AngulismoTV-debug** con el APK para instalar.
4. Si falla, abrí el paso en rojo, copiá el error (líneas que empiezan con `e:`) y pasámelo.

## Configuración de fuentes (opcional)

La fuente primaria de canales es IPTV-org y por defecto apunta a su playlist pública principal (`https://iptv-org.github.io/iptv/index.m3u`). Si no responde, no es M3U válido o no contiene canales utilizables, la app utiliza tus feeds JSON como fallback.

- `IPTV_ORG_URL`: fuente M3U primaria. Para solo Argentina podés usar `https://iptv-org.github.io/iptv/countries/ar.m3u`. Configurá el valor literal `disabled` para deshabilitar IPTV-org.
- `CHANNELS_URL`: tu JSON de canales, usado como fallback.
- `EVENTS_URL`: tu JSON de eventos/canales, usado como fallback.
- `UPDATE_URL`: manifiesto JSON de actualizaciones.
- `WEB_BASE_URL`: sitio de Agenda.

**En GitHub Actions:** en *Settings → Secrets and variables → Actions* podés definir `IPTV_ORG_URL`, `CHANNELS_URL`, `EVENTS_URL`, `UPDATE_URL` y `WEB_BASE_URL`. Si el secreto `IPTV_ORG_URL` no existe o está vacío, se usa la URL oficial por defecto. Para deshabilitar la fuente primaria y usar siempre tus fuentes propias, configurá el valor literal `disabled` en ese secreto o en `local.properties`.

**En tu PC:** copiá `local.properties.example` a `local.properties` y editá las URLs. Para deshabilitar IPTV-org localmente, configurá `IPTV_ORG_URL=disabled`.

Nota: la lista propia no se mezcla con IPTV-org. Se usa únicamente cuando la fuente principal falla o no devuelve ninguna entrada reproducible, tal como fallback.

Ojo: todo lo que se compila dentro del APK puede extraerse de él, así que no pongas ahí credenciales.


## Etapa 7
Esta versión unifica la paleta y el tratamiento visual de diálogos y menús. La compilación debe hacerse en un entorno Android con la distribución Gradle 8.13 disponible; en el entorno de edición no se pudo descargar por falta de conexión a `services.gradle.org`.


### Corrección de etapa 7 (error AAPT)
Si descargaste la primera etapa 7 y falló con `resource android:style/Widget.Material.ContextPopupMenu is private`, usa esta versión corregida. El estilo contextual ya no hereda del recurso interno de Android.


## Etapa 31 — manifiestos de actualización con firma digital

El actualizador ahora exige una firma RSA-SHA256 para el manifiesto además del SHA-256 del APK. Consulta `FIRMA-DIGITAL-ACTUALIZADOR-ETAPA31.md` para configurar `UPDATE_PRIVATE_KEY_PEM` y publicar el JSON junto con su archivo `.sig`. El workflow **Firmar manifiesto de actualización** permite hacerlo desde la pestaña Actions, sin terminal ni Android Studio.

**Importante:** el nombre que ingreses al firmar debe coincidir con el archivo al que apunta `UPDATE_URL` (y se publicará también como `<nombre>.sig`). No edites el JSON después de descargar el artefacto. Antes de usar el autoactualizador en instalaciones existentes, asegurate también de que el APK esté firmado con el mismo certificado Android que la app instalada.
