# Etapa 43 — QA y límites de validación

## Verificaciones ejecutadas

- `InlineSourceResolver` y `InlinePlaybackSessionState` compilaron con Kotlin 1.9 en un harness local usando versiones mínimas de los modelos Android-dependientes.
- 17 escenarios del harness cubrieron resolución de opción, selección inválida, URL en blanco, tipos inferidos, invalidación por cambio de canal, cambio/recarga de fuente, restauración desde fullscreen, fallo de intento, elegibilidad de Cast y limpieza.
- Las 10 pruebas nuevas de `InlineSourceResolverTest` y `InlinePlaybackSessionStateTest` se compilaron y ejecutaron con un runner local compatible con las aserciones JUnit. Esto **no equivale** a ejecutar la suite de Gradle del proyecto.
- `InlineWebViewPlaybackController` compiló contra stubs locales de las API Android que utiliza. Un harness de 9 escenarios comprobó carga, foco en móvil, evento de página cargada, deduplicación de errores de red/HTTP, evento obsoleto, limpieza a `about:blank` y excepción síncrona de `loadUrl`.
- Los archivos XML del proyecto se validaron con el parser XML.
- El ZIP final se comprobó con `unzip -t`.

## Pendiente

No fue posible completar `testDebugUnitTest` ni `assembleDebug`: el wrapper necesita descargar Gradle 8.13 y el entorno no puede resolver `services.gradle.org`. No se afirma que el APK compile ni que la reproducción/Cast/fullscreen haya sido probada en un dispositivo real.

Antes de publicar en GitHub, ejecutar las pruebas oficiales y la compilación en un entorno con Gradle disponible, y probar especialmente: cambio rápido de fuentes, recarga tras error, volver de fullscreen con iframe, rotación móvil y reanudación después de ocultar/mostrar el fragmento.
