# AngulismoTV — Etapa 34: error visible si la última fuente no inicia

## Problema
El fallback del reproductor fullscreen probaba la siguiente opción tras 12 segundos de `IDLE`/`BUFFERING`, pero si la opción que fallaba era la última no hacía nada. Como el watchdog de recuperación se activa al llegar a `STATE_READY`, una fuente que nunca llegara a estar lista podía dejar el indicador de carga girando indefinidamente.

## Cambio
- Si queda una opción alternativa, se conserva el comportamiento de liberar el reproductor actual e intentar la siguiente.
- Si no quedan alternativas y la fuente sigue en `IDLE`/`BUFFERING`, se libera el reproductor y se muestra un error accionable con las opciones Recargar o elegir otra fuente.
- Se mantienen las comprobaciones de generación, canal actual e índice de fuente para ignorar temporizadores obsoletos.

## Validación
- Revisión estática de la rama terminal y del orden `releasePlayer()` → `showError()`.
- ZIP comprobado por integridad y XML revisados.
- No se afirma prueba funcional: la compilación de Gradle no se pudo ejecutar porque no se pudo descargar Gradle 8.13; falta probar una fuente lenta/fallida en un dispositivo real.
