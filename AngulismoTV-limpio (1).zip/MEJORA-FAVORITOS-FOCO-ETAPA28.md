# AngulismoTV — Favoritos y refinamiento del foco TV (etapa 28)

## Base de trabajo

Se aplicaron los cambios sobre el código fuente original incluido en `AngulismoTV-fuentes-fix.zip`. No se utilizó la variante reducida CanalesTV.

## Cambios implementados

- Se expuso la colección persistente de `FavoritesStore` como una vista dentro del panel lateral del reproductor, inmediatamente debajo de Buscar. La entrada muestra el contador, estado seleccionado y un mensaje accesible.
- La vista Favoritos filtra por la identidad estable de cada canal y permite seguir aplicando categorías. Si no hay favoritos, muestra una explicación en vez de una lista vacía sin contexto.
- Al agregar o quitar el corazón del reproductor, se actualiza el contador y, cuando corresponde, la lista de Favoritos abierta. Al volver a la pantalla principal se vuelve a sincronizar la pestaña activa.
- Se incorporaron pestañas Canales / Favoritos en la pantalla principal móvil y en el panel de catálogo de TV, debajo del reproductor/acciones superiores. Ambas vistas reutilizan la misma persistencia de favoritos.
- Se corrigieron inserciones duplicadas de los bloques XML de Favoritos que habían dejado repetidos los IDs de las pestañas móviles y de la fila del panel de TV.
- Se definió la navegación D-pad: en el panel del reproductor, Cerrar → Buscar → Favoritos → Lista de canales → Categorías. En la vista principal TV, las pestañas conducen a la lista y el primer canal devuelve el foco a Favoritos.
- Se uniformó el feedback del foco en controles, pestañas, filas de canales y categorías: escala moderada (aprox. 1,025–1,045) y acento en icono/texto. En los controles circulares se quitó el disco de relleno al enfocar; queda un contorno fino.
- Se reemplazó el fondo cian sólido del chip de categoría enfocado por una superficie oscura con borde discreto, para conservar el contraste del texto.

## Validaciones realizadas

- 87 archivos XML parseados correctamente.
- No se detectaron IDs duplicados en los layouts.
- Se comprobó que los nuevos IDs, drawables y selectores de color están declarados.
- Prueba aislada de las transiciones verticales de `PanelRailFocusPolicy`: correcta.
- Se revisaron las comprobaciones de generación y actualización asíncrona de listas para no aplicar resultados de un modo Favoritos anterior.

## Limitación de compilación

No se pudo completar `:app:assembleDebug` en este entorno. El Gradle Wrapper intenta descargar Gradle 8.13 desde `services.gradle.org`, pero la conexión falla con `UnknownHostException`. Tampoco hay Android SDK configurado aquí. Por eso este paquete no se presenta como APK compilado ni como probado en dispositivo.

## Prueba manual recomendada

1. En móvil, guardar y quitar un canal desde el corazón del reproductor; volver y comprobar que la pestaña Favoritos se actualiza.
2. Abrir Favoritos sin canales guardados y comprobar el mensaje vacío; añadir el primero y verificar que aparece.
3. En TV, recorrer con el mando las pestañas, la lista y el primer canal; comprobar que el foco no cubre el texto con un relleno cian.
4. En el panel lateral del reproductor, recorrer Cerrar → Buscar → Favoritos → Lista de canales → Categorías y verificar que el contador y el filtrado coinciden.

## Revisión posterior (sin compilar)

- `side_category_item_selected.xml`: la fila seleccionada del panel del reproductor (Favoritos, Lista de canales, categoría activa) se rellenaba con `accent_surface_subtle` (#5CC7C6), el mismo cian que el texto resaltado, y quedaba ilegible. Ahora usa superficie oscura con borde discreto.
- `bg_count_chip.xml`: el contador usaba el mismo cian sólido con texto violeta; ahora superficie oscura con borde.
- `ChannelsFragment`: `setCategoryFocusTarget` usa el id constante `R.id.btn_favorites_view_tab` en lugar de leer `favoritesViewTab.id`, que falla si la vista ya fue liberada.

## Número de canal en el zapping

- Al cambiar de canal (CH+/CH-, número tecleado o elección desde el panel) se muestra el número del canal arriba a la derecha, junto al logo que ya aparecía arriba a la izquierda. Se oculta a los 2 s, igual que el logo.
- El número es la posición del canal en el catálogo (1 = primero), la misma que se teclea con el mando.
- Cambios: `activity_unified_player.xml` (`zapping_number`), `dimens.xml` (`text_size_zapping_number`, 40sp), `ZappingOverlayController` (parámetro opcional del número) y `UnifiedPlayerActivity` (calcula el número en `beginZapTransition`). `PlayerZappingController` y sus pruebas no cambian.

## Corrección de compilación

- `PlayerChannelPanelController`: el parámetro `searchEmptyText` estaba declarado como `View`, pero el modo favoritos le asigna `.text` (error `Unresolved reference 'text'` en la línea 434). Ahora es `TextView`; la Activity ya le pasa un `TextView`.
