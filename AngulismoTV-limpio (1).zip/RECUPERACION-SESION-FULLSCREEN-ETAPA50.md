# Etapa 50 — recuperación de sesión entre reproductor integrado y fullscreen

## Cambios

- `InlinePlayerHandoff.recoverUnclaimedFullscreenToInline()` devuelve atómicamente una sesión ofrecida por `ChannelsFragment` pero no reclamada por `UnifiedPlayerActivity`. Cubre cierres durante el arranque, antes de resolver la fuente.
- `returnSessionToInline()` intenta recuperar primero esa sesión pendiente y conserva una ruta de devolución para sesiones que la Activity ya reclamó.
- El canal de retorno puede recuperarse desde la sesión WebView original o desde el Intent si la carga del catálogo todavía no asignó `currentChannel`.
- `InlineSessionReturnPolicy` centraliza la decisión de recuperación y el fallback de URL/tipo/índice cuando fullscreen termina antes de resolver una fuente nueva.
- La devolución de un WebView calcula el tipo efectivo antes de decidir si debe navegar a `about:blank`. Así no borra la página iframe original cuando la Activity todavía tiene el tipo predeterminado `AUTO`.
- `releasePlayer()` ya no inicializa el controlador lazy de recuperación solo para detener un watchdog inexistente.

## Validación

- `InlineSessionReturnPolicy` compiló con `kotlinc`; 6 escenarios smoke pasaron.
- Los 74 XML del proyecto se analizaron sin errores.
- El ZIP acumulativo pasó `unzip -t`.
- `testDebugUnitTest` no pudo arrancar: el wrapper no pudo descargar Gradle 8.13 por `UnknownHostException: services.gradle.org`. No se afirma que el APK compile ni que la transferencia esté probada en un dispositivo.
