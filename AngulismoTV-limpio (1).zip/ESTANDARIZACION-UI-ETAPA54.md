# AngulismoTV — Estandarización de interfaz (etapa 54)

## Objetivo

Consolidar una base visual reutilizable sin rediseñar de golpe la aplicación ni alterar intencionalmente las medidas que ya estaban funcionando. Móvil y Android TV conservan sus perfiles y diferencias de composición.

## Qué se centralizó

- **Paleta:** los layouts y drawables ya no contienen colores hexadecimales sueltos. Se usan nombres de `res/values/colors.xml`; el negro de las superficies de vídeo sigue siendo negro real cuando corresponde.
- **Dimensiones:** se añadieron tokens compartidos de espaciado, tamaños, tipografía, radios, anchos de borde y elevaciones en `res/values/dimens.xml`. También hay dimensiones semánticas para cabecera, menú lateral TV, filas de canales, chips, búsqueda, controles del reproductor y su timeline.
- **Tipografía:** nuevo `res/values/styles.xml` con apariencias de texto para nombres y números de canal, categorías, búsqueda, mensajes de error, metadatos del reproductor, guías de TV y títulos de panel.
- **Recursos gráficos:** los íconos vectoriales reutilizan dimensiones globales; radios, bordes e insets de drawables pasan a usar tokens de dimensiones.
- **Kotlin:** se añadió `utils/UiDimensions.kt`, que obtiene tamaños desde recursos en píxeles. Los cambios de cabecera, filas/chips, perfil responsive y controles del reproductor dejaron de repetir conversiones `dp()` y valores de tipografía en los lugares intervenidos. También se centralizaron el tamaño de los controles TV, el máximo ancho del rótulo de zapping y el radio del logo de canal.

## Archivos principales

- `app/src/main/res/values/colors.xml`
- `app/src/main/res/values/dimens.xml`
- `app/src/main/res/values/styles.xml` (nuevo)
- `app/src/main/res/values/themes.xml`
- `app/src/main/res/layout/` — layouts de actividad, canales, agenda y filas/chips
- `app/src/main/res/drawable/` — fondos, estados de foco, superficies y vectores
- `MainActivity.kt`, `UnifiedPlayerActivity.kt`, `ChannelsFragment.kt`, `ChannelsAdapter.kt`, `ChannelCategoryRailRenderer.kt`
- `app/src/main/java/com/angulismotv/utils/UiDimensions.kt` (nuevo)

## Compatibilidad de perfiles

Los valores migrados conservan sus medidas de origen en dp/sp: la etapa busca que el siguiente ajuste visual se haga desde los recursos, no cambiar arbitrariamente el aspecto. Los tamaños semánticos de cabecera y controles continúan diferenciando móvil y TV. No se agregó un reloj a móvil; el reloj sigue sin formar parte de esta etapa.

## Validación efectuada

- Se analizaron sintácticamente los **74 XML** del directorio de recursos; no hubo errores.
- Se comprobó que las referencias a recursos locales usadas desde XML resuelven; no hubo referencias faltantes.
- Se inspeccionaron referencias `R.*` en Kotlin; no se detectaron nombres de recursos inexistentes.
- No quedan literales hexadecimales de color en `layout/` ni `drawable/`.
- En los recursos XML no quedan dimensiones positivas escritas directamente en dp/sp fuera de `dimens.xml`; los valores `0dp` siguen literales en constraints, pesos y márgenes de cero donde son convencionales.
- `UiDimensions.kt` se compiló de forma aislada con un stub mínimo de `Resources`, y pasó un smoke test.
- Se intentó ejecutar `./gradlew testDebugUnitTest --no-daemon`; la ejecución se detuvo antes de compilar porque Gradle 8.13 no pudo descargarse: `UnknownHostException: services.gradle.org`.

## Decisiones y límites de esta etapa

`CrashActivity` se mantiene deliberadamente autocontenida, con dimensiones y colores propios: es una pantalla de diagnóstico que debe seguir siendo simple incluso cuando el fallo original pueda estar en un recurso o tema. Los cálculos que convierten el ancho real de pantalla a dp para decidir la anchura del panel TV siguen siendo cálculos responsive, no medidas fijas.

Las comprobaciones de recursos y del helper no sustituyen AAPT/Gradle, una compilación Android completa ni pruebas visuales en teléfono y televisor. La interfaz debe revisarse en ambos perfiles tras recuperar conectividad para Gradle y generar una build instalable. No se rediseñó el contenido de Agenda ni se añadió un reloj a móvil. Los cambios no se publicaron en GitHub en esta etapa.
