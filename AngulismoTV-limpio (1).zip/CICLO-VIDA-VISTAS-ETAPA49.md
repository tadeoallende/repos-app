# Etapa 49 — ciclo de vida de vistas de ChannelsFragment

## Cambios

- Se reemplazaron los campos `lateinit` que retenían controles y superficies del layout por `ChannelsFragmentViews`, un holder válido para un solo árbol de vistas.
- `onDestroyView()` invalida primero la generación activa y libera el holder al final. `ChannelsFragment` ya no conserva directamente el `RecyclerView`, los botones, `PlayerView`, `WebView`, seek bar y demás vistas del árbol anterior.
- Se agregó `ViewLifecycleGate`: las tareas diferidas del foco inicial, el mando, el `AsyncListDiffer`, el cambio de orientación y el listener de layout verifican el token exacto del árbol que las programó. Así, una tarea vieja no puede aprovechar que existe una vista nueva para actuar sobre la anterior.
- Se añadió `ViewPostCallbackRegistry` para registrar los `View.post` de una vista, cancelar físicamente sus callbacks y liberar referencias cuando se destruye el árbol.
- `ChannelCatalogFocusController` usa ese registro compartido para sus restauraciones de foco. El foco inicial y el retorno al reproductor también pasan por el registro, por lo que dejan de depender solamente del token de generación.
- `ChannelsAdapter` y `InlineControlsAutoHideController` dejaron de ser propiedades `lateinit` persistentes. Se liberan y pasan a `null` al destruir la vista, para que el Fragment no retenga el adapter viejo ni controladores asociados al árbol anterior.
- Se añadieron guardas a las entradas de selección, búsqueda, foco, recarga y apertura de fullscreen para ignorar eventos tardíos cuando ya no hay una vista activa.
- El diálogo de selección de fuente ahora se conserva como estado de la vista; se cierra y se desengancha al destruirla. Sus acciones y su callback de cierre validan el token del árbol original.
- Se elimina el listener táctil del `WebView` al transferirlo a fullscreen y se instala uno nuevo al devolver la instancia. Esto evita que el WebView de fullscreen conserve callbacks del fragmento que lo creó.
- Se detienen y se anulan los controladores que retienen vistas (`PlayerTimelineController`, visual renderer, estado del catálogo, foco, categoría, búsqueda, Cast y controlador WebView). Se retira el `TextWatcher`, se cancela el temporizador de controles, se limpian los listeners de la UI y se desasocia el adapter del `RecyclerView`.
- Se mueve la limpieza del `WebView` antes de `destroy()`: no se invocan métodos de `View` sobre esa instancia después de destruirla.
- Se añadió `ViewLifecycleGateTest.kt` con cuatro pruebas unitarias para activación, invalidación, recreación con token nuevo e invalidación repetida.

## Verificaciones realizadas

- Compilé `ViewLifecycleGate.kt` con `kotlinc` y ejecuté un smoke test aislado: **4 escenarios OK**.
- Compilé `ChannelsFragmentViews.kt` por separado contra stubs mínimos de las APIs Android que usa. Esto verifica sintaxis y tipos del holder, pero no constituye una compilación Android completa.
- Compilé `ChannelCatalogFocusController.kt` y `ViewPostCallbackRegistry.kt` contra stubs de Android/RecyclerView y ejecuté un smoke test encolando una restauración de foco, llamando a `dispose()` y verificando que la tarea pendiente se cancelara y no se pudiera reprogramar: **OK**.
- Revisé que los 31 IDs obligatorios del holder estén definidos en `fragment_channels.xml` y `fragment_channels_tv.xml`.
- Analicé **73 recursos XML**: sin errores de parseo.
- La revisión estática confirma que `ChannelsFragment` ya no mantiene campos `lateinit`, ni para vistas ni para el adapter/controlador de controles.
- Analicé el archivo de `ChannelsFragment` con el parser de Kotlin sin hallar diagnósticos de sintaxis. La compilación completa del archivo no es posible sin el classpath de Android/AndroidX y el build system.
- El ZIP pasa `unzip -t`.

## Pendiente

Intenté ejecutar `bash ./gradlew testDebugUnitTest --no-daemon`, pero el wrapper falla antes de configurar el proyecto porque no puede resolver `services.gradle.org` (`UnknownHostException`) para descargar Gradle 8.13. No se pudo ejecutar la suite JUnit ni compilar el APK. El smoke test de callbacks no sustituye la suite oficial. Aún hace falta probar la recreación de la vista y el traspaso del WebView en Android TV y móvil. Esta tanda prioriza el ciclo de vida y la cancelación segura, por lo que `ChannelsFragment.kt` crece en líneas respecto de la etapa anterior; no se presenta como una reducción de tamaño, sino como una reducción de referencias persistentes y riesgos de callbacks obsoletos.
