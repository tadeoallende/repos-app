# AngulismoTV — Etapa 36: separar el fallback de fuentes

## Cambios
- Se extrajo el timeout y la decisión de fallback de `UnifiedPlayerActivity` a `ChannelOptionFallbackController`.
- El controlador recibe por callbacks la generación activa, el canal/fuente seleccionados, el reproductor y las acciones para liberar, intentar otra fuente o mostrar un error; no toma posesión de la Activity ni de sus vistas.
- Se conserva el timeout de 12 segundos para fuentes nativas, sin aplicar esta política a iframes.
- Si una opción nativa no inicia, prueba la siguiente; si era la última, libera el reproductor y presenta un error recuperable.
- `UnifiedPlayerActivity` conserva métodos puente pequeños para programar/cancelar el fallback y lo libera durante `onDestroy()`.

## Validación
- Revisado el control de generación, canal e índice para descartar temporizadores obsoletos.
- ZIP verificado por integridad y XML revisados.
- No se declara compilación: Gradle 8.13 no pudo descargarse en este entorno. Falta ejecutar pruebas y verificar los escenarios de fallback en dispositivos.
