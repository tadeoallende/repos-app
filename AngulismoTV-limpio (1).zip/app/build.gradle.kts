import java.util.Properties

plugins {
    alias(libs.plugins.android.application)
    alias(libs.plugins.kotlin.android)
    alias(libs.plugins.kotlin.parcelize)
}

// Configuración local (no se sube al repo): ver local.properties.example
val localProps = Properties().apply {
    rootProject.file("local.properties").takeIf { it.exists() }?.inputStream()?.use(::load)
}
// Orden: local.properties → propiedad Gradle / variable ORG_GRADLE_PROJECT_<NOMBRE> → valor por defecto.
// Un valor vacío cuenta como "no definido".
fun prop(name: String, default: String = ""): String =
    listOf(localProps.getProperty(name), providers.gradleProperty(name).orNull)
        .firstOrNull { !it.isNullOrBlank() } ?: default

android {
    namespace = "com.angulismotv"
    compileSdk = 36

    defaultConfig {
        applicationId = "com.angulismotv"
        minSdk = 21
        targetSdk = 34
        versionCode = 4
        versionName = "1.3"

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"

        // URLs configurables (vacías = función deshabilitada)
        buildConfigField("String", "IPTV_ORG_URL", "\"${prop("IPTV_ORG_URL", "https://iptv-org.github.io/iptv/index.m3u")}\"")
        buildConfigField("String", "CHANNELS_URL", "\"${prop("CHANNELS_URL")}\"")
        buildConfigField("String", "EVENTS_URL", "\"${prop("EVENTS_URL")}\"")
        buildConfigField("String", "UPDATE_URL", "\"${prop("UPDATE_URL")}\"")
        buildConfigField("String", "WEB_BASE_URL", "\"${prop("WEB_BASE_URL", "https://angulismotv.pages.dev")}\"")
    }

    signingConfigs {
        // Solo se crea si definís las 4 propiedades en local.properties
        if (prop("RELEASE_STORE_FILE").isNotEmpty()) {
            create("release") {
                storeFile = rootProject.file(prop("RELEASE_STORE_FILE"))
                storePassword = prop("RELEASE_STORE_PASSWORD")
                keyAlias = prop("RELEASE_KEY_ALIAS")
                keyPassword = prop("RELEASE_KEY_PASSWORD")
            }
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
            signingConfigs.findByName("release")?.let { signingConfig = it }
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_11
        targetCompatibility = JavaVersion.VERSION_11
    }

    kotlinOptions {
        jvmTarget = "11"
    }

    buildFeatures {
        viewBinding = true
        buildConfig = true
    }
}

dependencies {
    // UI, navegación y ciclo de vida AndroidX.
    implementation(libs.bundles.android.ui)

    // Reproducción nativa: HLS, DASH, MP4 y vista de controles.
    implementation(libs.bundles.media.playback)

    // Transporte HTTP, JSON y corrutinas.
    implementation(libs.bundles.network.json)

    // Google Cast y selector de dispositivos.
    implementation(libs.bundles.cast)

    // Carga de logos e imágenes.
    implementation(libs.glide)

    // Pruebas.
    testImplementation(libs.bundles.unit.testing)
    androidTestImplementation(libs.bundles.instrumentation.testing)
}
