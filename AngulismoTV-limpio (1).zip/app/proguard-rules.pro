# Modelos que Gson (de)serializa por reflexión
-keepclassmembers class com.angulismotv.data.ChannelRepository$* { <fields>; }
-keep class com.angulismotv.data.ChannelFeedDataSource$* { <fields>; }
-keep class com.angulismotv.models.** { *; }
-keepattributes Signature, *Annotation*

# Métodos expuestos al JavaScript del WebView
-keepclassmembers class * {
    @android.webkit.JavascriptInterface <methods>;
}

# Renderer FFmpeg de ExoPlayer: se carga por reflexión desde DefaultRenderersFactory.
-keep class com.google.android.exoplayer2.ext.ffmpeg.** { *; }

# Gson + R8 modo full: conservar el tipo genérico de TypeToken (si no, falla al iniciar)
-keep,allowobfuscation,allowshrinking class com.google.gson.reflect.TypeToken
-keep,allowobfuscation,allowshrinking class * extends com.google.gson.reflect.TypeToken
