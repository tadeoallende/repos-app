package com.angulismotv.fragments

import android.content.Intent
import android.content.res.Configuration
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.Editable
import android.text.TextWatcher
import android.view.LayoutInflater
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.view.MotionEvent
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.view.animation.AnimationUtils
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.SeekBar
import android.widget.TextView
import androidx.core.content.ContextCompat
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.isVisible
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.angulismotv.MainActivity
import com.angulismotv.BackHandler
import com.angulismotv.R
import com.angulismotv.UnifiedPlayerActivity
import com.angulismotv.data.LoadResult
import android.widget.Toast
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout
import com.angulismotv.adapters.ChannelsAdapter
import com.angulismotv.models.Channel
import com.angulismotv.models.StreamType
import com.angulismotv.player.CastController
import com.angulismotv.player.CastStream
import com.angulismotv.player.StreamUtils
import com.angulismotv.player.applyPlayerSettings
import com.angulismotv.network.HttpClient
import com.google.android.exoplayer2.DefaultLoadControl
import com.google.android.exoplayer2.ExoPlayer
import com.google.android.exoplayer2.MediaItem
import com.google.android.exoplayer2.PlaybackException
import com.google.android.exoplayer2.Player
import com.google.android.exoplayer2.source.dash.DashMediaSource
import com.google.android.exoplayer2.source.hls.HlsMediaSource
import com.google.android.exoplayer2.source.ProgressiveMediaSource
import com.google.android.exoplayer2.ui.PlayerView
import com.google.android.exoplayer2.ext.okhttp.OkHttpDataSource
import com.angulismotv.utils.DeviceHelper
import com.angulismotv.utils.loadChannelLogo
import java.util.Locale

class ChannelsFragment : Fragment(), BackHandler {

    // Views
    private lateinit var channelsRecycler: RecyclerView
    private lateinit var progressBar: ProgressBar
    private lateinit var swipeRefresh: SwipeRefreshLayout
    private lateinit var stateContainer: LinearLayout
    private lateinit var retryButton: TextView
    private lateinit var errorText: TextView
    private lateinit var categoriesContainer: LinearLayout
    private lateinit var categoriesScroll: HorizontalScrollView
    private lateinit var searchInput: EditText
    private lateinit var btnSearch: ImageView
    private lateinit var channelsSectionHeader: View
    private lateinit var channelsSearchContainer: View
    private lateinit var channelsSectionSubtitle: TextView

    // Guía contextual exclusiva de la composición Android TV.
    private var tvPlayerEmptyState: View? = null
    private var tvCurrentChannelInfo: View? = null
    private var tvCurrentChannelLogo: ImageView? = null
    private var tvCurrentChannelName: TextView? = null
    private var tvCurrentChannelCategory: TextView? = null
    private var tvPlayerGuide: TextView? = null
    private var tvPlayerKeysHint: TextView? = null
    private var tvPlayerFooterHint: TextView? = null
    private var tvListGuide: TextView? = null
    private var selectedCategoryFocusViewId: Int = View.NO_ID

    // Reproductor integrado móvil
    private lateinit var inlinePlayerContainer: FrameLayout
    private lateinit var inlinePlayerView: PlayerView
    private lateinit var inlineWebView: WebView
    private lateinit var inlineProgressBar: ProgressBar
    private lateinit var inlineErrorText: TextView
    private lateinit var inlineControlsBar: LinearLayout
    private lateinit var inlineTimelineContainer: View
    private lateinit var inlineSeekBar: SeekBar
    private lateinit var inlineTimeCurrent: TextView
    private lateinit var inlineTimeDuration: TextView
    private lateinit var inlineChannelLogo: ImageView
    private lateinit var inlineChannelName: TextView
    private lateinit var inlineBtnPlayPause: ImageButton
    private lateinit var inlineBtnSources: ImageButton
    private lateinit var inlineBtnCast: ImageButton
    private lateinit var inlineBtnFullscreen: ImageButton
    private lateinit var inlineBtnClose: ImageButton
    private var inlineExoPlayer: ExoPlayer? = null
    private var inlineChannel: Channel? = null
    private var inlineSourceIndex = 0
    private var inlineCurrentStreamUrl = ""
    private var inlineCurrentStreamType = StreamType.AUTO
    private var inlineCastController: CastController? = null
    private var inlineCastDiscoveryStarted = false
    private var inlineGeneration = 0
    private var inlineControlsVisible = false
    private var isLaunchingFullscreen = false
    private val inlineControlsHandler = Handler(Looper.getMainLooper())
    private var hideInlineControlsRunnable: Runnable? = null
    private var inlineTimelineRunnable: Runnable? = null
    private var isInlineUserSeeking = false

    // Adapter y datos
    private lateinit var channelsAdapter: ChannelsAdapter
    private var originalChannels = listOf<Channel>()
    private var filteredChannels = listOf<Channel>()
    private var currentCategory = "todos"
    private var isSearchVisible = false

    // ✅ Lista dinámica de categorías (se genera desde los datos)
    private var categories = mutableListOf<Pair<String, String>>()

    // Mapeo de nombres de categoría para mostrar en español
    private val categoryNames = mapOf(
        "todos" to "Todos",
        "deportes" to "Deportes",
        "noticias" to "Noticias",
        "peliculas" to "Películas",
        "infantiles" to "Infantiles",
        "educativos" to "Educativos",
        "internacionales" to "Internacionales",
        "estilo-vida" to "Estilo de vida",
        "musicales" to "Musicales",
        "documentales" to "Documentales",
        "eventos" to "Eventos"
    )

    // Optimizaciones
    private val searchHandler = Handler(Looper.getMainLooper())
    private var searchRunnable: Runnable? = null
    private val SEARCH_DELAY = 300L

    private var isTV = false

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        // Android TV necesita una composición horizontal propia: vista previa a la izquierda,
        // catálogo a la derecha. El layout móvil permanece independiente y compacto.
        val layoutRes = if (DeviceHelper.isTV(requireContext())) {
            R.layout.fragment_channels_tv
        } else {
            R.layout.fragment_channels
        }
        return inflater.inflate(layoutRes, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        isTV = DeviceHelper.isTV(requireContext())

        initViews(view)
        applyDeviceSpecificLayout(view)
        setupInlinePlayer()
        setupSearch()
        setupRecyclerView()
        setupStates()
        renderInitialState()

        if (isTV) {
            view.post {
                if (!isAdded || !inlinePlayerContainer.isShown) return@post
                if (retryButton.isShown) retryButton.requestFocus()
                else inlinePlayerContainer.requestFocus()
            }
        }
    }

    private fun initViews(view: View) {
        channelsRecycler = view.findViewById(R.id.channels_recycler)
        progressBar = view.findViewById(R.id.progress_bar)
        errorText = view.findViewById(R.id.error_text)
        swipeRefresh = view.findViewById(R.id.swipe_refresh)
        stateContainer = view.findViewById(R.id.state_container)
        retryButton = view.findViewById(R.id.retry_button)
        categoriesContainer = view.findViewById(R.id.categories_container)
        categoriesScroll = view.findViewById(R.id.categories_scroll)
        searchInput = view.findViewById(R.id.search_input)
        btnSearch = view.findViewById(R.id.btn_search)
        channelsSectionHeader = view.findViewById(R.id.channels_section_header)
        channelsSearchContainer = view.findViewById(R.id.channels_search_container)
        channelsSectionSubtitle = view.findViewById(R.id.channels_section_subtitle)
        tvPlayerEmptyState = view.findViewById(R.id.tv_player_empty_state)
        tvCurrentChannelInfo = view.findViewById(R.id.tv_current_channel_info)
        tvCurrentChannelLogo = view.findViewById(R.id.tv_current_channel_logo)
        tvCurrentChannelName = view.findViewById(R.id.tv_current_channel_name)
        tvCurrentChannelCategory = view.findViewById(R.id.tv_current_channel_category)
        tvPlayerGuide = view.findViewById(R.id.tv_player_guide)
        tvPlayerKeysHint = view.findViewById(R.id.tv_player_keys_hint)
        tvPlayerFooterHint = view.findViewById(R.id.tv_player_footer_hint)
        tvListGuide = view.findViewById(R.id.tv_list_guide)
        inlinePlayerContainer = view.findViewById(R.id.inline_player_container)
        inlinePlayerContainer.addOnLayoutChangeListener { v, left, top, right, bottom, oldLeft, oldTop, oldRight, oldBottom ->
            val width = right - left
            if (width > 0) {
                val targetHeight = (width * 9f / 16f).toInt()
                if (v.layoutParams.height != targetHeight) {
                    v.layoutParams = v.layoutParams.apply { height = targetHeight }
                }
            }
        }
        inlinePlayerView = view.findViewById(R.id.inline_player_view)
        inlineWebView = view.findViewById(R.id.inline_web_view)
        inlineProgressBar = view.findViewById(R.id.inline_progress_bar)
        inlineErrorText = view.findViewById(R.id.inline_error_text)
        inlineControlsBar = view.findViewById(R.id.inline_controls_bar)
        inlineTimelineContainer = view.findViewById(R.id.inline_timeline_container)
        inlineSeekBar = view.findViewById(R.id.inline_seek_bar)
        inlineTimeCurrent = view.findViewById(R.id.inline_time_current)
        inlineTimeDuration = view.findViewById(R.id.inline_time_duration)
        inlineChannelLogo = view.findViewById(R.id.inline_channel_logo)
        inlineChannelName = view.findViewById(R.id.inline_channel_name)
        inlineBtnPlayPause = view.findViewById(R.id.inline_btn_play_pause)
        inlineBtnSources = view.findViewById(R.id.inline_btn_sources)
        inlineBtnCast = view.findViewById(R.id.inline_btn_cast)
        inlineBtnFullscreen = view.findViewById(R.id.inline_btn_fullscreen)
        inlineBtnClose = view.findViewById(R.id.inline_btn_close)
    }

    /**
     * Mobile follows a compact, connected TV-guide layout. Android TV explicitly restores
     * its larger paddings and chip sizes so these changes never reduce 10-foot readability.
     */
    private fun applyDeviceSpecificLayout(root: View) {
        val density = resources.displayMetrics.density
        fun dp(value: Int) = (value * density + 0.5f).toInt()

        val listContainer = root.findViewById<FrameLayout>(R.id.channels_list_container)
        val searchRow = channelsSearchContainer as? ViewGroup
        val searchField = searchRow?.getChildAt(0) as? ViewGroup
        val searchParams = searchField?.layoutParams
        val listContainerPadding = if (isTV) 0 else dp(8)

        if (isTV) {
            // Layout dedicado 10-foot: el espacio se invierte en el vídeo y en más filas visibles,
            // no en márgenes interiores redundantes.
            channelsSectionHeader.visibility = View.VISIBLE
            channelsSearchContainer.visibility = View.GONE
            isSearchVisible = false
            // El icono dentro del campo se conserva como decoración; la cabecera abre/cierra la búsqueda.
            btnSearch.isFocusable = false
            btnSearch.isClickable = false
            btnSearch.setOnClickListener(null)
            channelsSearchContainer.setPadding(dp(4), dp(4), dp(4), dp(4))
            if (searchParams != null) {
                searchParams.height = dp(46)
                searchField?.layoutParams = searchParams
            }
            searchField?.setPadding(dp(12), 0, dp(12), 0)
            searchInput.textSize = 15f
            (searchInput.layoutParams as? ViewGroup.MarginLayoutParams)?.let { params ->
                params.marginStart = dp(8)
                searchInput.layoutParams = params
            }
            categoriesScroll.setPadding(dp(4), dp(4), dp(4), dp(4))
            listContainer?.setPadding(listContainerPadding, 0, 0, 0)
            channelsRecycler.setPadding(dp(2), dp(4), dp(2), dp(6))
            categoriesScroll.isFillViewport = false
        } else {
            // The branded app header already identifies the section; avoid a redundant title block.
            channelsSectionHeader.visibility = View.GONE
            channelsSectionHeader.layoutParams = channelsSectionHeader.layoutParams.apply { height = 0 }
            channelsSearchContainer.visibility = View.GONE
            channelsSearchContainer.setPadding(dp(8), dp(3), dp(8), dp(2))
            if (searchParams != null) {
                searchParams.height = dp(38)
                searchField?.layoutParams = searchParams
            }
            searchField?.setPadding(dp(12), 0, dp(12), 0)
            searchInput.textSize = 14f
            (searchInput.layoutParams as? ViewGroup.MarginLayoutParams)?.let { params ->
                params.marginStart = dp(8)
                searchInput.layoutParams = params
            }
            categoriesScroll.setPadding(dp(8), dp(2), dp(8), dp(2))
            listContainer?.setPadding(0, 0, 0, 0)
            channelsRecycler.setPadding(dp(4), dp(1), dp(4), dp(8))
            channelsRecycler.clipToPadding = false

            val playerParams = inlinePlayerContainer.layoutParams as? ViewGroup.MarginLayoutParams
            playerParams?.setMargins(dp(2), dp(2), dp(2), 0)
            if (playerParams != null) inlinePlayerContainer.layoutParams = playerParams
            inlinePlayerContainer.elevation = 0f
            inlineControlsBar.apply {
                minHeight = dp(44)
                setPadding(dp(6), dp(2), dp(6), dp(2))
            }
            inlineChannelLogo.layoutParams = inlineChannelLogo.layoutParams.apply {
                width = dp(28)
                height = dp(28)
            }
            inlineChannelName.apply {
                textSize = 12f
                (layoutParams as? ViewGroup.MarginLayoutParams)?.let { params ->
                    params.marginStart = dp(6)
                    layoutParams = params
                }
            }
            (inlineTimelineContainer.layoutParams as? FrameLayout.LayoutParams)?.let { params ->
                params.height = dp(24)
                params.leftMargin = dp(8)
                params.rightMargin = dp(8)
                params.bottomMargin = dp(46)
                inlineTimelineContainer.layoutParams = params
            }
            inlineTimeCurrent.layoutParams = inlineTimeCurrent.layoutParams.apply { width = dp(32) }
            inlineTimeDuration.layoutParams = inlineTimeDuration.layoutParams.apply { width = dp(32) }
            inlineTimeCurrent.textSize = 9f
            inlineTimeDuration.textSize = 9f
            inlineSeekBar.layoutParams = inlineSeekBar.layoutParams.apply { height = dp(20) }
            listContainer?.clipToPadding = false
        }
    }

    private fun setupInlinePlayer() {
        if (isTV) {
            // En TV el reproductor es un objetivo real del D-pad, incluso antes de elegir canal.
            inlinePlayerContainer.visibility = View.VISIBLE
            inlinePlayerContainer.isFocusable = true
            inlinePlayerContainer.isFocusableInTouchMode = true
            inlinePlayerContainer.isClickable = true
            inlinePlayerView.isFocusable = false
            inlinePlayerView.isFocusableInTouchMode = false
            inlinePlayerView.isClickable = false
            inlineWebView.isFocusable = false
            inlineWebView.isFocusableInTouchMode = false
            inlineWebView.isClickable = false
            inlineBtnCast.visibility = View.GONE
            inlineControlsBar.visibility = View.GONE
            inlineTimelineContainer.visibility = View.GONE
            tvPlayerEmptyState?.visibility = View.VISIBLE
            tvCurrentChannelInfo?.visibility = View.GONE
            tvPlayerGuide?.setText(R.string.tv_player_idle_guide)
            tvPlayerKeysHint?.setText(R.string.tv_player_keys_hint)
            tvPlayerFooterHint?.setText(R.string.tv_player_footer_hint)

            inlinePlayerContainer.nextFocusLeftId = R.id.menu_channels
            inlinePlayerContainer.nextFocusRightId = R.id.channels_recycler
            inlinePlayerContainer.nextFocusUpId = R.id.header_search_button
            inlinePlayerContainer.setOnClickListener { activateTvPlayer() }
            inlinePlayerContainer.setOnKeyListener { v, keyCode, event ->
                if (event.action != KeyEvent.ACTION_DOWN || event.repeatCount > 0) return@setOnKeyListener false
                when (keyCode) {
                    KeyEvent.KEYCODE_DPAD_CENTER,
                    KeyEvent.KEYCODE_ENTER,
                    KeyEvent.KEYCODE_NUMPAD_ENTER -> {
                        v.performClick()
                        true
                    }
                    KeyEvent.KEYCODE_DPAD_RIGHT -> {
                        focusChannelList()
                        true
                    }
                    KeyEvent.KEYCODE_DPAD_LEFT -> {
                        requireActivity().findViewById<View>(R.id.menu_channels)?.requestFocus() == true
                    }
                    else -> false
                }
            }
            inlinePlayerContainer.setOnFocusChangeListener { _, hasFocus ->
                // La ayuda depende del destino real del foco: no anunciar OK a pantalla completa
                // mientras el mando está navegando por las filas de canales.
                val guideRes = when {
                    hasFocus && inlineChannel != null -> R.string.tv_player_active_guide
                    hasFocus -> R.string.tv_player_idle_guide
                    inlineChannel != null -> R.string.tv_player_preview_ready_guide
                    else -> R.string.tv_player_idle_guide
                }
                tvPlayerGuide?.setText(guideRes)
            }
        } else {
            val hostActivity = activity as? AppCompatActivity
            if (hostActivity != null) {
                inlineCastController = CastController(
                    activity = hostActivity,
                    button = inlineBtnCast,
                    handler = inlineControlsHandler,
                    currentStream = {
                        val channel = inlineChannel
                        val url = inlineCurrentStreamUrl
                        if (channel == null || url.isBlank() || inlineCurrentStreamType == StreamType.IFRAME) null
                        else CastStream(url, inlineCurrentStreamType, channel.name)
                    },
                    onCastStarted = {
                        inlineExoPlayer?.pause()
                        updateInlinePlayPauseIcon()
                    }
                ).also { controller ->
                    controller.setup(isTV = false)
                    inlineBtnCast.visibility = View.GONE
                }
            } else {
                inlineBtnCast.visibility = View.GONE
            }
            inlinePlayerContainer.visibility = View.GONE
            inlinePlayerView.isFocusable = false
            inlinePlayerView.isClickable = true
            inlinePlayerView.setOnClickListener {
                if (inlineControlsVisible) hideInlineControls() else showInlineControlsTemporarily()
            }
            // No consume los toques del reproductor web: sus controles internos siguen funcionando.
            inlineWebView.applyPlayerSettings()
            inlineWebView.setOnTouchListener { _, event ->
                if (event.action == MotionEvent.ACTION_UP) showInlineControlsTemporarily()
                false
            }
        }

        inlineSeekBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onStartTrackingTouch(seekBar: SeekBar?) {
                isInlineUserSeeking = true
                showInlineControlsTemporarily()
            }

            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                if (!fromUser) return
                val duration = inlineExoPlayer?.duration ?: return
                inlineTimeCurrent.text = formatInlineTime(duration * progress.toLong() / 1000L)
            }

            override fun onStopTrackingTouch(seekBar: SeekBar?) {
                val player = inlineExoPlayer
                if (player != null && player.duration > 0) {
                    player.seekTo(player.duration * inlineSeekBar.progress.toLong() / 1000L)
                }
                isInlineUserSeeking = false
                showInlineControlsTemporarily()
            }
        })

        inlineBtnPlayPause.setOnClickListener {
            val player = inlineExoPlayer ?: return@setOnClickListener
            if (player.isPlaying) player.pause() else player.play()
            updateInlinePlayPauseIcon()
            showInlineControlsTemporarily()
        }
        inlineBtnSources.setOnClickListener { showInlineSourcePicker() }
        inlineBtnCast.visibility = View.GONE
        inlineBtnFullscreen.setOnClickListener { launchInlineFullscreen() }
        inlineBtnClose.setOnClickListener { closeInlinePlayer() }
    }

    private fun activateTvPlayer() {
        if (!isTV) return
        if (inlineChannel != null) {
            launchInlineFullscreen()
        } else {
            tvPlayerGuide?.setText(R.string.tv_player_no_channel_selected)
            focusChannelList()
        }
    }

    /** Move to the current channel in the right-hand list, or its first item if none is selected. */
    private fun focusChannelList() {
        if (!isTV || !::channelsRecycler.isInitialized || !::channelsAdapter.isInitialized) return
        val itemCount = channelsAdapter.itemCount
        if (itemCount <= 0) {
            val fallback = if (retryButton.isShown) retryButton else searchInput
            fallback.requestFocus()
            return
        }
        val selectedPosition = inlineChannel?.let { channel ->
            filteredChannels.indexOfFirst { it.name == channel.name && it.logo == channel.logo }
        } ?: -1
        val remembered = channelsAdapter.getLastFocusedPosition()
        val targetPosition = when {
            selectedPosition in 0 until itemCount -> selectedPosition
            remembered in 0 until itemCount -> remembered
            else -> 0
        }
        channelsRecycler.post {
            if (!isAdded || !channelsRecycler.isShown) return@post
            channelsRecycler.scrollToPosition(targetPosition)
            channelsRecycler.post itemFocus@{
                val target = channelsRecycler.findViewHolderForAdapterPosition(targetPosition)?.itemView
                if (target?.isShown == true && target.requestFocus()) return@itemFocus
                channelsRecycler.requestFocus()
            }
        }
    }

    private fun focusSelectedCategory() {
        if (!isTV) return
        val selected = categoriesContainer.findViewWithTag<TextView>(currentCategory)
            ?: categoriesContainer.getChildAt(0) as? TextView
        selected?.requestFocus()
    }

    private fun showInlinePlayer(channel: Channel, startPlayback: Boolean = true) {
        // Invalida callbacks tardíos de la fuente anterior antes de cambiar de canal.
        inlineGeneration++
        stopInlineCastDiscovery()
        inlineCurrentStreamUrl = ""
        inlineCurrentStreamType = StreamType.AUTO
        inlineBtnCast.visibility = View.GONE
        inlineChannel = channel
        inlineSourceIndex = 0
        if (isTV && ::channelsAdapter.isInitialized) channelsAdapter.setPreviewChannel(channel)
        inlinePlayerContainer.visibility = View.VISIBLE
        if (!isTV) {
            channelsSectionHeader.visibility = View.GONE
            channelsSearchContainer.visibility = View.GONE
            isSearchVisible = false
            searchInput.clearFocus()
            val inputMethodManager = requireContext().getSystemService(android.content.Context.INPUT_METHOD_SERVICE) as android.view.inputmethod.InputMethodManager
            inputMethodManager.hideSoftInputFromWindow(searchInput.windowToken, 0)
        } else {
            channelsSectionHeader.visibility = View.VISIBLE
            channelsSearchContainer.visibility = if (isSearchVisible) View.VISIBLE else View.GONE
            tvPlayerEmptyState?.visibility = View.GONE
            tvCurrentChannelInfo?.visibility = View.VISIBLE
            tvCurrentChannelLogo?.loadChannelLogo(channel.name, channel.logo)
            tvCurrentChannelName?.text = channel.name
            tvCurrentChannelCategory?.text = channel.category?.takeIf { it.isNotBlank() }?.let(::displayCategoryName)
                ?: getString(R.string.tv_live_category)
            tvPlayerGuide?.setText(R.string.tv_player_active_guide)
            tvPlayerFooterHint?.setText(R.string.tv_player_footer_hint)
            channelsSectionSubtitle.text = getString(R.string.tv_channels_subtitle_count, filteredChannels.size)
        }
        inlineChannelName.text = channel.name
        inlineChannelLogo.loadChannelLogo(channel.name, channel.logo)
        inlineBtnSources.visibility = if ((channel.options?.size ?: 0) > 1) View.VISIBLE else View.GONE
        inlineErrorText.visibility = View.GONE
        inlinePlayerView.visibility = View.GONE
        inlineWebView.visibility = View.GONE
        showInlineControlsTemporarily()

        if (startPlayback) {
            startInlinePlayback(channel, 0)
        } else {
            releaseInlineEngine()
            inlineProgressBar.visibility = View.GONE
        }
    }

    private fun startInlinePlayback(channel: Channel, sourceIndex: Int) {
        if (!isAdded || view == null) return
        // Durante un cambio de fuente no se debe ofrecer Cast con la URL anterior.
        inlineGeneration++
        stopInlineCastDiscovery()
        inlineCurrentStreamUrl = ""
        inlineCurrentStreamType = StreamType.AUTO
        if (::inlineBtnCast.isInitialized) inlineBtnCast.visibility = View.GONE
        val generation = inlineGeneration
        releaseInlineEngine()
        inlineSourceIndex = sourceIndex
        inlineErrorText.visibility = View.GONE
        inlineProgressBar.visibility = View.VISIBLE

        val options = channel.options.orEmpty()
        val url: String
        val type: String
        if (options.isNotEmpty()) {
            if (sourceIndex !in options.indices) {
                showInlineError("No se pudo reproducir ninguna fuente de este canal.")
                return
            }
            val option = options[sourceIndex]
            url = option.iframe
            type = StreamUtils.resolveType(url, option.streamType)
        } else {
            url = channel.streamUrl.orEmpty()
            type = StreamUtils.resolveType(url, channel.streamType ?: StreamType.AUTO)
        }

        if (url.isBlank()) {
            handleInlineSourceFailure(generation)
            return
        }

        inlineCurrentStreamUrl = url
        inlineCurrentStreamType = type
        refreshInlineCastAvailability()

        if (type == StreamType.IFRAME) {
            startInlineWebView(url, generation)
        } else {
            startInlineExoPlayer(url, type, generation)
        }
    }

    private fun startInlineExoPlayer(url: String, type: String, generation: Int) {
        inlineWebView.stopLoading()
        inlineWebView.visibility = View.GONE
        inlinePlayerView.visibility = View.VISIBLE
        inlineBtnPlayPause.visibility = View.VISIBLE
        inlineTimelineContainer.visibility = View.GONE

        try {
            val dataSource = OkHttpDataSource.Factory(HttpClient.shared)
                .setUserAgent(HttpClient.USER_AGENT)
            val mediaItem = MediaItem.fromUri(Uri.parse(url))
            val mediaSource = when (type) {
                StreamType.DASH -> DashMediaSource.Factory(dataSource).createMediaSource(mediaItem)
                StreamType.MP4 -> ProgressiveMediaSource.Factory(dataSource).createMediaSource(mediaItem)
                else -> HlsMediaSource.Factory(dataSource)
                    .setAllowChunklessPreparation(true)
                    .createMediaSource(mediaItem)
            }
            val loadControl = DefaultLoadControl.Builder()
                .setBufferDurationsMs(10_000, 45_000, 1_000, 3_000)
                .build()
            val player = ExoPlayer.Builder(requireContext())
                .setLoadControl(loadControl)
                .build()
            inlineExoPlayer = player
            inlinePlayerView.player = player
            inlinePlayerView.useController = false
            player.addListener(object : Player.Listener {
                override fun onPlaybackStateChanged(state: Int) {
                    if (generation != inlineGeneration) return
                    when (state) {
                        Player.STATE_BUFFERING -> inlineProgressBar.visibility = View.VISIBLE
                        Player.STATE_READY -> {
                            inlineProgressBar.visibility = View.GONE
                            inlineErrorText.visibility = View.GONE
                            updateInlinePlayPauseIcon()
                            updateInlineTimeline(player)
                            startInlineTimelineUpdates()
                            showInlineControlsTemporarily()
                        }
                        Player.STATE_ENDED -> inlineProgressBar.visibility = View.GONE
                    }
                }

                override fun onIsPlayingChanged(isPlaying: Boolean) {
                    if (generation == inlineGeneration) updateInlinePlayPauseIcon()
                }

                override fun onPlayerError(error: PlaybackException) {
                    if (generation == inlineGeneration) handleInlineSourceFailure(generation)
                }
            })
            player.setMediaSource(mediaSource)
            player.playWhenReady = true
            player.prepare()
        } catch (error: Exception) {
            android.util.Log.e("InlinePlayer", "No se pudo iniciar la fuente", error)
            handleInlineSourceFailure(generation)
        }
    }

    private fun startInlineWebView(url: String, generation: Int) {
        inlinePlayerView.player = null
        inlinePlayerView.visibility = View.GONE
        inlineWebView.visibility = View.VISIBLE
        inlineBtnPlayPause.visibility = View.GONE
        inlineTimelineContainer.visibility = View.GONE
        stopInlineTimelineUpdates()
        inlineWebView.applyPlayerSettings()
        inlineWebView.isFocusable = !isTV
        inlineWebView.isFocusableInTouchMode = !isTV
        inlineWebView.isClickable = !isTV
        val initialHost = Uri.parse(url).host.orEmpty()

        inlineWebView.webChromeClient = object : WebChromeClient() {
            override fun onPermissionRequest(request: android.webkit.PermissionRequest?) {
                request?.deny()
            }

            override fun onCreateWindow(
                view: WebView?,
                isDialog: Boolean,
                isUserGesture: Boolean,
                resultMsg: android.os.Message?
            ): Boolean = false
        }
        inlineWebView.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView?, finishedUrl: String?) {
                if (generation != inlineGeneration || finishedUrl.isNullOrBlank() || finishedUrl == "about:blank") return
                inlineProgressBar.visibility = View.GONE
                inlineErrorText.visibility = View.GONE
                showInlineControlsTemporarily()
            }

            @android.annotation.TargetApi(android.os.Build.VERSION_CODES.M)
            override fun onReceivedError(
                view: WebView?,
                request: WebResourceRequest?,
                error: android.webkit.WebResourceError?
            ) {
                if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.M && request?.isForMainFrame == true) {
                    if (request.url.toString() != "about:blank") handleInlineSourceFailure(generation)
                }
            }

            @Suppress("DEPRECATION")
            override fun onReceivedError(view: WebView?, code: Int, description: String?, failedUrl: String?) {
                if (android.os.Build.VERSION.SDK_INT < android.os.Build.VERSION_CODES.M &&
                    !failedUrl.isNullOrBlank() && failedUrl != "about:blank") {
                    handleInlineSourceFailure(generation)
                }
            }

            @android.annotation.TargetApi(android.os.Build.VERSION_CODES.M)
            override fun onReceivedHttpError(
                view: WebView?,
                request: WebResourceRequest?,
                errorResponse: android.webkit.WebResourceResponse?
            ) {
                if (request?.isForMainFrame == true && (errorResponse?.statusCode ?: 0) >= 400) {
                    handleInlineSourceFailure(generation)
                }
            }

            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                request ?: return false
                if (!request.isForMainFrame) return false
                if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.N && request.isRedirect) return false
                val host = request.url.host.orEmpty()
                val sameSite = host == initialHost || host.endsWith(".$initialHost")
                return !sameSite
            }
        }
        inlineWebView.loadUrl(url)
    }

    private fun handleInlineSourceFailure(generation: Int) {
        if (generation != inlineGeneration) return
        // Mantener la fuente elegida: el cambio de fuente siempre debe ser manual.
        showInlineError("No se pudo cargar esta fuente. Podés elegir otra manualmente.")
    }

    private fun showInlineError(message: String) {
        stopInlineTimelineUpdates()
        inlineProgressBar.visibility = View.GONE
        inlineErrorText.text = message
        inlineErrorText.visibility = View.VISIBLE
        showInlineControlsTemporarily()
    }

    private fun releaseInlineEngine() {
        stopInlineTimelineUpdates()
        inlineTimelineContainer.visibility = View.GONE
        inlineExoPlayer?.run {
            stop()
            clearMediaItems()
            release()
        }
        inlineExoPlayer = null
        if (::inlinePlayerView.isInitialized) inlinePlayerView.player = null
        if (::inlineWebView.isInitialized) {
            inlineWebView.stopLoading()
            inlineWebView.visibility = View.GONE
            inlineWebView.loadUrl("about:blank")
        }
    }

    private fun updateInlineTimeline(player: ExoPlayer) {
        val duration = player.duration
        val canSeek = player.playbackState == Player.STATE_READY && player.isCurrentWindowSeekable && duration > 0L
        if (!canSeek || !inlineControlsVisible) {
            inlineTimelineContainer.visibility = View.GONE
            return
        }
        inlineTimelineContainer.visibility = View.VISIBLE
        inlineSeekBar.max = 1000
        if (!isInlineUserSeeking) {
            inlineSeekBar.progress = ((player.currentPosition.coerceAtLeast(0L) * 1000L) / duration)
                .toInt().coerceIn(0, 1000)
            inlineTimeCurrent.text = formatInlineTime(player.currentPosition)
        }
        inlineTimeDuration.text = formatInlineTime(duration)
    }

    private fun startInlineTimelineUpdates() {
        stopInlineTimelineUpdates()
        inlineTimelineRunnable = object : Runnable {
            override fun run() {
                val player = inlineExoPlayer
                if (player == null || inlineChannel == null || inlinePlayerContainer.visibility != View.VISIBLE) return
                updateInlineTimeline(player)
                inlineControlsHandler.postDelayed(this, 500L)
            }
        }
        inlineControlsHandler.post(inlineTimelineRunnable!!)
    }

    private fun stopInlineTimelineUpdates() {
        inlineTimelineRunnable?.let { inlineControlsHandler.removeCallbacks(it) }
        inlineTimelineRunnable = null
        isInlineUserSeeking = false
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density + 0.5f).toInt()

    private fun formatInlineTime(positionMs: Long): String {
        val totalSeconds = (positionMs.coerceAtLeast(0L) / 1000L)
        val hours = totalSeconds / 3600L
        val minutes = (totalSeconds % 3600L) / 60L
        val seconds = totalSeconds % 60L
        return if (hours > 0L) String.format(Locale.ROOT, "%d:%02d:%02d", hours, minutes, seconds)
        else String.format(Locale.ROOT, "%02d:%02d", minutes, seconds)
    }

    private fun updateInlinePlayPauseIcon() {
        val isPlaying = inlineExoPlayer?.isPlaying == true
        inlineBtnPlayPause.setImageResource(if (isPlaying) R.drawable.ic_pause else R.drawable.ic_play)
        inlineBtnPlayPause.contentDescription = if (isPlaying) "Pausar" else "Reproducir"
    }

    private fun showInlineControlsTemporarily() {
        if (isTV || !::inlineControlsBar.isInitialized || inlinePlayerContainer.visibility != View.VISIBLE) return
        inlineControlsVisible = true
        inlineControlsBar.visibility = View.VISIBLE
        inlineControlsBar.bringToFront()
        inlineExoPlayer?.let { updateInlineTimeline(it) }
        hideInlineControlsRunnable?.let { inlineControlsHandler.removeCallbacks(it) }
        hideInlineControlsRunnable = Runnable { hideInlineControls() }
        inlineControlsHandler.postDelayed(hideInlineControlsRunnable!!, 4_000L)
    }

    private fun hideInlineControls() {
        if (!::inlineControlsBar.isInitialized) return
        inlineControlsVisible = false
        inlineControlsBar.visibility = View.GONE
        inlineTimelineContainer.visibility = View.GONE
        hideInlineControlsRunnable?.let { inlineControlsHandler.removeCallbacks(it) }
        hideInlineControlsRunnable = null
    }

    private fun refreshInlineCastAvailability() {
        if (!::inlineBtnCast.isInitialized) return
        val canCast = !isTV &&
            inlinePlayerContainer.visibility == View.VISIBLE &&
            inlineChannel != null &&
            inlineCurrentStreamUrl.isNotBlank() &&
            inlineCurrentStreamType != StreamType.IFRAME &&
            inlineCastController?.isConfigured == true

        inlineBtnCast.visibility = if (canCast) View.VISIBLE else View.GONE
        if (canCast && isResumed && !isHidden) {
            startInlineCastDiscovery()
        } else {
            stopInlineCastDiscovery()
        }
    }

    private fun startInlineCastDiscovery() {
        if (inlineCastDiscoveryStarted || inlineCastController?.isConfigured != true) return
        inlineCastController?.startDiscovery()
        inlineCastDiscoveryStarted = true
    }

    private fun stopInlineCastDiscovery() {
        if (!inlineCastDiscoveryStarted) return
        inlineCastController?.stopDiscovery()
        inlineCastDiscoveryStarted = false
    }

    private fun showInlineSourcePicker() {
        val channel = inlineChannel ?: return
        val options = channel.options.orEmpty()
        if (options.size < 2) return
        androidx.appcompat.app.AlertDialog.Builder(requireContext())
            .setTitle("Seleccionar fuente")
            .setItems(options.map { it.name }.toTypedArray()) { _, which ->
                startInlinePlayback(channel, which)
                showInlineControlsTemporarily()
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    private fun closeInlinePlayer() {
        inlineGeneration++
        stopInlineCastDiscovery()
        inlineCurrentStreamUrl = ""
        inlineCurrentStreamType = StreamType.AUTO
        inlineBtnCast.visibility = View.GONE
        hideInlineControls()
        hideInlineControlsRunnable?.let { inlineControlsHandler.removeCallbacks(it) }
        releaseInlineEngine()
        inlinePlayerContainer.visibility = if (isTV) View.VISIBLE else View.GONE
        inlineProgressBar.visibility = View.GONE
        inlineErrorText.visibility = View.GONE
        inlineChannel = null
        if (isTV && ::channelsAdapter.isInitialized) channelsAdapter.setPreviewChannel(null)
        channelsSectionHeader.visibility = if (isTV) View.VISIBLE else View.GONE
        isSearchVisible = false
        channelsSearchContainer.visibility = View.GONE
        searchInput.setText("")
        syncHeaderSearchButton(false)
        currentCategory = currentCategory.ifBlank { "todos" }
        if (isTV) {
            tvPlayerEmptyState?.visibility = View.VISIBLE
            tvCurrentChannelInfo?.visibility = View.GONE
            tvCurrentChannelLogo?.setImageResource(R.drawable.ic_channel_placeholder)
            tvCurrentChannelName?.setText(R.string.tv_channel_not_selected)
            tvCurrentChannelCategory?.setText(R.string.tv_live_category)
            tvPlayerGuide?.setText(R.string.tv_player_idle_guide)
            inlinePlayerContainer.requestFocus()
        }
    }

    private fun launchInlineFullscreen() {
        val channel = inlineChannel ?: return
        launchPlayerActivity(channel, fromInline = true)
    }

    private fun launchPlayerActivity(channel: Channel, fromInline: Boolean) {
        val channelIndex = originalChannels.indexOfFirst { it.name == channel.name && it.logo == channel.logo }
            .takeIf { it >= 0 } ?: 0
        isLaunchingFullscreen = fromInline
        inlineExoPlayer?.pause()
        inlineWebView.onPause()
        val intent = Intent(requireContext(), UnifiedPlayerActivity::class.java).apply {
            putParcelableArrayListExtra("channels", ArrayList(originalChannels))
            putExtra("channel_index", channelIndex)
            putExtra("channel_name", channel.name)
            putExtra("channel_logo", channel.logo)
            putExtra("stream_url", channel.streamUrl)
            putExtra("stream_type", channel.streamType ?: StreamType.AUTO)
            putExtra("from_inline_player", fromInline)
            putExtra("force_landscape_fullscreen", fromInline && !isTV)
            putExtra("source_index", inlineSourceIndex)
        }
        startActivity(intent)
        if (!isTV) requireActivity().overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
    }

    private fun maybeOpenFullscreenAfterRotation(newConfig: Configuration) {
        if (isTV || isHidden || newConfig.orientation != Configuration.ORIENTATION_LANDSCAPE) return
        if (inlineChannel == null || inlinePlayerContainer.visibility != View.VISIBLE || isLaunchingFullscreen) return
        launchPlayerActivity(inlineChannel!!, fromInline = true)
    }

    private fun setupSearch() {
        if (!isTV) {
            btnSearch.setOnClickListener {
                searchInput.requestFocus()
                val imm = requireContext().getSystemService(android.content.Context.INPUT_METHOD_SERVICE) as android.view.inputmethod.InputMethodManager
                imm.showSoftInput(searchInput, android.view.inputmethod.InputMethodManager.SHOW_IMPLICIT)
            }
        }

        searchInput.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                searchRunnable?.let { searchHandler.removeCallbacks(it) }
                searchRunnable = Runnable { applyFiltersAndUpdate() }
                searchHandler.postDelayed(searchRunnable!!, SEARCH_DELAY)
            }
            override fun afterTextChanged(s: Editable?) {}
        })
    }

    /** Opens/closes the search field from the shared header (mobile and Android TV). */
    fun toggleSearchFromHeader() {
        if (!isAdded || isHidden || !::searchInput.isInitialized) return

        if (isTV) {
            val opening = !isSearchVisible
            toggleSearch()
            if (opening) {
                searchInput.requestFocus()
            } else {
                activity?.findViewById<View>(R.id.header_search_button)?.requestFocus()
            }
            return
        }

        if (channelsSearchContainer.visibility == View.VISIBLE) {
            channelsSearchContainer.visibility = View.GONE
            isSearchVisible = false
            searchInput.setText("")
            searchInput.clearFocus()
            val imm = requireContext().getSystemService(android.content.Context.INPUT_METHOD_SERVICE) as android.view.inputmethod.InputMethodManager
            imm.hideSoftInputFromWindow(searchInput.windowToken, 0)
            syncHeaderSearchButton(false)
            applyFiltersAndUpdate()
        } else {
            channelsSearchContainer.visibility = View.VISIBLE
            searchInput.visibility = View.VISIBLE
            isSearchVisible = true
            searchInput.requestFocus()
            val imm = requireContext().getSystemService(android.content.Context.INPUT_METHOD_SERVICE) as android.view.inputmethod.InputMethodManager
            imm.showSoftInput(searchInput, android.view.inputmethod.InputMethodManager.SHOW_IMPLICIT)
            syncHeaderSearchButton(true)
        }
    }

    private fun syncHeaderSearchButton(open: Boolean) {
        val button = activity?.findViewById<ImageButton>(R.id.header_search_button) ?: return
        button.setImageResource(if (open) R.drawable.ic_close else R.drawable.ic_search)
        button.contentDescription = getString(
            if (open) R.string.close_channel_search else R.string.open_channel_search
        )
        button.nextFocusDownId = if (open) R.id.search_input else R.id.inline_player_container
    }

    private fun toggleSearch() {
        if (isTV) {
            isSearchVisible = !isSearchVisible
            channelsSearchContainer.visibility = if (isSearchVisible) View.VISIBLE else View.GONE
            if (isSearchVisible) {
                searchInput.visibility = View.VISIBLE
                syncHeaderSearchButton(true)
            } else {
                searchInput.setText("")
                searchInput.clearFocus()
                syncHeaderSearchButton(false)
                applyFiltersAndUpdate()
            }
            return
        }

        isSearchVisible = !isSearchVisible

        if (isSearchVisible) {
            searchInput.visibility = View.VISIBLE
            searchInput.requestFocus()
            if (!isTV) {
                val imm = requireContext().getSystemService(android.content.Context.INPUT_METHOD_SERVICE) as android.view.inputmethod.InputMethodManager
                imm.showSoftInput(searchInput, android.view.inputmethod.InputMethodManager.SHOW_IMPLICIT)
            } else {
                searchInput.startAnimation(AnimationUtils.loadAnimation(requireContext(), android.R.anim.fade_in))
            }
        } else {
            searchInput.visibility = View.GONE
            searchInput.text.clear()
            if (!isTV) {
                val imm = requireContext().getSystemService(android.content.Context.INPUT_METHOD_SERVICE) as android.view.inputmethod.InputMethodManager
                imm.hideSoftInputFromWindow(searchInput.windowToken, 0)
            }
            applyFiltersAndUpdate()
        }
    }

    private fun applyFiltersAndUpdate() {
        if (originalChannels.isEmpty()) return

        val categoryFiltered = if (currentCategory == "todos") {
            originalChannels
        } else {
            originalChannels.filter { it.category == currentCategory }
        }

        val searchQuery = searchInput.text.toString().trim()
        filteredChannels = if (searchQuery.isNotEmpty()) {
            val query = searchQuery.lowercase()
            categoryFiltered.filter { channel ->
                channel.name.lowercase().contains(query)
            }
        } else {
            categoryFiltered
        }

        channelsAdapter.submitList(filteredChannels)
        if (isTV) {
            channelsSectionSubtitle.text = if (filteredChannels.isEmpty()) {
                getString(R.string.tv_channels_subtitle_empty)
            } else {
                getString(R.string.tv_channels_subtitle_count, filteredChannels.size)
            }
        }

        if (filteredChannels.isEmpty()) {
            showState("No se encontraron canales", isError = false, showRetry = false)
        } else {
            hideState()
        }
    }

    // ✅ Función que genera categorías DINÁMICAMENTE desde los canales
    private fun generateCategoriesFromChannels(channels: List<Channel>) {
        if (channels.isEmpty()) return

        val uniqueCategories = channels.mapNotNull { it.category }
            .filter { it.isNotBlank() && it != "todos" }
            .distinct()
            .sorted()

        categories.clear()
        categories.add("todos" to categoryNames["todos"].orEmpty())

        uniqueCategories.forEach { categoryKey ->
            categories.add(categoryKey to displayCategoryName(categoryKey))
        }

        setupCategories()
    }


    private fun displayCategoryName(categoryKey: String): String {
        categoryNames[categoryKey]?.let { return it }
        val spanishLocale = Locale("es", "AR")
        return categoryKey
            .replace('-', ' ')
            .split(' ')
            .filter { it.isNotBlank() }
            .joinToString(" ") { word ->
                word.lowercase(spanishLocale).replaceFirstChar { first ->
                    if (first.isLowerCase()) first.titlecase(spanishLocale) else first.toString()
                }
            }
    }

    private fun setupCategories() {
        categoriesContainer.removeAllViews()

        if (categories.isEmpty()) {
            // Si no hay categorías, mostrar al menos "todos"
            categories.add("todos" to categoryNames["todos"].orEmpty())
        }

        for ((key, label) in categories) {
            val chip = LayoutInflater.from(requireContext())
                .inflate(R.layout.item_category, categoriesContainer, false) as TextView

            chip.text = label
            chip.tag = key
            chip.isSelected = key == currentCategory
            if (isTV) {
                chip.id = View.generateViewId()
                chip.layoutParams = chip.layoutParams.apply { height = dp(38) }
                chip.setPadding(dp(16), 0, dp(16), 0)
                chip.textSize = 13f
                (chip.layoutParams as? ViewGroup.MarginLayoutParams)?.let { params ->
                    params.marginEnd = dp(8)
                    chip.layoutParams = params
                }
            }

            updateChipStyle(chip, chip.isSelected)

            if (isTV) {
                // La categoría está sobre la lista y a la derecha del reproductor: las flechas
                // respetan esa geometría en vez de saltar al rail global desde el primer chip.
                chip.nextFocusLeftId = if (key == categories.firstOrNull()?.first) R.id.inline_player_container else View.NO_ID
                chip.setOnKeyListener { _, keyCode, event ->
                    if (event.action == KeyEvent.ACTION_DOWN && event.repeatCount == 0 && keyCode == KeyEvent.KEYCODE_DPAD_DOWN) {
                        focusChannelList()
                        true
                    } else false
                }
                setupTVFocusEffect(chip)
            } else {
                chip.setOnTouchListener { _, _ ->
                    chip.isSelected = true
                    false
                }
            }

            chip.setOnClickListener { selectCategory(key) }
            categoriesContainer.addView(chip)
        }

        if (isTV) {
            val selectedChip = categoriesContainer.findViewWithTag<TextView>(currentCategory)
                ?: categoriesContainer.getChildAt(0) as? TextView
            selectedCategoryFocusViewId = selectedChip?.id ?: View.NO_ID

            // D-pad: buscador ↓ categoría seleccionada ↓ lista. Las categorías mantienen
            // el movimiento lateral entre chips y el primer chip devuelve al reproductor.
            searchInput.nextFocusDownId = selectedCategoryFocusViewId
            channelsRecycler.nextFocusUpId = selectedCategoryFocusViewId
            for (index in 0 until categoriesContainer.childCount) {
                val chip = categoriesContainer.getChildAt(index)
                chip.nextFocusUpId = R.id.search_input
                chip.nextFocusDownId = R.id.channels_recycler
                chip.nextFocusLeftId = if (index == 0) R.id.inline_player_container
                    else categoriesContainer.getChildAt(index - 1).id
            }
            if (::channelsAdapter.isInitialized) {
                channelsAdapter.setCategoryFocusTarget(selectedCategoryFocusViewId)
            }
        }
    }

    private fun updateChipStyle(chip: TextView, isSelected: Boolean) {
        if (isSelected) {
            chip.setBackgroundResource(R.drawable.bg_category_selected)
            chip.setTextColor(ContextCompat.getColor(requireContext(), R.color.text_primary))
        } else {
            chip.setBackgroundResource(R.drawable.bg_category_default)
            chip.setTextColor(ContextCompat.getColor(requireContext(), R.color.text_secondary))
        }
    }

    private fun setupTVFocusEffect(chip: TextView) {
        chip.onFocusChangeListener = View.OnFocusChangeListener { _, hasFocus ->
            // Foco visible sin escalado: evita solapamientos y saltos en TV.
            chip.animate().cancel()
            chip.scaleX = 1f
            chip.scaleY = 1f
            if (hasFocus) {
                val container = chip.parent as? View
                val scroller = container?.parent as? android.widget.HorizontalScrollView
                if (scroller != null) {
                    val leftEdge = scroller.scrollX
                    val rightEdge = leftEdge + scroller.width - scroller.paddingLeft - scroller.paddingRight
                    when {
                        chip.left < leftEdge -> scroller.smoothScrollTo(chip.left, 0)
                        chip.right > rightEdge -> scroller.smoothScrollTo(chip.right - scroller.width + scroller.paddingRight, 0)
                    }
                }
            }
        }
    }

    private fun selectCategory(categoryKey: String) {
        if (currentCategory == categoryKey) return

        currentCategory = categoryKey

        for (i in 0 until categoriesContainer.childCount) {
            val chip = categoriesContainer.getChildAt(i) as TextView
            val selected = chip.tag == categoryKey
            updateChipStyle(chip, selected)
            if (selected) selectedCategoryFocusViewId = chip.id
        }
        if (isTV) {
            // El retorno vertical siempre va a la categoría activa tras cambiar el filtro.
            searchInput.nextFocusDownId = selectedCategoryFocusViewId
            channelsRecycler.nextFocusUpId = selectedCategoryFocusViewId
            if (::channelsAdapter.isInitialized) {
                channelsAdapter.setCategoryFocusTarget(selectedCategoryFocusViewId)
            }
        }

        applyFiltersAndUpdate()

        if (isSearchVisible) {
            toggleSearch()
        }

        channelsRecycler.smoothScrollToPosition(0)
    }

    private fun setupRecyclerView() {
        channelsRecycler.layoutManager = GridLayoutManager(requireContext(), calculateSpanCount())

        channelsAdapter = ChannelsAdapter { channel, position ->
            openPlayer(channel, position)
        }

        channelsRecycler.adapter = channelsAdapter

        if (isTV) {
            channelsRecycler.isFocusable = true
            channelsRecycler.isFocusableInTouchMode = true
            // El foco inicial va al reproductor; desde allí se entra a la lista con →.
            inlinePlayerContainer.nextFocusRightId = R.id.channels_recycler
            channelsRecycler.nextFocusLeftId = R.id.inline_player_container
        }
    }

    /**
     * Devuelve el foco a un elemento real de la lista en Android TV.
     * El retraso doble permite que RecyclerView procese el scroll y adjunte el ViewHolder,
     * evitando que el mando quede enfocado en el contenedor sin un indicador visible.
     */
    fun requestTvFocus() {
        if (!isTV || !::channelsRecycler.isInitialized || !::channelsAdapter.isInitialized) return
        inlinePlayerContainer.post {
            if (!isAdded || !inlinePlayerContainer.isShown) return@post
            if (retryButton.isShown && channelsAdapter.itemCount == 0) retryButton.requestFocus()
            else inlinePlayerContainer.requestFocus()
        }
    }

    /** Columnas según el ancho disponible: TV por rangos fijos; móvil/tablet una cada ~320dp. */
    private fun calculateSpanCount(): Int {
        if (isTV) return 1
        val dpWidth = resources.configuration.screenWidthDp
        return (dpWidth / 320).coerceAtLeast(1)
    }

    // MainActivity maneja la rotación sin recrearse: recalculamos la lista y ampliamos el reproductor.
    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        if (::channelsRecycler.isInitialized) {
            (channelsRecycler.layoutManager as? GridLayoutManager)?.spanCount = calculateSpanCount()
        }
        maybeOpenFullscreenAfterRotation(newConfig)
    }

    /** Al crear las vistas: muestra la carga en curso o el último resultado que tenga la activity. */
    private fun renderInitialState() {
        val main = activity as? MainActivity
        val result = main?.getLoadResult()
        if (main == null || main.isLoadingChannels() || result == null) {
            showLoading(true)
        } else {
            applyResult(result)
        }
    }

    private fun setupStates() {
        swipeRefresh.setColorSchemeResources(R.color.accent)
        swipeRefresh.setProgressBackgroundColorSchemeResource(R.color.space_surface_raised)
        swipeRefresh.isEnabled = !isTV // en TV no hay gesto: se usa el botón Reintentar
        swipeRefresh.setOnRefreshListener { (activity as? MainActivity)?.reloadChannels() }
        retryButton.setOnClickListener { (activity as? MainActivity)?.reloadChannels() }
    }

    private fun applyResult(result: LoadResult) {
        originalChannels = result.channels
        currentCategory = "todos"
        showLoading(false)
        swipeRefresh.isRefreshing = false

        if (originalChannels.isEmpty()) {
            filteredChannels = emptyList()
            channelsAdapter.submitList(emptyList())
            categoriesContainer.removeAllViews()
            when {
                result.notConfigured ->
                    showState("Todavía no hay una lista de canales configurada.", isError = false, showRetry = false)
                result.failed ->
                    showState("No se pudo cargar la lista de canales.\nRevisá tu conexión e intentá de nuevo.", isError = true, showRetry = true)
                else ->
                    showState("La lista de canales está vacía.", isError = false, showRetry = true)
            }
        } else {
            generateCategoriesFromChannels(originalChannels)
            applyFiltersAndUpdate()
        }
    }

    private fun showState(message: String, isError: Boolean, showRetry: Boolean) {
        errorText.text = message
        errorText.setTextColor(
            ContextCompat.getColor(requireContext(), if (isError) R.color.error else R.color.text_secondary)
        )
        retryButton.isVisible = showRetry
        stateContainer.isVisible = true
        if (showRetry && isTV) retryButton.requestFocus()
    }

    private fun hideState() {
        stateContainer.isVisible = false
    }

    private fun showLoading(show: Boolean) {
        progressBar.isVisible = show
    }

    /** True si las vistas ya existen (entre onViewCreated y onDestroyView). */
    private fun isViewReady() = view != null && ::progressBar.isInitialized && ::channelsAdapter.isInitialized

    /** La activity avisa que empezó (o se repitió) la carga de la lista. */
    fun onLoadStarted() {
        if (!isViewReady()) return
        hideState()
        if (!swipeRefresh.isRefreshing) showLoading(true)
    }

    /**
     * La activity llama a esto cuando termina de cargar. Si el fragmento todavía no creó sus vistas
     * no hay nada que actualizar: [renderInitialState] leerá el resultado desde la activity al crearlas.
     */
    fun showResult(result: LoadResult) {
        if (!isViewReady()) return
        applyResult(result)
    }

    // En TV, al volver del reproductor el foco regresa al canal que se estaba mirando.
    override fun onResume() {
        super.onResume()
        isLaunchingFullscreen = false
        if (isTV && !isHidden && isViewReady()) restoreTvFocus()
        if (!isHidden && ::inlinePlayerContainer.isInitialized && inlineChannel != null &&
            inlinePlayerContainer.visibility == View.VISIBLE) {
            inlineWebView.onResume()
            val player = inlineExoPlayer
            if (player != null) {
                player.play()
            } else if (inlineWebView.visibility != View.VISIBLE) {
                // Al volver de pantalla completa se reanuda la vista previa en móvil y Android TV.
                startInlinePlayback(inlineChannel!!, inlineSourceIndex)
            }
        }
        refreshInlineCastAvailability()
    }

    override fun handleBack(): Boolean {
        if (!isTV || !isSearchVisible || !::searchInput.isInitialized) return false
        toggleSearch()
        activity?.findViewById<View>(R.id.header_search_button)?.requestFocus()
        return true
    }

    override fun onPause() {
        super.onPause()
        stopInlineCastDiscovery()
        inlineExoPlayer?.pause()
        if (::inlineWebView.isInitialized) inlineWebView.onPause()
    }

    override fun onHiddenChanged(hidden: Boolean) {
        super.onHiddenChanged(hidden)
        if (hidden) {
            stopInlineCastDiscovery()
            inlineExoPlayer?.pause()
            if (::inlineWebView.isInitialized) inlineWebView.onPause()
        } else {
            inlineWebView.onResume()
            inlineExoPlayer?.play()
            refreshInlineCastAvailability()
        }
    }

    private fun restoreTvFocus() {
        val position = channelsAdapter.getLastFocusedPosition()
        if (position < 0 || position >= channelsAdapter.itemCount) return
        channelsRecycler.scrollToPosition(position)
        channelsRecycler.post {
            channelsRecycler.findViewHolderForAdapterPosition(position)?.itemView?.requestFocus()
        }
    }

    private fun openPlayer(channel: Channel, position: Int) {
        if (channel.streamUrl.isNullOrEmpty() && channel.options.isNullOrEmpty()) {
            Toast.makeText(requireContext(), "Este canal no tiene fuentes disponibles", Toast.LENGTH_SHORT).show()
            return
        }

        if (isTV) {
            showInlinePlayer(channel)
        } else if (resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE) {
            // Si el móvil ya está en horizontal, abre la pantalla dedicada directamente.
            showInlinePlayer(channel, startPlayback = false)
            launchPlayerActivity(channel, fromInline = true)
        } else {
            // En vertical el canal queda integrado encima de la lista, sin abandonar la pantalla.
            showInlinePlayer(channel)
        }
    }

    override fun onDestroyView() {
        stopInlineCastDiscovery()
        inlineCastController = null
        searchRunnable?.let { searchHandler.removeCallbacks(it) }
        hideInlineControlsRunnable?.let { inlineControlsHandler.removeCallbacks(it) }
        stopInlineTimelineUpdates()
        inlineGeneration++
        releaseInlineEngine()
        if (::inlineWebView.isInitialized) {
            inlineWebView.webChromeClient = WebChromeClient()
            inlineWebView.webViewClient = WebViewClient()
            inlineWebView.stopLoading()
            (inlineWebView.parent as? ViewGroup)?.removeView(inlineWebView)
            inlineWebView.removeAllViews()
            inlineWebView.destroy()
        }
        super.onDestroyView()
    }
}