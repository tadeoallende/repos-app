package com.angulismotv.fragments

import android.content.Intent
import android.content.res.Configuration
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.LayoutInflater
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.view.MotionEvent
import android.webkit.WebView
import android.widget.FrameLayout
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.SeekBar
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AlertDialog
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.angulismotv.MainActivity
import com.angulismotv.BackHandler
import com.angulismotv.R
import com.angulismotv.UnifiedPlayerActivity
import com.angulismotv.data.LoadResult
import com.angulismotv.data.ChannelFilterPolicy
import com.angulismotv.data.ChannelCatalogFilterController
import com.angulismotv.data.ChannelCatalogEmptyStatePolicy
import android.widget.Toast
import com.angulismotv.adapters.ChannelsAdapter
import com.angulismotv.models.Channel
import com.angulismotv.models.ChannelIdentity
import com.angulismotv.models.StreamType
import com.angulismotv.player.CastController
import com.angulismotv.player.CastStream
import com.angulismotv.player.InlinePlayerHandoff
import com.angulismotv.player.InlineControlsAutoHideController
import com.angulismotv.player.InlinePlaybackEngineController
import com.angulismotv.player.InlinePlaybackResumeIntent
import com.angulismotv.player.PlayerChannelCatalog
import com.angulismotv.player.PlayerTimelineController
import com.angulismotv.player.InlinePlaybackSessionState
import com.angulismotv.player.InlineSourceResolver
import com.angulismotv.player.InlineWebViewPlaybackController
import com.angulismotv.player.InlinePlayerVisualController
import com.angulismotv.ui.ChannelCatalogStateRenderer
import com.angulismotv.ui.TvPlayerPreviewRenderer
import com.angulismotv.ui.ChannelSearchInputBinding
import com.angulismotv.ui.ChannelSearchQueryController
import com.angulismotv.ui.ChannelCatalogFocusController
import com.angulismotv.ui.ChannelCategoryRailRenderer
import com.angulismotv.ui.ChannelCategoryLabels
import com.angulismotv.ui.CountryFilterDialogController
import com.angulismotv.ui.ViewLifecycleGate
import com.angulismotv.ui.ViewPostCallbackRegistry
import com.google.android.exoplayer2.ExoPlayer
import com.google.android.exoplayer2.Player
import com.angulismotv.utils.DeviceHelper
import com.angulismotv.utils.UiDimensions
import com.angulismotv.utils.loadChannelLogo

class ChannelsFragment : Fragment(), BackHandler {

    // The holder is scoped to one view lifecycle. Clearing it releases all old view references.
    private var viewRefs: ChannelsFragmentViews? = null
    private val viewLifecycleGate = ViewLifecycleGate()
    private var viewPostCallbackRegistry: ViewPostCallbackRegistry? = null
    private var viewGenerationToken: Int? = null
    private var inlineSourceDialog: AlertDialog? = null

    private fun requireViews(): ChannelsFragmentViews = checkNotNull(viewRefs) {
        "ChannelsFragment intentó acceder a una vista fuera de su ciclo de vida"
    }
    private fun hasActiveView(expectedGeneration: Int? = null): Boolean =
        viewRefs != null && viewLifecycleGate.isActive(expectedGeneration)

    private val channelsRecycler get() = requireViews().channelsRecycler
    private val progressBar get() = requireViews().progressBar
    private val swipeRefresh get() = requireViews().swipeRefresh
    private val stateContainer get() = requireViews().stateContainer
    private val retryButton get() = requireViews().retryButton
    private val errorText get() = requireViews().errorText
    private val categoriesContainer get() = requireViews().categoriesContainer
    private val categoriesScroll get() = requireViews().categoriesScroll
    private val searchInput get() = requireViews().searchInput
    private val btnSearch get() = requireViews().btnSearch
    private val channelsSectionHeader get() = requireViews().channelsSectionHeader
    private val channelsSearchContainer get() = requireViews().channelsSearchContainer
    private val channelsSectionSubtitle get() = requireViews().channelsSectionSubtitle
    private val tvListGuide get() = viewRefs?.tvListGuide

    // La composición de vista previa y sus guías son exclusivas de Android TV.
    private var tvPlayerPreviewRenderer: TvPlayerPreviewRenderer? = null
    private var categoryRailRenderer: ChannelCategoryRailRenderer? = null
    private var countryFilterDialogController: CountryFilterDialogController? = null

    // El holder retiene estos Views solo mientras la vista está activa.
    private val inlinePlayerContainer get() = requireViews().inlinePlayerContainer
    private val inlinePlayerView get() = requireViews().inlinePlayerView
    private var inlineWebViewController: InlineWebViewPlaybackController? = null
    private var inlinePlayerVisualController: InlinePlayerVisualController? = null
    private var catalogStateRenderer: ChannelCatalogStateRenderer? = null
    /** Exact WebView instance currently owned by UnifiedPlayerActivity after a handoff. */
    private var transferredInlineWebView: WebView? = null
    private var inlineWebView: WebView
        get() = requireViews().inlineWebView
        set(value) { requireViews().inlineWebView = value }
    private val inlineProgressBar get() = requireViews().inlineProgressBar
    private val inlineErrorText get() = requireViews().inlineErrorText
    private val inlineControlsBar get() = requireViews().inlineControlsBar
    private val inlineTimelineContainer get() = requireViews().inlineTimelineContainer
    private val inlineSeekBar get() = requireViews().inlineSeekBar
    private val inlineTimeCurrent get() = requireViews().inlineTimeCurrent
    private val inlineTimeDuration get() = requireViews().inlineTimeDuration
    private val inlineChannelLogo get() = requireViews().inlineChannelLogo
    private val inlineChannelName get() = requireViews().inlineChannelName
    private val inlineBtnPlayPause get() = requireViews().inlineBtnPlayPause
    private val inlineBtnSources get() = requireViews().inlineBtnSources
    private val inlineBtnReload get() = requireViews().inlineBtnReload
    private val inlineBtnCast get() = requireViews().inlineBtnCast
    private val inlineBtnFullscreen get() = requireViews().inlineBtnFullscreen
    private val inlineBtnClose get() = requireViews().inlineBtnClose
    private var inlinePlayerLayoutChangeListener: View.OnLayoutChangeListener? = null
    private val inlineSession = InlinePlaybackSessionState()
    private val inlinePlaybackResumeIntent = InlinePlaybackResumeIntent()
    private val inlineChannel: Channel? get() = inlineSession.channel
    private val inlineSourceIndex: Int get() = inlineSession.sourceIndex
    private val inlineCurrentStreamUrl: String get() = inlineSession.streamUrl
    private val inlineCurrentStreamType: String get() = inlineSession.streamType
    private var inlineCastController: CastController? = null
    private var inlineCastDiscoveryStarted = false
    private val inlineGeneration: Int get() = inlineSession.generation
    private var inlineControlsController: InlineControlsAutoHideController? = null
    private var isLaunchingFullscreen = false
    private val inlineControlsHandler = Handler(Looper.getMainLooper())

    // El motor nativo, el estado de sesión y la resolución de fuentes son componentes separados.
    // El Fragment conserva la coordinación visual y las decisiones propias del ciclo de vida UI.
    private val inlinePlaybackEngine = InlinePlaybackEngineController(
        handler = inlineControlsHandler,
        isGenerationCurrent = inlineSession::isCurrent,
        callbacks = object : InlinePlaybackEngineController.Callbacks {
            override fun onPlaybackStateChanged(player: ExoPlayer, generation: Int, state: Int) {
                when (state) {
                    Player.STATE_BUFFERING -> inlinePlayerVisualController?.showLoading()
                    Player.STATE_READY -> {
                        inlinePlayerVisualController?.showReady()
                        updateInlinePlayPauseIcon()
                        inlineTimelineController?.update()
                        showInlineControlsTemporarily()
                    }
                    Player.STATE_ENDED -> inlinePlayerVisualController?.showEnded()
                }
            }

            override fun onIsPlayingChanged(player: ExoPlayer, generation: Int) {
                updateInlinePlayPauseIcon()
            }

            override fun onPlayerError(generation: Int) {
                handleInlineSourceFailure(generation)
            }

            override fun onStartFailure(generation: Int, error: Exception) {
                handleInlineSourceFailure(generation)
            }

            override fun onStartupTimeout(generation: Int, streamUrl: String, streamType: String) {
                handleInlineSourceFailure(
                    generation = generation,
                    message = "La fuente tardó demasiado en iniciar. Podés recargarla o elegir otra manualmente."
                )
            }
        }
    )
    private val inlineExoPlayer: ExoPlayer? get() = inlinePlaybackEngine.player
    private var inlineTimelineController: PlayerTimelineController? = null

    // Adapter y datos
    private var channelsAdapterRef: ChannelsAdapter? = null
    private val channelsAdapter: ChannelsAdapter
        get() = checkNotNull(channelsAdapterRef) {
            "ChannelsAdapter no está disponible fuera del ciclo de vida de la vista"
        }
    private var originalChannels = listOf<Channel>()
    private var filteredChannels = listOf<Channel>()
    private val catalogFilterController = ChannelCatalogFilterController()
    private var currentCategory: String
        get() = catalogFilterController.selectedCategoryKey
        set(value) = catalogFilterController.selectCategory(value)
    private var currentCountry: String
        get() = catalogFilterController.selectedCountryKey
        set(value) = catalogFilterController.selectCountry(value)
    private var catalogFocusController: ChannelCatalogFocusController? = null
    private var isSearchVisible = false

    // La consulta y su debounce no dependen de la vista; el binding se desmonta con onDestroyView.
    private var searchQueryController: ChannelSearchQueryController? = null
    private var searchInputBinding: ChannelSearchInputBinding? = null
    private val SEARCH_DELAY = 300L

    private var isTV = false

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        // Android TV necesita una composición horizontal propia: vista previa a la izquierda,
        // catálogo a la derecha. El layout móvil permanece independiente y compacto.
        val layoutRes = if (DeviceHelper.isTV(requireContext())) {
            R.layout.fragment_channels_tv
        } else {
            R.layout.fragment_channels
        }
        return inflater.inflate(layoutRes, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        isTV = DeviceHelper.isTV(requireContext())

        viewGenerationToken = viewLifecycleGate.activate()
        viewPostCallbackRegistry = ViewPostCallbackRegistry()
        initViews(view)
        inlineTimelineController = PlayerTimelineController(
            handler = inlineControlsHandler,
            container = inlineTimelineContainer,
            seekBar = inlineSeekBar,
            currentTime = inlineTimeCurrent,
            durationTime = inlineTimeDuration,
            playerProvider = { inlineExoPlayer },
            isTimelineEnabled = {
                inlineControlsController?.isVisible == true
            },
            shouldContinueUpdates = {
                !isTV &&
                    inlineControlsController?.isVisible == true &&
                    inlineExoPlayer?.playbackState == Player.STATE_READY &&
                    inlineChannel != null && inlinePlayerContainer.visibility == View.VISIBLE
            },
            // El inline conservaba el comportamiento de permitir seek si hay duración positiva.
            canSeekOnStopTracking = { player -> player.duration > 0L }
        )
        inlineControlsController = InlineControlsAutoHideController(
            postDelayed = { task, delay -> inlineControlsHandler.postDelayed(task, delay) },
            removeCallbacks = { task -> inlineControlsHandler.removeCallbacks(task) },
            isTv = { isTV },
            canShow = {
                hasActiveView() &&
                    inlinePlayerContainer.visibility == View.VISIBLE
            },
            onVisibilityChanged = { visible ->
                inlinePlayerVisualController?.renderControlsVisibility(visible)
                if (!visible && inlineTimelineController != null) inlineTimelineController?.stopUpdates()
            },
            onShowRequested = {
                inlinePlayerVisualController?.bringControlsToFront()
                if (inlineTimelineController != null) {
                    inlineTimelineController?.update()
                    if (!isTV && inlineExoPlayer != null) inlineTimelineController?.startUpdates()
                }
            }
        )
        applyDeviceSpecificLayout(view)
        setupInlinePlayer()
        setupSearch()
        setupRecyclerView()
        setupStates()
        renderInitialState()

        if (isTV) {
            val expectedGeneration = viewGenerationToken ?: return
            viewPostCallbackRegistry?.post(view) {
                if (!isAdded || !hasActiveView(expectedGeneration) || !inlinePlayerContainer.isShown) return@post
                if (retryButton.isShown) retryButton.requestFocus()
                else inlinePlayerContainer.requestFocus()
            }
        }
    }

    private fun initViews(view: View) {
        viewRefs = ChannelsFragmentViews(view)
        tvPlayerPreviewRenderer = TvPlayerPreviewRenderer(
            emptyState = view.findViewById<View>(R.id.tv_player_empty_state),
            currentChannelInfo = view.findViewById<View>(R.id.tv_current_channel_info),
            channelLogo = view.findViewById<ImageView>(R.id.tv_current_channel_logo),
            channelName = view.findViewById<TextView>(R.id.tv_current_channel_name),
            channelCategory = view.findViewById<TextView>(R.id.tv_current_channel_category),
            guide = view.findViewById<TextView>(R.id.tv_player_guide),
            keysHint = view.findViewById<TextView>(R.id.tv_player_keys_hint),
            footerHint = view.findViewById<TextView>(R.id.tv_player_footer_hint),
            displayCategoryName = ChannelCategoryLabels::displayName
        )
        val expectedGeneration = checkNotNull(viewGenerationToken)
        val layoutChangeListener = View.OnLayoutChangeListener { v, left, _, right, _, _, _, _, _ ->
            if (!hasActiveView(expectedGeneration)) return@OnLayoutChangeListener
            val width = right - left
            if (width > 0) {
                val targetHeight = (width * 9f / 16f).toInt()
                if (v.layoutParams.height != targetHeight) {
                    v.layoutParams = v.layoutParams.apply { height = targetHeight }
                }
            }
        }
        inlinePlayerLayoutChangeListener = layoutChangeListener
        inlinePlayerContainer.addOnLayoutChangeListener(layoutChangeListener)
        inlinePlayerVisualController = InlinePlayerVisualController(
            progressBar = inlineProgressBar,
            errorText = inlineErrorText,
            playerView = inlinePlayerView,
            webView = inlineWebView,
            controlsBar = inlineControlsBar,
            timelineContainer = inlineTimelineContainer,
            playPauseButton = inlineBtnPlayPause,
            sourcesButton = inlineBtnSources,
            isTv = { isTV }
        )
        inlineWebViewController = InlineWebViewPlaybackController(
            webViewProvider = { inlineWebView },
            isTV = { isTV },
            isGenerationCurrent = inlineSession::isCurrent,
            onPageLoaded = { generation ->
                if (generation == inlineGeneration) {
                    inlinePlayerVisualController?.showReady()
                    showInlineControlsTemporarily()
                }
            },
            onMainFrameFailure = ::handleInlineSourceFailure
        )
        categoryRailRenderer = ChannelCategoryRailRenderer(
            container = categoriesContainer,
            searchInput = searchInput,
            channelsRecycler = channelsRecycler,
            adapterProvider = { channelsAdapterRef },
            isTv = { isTV },
            onCategoryClick = ::selectCategory,
            onCountryClick = ::showCountryPicker,
            onFocusChannelList = ::focusChannelList
        )
        countryFilterDialogController = CountryFilterDialogController(
            context = requireContext(),
            availableCountryKeys = { catalogFilterController.availableCountryKeys() },
            countryLabel = ChannelFilterPolicy::countryLabel
        )
    }

    /**
     * Mobile follows a compact, connected TV-guide layout. Android TV explicitly restores
     * its larger paddings and chip sizes so these changes never reduce 10-foot readability.
     */
    private fun applyDeviceSpecificLayout(root: View) {
        val listContainer = root.findViewById<FrameLayout>(R.id.channels_list_container)
        val searchRow = channelsSearchContainer as? ViewGroup
        val searchField = searchRow?.getChildAt(0) as? ViewGroup
        val searchParams = searchField?.layoutParams
        val listContainerPadding = if (isTV) 0 else UiDimensions.px(resources, R.dimen.channels_mobile_search_padding_horizontal)

        if (isTV) {
            // Layout dedicado 10-foot: el espacio se invierte en el vídeo y en más filas visibles,
            // no en márgenes interiores redundantes.
            channelsSectionHeader.visibility = View.VISIBLE
            channelsSearchContainer.visibility = View.GONE
            isSearchVisible = false
            // El icono dentro del campo se conserva como decoración; la cabecera abre/cierra la búsqueda.
            btnSearch.isFocusable = false
            btnSearch.isClickable = false
            btnSearch.setOnClickListener(null)
            channelsSearchContainer.setPadding(
                UiDimensions.px(resources, R.dimen.channels_tv_search_padding),
                UiDimensions.px(resources, R.dimen.channels_tv_search_padding),
                UiDimensions.px(resources, R.dimen.channels_tv_search_padding),
                UiDimensions.px(resources, R.dimen.channels_tv_search_padding)
            )
            if (searchParams != null) {
                searchParams.height = UiDimensions.px(resources, R.dimen.channels_tv_search_height)
                searchField?.layoutParams = searchParams
            }
            searchField?.setPadding(UiDimensions.px(resources, R.dimen.channels_search_input_padding_horizontal), 0, UiDimensions.px(resources, R.dimen.channels_search_input_padding_horizontal), 0)
            (searchInput.layoutParams as? ViewGroup.MarginLayoutParams)?.let { params ->
                params.marginStart = UiDimensions.px(resources, R.dimen.channels_search_input_margin_start)
                searchInput.layoutParams = params
            }
            categoriesScroll.setPadding(
                UiDimensions.px(resources, R.dimen.channels_tv_search_padding),
                UiDimensions.px(resources, R.dimen.channels_tv_search_padding),
                UiDimensions.px(resources, R.dimen.channels_tv_search_padding),
                UiDimensions.px(resources, R.dimen.channels_tv_search_padding)
            )
            listContainer?.setPadding(listContainerPadding, 0, 0, 0)
            channelsRecycler.setPadding(
                UiDimensions.px(resources, R.dimen.channels_tv_list_padding_horizontal),
                UiDimensions.px(resources, R.dimen.channels_tv_list_padding_top),
                UiDimensions.px(resources, R.dimen.channels_tv_list_padding_horizontal),
                UiDimensions.px(resources, R.dimen.channels_tv_list_padding_bottom)
            )
            categoriesScroll.isFillViewport = false
        } else {
            // The branded app header already identifies the section; avoid a redundant title block.
            channelsSectionHeader.visibility = View.GONE
            channelsSectionHeader.layoutParams = channelsSectionHeader.layoutParams.apply { height = 0 }
            channelsSearchContainer.visibility = View.GONE
            channelsSearchContainer.setPadding(
                UiDimensions.px(resources, R.dimen.channels_mobile_search_padding_horizontal),
                UiDimensions.px(resources, R.dimen.channels_mobile_search_padding_top),
                UiDimensions.px(resources, R.dimen.channels_mobile_search_padding_horizontal),
                UiDimensions.px(resources, R.dimen.channels_mobile_search_padding_bottom)
            )
            if (searchParams != null) {
                searchParams.height = UiDimensions.px(resources, R.dimen.channels_mobile_search_height)
                searchField?.layoutParams = searchParams
            }
            searchField?.setPadding(UiDimensions.px(resources, R.dimen.channels_search_input_padding_horizontal), 0, UiDimensions.px(resources, R.dimen.channels_search_input_padding_horizontal), 0)
            (searchInput.layoutParams as? ViewGroup.MarginLayoutParams)?.let { params ->
                params.marginStart = UiDimensions.px(resources, R.dimen.channels_search_input_margin_start)
                searchInput.layoutParams = params
            }
            categoriesScroll.setPadding(
                UiDimensions.px(resources, R.dimen.channels_mobile_category_padding_horizontal),
                UiDimensions.px(resources, R.dimen.channels_mobile_category_padding_vertical),
                UiDimensions.px(resources, R.dimen.channels_mobile_category_padding_horizontal),
                UiDimensions.px(resources, R.dimen.channels_mobile_category_padding_vertical)
            )
            listContainer?.setPadding(0, 0, 0, 0)
            channelsRecycler.setPadding(
                UiDimensions.px(resources, R.dimen.channels_mobile_list_padding_horizontal),
                UiDimensions.px(resources, R.dimen.channels_mobile_list_padding_top),
                UiDimensions.px(resources, R.dimen.channels_mobile_list_padding_horizontal),
                UiDimensions.px(resources, R.dimen.channels_mobile_list_padding_bottom)
            )
            channelsRecycler.clipToPadding = false

            val playerParams = inlinePlayerContainer.layoutParams as? ViewGroup.MarginLayoutParams
            playerParams?.setMargins(
                UiDimensions.px(resources, R.dimen.inline_player_margin_mobile),
                UiDimensions.px(resources, R.dimen.inline_player_margin_mobile),
                UiDimensions.px(resources, R.dimen.inline_player_margin_mobile),
                0
            )
            if (playerParams != null) inlinePlayerContainer.layoutParams = playerParams
            inlinePlayerContainer.elevation = 0f
            inlineControlsBar.apply {
                minimumHeight = UiDimensions.px(resources, R.dimen.inline_controls_min_height_mobile)
                setPadding(
                    UiDimensions.px(resources, R.dimen.inline_controls_padding_horizontal_mobile),
                    UiDimensions.px(resources, R.dimen.inline_controls_padding_vertical_mobile),
                    UiDimensions.px(resources, R.dimen.inline_controls_padding_horizontal_mobile),
                    UiDimensions.px(resources, R.dimen.inline_controls_padding_vertical_mobile)
                )
            }
            inlineChannelLogo.layoutParams = inlineChannelLogo.layoutParams.apply {
                width = UiDimensions.px(resources, R.dimen.inline_channel_logo_size_mobile)
                height = UiDimensions.px(resources, R.dimen.inline_channel_logo_size_mobile)
            }
            inlineChannelName.apply {
                (layoutParams as? ViewGroup.MarginLayoutParams)?.let { params ->
                    params.marginStart = UiDimensions.px(resources, R.dimen.inline_channel_name_margin_start_mobile)
                    layoutParams = params
                }
            }
            (inlineTimelineContainer.layoutParams as? FrameLayout.LayoutParams)?.let { params ->
                params.height = UiDimensions.px(resources, R.dimen.inline_timeline_height_mobile)
                params.leftMargin = UiDimensions.px(resources, R.dimen.inline_timeline_margin_horizontal_mobile)
                params.rightMargin = UiDimensions.px(resources, R.dimen.inline_timeline_margin_horizontal_mobile)
                params.bottomMargin = UiDimensions.px(resources, R.dimen.inline_timeline_margin_bottom_mobile)
                inlineTimelineContainer.layoutParams = params
            }
            inlineTimeCurrent.layoutParams = inlineTimeCurrent.layoutParams.apply { width = UiDimensions.px(resources, R.dimen.inline_time_label_width_mobile) }
            inlineTimeDuration.layoutParams = inlineTimeDuration.layoutParams.apply { width = UiDimensions.px(resources, R.dimen.inline_time_label_width_mobile) }
            inlineSeekBar.layoutParams = inlineSeekBar.layoutParams.apply { height = UiDimensions.px(resources, R.dimen.inline_seekbar_height_mobile) }
            listContainer?.clipToPadding = false
        }
    }

    private fun setupInlinePlayer() {
        if (isTV) {
            // En TV el reproductor es un objetivo real del D-pad, incluso antes de elegir canal.
            inlinePlayerContainer.visibility = View.VISIBLE
            inlinePlayerContainer.isFocusable = true
            inlinePlayerContainer.isFocusableInTouchMode = true
            inlinePlayerContainer.isClickable = true
            inlinePlayerView.isFocusable = false
            inlinePlayerView.isFocusableInTouchMode = false
            inlinePlayerView.isClickable = false
            inlineWebView.isFocusable = false
            inlineWebView.isFocusableInTouchMode = false
            inlineWebView.isClickable = false
            inlineBtnCast.visibility = View.GONE
            inlinePlayerVisualController?.renderControlsVisibility(false)
            tvPlayerPreviewRenderer?.showIdle()

            inlinePlayerContainer.nextFocusLeftId = R.id.menu_channels
            inlinePlayerContainer.nextFocusRightId = R.id.channels_recycler
            inlinePlayerContainer.nextFocusUpId = R.id.header_search_button
            inlinePlayerContainer.setOnClickListener { activateTvPlayer() }
            inlinePlayerContainer.setOnKeyListener { v, keyCode, event ->
                if (event.action != KeyEvent.ACTION_DOWN || event.repeatCount > 0) return@setOnKeyListener false
                when (keyCode) {
                    KeyEvent.KEYCODE_DPAD_CENTER,
                    KeyEvent.KEYCODE_ENTER,
                    KeyEvent.KEYCODE_NUMPAD_ENTER -> {
                        v.performClick()
                        true
                    }
                    KeyEvent.KEYCODE_DPAD_RIGHT -> {
                        focusChannelList()
                        true
                    }
                    KeyEvent.KEYCODE_DPAD_LEFT -> {
                        requireActivity().findViewById<View>(R.id.menu_channels)?.requestFocus() == true
                    }
                    else -> false
                }
            }
            inlinePlayerContainer.setOnFocusChangeListener { _, hasFocus ->
                // La ayuda depende del destino real del foco: no anunciar OK a pantalla completa
                // mientras el mando está navegando por las filas de canales.
                tvPlayerPreviewRenderer?.renderFocus(hasFocus, inlineChannel != null)
            }
        } else {
            val hostActivity = activity as? AppCompatActivity
            if (hostActivity != null) {
                inlineCastController = CastController(
                    activity = hostActivity,
                    button = inlineBtnCast,
                    handler = inlineControlsHandler,
                    currentStream = {
                        val channel = inlineChannel
                        val url = inlineCurrentStreamUrl
                        if (channel == null || url.isBlank() || inlineCurrentStreamType == StreamType.IFRAME) null
                        else CastStream(url, inlineCurrentStreamType, channel.name)
                    },
                    onCastStarted = {
                        inlineExoPlayer?.pause()
                        updateInlinePlayPauseIcon()
                    },
                    onStatusChanged = { message ->
                        tvPlayerPreviewRenderer?.showStatus(message)
                    }
                ).also { controller ->
                    controller.setup(isTV = false)
                    inlineBtnCast.visibility = View.GONE
                }
            } else {
                inlineBtnCast.visibility = View.GONE
            }
            inlinePlayerContainer.visibility = View.GONE
            inlinePlayerView.isFocusable = false
            inlinePlayerView.isClickable = true
            inlinePlayerView.setOnClickListener {
                inlineControlsController?.toggleTemporarily()
            }
            // No consume los toques del reproductor web: sus controles internos siguen funcionando.
            bindInlineWebViewTouchListener(inlineWebView)
        }

        inlineSeekBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onStartTrackingTouch(seekBar: SeekBar?) {
                inlineTimelineController?.onStartTracking()
                // No ocultar el control mientras el usuario mantiene el dedo en la línea de tiempo.
                inlineControlsController?.showPersistent()
            }

            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                inlineTimelineController?.onProgressChanged(progress, fromUser)
            }

            override fun onStopTrackingTouch(seekBar: SeekBar?) {
                inlineTimelineController?.onStopTracking()
                showInlineControlsTemporarily()
            }
        })

        inlineBtnPlayPause.setOnClickListener {
            val player = inlineExoPlayer ?: return@setOnClickListener
            if (player.isPlaying) player.pause() else player.play()
            updateInlinePlayPauseIcon()
            showInlineControlsTemporarily()
        }
        inlineBtnSources.setOnClickListener { showInlineSourcePicker() }
        inlineBtnReload.setOnClickListener { reloadInlineTransmission() }
        inlineBtnCast.visibility = View.GONE
        inlineBtnFullscreen.setOnClickListener { launchInlineFullscreen() }
        inlineBtnClose.setOnClickListener { closeInlinePlayer() }
    }

    /** The WebView can outlive this view tree during fullscreen handoff; never leave the old
     * Fragment's touch listener attached to that transferred instance. */
    private fun bindInlineWebViewTouchListener(target: WebView) {
        if (isTV) {
            target.setOnTouchListener(null)
            return
        }
        val expectedGeneration = viewGenerationToken ?: run {
            target.setOnTouchListener(null)
            return
        }
        target.setOnTouchListener { _, event ->
            if (event.action == MotionEvent.ACTION_UP && hasActiveView(expectedGeneration)) {
                showInlineControlsTemporarily()
            }
            false
        }
    }

    /** Reattaches a native player returned from fullscreen without resetting its media item. */
    private fun restoreInlineSession(session: InlinePlayerHandoff.Session) {
        if (!hasActiveView()) return
        val channel = session.channel
        inlineSession.restore(
            channel = channel,
            sourceIndex = session.sourceIndex,
            url = session.streamUrl,
            type = session.streamType
        )
        if (isTV && channelsAdapterRef != null) channelsAdapter.setPreviewChannel(channel)
        inlinePlayerContainer.visibility = View.VISIBLE
        tvPlayerPreviewRenderer?.showChannel(channel)
        inlineChannelName.text = channel.name
        inlineChannelLogo.loadChannelLogo(channel.name, channel.logo)
        inlinePlayerVisualController?.setSourcesAvailable((channel.options?.size ?: 0) > 1)
        inlinePlayerVisualController?.clearError()

        val player = session.player
        val returnedWebView = session.webView
        // Restore the exact WebView instance and its previous position if fullscreen returned it.
        if (returnedWebView != null) {
            // A recreated Fragment already inflated an empty placeholder WebView. Destroy that
            // placeholder before attaching the original page, otherwise the two views overlap.
            val placeholderWebView = inlineWebView
            if (placeholderWebView !== returnedWebView) {
                inlineWebViewController?.disposeSpecificView(placeholderWebView)
            }
            // Restore the exact WebView instance and its previous position in the inline player.
            inlineWebView = returnedWebView
            transferredInlineWebView = null
            bindInlineWebViewTouchListener(returnedWebView)
            inlineWebViewController?.attachReturnedView(
                parent = inlinePlayerContainer,
                parentIndex = session.webViewParentIndex,
                layoutParams = session.webViewLayoutParams
            )
        } else {
            // Also resume the inline instance when a native-only fullscreen session returns.
            inlineWebViewController?.onResume()
        }

        if (player != null && session.streamType != StreamType.IFRAME) {
            if (returnedWebView != null) inlineWebViewController?.resetForNativePlayback()
            val generation = inlineSession.advanceGeneration()
            inlinePlayerVisualController?.showNativeSurface()
            if (player.playbackState == Player.STATE_BUFFERING || player.playbackState == Player.STATE_IDLE) {
                inlinePlayerVisualController?.showLoading()
            } else {
                inlinePlayerVisualController?.showReady()
            }
            inlinePlaybackEngine.attachExistingPlayer(
                existingPlayer = player,
                targetView = inlinePlayerView,
                url = session.streamUrl,
                type = session.streamType,
                playbackGeneration = generation
            )
            player.playWhenReady = session.wasPlaying
            updateInlinePlayPauseIcon()
            if (player.playbackState == Player.STATE_READY) {
                inlinePlayerVisualController?.showReady()
                inlineTimelineController?.update()
                if (!isTV && inlineControlsController?.isVisible == true) startInlineTimelineUpdates()
            }
        } else if (returnedWebView != null && session.streamType == StreamType.IFRAME) {
            val generation = inlineSession.advanceGeneration()
            inlinePlayerVisualController?.showWebSurface()
            inlinePlayerVisualController?.showReady()
            startInlineWebView(session.streamUrl, generation, loadUrl = false)
        } else {
            // Fallback only when there was no reusable native player or transferred WebView.
            showInlinePlayer(channel, startPlayback = false)
            startInlinePlayback(channel, inlineSourceIndex)
        }
        refreshInlineCastAvailability()
    }

    private fun activateTvPlayer() {
        if (!isTV || !hasActiveView()) return
        if (inlineChannel != null) {
            launchInlineFullscreen()
        } else {
            tvPlayerPreviewRenderer?.showNoChannelSelected()
            focusChannelList()
        }
    }

    /** The view-specific focus path is coordinated separately from catalog/filter state. */
    private fun focusChannelList() {
        if (!hasActiveView()) return
        catalogFocusController?.focusChannelList()
    }

    private fun focusSelectedCategory() {
        if (!hasActiveView()) return
        if (categoryRailRenderer?.focusSelectedCategory(currentCategory) != true) {
            catalogFocusController?.focusSelectedCategory()
        }
    }

    private fun showInlinePlayer(channel: Channel, startPlayback: Boolean = true) {
        if (!hasActiveView()) return
        // El reproductor se actualiza sin mover la lista. En TV el foco permanece en el canal
        // que acaba de seleccionarse, incluso si el D-pad mantiene pulsado OK.

        // Invalida callbacks tardíos de la fuente anterior antes de cambiar de canal.
        inlineSession.beginChannel(channel)
        stopInlineCastDiscovery()
        inlineBtnCast.visibility = View.GONE
        if (isTV && channelsAdapterRef != null) channelsAdapter.setPreviewChannel(channel)
        inlinePlayerContainer.visibility = View.VISIBLE
        if (!isTV) {
            channelsSectionHeader.visibility = View.GONE
            channelsSearchContainer.visibility = View.GONE
            isSearchVisible = false
            searchInput.clearFocus()
            syncHeaderSearchButton(false)
            val inputMethodManager = requireContext().getSystemService(android.content.Context.INPUT_METHOD_SERVICE) as android.view.inputmethod.InputMethodManager
            inputMethodManager.hideSoftInputFromWindow(searchInput.windowToken, 0)
        } else {
            channelsSectionHeader.visibility = View.VISIBLE
            channelsSearchContainer.visibility = if (isSearchVisible) View.VISIBLE else View.GONE
            tvPlayerPreviewRenderer?.showChannel(channel)
            channelsSectionSubtitle.text = getString(R.string.tv_channels_subtitle_count, filteredChannels.size)
        }
        inlineChannelName.text = channel.name
        inlineChannelLogo.loadChannelLogo(channel.name, channel.logo)
        inlinePlayerVisualController?.setSourcesAvailable((channel.options?.size ?: 0) > 1)
        inlinePlayerVisualController?.clearError()
        inlinePlayerVisualController?.hideSurfaces(clearWebSurface = true)
        showInlineControlsTemporarily()

        if (startPlayback) {
            startInlinePlayback(channel, 0)
        } else {
            releaseInlineEngine()
            inlinePlayerVisualController?.showEnded()
        }
        if (isTV) restoreTvFocusForChannel(ChannelIdentity.key(channel), scrollIfNeeded = true)
    }

    /** Keep D-pad focus tied to channel identity, not an adapter position that can change. */
    private fun restoreTvFocusForChannel(key: String, scrollIfNeeded: Boolean) {
        if (!hasActiveView()) return
        catalogFocusController?.restoreChannelForKey(key, scrollIfNeeded)
    }

    private fun currentFocusedChannelKey(): String? =
        catalogFocusController?.currentFocusedChannelKey()

    /** Recarga la fuente actualmente seleccionada sin cambiar de canal ni saltar a otra opción. */
    private fun reloadInlineTransmission() {
        if (!hasActiveView()) return
        val channel = inlineChannel ?: return
        val sourceIndex = inlineSourceIndex
        inlinePlayerVisualController?.showLoading()
        startInlinePlayback(channel, sourceIndex)
        showInlineControlsTemporarily()
    }

    private fun startInlinePlayback(channel: Channel, sourceIndex: Int) {
        if (!isAdded || !hasActiveView()) return
        // Durante un cambio de fuente no se debe ofrecer Cast con la URL anterior.
        val generation = inlineSession.beginSourceSelection(sourceIndex)
        stopInlineCastDiscovery()
        if (hasActiveView()) inlineBtnCast.visibility = View.GONE
        releaseInlineEngine()
        inlinePlayerVisualController?.showLoading()

        val resolved = when (val result = InlineSourceResolver.resolve(channel, sourceIndex)) {
            is InlineSourceResolver.Result.Resolved -> result
            is InlineSourceResolver.Result.Unavailable -> {
                val message = when (result.reason) {
                    InlineSourceResolver.FailureReason.INVALID_SOURCE_INDEX ->
                        "No se pudo reproducir ninguna fuente de este canal."
                    InlineSourceResolver.FailureReason.EMPTY_URL ->
                        "Esta fuente no tiene una dirección de reproducción válida."
                }
                showInlineError(message)
                return
            }
        }
        val url = resolved.url
        val type = resolved.type
        if (!inlineSession.setResolvedSource(url, type)) {
            showInlineError("Esta fuente no tiene una dirección de reproducción válida.")
            return
        }
        refreshInlineCastAvailability()

        if (type == StreamType.IFRAME) {
            startInlineWebView(url, generation)
        } else {
            startInlineExoPlayer(url, type, generation)
        }
    }

    private fun startInlineExoPlayer(url: String, type: String, generation: Int) {
        inlineWebViewController?.stopAndHide(clearDocument = false)
        inlinePlayerVisualController?.showNativeSurface()
        inlinePlaybackEngine.start(
            context = requireContext(),
            targetView = inlinePlayerView,
            url = url,
            type = type,
            playbackGeneration = generation
        )
    }

    private fun scheduleInlineStartupTimeout(player: ExoPlayer, generation: Int) {
        inlinePlaybackEngine.scheduleStartupTimeout(player, generation)
    }

    private fun cancelInlineStartupTimeout() {
        inlinePlaybackEngine.cancelStartupTimeout()
    }

    private fun startInlineWebView(url: String, generation: Int, loadUrl: Boolean = true) {
        inlinePlayerVisualController?.showWebSurface()
        stopInlineTimelineUpdates()
        inlineWebViewController?.load(url, generation, loadUrl)
    }

    private fun handleInlineSourceFailure(
        generation: Int,
        message: String = "No se pudo cargar esta fuente. Podés elegir otra manualmente."
    ) {
        // Solo el intento vigente puede mostrar error o liberar recursos: los callbacks viejos
        // no deben afectar la fuente nueva. La selección se conserva para que Recargar la repita.
        if (!inlineSession.failSource(generation)) return
        stopInlineCastDiscovery()
        if (hasActiveView()) inlineBtnCast.visibility = View.GONE
        releaseInlineEngine()
        showInlineError(message)
    }

    private fun showInlineError(message: String) {
        stopInlineTimelineUpdates()
        inlinePlayerVisualController?.showError(message)
        // Mantener accesible Recargar en móvil mientras haya error; la próxima reproducción
        // vuelve a habilitar el auto-ocultado normal.
        if (!isTV) inlineControlsController?.showPersistent()
    }

    private fun releaseInlineEngine(clearWebView: Boolean = true) {
        inlinePlaybackEngine.release()
        stopInlineTimelineUpdates()
        inlinePlayerVisualController?.onNativeEngineReleased(clearWebSurface = clearWebView)
        if (clearWebView && inlineWebViewController != null) {
            inlineWebViewController?.stopAndHide(clearDocument = true)
        }
    }

    private fun startInlineTimelineUpdates() {
        if (inlineTimelineController != null) inlineTimelineController?.startUpdates()
    }

    private fun stopInlineTimelineUpdates() {
        if (inlineTimelineController != null) inlineTimelineController?.stopUpdates()
    }

    private fun updateInlinePlayPauseIcon() {
        inlinePlayerVisualController?.renderPlayPause(inlineExoPlayer?.isPlaying == true)
    }

    private fun showInlineControlsTemporarily() {
        inlineControlsController?.showTemporarily()
    }

    private fun hideInlineControls() {
        inlineControlsController?.hide()
    }

    private fun refreshInlineCastAvailability() {
        // A stale view holder must never be used after its lifecycle ended.
        if (!hasActiveView()) return
        val canCast = !isTV &&
            inlinePlayerContainer.visibility == View.VISIBLE &&
            inlineSession.canCast() &&
            inlineCastController?.isConfigured == true

        inlineBtnCast.visibility = if (canCast) View.VISIBLE else View.GONE
        if (canCast && isResumed && !isHidden) {
            startInlineCastDiscovery()
        } else {
            stopInlineCastDiscovery()
        }
    }

    private fun startInlineCastDiscovery() {
        if (inlineCastDiscoveryStarted || inlineCastController?.isConfigured != true) return
        inlineCastController?.startDiscovery()
        inlineCastDiscoveryStarted = true
    }

    private fun stopInlineCastDiscovery() {
        if (!inlineCastDiscoveryStarted) return
        inlineCastController?.stopDiscovery()
        inlineCastDiscoveryStarted = false
    }

    private fun showInlineSourcePicker() {
        val expectedGeneration = viewGenerationToken ?: return
        if (!hasActiveView(expectedGeneration)) return
        val channel = inlineChannel ?: return
        val options = channel.options.orEmpty()
        if (options.size < 2) return
        inlineSourceDialog?.let { previous ->
            previous.setOnDismissListener(null)
            previous.dismiss()
        }
        // Mantener accesibles los controles mientras el selector modal está abierto.
        if (!isTV) inlineControlsController?.showPersistent()
        val dialog = AlertDialog.Builder(requireContext())
            .setTitle("Seleccionar fuente")
            .setItems(options.mapIndexed { index, option ->
                option.name.trim().takeIf { it.isNotEmpty() } ?: "Fuente ${index + 1}"
            }.toTypedArray()) { _, which ->
                if (hasActiveView(expectedGeneration)) startInlinePlayback(channel, which)
            }
            .setNegativeButton("Cancelar", null)
            .create()
        inlineSourceDialog = dialog
        dialog.setOnDismissListener {
            if (inlineSourceDialog === dialog) inlineSourceDialog = null
            if (hasActiveView(expectedGeneration)) showInlineControlsTemporarily()
        }
        dialog.show()
    }

    private fun closeInlinePlayer() {
        if (!hasActiveView()) return
        inlineSession.clear()
        stopInlineCastDiscovery()
        inlineBtnCast.visibility = View.GONE
        hideInlineControls()
        releaseInlineEngine()
        inlinePlayerVisualController?.close()
        inlinePlayerContainer.visibility = if (isTV) View.VISIBLE else View.GONE
        if (isTV && channelsAdapterRef != null) channelsAdapter.setPreviewChannel(null)
        channelsSectionHeader.visibility = if (isTV) View.VISIBLE else View.GONE
        isSearchVisible = false
        channelsSearchContainer.visibility = View.GONE
        clearSearchQuery(applyImmediately = true)
        syncHeaderSearchButton(false)
        currentCategory = currentCategory.ifBlank { "todos" }
        if (isTV) {
            tvPlayerPreviewRenderer?.showIdle()
            inlinePlayerContainer.requestFocus()
        }
    }

    private fun launchInlineFullscreen() {
        if (!hasActiveView()) return
        val channel = inlineChannel ?: return
        launchPlayerActivity(channel, fromInline = true)
    }

    private fun launchPlayerActivity(channel: Channel, fromInline: Boolean) {
        if (!hasActiveView() || (fromInline && isLaunchingFullscreen)) return
        val matchingIndex = originalChannels.indexOfFirst { ChannelIdentity.same(it, channel) }
        // Si el canal ya no está en el snapshot por una actualización, lo agregamos al
        // catálogo entregado al reproductor en vez de seleccionar silenciosamente el primero.
        val playerChannels = if (matchingIndex >= 0) originalChannels else originalChannels + channel
        val channelIndex = if (matchingIndex >= 0) matchingIndex else playerChannels.lastIndex
        isLaunchingFullscreen = fromInline

        // Transferir también en móviles: la Activity cambia a horizontal, pero el motor ya
        // preparado (o el WebView del iframe) tiene que sobrevivir sin volver a cargar la fuente.
        val currentPlayer = inlineExoPlayer
        val canTransferNativePlayer = fromInline && currentPlayer != null &&
            inlineCurrentStreamUrl.isNotBlank() && inlineCurrentStreamType != StreamType.IFRAME
        val canTransferWebView = fromInline && currentPlayer == null &&
            inlineCurrentStreamType == StreamType.IFRAME && inlineCurrentStreamUrl.isNotBlank() &&
            inlineWebView.visibility == View.VISIBLE && inlineWebView.url != null
        if (canTransferNativePlayer && currentPlayer != null) {
            val transferredPlayer = inlinePlaybackEngine.detachForHandoff() ?: currentPlayer
            val session = InlinePlayerHandoff.Session(
                player = transferredPlayer,
                channel = inlineChannel ?: channel,
                streamUrl = inlineCurrentStreamUrl,
                streamType = inlineCurrentStreamType,
                sourceIndex = inlineSourceIndex,
                wasPlaying = transferredPlayer.playWhenReady
            )
            stopInlineTimelineUpdates()
            // detachForHandoff quita listeners/vista, pero no pausa ni libera el motor.
            InlinePlayerHandoff.offerToFullscreen(session)
        } else if (canTransferWebView) {
            // Detach the live page without destroying it: fullscreen takes ownership of this exact view.
            val detachedWebView = requireNotNull(inlineWebViewController).detachForHandoff()
            detachedWebView.webView.setOnTouchListener(null)
            InlinePlayerHandoff.offerToFullscreen(
                InlinePlayerHandoff.Session(
                    player = null,
                    channel = inlineChannel ?: channel,
                    streamUrl = inlineCurrentStreamUrl,
                    streamType = StreamType.IFRAME,
                    sourceIndex = inlineSourceIndex,
                    wasPlaying = true,
                    webView = detachedWebView.webView,
                    webViewParentIndex = detachedWebView.parentIndex,
                    webViewLayoutParams = detachedWebView.layoutParams
                )
            )
            transferredInlineWebView = detachedWebView.webView
        } else {
            inlineExoPlayer?.pause()
        }
        inlineWebViewController?.onPause()

        // El catálogo global puede contener miles de canales: no lo serializamos en el Intent,
        // porque el tamaño del Bundle/Binder es limitado. Enviamos un token de la lista en memoria.
        val catalogToken = PlayerChannelCatalog.publish(playerChannels)
        val intent = Intent(requireContext(), UnifiedPlayerActivity::class.java).apply {
            putExtra("channel_catalog_token", catalogToken)
            putExtra("current_channel", channel)
            putExtra("channel_index", channelIndex)
            putExtra("channel_name", channel.name)
            putExtra("channel_logo", channel.logo)
            putExtra("stream_url", channel.streamUrl)
            putExtra("stream_type", channel.streamType ?: StreamType.AUTO)
            putExtra("from_inline_player", fromInline)
            putExtra("force_landscape_fullscreen", fromInline && !isTV)
            putExtra("source_index", inlineSourceIndex)
            putExtra("reuse_inline_player_session", canTransferNativePlayer)
            putExtra("reuse_inline_webview_session", canTransferWebView)
        }
        try {
            startActivity(intent)
            if (!isTV) requireActivity().overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
        } catch (error: Exception) {
            isLaunchingFullscreen = false
            if (canTransferNativePlayer || canTransferWebView) {
                InlinePlayerHandoff.cancelPendingFullscreen()?.let(::restoreInlineSession)
            }
            android.util.Log.e("InlinePlayer", "No se pudo abrir pantalla completa", error)
            Toast.makeText(requireContext(), "No se pudo abrir el reproductor a pantalla completa", Toast.LENGTH_SHORT).show()
        }
    }

    private fun maybeOpenFullscreenAfterRotation(newConfig: Configuration) {
        if (!hasActiveView() || isTV || isHidden ||
            newConfig.orientation != Configuration.ORIENTATION_LANDSCAPE
        ) return
        val channel = inlineChannel ?: return
        if (inlinePlayerContainer.visibility != View.VISIBLE || isLaunchingFullscreen) return
        launchPlayerActivity(channel, fromInline = true)
    }

    private fun setupSearch() {
        searchInputBinding?.dispose()
        searchQueryController?.dispose()

        val queryController = ChannelSearchQueryController(
            delayMillis = SEARCH_DELAY,
            postDelayed = { task, delay -> inlineControlsHandler.postDelayed(task, delay) },
            removeCallbacks = { task -> inlineControlsHandler.removeCallbacks(task) },
            onQueryChanged = catalogFilterController::setQuery,
            onApply = {
                // The callback may race with fragment navigation, but it must never touch a dead view.
                if (isViewReady()) applyFiltersAndUpdate()
            }
        )
        searchQueryController = queryController
        searchInputBinding = ChannelSearchInputBinding(searchInput, queryController) { hasFocus ->
            // El selector de la superficie completa refleja el foco del campo, tanto en TV como en móvil.
            (searchInput.parent as? View)?.isSelected = hasFocus
        }

        if (!isTV) {
            btnSearch.setOnClickListener {
                searchInput.requestFocus()
                val imm = requireContext().getSystemService(android.content.Context.INPUT_METHOD_SERVICE) as android.view.inputmethod.InputMethodManager
                imm.showSoftInput(searchInput, android.view.inputmethod.InputMethodManager.SHOW_IMPLICIT)
            }
        }
    }

    /** Opens/closes the search field from the shared header (mobile and Android TV). */
    fun toggleSearchFromHeader() {
        if (!isAdded || isHidden || !hasActiveView()) return

        val opening = !isSearchVisible
        setSearchVisible(opening, applyFiltersOnClose = true)
        if (opening) {
            searchInput.requestFocus()
        } else {
            activity?.findViewById<View>(R.id.header_search_button)?.requestFocus()
        }
    }

    private fun syncHeaderSearchButton(open: Boolean) {
        val button = activity?.findViewById<ImageButton>(R.id.header_search_button) ?: return
        button.setImageResource(if (open) R.drawable.ic_close else R.drawable.ic_search)
        button.contentDescription = getString(
            if (open) R.string.close_channel_search else R.string.open_channel_search
        )
        button.nextFocusDownId = if (open) R.id.search_input else R.id.inline_player_container
    }

    private fun toggleSearch(applyFiltersOnClose: Boolean = true) {
        setSearchVisible(!isSearchVisible, applyFiltersOnClose)
    }

    /** Keeps the field, its container, keyboard, header icon and query cleanup in one transition. */
    private fun setSearchVisible(visible: Boolean, applyFiltersOnClose: Boolean = true) {
        val wasVisible = isSearchVisible
        isSearchVisible = visible
        channelsSearchContainer.visibility = if (visible) View.VISIBLE else View.GONE
        searchInput.visibility = if (visible) View.VISIBLE else View.GONE
        syncHeaderSearchButton(visible)

        if (visible) {
            if (!isTV) {
                searchInput.requestFocus()
                val imm = requireContext().getSystemService(android.content.Context.INPUT_METHOD_SERVICE) as android.view.inputmethod.InputMethodManager
                imm.showSoftInput(searchInput, android.view.inputmethod.InputMethodManager.SHOW_IMPLICIT)
            }
            return
        }

        searchInput.clearFocus()
        if (!isTV) {
            val imm = requireContext().getSystemService(android.content.Context.INPUT_METHOD_SERVICE) as android.view.inputmethod.InputMethodManager
            imm.hideSoftInputFromWindow(searchInput.windowToken, 0)
        }
        if (wasVisible) clearSearchQuery(applyImmediately = applyFiltersOnClose)
    }

    private fun clearSearchQuery(applyImmediately: Boolean) {
        val binding = searchInputBinding
        if (binding != null) {
            binding.clear(applyImmediately)
        } else {
            searchInput.setText("")
            val controller = searchQueryController
            if (controller != null) {
                controller.clear(applyImmediately)
            } else if (applyImmediately) {
                applyFiltersAndUpdate()
            }
        }
    }

    private fun applyFiltersAndUpdate(onListCommitted: (() -> Unit)? = null) {
        val expectedGeneration = viewGenerationToken ?: return
        if (!hasActiveView(expectedGeneration) || channelsAdapterRef == null) return
        val guardedCommit: (() -> Unit)? = onListCommitted?.let { action ->
            { if (hasActiveView(expectedGeneration)) action() }
        }
        searchQueryController?.cancelPending()
        val currentQuery = searchInput.text?.toString().orEmpty()
        if (searchQueryController != null) {
            searchQueryController?.syncQuery(currentQuery)
        } else {
            catalogFilterController.setQuery(currentQuery)
        }
        if (originalChannels.isEmpty()) {
            filteredChannels = emptyList()
            channelsAdapter.submitList(emptyList(), guardedCommit)
            return
        }

        filteredChannels = catalogFilterController.filter()

        channelsAdapter.submitList(filteredChannels, guardedCommit)
        if (isTV) {
            channelsSectionSubtitle.text = if (filteredChannels.isEmpty()) {
                getString(R.string.tv_channels_subtitle_empty)
            } else {
                getString(R.string.tv_channels_subtitle_count, filteredChannels.size)
            }
        }

        if (filteredChannels.isEmpty()) {
            showState("No se encontraron canales", isError = false, showRetry = false)
        } else {
            hideState()
        }
    }

    // La política agrupa group-title del proveedor; el renderizador solo dibuja y enlaza el foco.
    private fun renderCategoryRail() {
        if (!hasActiveView()) return
        categoryRailRenderer?.render(
            categories = catalogFilterController.categoryOptions(ChannelCategoryLabels.names, ChannelCategoryLabels::displayName),
            selectedCategory = currentCategory,
            selectedCountry = currentCountry,
            countryLabel = ChannelFilterPolicy::countryLabel
        )
    }

    private fun showCountryPicker() {
        if (!hasActiveView()) return
        countryFilterDialogController?.show(currentCountry) { selectedCountry ->
            if (!hasActiveView()) return@show
            currentCountry = selectedCountry
            categoryRailRenderer?.updateCountry(currentCountry, ChannelFilterPolicy::countryLabel)
            applyFiltersAndUpdate {
                if (isTV) focusSelectedCategory()
            }
        }
    }

    private fun selectCategory(categoryKey: String) {
        if (!hasActiveView() || currentCategory == categoryKey) return
        val focusedChannelKey = currentFocusedChannelKey()

        currentCategory = categoryKey

        // El renderizador actualiza selección visual y navegación del D-pad en un solo lugar.
        categoryRailRenderer?.selectCategory(categoryKey, currentCountry)

        if (isSearchVisible) {
            toggleSearch(applyFiltersOnClose = false)
        }

        applyFiltersAndUpdate {
            // Esperar al commit del AsyncListDiffer evita solicitar foco sobre un ViewHolder viejo.
            val key = focusedChannelKey
            if (isTV && key != null && channelsAdapter.getPositionForKey(key) >= 0) {
                restoreTvFocusForChannel(key, scrollIfNeeded = true)
            } else if (isTV) {
                focusSelectedCategory()
            }
        }
        // No desplazar la lista al principio al cambiar de categoría o seleccionar una vista previa.
    }

    private fun setupRecyclerView() {
        channelsRecycler.layoutManager = GridLayoutManager(requireContext(), calculateSpanCount())

        channelsAdapterRef = ChannelsAdapter(
            onItemClick = { channel, position -> openPlayer(channel, position) },
            channelNumber = { channel -> originalChannels.indexOfFirst { ChannelIdentity.same(it, channel) } + 1 }
        )

        channelsRecycler.adapter = channelsAdapter
        val expectedViewGeneration = checkNotNull(viewGenerationToken)
        catalogFocusController = ChannelCatalogFocusController(
            channelsRecycler = channelsRecycler,
            categoriesContainer = categoriesContainer,
            adapterProvider = { channelsAdapter },
            filteredChannelsProvider = { filteredChannels },
            selectedChannelProvider = { inlineChannel },
            selectedCategoryProvider = { currentCategory },
            isTv = { isTV },
            isActive = {
                isAdded && !isHidden && hasActiveView(expectedViewGeneration) &&
                    channelsAdapterRef != null
            },
            emptyListFallbackProvider = { if (retryButton.isShown) retryButton else searchInput }
        )

        if (isTV) {
            channelsRecycler.isFocusable = true
            channelsRecycler.isFocusableInTouchMode = true
            // El foco inicial va al reproductor; desde allí se entra a la lista con →.
            inlinePlayerContainer.nextFocusRightId = R.id.channels_recycler
            channelsRecycler.nextFocusLeftId = R.id.inline_player_container
        }
    }

    /**
     * Devuelve el foco a un elemento real de la lista en Android TV.
     * El retraso doble permite que RecyclerView procese el scroll y adjunte el ViewHolder,
     * evitando que el mando quede enfocado en el contenedor sin un indicador visible.
     */
    fun requestTvFocus() {
        val expectedGeneration = viewGenerationToken ?: return
        if (!isTV || !hasActiveView(expectedGeneration) || channelsAdapterRef == null) return
        viewPostCallbackRegistry?.post(inlinePlayerContainer) {
            if (!isAdded || !hasActiveView(expectedGeneration) || !inlinePlayerContainer.isShown) return@post
            if (retryButton.isShown && channelsAdapter.itemCount == 0) retryButton.requestFocus()
            else inlinePlayerContainer.requestFocus()
        }
    }

    /** Columnas según el ancho disponible: TV por rangos fijos; móvil/tablet una cada ~320dp. */
    private fun calculateSpanCount(): Int {
        if (isTV) return 1
        val dpWidth = resources.configuration.screenWidthDp
        return (dpWidth / 320).coerceAtLeast(1)
    }

    // MainActivity maneja la rotación sin recrearse: recalculamos la lista y ampliamos el reproductor.
    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        if (hasActiveView()) {
            (channelsRecycler.layoutManager as? GridLayoutManager)?.spanCount = calculateSpanCount()
        }
        maybeOpenFullscreenAfterRotation(newConfig)
    }

    /** Al crear las vistas: muestra la carga en curso o el último resultado que tenga la activity. */
    private fun renderInitialState() {
        val main = activity as? MainActivity
        val result = main?.getLoadResult()
        if (main == null || main.isLoadingChannels() || result == null) {
            showLoading(true)
        } else {
            applyResult(result)
        }
    }

    private fun setupStates() {
        catalogStateRenderer = ChannelCatalogStateRenderer(
            context = requireContext(),
            progressBar = progressBar,
            swipeRefresh = swipeRefresh,
            stateContainer = stateContainer,
            retryButton = retryButton,
            errorText = errorText,
            isTv = { isTV },
            reloadChannels = { (activity as? MainActivity)?.reloadChannels() }
        ).also { it.bind() }
    }

    private fun applyResult(result: LoadResult) {
        if (!isViewReady()) return
        searchQueryController?.cancelPending()
        countryFilterDialogController?.dismiss()
        originalChannels = result.channels
        catalogFilterController.replaceCatalog(originalChannels, resetSelection = true)
        catalogStateRenderer?.finishLoading()

        if (originalChannels.isEmpty()) {
            filteredChannels = emptyList()
            channelsAdapter.submitList(emptyList())
            categoryRailRenderer?.clear()
            ChannelCatalogEmptyStatePolicy.forResult(result)?.let { emptyState ->
                showState(
                    message = emptyState.message,
                    isError = emptyState.isError,
                    showRetry = emptyState.showRetry
                )
            }
        } else {
            renderCategoryRail()
            applyFiltersAndUpdate()
        }
    }

    private fun showState(message: String, isError: Boolean, showRetry: Boolean) {
        catalogStateRenderer?.showState(message, isError, showRetry)
    }

    private fun hideState() {
        catalogStateRenderer?.hideState()
    }

    private fun showLoading(show: Boolean) {
        catalogStateRenderer?.showLoading(show)
    }

    /** True si las vistas ya existen (entre onViewCreated y onDestroyView). */
    private fun isViewReady() = hasActiveView() && channelsAdapterRef != null

    /** La activity avisa que empezó (o se repitió) la carga de la lista. */
    fun onLoadStarted() {
        if (!isViewReady()) return
        countryFilterDialogController?.dismiss()
        catalogStateRenderer?.beginLoading()
    }

    /**
     * La activity llama a esto cuando termina de cargar. Si el fragmento todavía no creó sus vistas
     * no hay nada que actualizar: [renderInitialState] leerá el resultado desde la activity al crearlas.
     */
    fun showResult(result: LoadResult) {
        if (!isViewReady()) return
        applyResult(result)
    }

    // En TV, al volver del reproductor el foco regresa al canal que se estaba mirando.
    override fun onResume() {
        super.onResume()
        isLaunchingFullscreen = false

        // Do not consume a returned session until this Fragment has a usable view. This avoids
        // losing the transferred engine during transient navigation/lifecycle changes.
        val returnedSession = if (!isHidden && isViewReady()) {
            InlinePlayerHandoff.takeReturnedToInline()
        } else null

        if (returnedSession != null) {
            restoreInlineSession(returnedSession)
            val key = ChannelIdentity.key(returnedSession.channel)
            if (channelsAdapter.getPositionForKey(key) >= 0) {
                restoreTvFocusForChannel(key, scrollIfNeeded = true)
            } else {
                focusSelectedCategory()
            }
        } else {
            if (isTV && !isHidden && isViewReady()) restoreTvFocus()
            val activeChannel = inlineChannel
            if (!isHidden && hasActiveView() && activeChannel != null &&
                inlinePlayerContainer.visibility == View.VISIBLE) {
                inlineWebViewController?.onResume()
                val player = inlineExoPlayer
                if (player != null) {
                    inlinePlaybackResumeIntent.consume()?.let { shouldResume ->
                        player.playWhenReady = shouldResume
                    }
                } else if (inlineWebView.visibility != View.VISIBLE) {
                    // Fallback for WebView sources or if the native handoff was unavailable.
                    startInlinePlayback(activeChannel, inlineSourceIndex)
                }
            }
        }
        if (!isHidden && isViewReady()) {
            inlineExoPlayer?.let { player ->
                if (player.playbackState != Player.STATE_READY) scheduleInlineStartupTimeout(player, inlineGeneration)
            }
        }
        refreshInlineCastAvailability()
    }

    override fun handleBack(): Boolean {
        if (!isTV || !isSearchVisible || !hasActiveView()) return false
        toggleSearch()
        activity?.findViewById<View>(R.id.header_search_button)?.requestFocus()
        return true
    }

    private fun pauseInlinePlaybackForLifecycle() {
        inlineExoPlayer?.let { player ->
            // onPause and onHiddenChanged may both fire; keep the original user intent.
            inlinePlaybackResumeIntent.capture(player.playWhenReady)
            player.pause()
        }
    }

    override fun onPause() {
        super.onPause()
        cancelInlineStartupTimeout()
        stopInlineCastDiscovery()
        pauseInlinePlaybackForLifecycle()
        if (inlineWebViewController != null) inlineWebViewController?.onPause()
    }

    override fun onHiddenChanged(hidden: Boolean) {
        super.onHiddenChanged(hidden)
        if (hidden) {
            cancelInlineStartupTimeout()
            stopInlineCastDiscovery()
            pauseInlinePlaybackForLifecycle()
            if (inlineWebViewController != null) inlineWebViewController?.onPause()
        } else {
            // onHiddenChanged puede llegar antes de que esta instancia haya creado su vista.
            if (hasActiveView()) inlineWebViewController?.onResume()
            if (hasActiveView()) {
                inlineExoPlayer?.let { player ->
                    inlinePlaybackResumeIntent.consume()?.let { shouldResume ->
                        player.playWhenReady = shouldResume
                    }
                    if (player.playbackState != Player.STATE_READY) {
                        scheduleInlineStartupTimeout(player, inlineGeneration)
                    }
                }
            }
            refreshInlineCastAvailability()
        }
    }

    private fun restoreTvFocus() {
        catalogFocusController?.restoreLastFocus()
    }

    private fun isSameActivePreview(channel: Channel): Boolean {
        if (!hasActiveView()) return false
        val current = inlineChannel ?: return false
        if (!ChannelIdentity.same(current, channel)) return false
        if (inlinePlayerContainer.visibility != View.VISIBLE || inlineCurrentStreamUrl.isBlank()) return false
        if (inlinePlayerVisualController?.isErrorVisible == true) return false
        if (inlineExoPlayer?.playbackState == Player.STATE_ENDED) return false
        return inlineExoPlayer != null || inlinePlayerVisualController?.isWebVisible == true ||
            inlinePlayerVisualController?.isLoading == true
    }

    private fun openPlayer(channel: Channel, position: Int) {
        if (!hasActiveView()) return
        if (isTV && isSameActivePreview(channel)) {
            // Volver a confirmar explícitamente la fila que ya se está previsualizando abre
            // fullscreen transfiriendo la sesión activa; no reinicia el stream ni el buffer.
            launchPlayerActivity(channel, fromInline = true)
            return
        }
        if (channel.streamUrl.isNullOrEmpty() && channel.options.isNullOrEmpty()) {
            Toast.makeText(requireContext(), "Este canal no tiene fuentes disponibles", Toast.LENGTH_SHORT).show()
            return
        }

        if (isTV) {
            showInlinePlayer(channel)
        } else if (resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE) {
            // Si el móvil ya está en horizontal, abre la pantalla dedicada directamente.
            showInlinePlayer(channel, startPlayback = false)
            launchPlayerActivity(channel, fromInline = true)
        } else {
            // En vertical el canal queda integrado encima de la lista, sin abandonar la pantalla.
            showInlinePlayer(channel)
        }
    }

    override fun onDestroyView() {
        // Capture ownership while the old holder is still available; then reject any late UI work.
        val webViewTransferredOut = viewRefs != null && transferredInlineWebView === inlineWebView
        // Fragment.getView() may still return the old tree while onDestroyView is executing.
        viewLifecycleGate.invalidate()
        viewPostCallbackRegistry?.dispose()
        viewPostCallbackRegistry = null
        viewGenerationToken = null
        inlineSourceDialog?.setOnDismissListener(null)
        inlineSourceDialog?.dismiss()
        inlineSourceDialog = null
        stopInlineCastDiscovery()
        inlineCastController?.dispose()
        inlineCastController = null
        searchInputBinding?.dispose()
        searchInputBinding = null
        searchQueryController?.dispose()
        searchQueryController = null
        inlineControlsController?.dispose()
        inlineControlsController = null
        stopInlineTimelineUpdates()
        inlineTimelineController = null

        // Remove listeners before destroying a WebView; Android forbids further calls on a
        // WebView after destroy(). It also prevents queued view events from retaining this Fragment.
        if (viewRefs != null) {
            inlinePlayerLayoutChangeListener?.let { listener ->
                inlinePlayerContainer.removeOnLayoutChangeListener(listener)
            }
            inlinePlayerLayoutChangeListener = null
            inlinePlayerContainer.setOnClickListener(null)
            inlinePlayerContainer.setOnKeyListener(null)
            inlinePlayerContainer.setOnFocusChangeListener(null)
            inlinePlayerView.setOnClickListener(null)
            inlineWebView.setOnTouchListener(null)
            inlineSeekBar.setOnSeekBarChangeListener(null)
            inlineBtnPlayPause.setOnClickListener(null)
            inlineBtnCast.setOnClickListener(null)
            inlineBtnSources.setOnClickListener(null)
            inlineBtnReload.setOnClickListener(null)
            inlineBtnFullscreen.setOnClickListener(null)
            inlineBtnClose.setOnClickListener(null)
            btnSearch.setOnClickListener(null)
            categoriesContainer.removeAllViews()
            channelsRecycler.stopScroll()
            channelsRecycler.adapter = null
        }

        // Release UI controllers before media teardown so teardown cannot render into a dying view.
        inlinePlayerVisualController?.dispose()
        inlinePlayerVisualController = null
        catalogStateRenderer?.dispose()
        catalogStateRenderer = null
        countryFilterDialogController?.dispose()
        countryFilterDialogController = null
        categoryRailRenderer = null
        tvPlayerPreviewRenderer = null
        catalogFocusController?.dispose()
        catalogFocusController = null

        inlineSession.advanceGeneration()
        // Do not blank or otherwise mutate a page that UnifiedPlayerActivity currently owns.
        releaseInlineEngine(clearWebView = !webViewTransferredOut)
        inlineWebViewController?.dispose(destroyWebView = !webViewTransferredOut)
        inlineWebViewController = null
        transferredInlineWebView = null
        channelsAdapterRef = null
        viewRefs = null
        super.onDestroyView()
    }
}