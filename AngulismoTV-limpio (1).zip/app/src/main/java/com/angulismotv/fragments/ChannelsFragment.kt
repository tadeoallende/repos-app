package com.angulismotv.fragments

import android.content.Intent
import android.content.res.Configuration
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.Editable
import android.text.TextWatcher
import android.view.LayoutInflater
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.view.MotionEvent
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.view.animation.AnimationUtils
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.SeekBar
import android.widget.TextView
import androidx.core.content.ContextCompat
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AlertDialog
import androidx.core.view.isVisible
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.angulismotv.MainActivity
import com.angulismotv.BackHandler
import com.angulismotv.R
import com.angulismotv.UnifiedPlayerActivity
import com.angulismotv.data.LoadResult
import com.angulismotv.data.ChannelCatalog
import android.widget.Toast
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout
import com.angulismotv.adapters.ChannelsAdapter
import com.angulismotv.models.Channel
import com.angulismotv.models.ChannelIdentity
import com.angulismotv.models.StreamType
import com.angulismotv.player.CastController
import com.angulismotv.player.CastStream
import com.angulismotv.player.InlinePlayerHandoff
import com.angulismotv.player.PlayerChannelCatalog
import com.angulismotv.player.PlayerTimelineController
import com.angulismotv.player.StreamUtils
import com.angulismotv.player.WebViewNavigationPolicy
import com.angulismotv.player.StreamMediaSourceFactory
import com.angulismotv.player.StreamUrlPolicy
import com.angulismotv.player.applyPlayerSettings
import com.google.android.exoplayer2.ExoPlayer
import com.google.android.exoplayer2.PlaybackException
import com.google.android.exoplayer2.Player
import com.google.android.exoplayer2.ui.PlayerView
import com.angulismotv.utils.DeviceHelper
import com.angulismotv.utils.loadChannelLogo
import java.util.Locale

class ChannelsFragment : Fragment(), BackHandler {

    // Views
    private lateinit var channelsRecycler: RecyclerView
    private lateinit var progressBar: ProgressBar
    private lateinit var swipeRefresh: SwipeRefreshLayout
    private lateinit var stateContainer: LinearLayout
    private lateinit var retryButton: TextView
    private lateinit var errorText: TextView
    private lateinit var categoriesContainer: LinearLayout
    private lateinit var categoriesScroll: HorizontalScrollView
    private lateinit var searchInput: EditText
    private lateinit var btnSearch: ImageView
    private lateinit var channelsSectionHeader: View
    private lateinit var channelsSearchContainer: View
    private lateinit var channelsSectionSubtitle: TextView

    // Guía contextual exclusiva de la composición Android TV.
    private var tvPlayerEmptyState: View? = null
    private var tvCurrentChannelInfo: View? = null
    private var tvCurrentChannelLogo: ImageView? = null
    private var tvCurrentChannelName: TextView? = null
    private var tvCurrentChannelCategory: TextView? = null
    private var tvPlayerGuide: TextView? = null
    private var tvPlayerKeysHint: TextView? = null
    private var tvPlayerFooterHint: TextView? = null
    private var tvListGuide: TextView? = null
    private var selectedCategoryFocusViewId: Int = View.NO_ID

    // Reproductor integrado móvil
    private lateinit var inlinePlayerContainer: FrameLayout
    private lateinit var inlinePlayerView: PlayerView
    private lateinit var inlineWebView: WebView
    private lateinit var inlineProgressBar: ProgressBar
    private lateinit var inlineErrorText: TextView
    private lateinit var inlineControlsBar: LinearLayout
    private lateinit var inlineTimelineContainer: View
    private lateinit var inlineSeekBar: SeekBar
    private lateinit var inlineTimeCurrent: TextView
    private lateinit var inlineTimeDuration: TextView
    private lateinit var inlineChannelLogo: ImageView
    private lateinit var inlineChannelName: TextView
    private lateinit var inlineBtnPlayPause: ImageButton
    private lateinit var inlineBtnSources: ImageButton
    private lateinit var inlineBtnReload: ImageButton
    private lateinit var inlineBtnCast: ImageButton
    private lateinit var inlineBtnFullscreen: ImageButton
    private lateinit var inlineBtnClose: ImageButton
    private var inlineExoPlayer: ExoPlayer? = null
    private var inlinePlayerListener: Player.Listener? = null
    private var inlineChannel: Channel? = null
    private var inlineSourceIndex = 0
    private var inlineCurrentStreamUrl = ""
    private var inlineCurrentStreamType = StreamType.AUTO
    private var inlineCastController: CastController? = null
    private var inlineCastDiscoveryStarted = false
    private var inlineGeneration = 0
    private var inlineControlsVisible = false
    private var isLaunchingFullscreen = false
    private val inlineControlsHandler = Handler(Looper.getMainLooper())
    private var hideInlineControlsRunnable: Runnable? = null
    private lateinit var inlineTimelineController: PlayerTimelineController

    // Adapter y datos
    private lateinit var channelsAdapter: ChannelsAdapter
    private var originalChannels = listOf<Channel>()
    private var filteredChannels = listOf<Channel>()
    private var currentCategory = "todos"
    private var currentCountry = "todos"
    private var countryFilterButton: TextView? = null
    private var countryFilterButtonId: Int = View.NO_ID
    private var isSearchVisible = false

    // ✅ Lista dinámica de categorías (se genera desde los datos)
    private var categories = mutableListOf<Pair<String, String>>()

    // Mapeo de nombres de categoría para mostrar en español
    private val categoryNames = mapOf(
        "todos" to "Todos",
        "deportes" to "Deportes",
        "noticias" to "Noticias",
        "peliculas" to "Películas",
        "series" to "Series",
        "infantiles" to "Infantiles",
        "educativos" to "Educativos",
        "internacionales" to "Internacionales",
        "estilo-vida" to "Estilo de vida",
        "musicales" to "Musicales",
        "documentales" to "Documentales",
        "entretenimiento" to "Entretenimiento",
        "otros" to "Otros",
        "eventos" to "Eventos"
    )

    // Optimizaciones
    private val searchHandler = Handler(Looper.getMainLooper())
    private var searchRunnable: Runnable? = null
    private val SEARCH_DELAY = 300L

    private var isTV = false

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        // Android TV necesita una composición horizontal propia: vista previa a la izquierda,
        // catálogo a la derecha. El layout móvil permanece independiente y compacto.
        val layoutRes = if (DeviceHelper.isTV(requireContext())) {
            R.layout.fragment_channels_tv
        } else {
            R.layout.fragment_channels
        }
        return inflater.inflate(layoutRes, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        isTV = DeviceHelper.isTV(requireContext())

        initViews(view)
        inlineTimelineController = PlayerTimelineController(
            handler = inlineControlsHandler,
            container = inlineTimelineContainer,
            seekBar = inlineSeekBar,
            currentTime = inlineTimeCurrent,
            durationTime = inlineTimeDuration,
            playerProvider = { inlineExoPlayer },
            isTimelineEnabled = { inlineControlsVisible },
            shouldContinueUpdates = {
                inlineExoPlayer != null && inlineChannel != null && inlinePlayerContainer.visibility == View.VISIBLE
            },
            // El inline conservaba el comportamiento de permitir seek si hay duración positiva.
            canSeekOnStopTracking = { player -> player.duration > 0L }
        )
        applyDeviceSpecificLayout(view)
        setupInlinePlayer()
        setupSearch()
        setupRecyclerView()
        setupStates()
        renderInitialState()

        if (isTV) {
            view.post {
                if (!isAdded || !inlinePlayerContainer.isShown) return@post
                if (retryButton.isShown) retryButton.requestFocus()
                else inlinePlayerContainer.requestFocus()
            }
        }
    }

    private fun initViews(view: View) {
        channelsRecycler = view.findViewById(R.id.channels_recycler)
        progressBar = view.findViewById(R.id.progress_bar)
        errorText = view.findViewById(R.id.error_text)
        swipeRefresh = view.findViewById(R.id.swipe_refresh)
        stateContainer = view.findViewById(R.id.state_container)
        retryButton = view.findViewById(R.id.retry_button)
        categoriesContainer = view.findViewById(R.id.categories_container)
        categoriesScroll = view.findViewById(R.id.categories_scroll)
        searchInput = view.findViewById(R.id.search_input)
        btnSearch = view.findViewById(R.id.btn_search)
        channelsSectionHeader = view.findViewById(R.id.channels_section_header)
        channelsSearchContainer = view.findViewById(R.id.channels_search_container)
        channelsSectionSubtitle = view.findViewById(R.id.channels_section_subtitle)
        tvPlayerEmptyState = view.findViewById(R.id.tv_player_empty_state)
        tvCurrentChannelInfo = view.findViewById(R.id.tv_current_channel_info)
        tvCurrentChannelLogo = view.findViewById(R.id.tv_current_channel_logo)
        tvCurrentChannelName = view.findViewById(R.id.tv_current_channel_name)
        tvCurrentChannelCategory = view.findViewById(R.id.tv_current_channel_category)
        tvPlayerGuide = view.findViewById(R.id.tv_player_guide)
        tvPlayerKeysHint = view.findViewById(R.id.tv_player_keys_hint)
        tvPlayerFooterHint = view.findViewById(R.id.tv_player_footer_hint)
        tvListGuide = view.findViewById(R.id.tv_list_guide)
        inlinePlayerContainer = view.findViewById(R.id.inline_player_container)
        inlinePlayerContainer.addOnLayoutChangeListener { v, left, top, right, bottom, oldLeft, oldTop, oldRight, oldBottom ->
            val width = right - left
            if (width > 0) {
                val targetHeight = (width * 9f / 16f).toInt()
                if (v.layoutParams.height != targetHeight) {
                    v.layoutParams = v.layoutParams.apply { height = targetHeight }
                }
            }
        }
        inlinePlayerView = view.findViewById(R.id.inline_player_view)
        inlineWebView = view.findViewById(R.id.inline_web_view)
        inlineProgressBar = view.findViewById(R.id.inline_progress_bar)
        inlineErrorText = view.findViewById(R.id.inline_error_text)
        inlineControlsBar = view.findViewById(R.id.inline_controls_bar)
        inlineTimelineContainer = view.findViewById(R.id.inline_timeline_container)
        inlineSeekBar = view.findViewById(R.id.inline_seek_bar)
        inlineTimeCurrent = view.findViewById(R.id.inline_time_current)
        inlineTimeDuration = view.findViewById(R.id.inline_time_duration)
        inlineChannelLogo = view.findViewById(R.id.inline_channel_logo)
        inlineChannelName = view.findViewById(R.id.inline_channel_name)
        inlineBtnPlayPause = view.findViewById(R.id.inline_btn_play_pause)
        inlineBtnSources = view.findViewById(R.id.inline_btn_sources)
        inlineBtnReload = view.findViewById(R.id.inline_btn_reload)
        inlineBtnCast = view.findViewById(R.id.inline_btn_cast)
        inlineBtnFullscreen = view.findViewById(R.id.inline_btn_fullscreen)
        inlineBtnClose = view.findViewById(R.id.inline_btn_close)
    }

    /**
     * Mobile follows a compact, connected TV-guide layout. Android TV explicitly restores
     * its larger paddings and chip sizes so these changes never reduce 10-foot readability.
     */
    private fun applyDeviceSpecificLayout(root: View) {
        val density = resources.displayMetrics.density
        fun dp(value: Int) = (value * density + 0.5f).toInt()

        val listContainer = root.findViewById<FrameLayout>(R.id.channels_list_container)
        val searchRow = channelsSearchContainer as? ViewGroup
        val searchField = searchRow?.getChildAt(0) as? ViewGroup
        val searchParams = searchField?.layoutParams
        val listContainerPadding = if (isTV) 0 else dp(8)

        if (isTV) {
            // Layout dedicado 10-foot: el espacio se invierte en el vídeo y en más filas visibles,
            // no en márgenes interiores redundantes.
            channelsSectionHeader.visibility = View.VISIBLE
            channelsSearchContainer.visibility = View.GONE
            isSearchVisible = false
            // El icono dentro del campo se conserva como decoración; la cabecera abre/cierra la búsqueda.
            btnSearch.isFocusable = false
            btnSearch.isClickable = false
            btnSearch.setOnClickListener(null)
            channelsSearchContainer.setPadding(dp(4), dp(4), dp(4), dp(4))
            if (searchParams != null) {
                searchParams.height = dp(46)
                searchField?.layoutParams = searchParams
            }
            searchField?.setPadding(dp(12), 0, dp(12), 0)
            searchInput.textSize = 15f
            (searchInput.layoutParams as? ViewGroup.MarginLayoutParams)?.let { params ->
                params.marginStart = dp(8)
                searchInput.layoutParams = params
            }
            categoriesScroll.setPadding(dp(4), dp(4), dp(4), dp(4))
            listContainer?.setPadding(listContainerPadding, 0, 0, 0)
            channelsRecycler.setPadding(dp(2), dp(4), dp(2), dp(6))
            categoriesScroll.isFillViewport = false
        } else {
            // The branded app header already identifies the section; avoid a redundant title block.
            channelsSectionHeader.visibility = View.GONE
            channelsSectionHeader.layoutParams = channelsSectionHeader.layoutParams.apply { height = 0 }
            channelsSearchContainer.visibility = View.GONE
            channelsSearchContainer.setPadding(dp(8), dp(3), dp(8), dp(2))
            if (searchParams != null) {
                searchParams.height = dp(38)
                searchField?.layoutParams = searchParams
            }
            searchField?.setPadding(dp(12), 0, dp(12), 0)
            searchInput.textSize = 14f
            (searchInput.layoutParams as? ViewGroup.MarginLayoutParams)?.let { params ->
                params.marginStart = dp(8)
                searchInput.layoutParams = params
            }
            categoriesScroll.setPadding(dp(8), dp(2), dp(8), dp(2))
            listContainer?.setPadding(0, 0, 0, 0)
            channelsRecycler.setPadding(dp(4), dp(1), dp(4), dp(8))
            channelsRecycler.clipToPadding = false

            val playerParams = inlinePlayerContainer.layoutParams as? ViewGroup.MarginLayoutParams
            playerParams?.setMargins(dp(2), dp(2), dp(2), 0)
            if (playerParams != null) inlinePlayerContainer.layoutParams = playerParams
            inlinePlayerContainer.elevation = 0f
            inlineControlsBar.apply {
                minimumHeight = dp(44)
                setPadding(dp(6), dp(2), dp(6), dp(2))
            }
            inlineChannelLogo.layoutParams = inlineChannelLogo.layoutParams.apply {
                width = dp(28)
                height = dp(28)
            }
            inlineChannelName.apply {
                textSize = 12f
                (layoutParams as? ViewGroup.MarginLayoutParams)?.let { params ->
                    params.marginStart = dp(6)
                    layoutParams = params
                }
            }
            (inlineTimelineContainer.layoutParams as? FrameLayout.LayoutParams)?.let { params ->
                params.height = dp(24)
                params.leftMargin = dp(8)
                params.rightMargin = dp(8)
                params.bottomMargin = dp(46)
                inlineTimelineContainer.layoutParams = params
            }
            inlineTimeCurrent.layoutParams = inlineTimeCurrent.layoutParams.apply { width = dp(32) }
            inlineTimeDuration.layoutParams = inlineTimeDuration.layoutParams.apply { width = dp(32) }
            inlineTimeCurrent.textSize = 9f
            inlineTimeDuration.textSize = 9f
            inlineSeekBar.layoutParams = inlineSeekBar.layoutParams.apply { height = dp(20) }
            listContainer?.clipToPadding = false
        }
    }

    private fun setupInlinePlayer() {
        if (isTV) {
            // En TV el reproductor es un objetivo real del D-pad, incluso antes de elegir canal.
            inlinePlayerContainer.visibility = View.VISIBLE
            inlinePlayerContainer.isFocusable = true
            inlinePlayerContainer.isFocusableInTouchMode = true
            inlinePlayerContainer.isClickable = true
            inlinePlayerView.isFocusable = false
            inlinePlayerView.isFocusableInTouchMode = false
            inlinePlayerView.isClickable = false
            inlineWebView.isFocusable = false
            inlineWebView.isFocusableInTouchMode = false
            inlineWebView.isClickable = false
            inlineBtnCast.visibility = View.GONE
            inlineControlsBar.visibility = View.GONE
            inlineTimelineContainer.visibility = View.GONE
            tvPlayerEmptyState?.visibility = View.VISIBLE
            tvCurrentChannelInfo?.visibility = View.GONE
            tvPlayerGuide?.setText(R.string.tv_player_idle_guide)
            tvPlayerKeysHint?.setText(R.string.tv_player_keys_hint)
            tvPlayerFooterHint?.setText(R.string.tv_player_footer_hint)

            inlinePlayerContainer.nextFocusLeftId = R.id.menu_channels
            inlinePlayerContainer.nextFocusRightId = R.id.channels_recycler
            inlinePlayerContainer.nextFocusUpId = R.id.header_search_button
            inlinePlayerContainer.setOnClickListener { activateTvPlayer() }
            inlinePlayerContainer.setOnKeyListener { v, keyCode, event ->
                if (event.action != KeyEvent.ACTION_DOWN || event.repeatCount > 0) return@setOnKeyListener false
                when (keyCode) {
                    KeyEvent.KEYCODE_DPAD_CENTER,
                    KeyEvent.KEYCODE_ENTER,
                    KeyEvent.KEYCODE_NUMPAD_ENTER -> {
                        v.performClick()
                        true
                    }
                    KeyEvent.KEYCODE_DPAD_RIGHT -> {
                        focusChannelList()
                        true
                    }
                    KeyEvent.KEYCODE_DPAD_LEFT -> {
                        requireActivity().findViewById<View>(R.id.menu_channels)?.requestFocus() == true
                    }
                    else -> false
                }
            }
            inlinePlayerContainer.setOnFocusChangeListener { _, hasFocus ->
                // La ayuda depende del destino real del foco: no anunciar OK a pantalla completa
                // mientras el mando está navegando por las filas de canales.
                val guideRes = when {
                    hasFocus && inlineChannel != null -> R.string.tv_player_active_guide
                    hasFocus -> R.string.tv_player_idle_guide
                    inlineChannel != null -> R.string.tv_player_preview_ready_guide
                    else -> R.string.tv_player_idle_guide
                }
                tvPlayerGuide?.setText(guideRes)
            }
        } else {
            val hostActivity = activity as? AppCompatActivity
            if (hostActivity != null) {
                inlineCastController = CastController(
                    activity = hostActivity,
                    button = inlineBtnCast,
                    handler = inlineControlsHandler,
                    currentStream = {
                        val channel = inlineChannel
                        val url = inlineCurrentStreamUrl
                        if (channel == null || url.isBlank() || inlineCurrentStreamType == StreamType.IFRAME) null
                        else CastStream(url, inlineCurrentStreamType, channel.name)
                    },
                    onCastStarted = {
                        inlineExoPlayer?.pause()
                        updateInlinePlayPauseIcon()
                    },
                    onStatusChanged = { message ->
                        tvPlayerGuide?.text = message
                    }
                ).also { controller ->
                    controller.setup(isTV = false)
                    inlineBtnCast.visibility = View.GONE
                }
            } else {
                inlineBtnCast.visibility = View.GONE
            }
            inlinePlayerContainer.visibility = View.GONE
            inlinePlayerView.isFocusable = false
            inlinePlayerView.isClickable = true
            inlinePlayerView.setOnClickListener {
                if (inlineControlsVisible) hideInlineControls() else showInlineControlsTemporarily()
            }
            // No consume los toques del reproductor web: sus controles internos siguen funcionando.
            inlineWebView.applyPlayerSettings()
            inlineWebView.setOnTouchListener { _, event ->
                if (event.action == MotionEvent.ACTION_UP) showInlineControlsTemporarily()
                false
            }
        }

        inlineSeekBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onStartTrackingTouch(seekBar: SeekBar?) {
                inlineTimelineController.onStartTracking()
                showInlineControlsTemporarily()
            }

            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                inlineTimelineController.onProgressChanged(progress, fromUser)
            }

            override fun onStopTrackingTouch(seekBar: SeekBar?) {
                inlineTimelineController.onStopTracking()
                showInlineControlsTemporarily()
            }
        })

        inlineBtnPlayPause.setOnClickListener {
            val player = inlineExoPlayer ?: return@setOnClickListener
            if (player.isPlaying) player.pause() else player.play()
            updateInlinePlayPauseIcon()
            showInlineControlsTemporarily()
        }
        inlineBtnSources.setOnClickListener { showInlineSourcePicker() }
        inlineBtnReload.setOnClickListener { reloadInlineTransmission() }
        inlineBtnCast.visibility = View.GONE
        inlineBtnFullscreen.setOnClickListener { launchInlineFullscreen() }
        inlineBtnClose.setOnClickListener { closeInlinePlayer() }
    }

    private fun updateTvPreviewIdentity(channel: Channel) {
        if (!isTV) return
        tvPlayerEmptyState?.visibility = View.GONE
        tvCurrentChannelInfo?.visibility = View.VISIBLE
        tvCurrentChannelLogo?.loadChannelLogo(channel.name, channel.logo)
        tvCurrentChannelName?.text = channel.name
        tvCurrentChannelCategory?.text = channel.category?.takeIf { it.isNotBlank() }?.let(::displayCategoryName)
            ?: getString(R.string.tv_live_category)
        tvPlayerGuide?.setText(R.string.tv_player_active_guide)
        tvPlayerFooterHint?.setText(R.string.tv_player_footer_hint)
    }

    /** Reattaches a native player returned from fullscreen without resetting its media item. */
    private fun restoreInlineSession(session: InlinePlayerHandoff.Session) {
        val channel = session.channel
        inlineChannel = channel
        inlineSourceIndex = session.sourceIndex.coerceAtLeast(0)
        inlineCurrentStreamUrl = session.streamUrl
        inlineCurrentStreamType = session.streamType
        if (isTV && ::channelsAdapter.isInitialized) channelsAdapter.setPreviewChannel(channel)
        inlinePlayerContainer.visibility = View.VISIBLE
        updateTvPreviewIdentity(channel)
        inlineChannelName.text = channel.name
        inlineChannelLogo.loadChannelLogo(channel.name, channel.logo)
        inlineBtnSources.visibility = if ((channel.options?.size ?: 0) > 1) View.VISIBLE else View.GONE
        inlineErrorText.visibility = View.GONE

        val player = session.player
        val returnedWebView = session.webView
        // The fragment was paused while fullscreen owned the player. Resume the embedded
        // WebView lifecycle even for a native session so future iframe selections work normally.
        inlineWebView.onResume()
        if (returnedWebView != null) {
            // Restore the original WebView instance to its exact inline slot, even when the
            // user changed from an iframe source to a native stream while in fullscreen.
            inlineWebView = returnedWebView
            (inlineWebView.parent as? ViewGroup)?.removeView(inlineWebView)
            val params = session.webViewLayoutParams ?: FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT
            )
            val index = session.webViewParentIndex.coerceIn(0, inlinePlayerContainer.childCount)
            inlinePlayerContainer.addView(inlineWebView, index, params)
        }

        if (player != null && session.streamType != StreamType.IFRAME) {
            if (returnedWebView != null) {
                inlineWebView.webViewClient = WebViewClient()
                inlineWebView.webChromeClient = WebChromeClient()
                inlineWebView.stopLoading()
                inlineWebView.loadUrl("about:blank")
                inlineWebView.visibility = View.GONE
            }
            inlineGeneration++
            val generation = inlineGeneration
            inlinePlayerView.visibility = View.VISIBLE
            inlineExoPlayer = player
            inlinePlayerView.player = player
            inlinePlayerView.useController = false
            inlineProgressBar.visibility = if (player.playbackState == Player.STATE_BUFFERING || player.playbackState == Player.STATE_IDLE) View.VISIBLE else View.GONE
            installInlinePlayerListener(player, generation)
            player.playWhenReady = session.wasPlaying
            updateInlinePlayPauseIcon()
            if (player.playbackState == Player.STATE_READY) {
                inlineProgressBar.visibility = View.GONE
                inlineErrorText.visibility = View.GONE
                inlineTimelineController.update()
            }
        } else if (returnedWebView != null && session.streamType == StreamType.IFRAME) {
            inlineGeneration++
            val generation = inlineGeneration
            inlinePlayerView.player = null
            inlinePlayerView.visibility = View.GONE
            inlineWebView.visibility = View.VISIBLE
            inlineProgressBar.visibility = View.GONE
            startInlineWebView(session.streamUrl, generation, loadUrl = false)
        } else {
            // Fallback only when there was no reusable native player or transferred WebView.
            showInlinePlayer(channel, startPlayback = false)
            startInlinePlayback(channel, inlineSourceIndex)
        }
        refreshInlineCastAvailability()
    }

    private fun activateTvPlayer() {
        if (!isTV) return
        if (inlineChannel != null) {
            launchInlineFullscreen()
        } else {
            tvPlayerGuide?.setText(R.string.tv_player_no_channel_selected)
            focusChannelList()
        }
    }

    /** Move to the current channel in the right-hand list, or its first item if none is selected. */
    private fun focusChannelList() {
        if (!isTV || !::channelsRecycler.isInitialized || !::channelsAdapter.isInitialized) return
        val itemCount = channelsAdapter.itemCount
        if (itemCount <= 0) {
            val fallback = if (retryButton.isShown) retryButton else searchInput
            fallback.requestFocus()
            return
        }
        val selectedPosition = inlineChannel?.let { channel ->
            filteredChannels.indexOfFirst { ChannelIdentity.same(it, channel) }
        } ?: -1
        val remembered = channelsAdapter.getLastFocusedPosition()
        val targetPosition = when {
            selectedPosition in 0 until itemCount -> selectedPosition
            remembered in 0 until itemCount -> remembered
            else -> 0
        }
        channelsRecycler.post {
            if (!isAdded || !channelsRecycler.isShown) return@post
            channelsRecycler.scrollToPosition(targetPosition)
            channelsRecycler.post itemFocus@{
                val target = channelsRecycler.findViewHolderForAdapterPosition(targetPosition)?.itemView
                if (target?.isShown == true && target.requestFocus()) return@itemFocus
                channelsRecycler.requestFocus()
            }
        }
    }

    private fun focusSelectedCategory() {
        if (!isTV) return
        val selected = categoriesContainer.findViewWithTag<TextView>(currentCategory)
            ?: categoriesContainer.getChildAt(0) as? TextView
        selected?.requestFocus()
    }

    private fun showInlinePlayer(channel: Channel, startPlayback: Boolean = true) {
        // El reproductor se actualiza sin mover la lista. En TV el foco permanece en el canal
        // que acaba de seleccionarse, incluso si el D-pad mantiene pulsado OK.

        // Invalida callbacks tardíos de la fuente anterior antes de cambiar de canal.
        inlineGeneration++
        stopInlineCastDiscovery()
        inlineCurrentStreamUrl = ""
        inlineCurrentStreamType = StreamType.AUTO
        inlineBtnCast.visibility = View.GONE
        inlineChannel = channel
        inlineSourceIndex = 0
        if (isTV && ::channelsAdapter.isInitialized) channelsAdapter.setPreviewChannel(channel)
        inlinePlayerContainer.visibility = View.VISIBLE
        if (!isTV) {
            channelsSectionHeader.visibility = View.GONE
            channelsSearchContainer.visibility = View.GONE
            isSearchVisible = false
            searchInput.clearFocus()
            val inputMethodManager = requireContext().getSystemService(android.content.Context.INPUT_METHOD_SERVICE) as android.view.inputmethod.InputMethodManager
            inputMethodManager.hideSoftInputFromWindow(searchInput.windowToken, 0)
        } else {
            channelsSectionHeader.visibility = View.VISIBLE
            channelsSearchContainer.visibility = if (isSearchVisible) View.VISIBLE else View.GONE
            updateTvPreviewIdentity(channel)
            channelsSectionSubtitle.text = getString(R.string.tv_channels_subtitle_count, filteredChannels.size)
        }
        inlineChannelName.text = channel.name
        inlineChannelLogo.loadChannelLogo(channel.name, channel.logo)
        inlineBtnSources.visibility = if ((channel.options?.size ?: 0) > 1) View.VISIBLE else View.GONE
        inlineErrorText.visibility = View.GONE
        inlinePlayerView.visibility = View.GONE
        inlineWebView.visibility = View.GONE
        showInlineControlsTemporarily()

        if (startPlayback) {
            startInlinePlayback(channel, 0)
        } else {
            releaseInlineEngine()
            inlineProgressBar.visibility = View.GONE
        }
        if (isTV) restoreTvFocusForChannel(ChannelIdentity.key(channel), scrollIfNeeded = true)
    }

    /** Keep D-pad focus tied to channel identity, not an adapter position that can change. */
    private fun restoreTvFocusForChannel(key: String, scrollIfNeeded: Boolean) {
        if (!isTV || !::channelsRecycler.isInitialized || !::channelsAdapter.isInitialized) return
        channelsRecycler.post {
            channelsRecycler.post secondFocusRestore@{
                if (!isAdded || isHidden || !::channelsRecycler.isInitialized || !channelsRecycler.isShown) {
                    return@secondFocusRestore
                }
                val position = channelsAdapter.getPositionForKey(key)
                if (position < 0) return@secondFocusRestore
                val row = channelsRecycler.findViewHolderForAdapterPosition(position)?.itemView
                if (row?.isShown == true) {
                    if (!row.hasFocus()) row.requestFocus()
                    return@secondFocusRestore
                }
                if (scrollIfNeeded) {
                    channelsRecycler.scrollToPosition(position)
                    channelsRecycler.post {
                        val attachedRow = channelsRecycler.findViewHolderForAdapterPosition(position)?.itemView
                        if (attachedRow?.isShown == true && !attachedRow.hasFocus()) attachedRow.requestFocus()
                    }
                }
            }
        }
    }

    private fun currentFocusedChannelKey(): String? {
        if (!isTV || !::channelsRecycler.isInitialized || !::channelsAdapter.isInitialized) return null
        val focusedView = channelsRecycler.findFocus() ?: return null
        val holder = channelsRecycler.findContainingViewHolder(focusedView) ?: return null
        val channel = channelsAdapter.getChannelAt(holder.bindingAdapterPosition) ?: return null
        return ChannelIdentity.key(channel)
    }

    /** Recarga la fuente actualmente seleccionada sin cambiar de canal ni saltar a otra opción. */
    private fun reloadInlineTransmission() {
        val channel = inlineChannel ?: return
        val sourceIndex = inlineSourceIndex
        inlineErrorText.visibility = View.GONE
        inlineProgressBar.visibility = View.VISIBLE
        startInlinePlayback(channel, sourceIndex)
        showInlineControlsTemporarily()
    }

    private fun startInlinePlayback(channel: Channel, sourceIndex: Int) {
        if (!isAdded || view == null) return
        // Durante un cambio de fuente no se debe ofrecer Cast con la URL anterior.
        inlineGeneration++
        stopInlineCastDiscovery()
        inlineCurrentStreamUrl = ""
        inlineCurrentStreamType = StreamType.AUTO
        if (::inlineBtnCast.isInitialized) inlineBtnCast.visibility = View.GONE
        val generation = inlineGeneration
        releaseInlineEngine()
        inlineSourceIndex = sourceIndex
        inlineErrorText.visibility = View.GONE
        inlineProgressBar.visibility = View.VISIBLE

        val options = channel.options.orEmpty()
        val url: String
        val type: String
        if (options.isNotEmpty()) {
            if (sourceIndex !in options.indices) {
                showInlineError("No se pudo reproducir ninguna fuente de este canal.")
                return
            }
            val option = options[sourceIndex]
            url = option.iframe
            type = StreamUtils.resolveType(url, option.streamType)
        } else {
            url = channel.streamUrl.orEmpty()
            type = StreamUtils.resolveType(url, channel.streamType ?: StreamType.AUTO)
        }

        if (url.isBlank()) {
            handleInlineSourceFailure(generation)
            return
        }

        inlineCurrentStreamUrl = url
        inlineCurrentStreamType = type
        refreshInlineCastAvailability()

        if (type == StreamType.IFRAME) {
            startInlineWebView(url, generation)
        } else {
            startInlineExoPlayer(url, type, generation)
        }
    }

    private fun startInlineExoPlayer(url: String, type: String, generation: Int) {
        inlineWebView.stopLoading()
        inlineWebView.visibility = View.GONE
        inlinePlayerView.visibility = View.VISIBLE
        inlineBtnPlayPause.visibility = View.VISIBLE
        inlineTimelineContainer.visibility = View.GONE

        try {
            val mediaSource = StreamMediaSourceFactory.create(url, type)
            val player = ExoPlayer.Builder(requireContext())
                .setLoadControl(StreamMediaSourceFactory.createLoadControl(StreamMediaSourceFactory.BufferProfile.INLINE))
                .build()
            inlineExoPlayer = player
            inlinePlayerView.player = player
            inlinePlayerView.useController = false
            installInlinePlayerListener(player, generation)
            player.setMediaSource(mediaSource)
            player.playWhenReady = true
            player.prepare()
        } catch (error: Exception) {
            android.util.Log.e("InlinePlayer", "No se pudo iniciar la fuente", error)
            handleInlineSourceFailure(generation)
        }
    }

    private fun installInlinePlayerListener(player: ExoPlayer, generation: Int) {
        inlinePlayerListener?.let { previous -> runCatching { player.removeListener(previous) } }
        val listener = object : Player.Listener {
            override fun onPlaybackStateChanged(state: Int) {
                if (generation != inlineGeneration || inlineExoPlayer !== player) return
                when (state) {
                    Player.STATE_BUFFERING -> inlineProgressBar.visibility = View.VISIBLE
                    Player.STATE_READY -> {
                        inlineProgressBar.visibility = View.GONE
                        inlineErrorText.visibility = View.GONE
                        updateInlinePlayPauseIcon()
                        inlineTimelineController.update()
                        if (!isTV) startInlineTimelineUpdates()
                        showInlineControlsTemporarily()
                    }
                    Player.STATE_ENDED -> inlineProgressBar.visibility = View.GONE
                }
            }

            override fun onIsPlayingChanged(isPlaying: Boolean) {
                if (generation == inlineGeneration && inlineExoPlayer === player) updateInlinePlayPauseIcon()
            }

            override fun onPlayerError(error: PlaybackException) {
                if (generation == inlineGeneration && inlineExoPlayer === player) handleInlineSourceFailure(generation)
            }
        }
        inlinePlayerListener = listener
        player.addListener(listener)
    }

    private fun startInlineWebView(url: String, generation: Int, loadUrl: Boolean = true) {
        inlinePlayerView.player = null
        inlinePlayerView.visibility = View.GONE
        inlineWebView.visibility = View.VISIBLE
        inlineBtnPlayPause.visibility = View.GONE
        inlineTimelineContainer.visibility = View.GONE
        stopInlineTimelineUpdates()
        inlineWebView.applyPlayerSettings()
        inlineWebView.isFocusable = !isTV
        inlineWebView.isFocusableInTouchMode = !isTV
        inlineWebView.isClickable = !isTV
        val initialHost = StreamUrlPolicy.parseHttpUrl(url)?.host.orEmpty()

        inlineWebView.webChromeClient = object : WebChromeClient() {
            override fun onPermissionRequest(request: android.webkit.PermissionRequest?) {
                request?.deny()
            }

            override fun onCreateWindow(
                view: WebView?,
                isDialog: Boolean,
                isUserGesture: Boolean,
                resultMsg: android.os.Message?
            ): Boolean = false
        }
        inlineWebView.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView?, finishedUrl: String?) {
                if (generation != inlineGeneration || finishedUrl.isNullOrBlank() || finishedUrl == "about:blank") return
                inlineProgressBar.visibility = View.GONE
                inlineErrorText.visibility = View.GONE
                showInlineControlsTemporarily()
            }

            @android.annotation.TargetApi(android.os.Build.VERSION_CODES.M)
            override fun onReceivedError(
                view: WebView?,
                request: WebResourceRequest?,
                error: android.webkit.WebResourceError?
            ) {
                if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.M && request?.isForMainFrame == true) {
                    if (request.url.toString() != "about:blank") handleInlineSourceFailure(generation)
                }
            }

            @Suppress("DEPRECATION")
            override fun onReceivedError(view: WebView?, code: Int, description: String?, failedUrl: String?) {
                if (android.os.Build.VERSION.SDK_INT < android.os.Build.VERSION_CODES.M &&
                    !failedUrl.isNullOrBlank() && failedUrl != "about:blank") {
                    handleInlineSourceFailure(generation)
                }
            }

            @android.annotation.TargetApi(android.os.Build.VERSION_CODES.M)
            override fun onReceivedHttpError(
                view: WebView?,
                request: WebResourceRequest?,
                errorResponse: android.webkit.WebResourceResponse?
            ) {
                if (request?.isForMainFrame == true && (errorResponse?.statusCode ?: 0) >= 400) {
                    handleInlineSourceFailure(generation)
                }
            }

            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                request ?: return false
                val host = request.url.host.orEmpty()
                return WebViewNavigationPolicy.shouldBlockTopLevelNavigation(
                    initialHost = initialHost,
                    requestedHost = host,
                    isMainFrame = request.isForMainFrame,
                    isRedirect = android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.N && request.isRedirect
                )
            }
        }
        if (loadUrl) inlineWebView.loadUrl(url)
    }

    private fun handleInlineSourceFailure(generation: Int) {
        if (generation != inlineGeneration) return
        // Mantener la fuente elegida: el cambio de fuente siempre debe ser manual.
        showInlineError("No se pudo cargar esta fuente. Podés elegir otra manualmente.")
    }

    private fun showInlineError(message: String) {
        stopInlineTimelineUpdates()
        inlineProgressBar.visibility = View.GONE
        inlineErrorText.text = if (isTV) "$message\n\nElegí Recargar para volver a intentar." else "$message\n\nTocá ↻ Recargar para volver a intentar."
        inlineErrorText.visibility = View.VISIBLE
        showInlineControlsTemporarily()
        // En móvil se mantiene la barra visible mientras haya error, para que Recargar no
        // desaparezca antes de poder tocarlo. La acción de recarga vuelve a activar el timeout.
        if (!isTV && inlinePlayerContainer.visibility == View.VISIBLE) {
            hideInlineControlsRunnable?.let { inlineControlsHandler.removeCallbacks(it) }
            hideInlineControlsRunnable = null
        }
    }

    private fun releaseInlineEngine() {
        stopInlineTimelineUpdates()
        inlineTimelineContainer.visibility = View.GONE
        inlinePlayerListener?.let { listener ->
            inlineExoPlayer?.let { player -> runCatching { player.removeListener(listener) } }
        }
        inlinePlayerListener = null
        inlineExoPlayer?.run {
            stop()
            clearMediaItems()
            release()
        }
        inlineExoPlayer = null
        if (::inlinePlayerView.isInitialized) inlinePlayerView.player = null
        if (::inlineWebView.isInitialized) {
            inlineWebView.stopLoading()
            inlineWebView.visibility = View.GONE
            inlineWebView.loadUrl("about:blank")
        }
    }

    private fun startInlineTimelineUpdates() {
        if (::inlineTimelineController.isInitialized) inlineTimelineController.startUpdates()
    }

    private fun stopInlineTimelineUpdates() {
        if (::inlineTimelineController.isInitialized) inlineTimelineController.stopUpdates()
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density + 0.5f).toInt()

    private fun updateInlinePlayPauseIcon() {
        val isPlaying = inlineExoPlayer?.isPlaying == true
        inlineBtnPlayPause.setImageResource(if (isPlaying) R.drawable.ic_pause else R.drawable.ic_play)
        inlineBtnPlayPause.contentDescription = if (isPlaying) "Pausar" else "Reproducir"
    }

    private fun showInlineControlsTemporarily() {
        if (isTV || !::inlineControlsBar.isInitialized || inlinePlayerContainer.visibility != View.VISIBLE) return
        inlineControlsVisible = true
        inlineControlsBar.visibility = View.VISIBLE
        inlineControlsBar.bringToFront()
        if (inlinePlayerView.visibility == View.VISIBLE) {
            inlineBtnPlayPause.visibility = View.VISIBLE
            inlineBtnPlayPause.bringToFront()
        }
        inlineTimelineContainer.bringToFront()
        if (::inlineTimelineController.isInitialized) inlineTimelineController.update()
        hideInlineControlsRunnable?.let { inlineControlsHandler.removeCallbacks(it) }
        hideInlineControlsRunnable = Runnable { hideInlineControls() }
        inlineControlsHandler.postDelayed(hideInlineControlsRunnable!!, 4_000L)
    }

    private fun hideInlineControls() {
        if (!::inlineControlsBar.isInitialized) return
        inlineControlsVisible = false
        inlineControlsBar.visibility = View.GONE
        inlineTimelineContainer.visibility = View.GONE
        inlineBtnPlayPause.visibility = View.GONE
        hideInlineControlsRunnable?.let { inlineControlsHandler.removeCallbacks(it) }
        hideInlineControlsRunnable = null
    }

    private fun refreshInlineCastAvailability() {
        if (!::inlineBtnCast.isInitialized) return
        val canCast = !isTV &&
            inlinePlayerContainer.visibility == View.VISIBLE &&
            inlineChannel != null &&
            inlineCurrentStreamUrl.isNotBlank() &&
            inlineCurrentStreamType != StreamType.IFRAME &&
            inlineCastController?.isConfigured == true

        inlineBtnCast.visibility = if (canCast) View.VISIBLE else View.GONE
        if (canCast && isResumed && !isHidden) {
            startInlineCastDiscovery()
        } else {
            stopInlineCastDiscovery()
        }
    }

    private fun startInlineCastDiscovery() {
        if (inlineCastDiscoveryStarted || inlineCastController?.isConfigured != true) return
        inlineCastController?.startDiscovery()
        inlineCastDiscoveryStarted = true
    }

    private fun stopInlineCastDiscovery() {
        if (!inlineCastDiscoveryStarted) return
        inlineCastController?.stopDiscovery()
        inlineCastDiscoveryStarted = false
    }

    private fun showInlineSourcePicker() {
        val channel = inlineChannel ?: return
        val options = channel.options.orEmpty()
        if (options.size < 2) return
        androidx.appcompat.app.AlertDialog.Builder(requireContext())
            .setTitle("Seleccionar fuente")
            .setItems(options.map { it.name }.toTypedArray()) { _, which ->
                startInlinePlayback(channel, which)
                showInlineControlsTemporarily()
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    private fun closeInlinePlayer() {
        inlineGeneration++
        stopInlineCastDiscovery()
        inlineCurrentStreamUrl = ""
        inlineCurrentStreamType = StreamType.AUTO
        inlineBtnCast.visibility = View.GONE
        hideInlineControls()
        hideInlineControlsRunnable?.let { inlineControlsHandler.removeCallbacks(it) }
        releaseInlineEngine()
        inlinePlayerContainer.visibility = if (isTV) View.VISIBLE else View.GONE
        inlineProgressBar.visibility = View.GONE
        inlineErrorText.visibility = View.GONE
        inlineChannel = null
        if (isTV && ::channelsAdapter.isInitialized) channelsAdapter.setPreviewChannel(null)
        channelsSectionHeader.visibility = if (isTV) View.VISIBLE else View.GONE
        isSearchVisible = false
        channelsSearchContainer.visibility = View.GONE
        searchInput.setText("")
        syncHeaderSearchButton(false)
        currentCategory = currentCategory.ifBlank { "todos" }
        if (isTV) {
            tvPlayerEmptyState?.visibility = View.VISIBLE
            tvCurrentChannelInfo?.visibility = View.GONE
            tvCurrentChannelLogo?.setImageResource(R.drawable.ic_channel_placeholder)
            tvCurrentChannelName?.setText(R.string.tv_channel_not_selected)
            tvCurrentChannelCategory?.setText(R.string.tv_live_category)
            tvPlayerGuide?.setText(R.string.tv_player_idle_guide)
            inlinePlayerContainer.requestFocus()
        }
    }

    private fun launchInlineFullscreen() {
        val channel = inlineChannel ?: return
        launchPlayerActivity(channel, fromInline = true)
    }

    private fun launchPlayerActivity(channel: Channel, fromInline: Boolean) {
        val matchingIndex = originalChannels.indexOfFirst { ChannelIdentity.same(it, channel) }
        // Si el canal ya no está en el snapshot por una actualización, lo agregamos al
        // catálogo entregado al reproductor en vez de seleccionar silenciosamente el primero.
        val playerChannels = if (matchingIndex >= 0) originalChannels else originalChannels + channel
        val channelIndex = if (matchingIndex >= 0) matchingIndex else playerChannels.lastIndex
        isLaunchingFullscreen = fromInline

        // Transferir también en móviles: la Activity cambia a horizontal, pero el motor ya
        // preparado (o el WebView del iframe) tiene que sobrevivir sin volver a cargar la fuente.
        val currentPlayer = inlineExoPlayer
        val canTransferNativePlayer = fromInline && currentPlayer != null &&
            inlineCurrentStreamUrl.isNotBlank() && inlineCurrentStreamType != StreamType.IFRAME
        val canTransferWebView = fromInline && currentPlayer == null &&
            inlineCurrentStreamType == StreamType.IFRAME && inlineCurrentStreamUrl.isNotBlank() &&
            inlineWebView.visibility == View.VISIBLE && inlineWebView.url != null
        if (canTransferNativePlayer && currentPlayer != null) {
            val session = InlinePlayerHandoff.Session(
                player = currentPlayer,
                channel = inlineChannel ?: channel,
                streamUrl = inlineCurrentStreamUrl,
                streamType = inlineCurrentStreamType,
                sourceIndex = inlineSourceIndex,
                wasPlaying = currentPlayer.playWhenReady
            )
            inlinePlayerListener?.let { listener -> runCatching { currentPlayer.removeListener(listener) } }
            inlinePlayerListener = null
            stopInlineTimelineUpdates()
            inlinePlayerView.player = null
            inlineExoPlayer = null // Ownership moves to the fullscreen Activity; do not release/pause it.
            InlinePlayerHandoff.offerToFullscreen(session)
        } else if (canTransferWebView) {
            val oldParent = inlineWebView.parent as? ViewGroup
            val oldIndex = oldParent?.indexOfChild(inlineWebView) ?: -1
            val oldParams = inlineWebView.layoutParams
            // Re-parent the live WebView instead of loading the iframe in a second WebView.
            inlineWebView.onPause()
            oldParent?.removeView(inlineWebView)
            InlinePlayerHandoff.offerToFullscreen(
                InlinePlayerHandoff.Session(
                    player = null,
                    channel = inlineChannel ?: channel,
                    streamUrl = inlineCurrentStreamUrl,
                    streamType = StreamType.IFRAME,
                    sourceIndex = inlineSourceIndex,
                    wasPlaying = true,
                    webView = inlineWebView,
                    webViewParentIndex = oldIndex,
                    webViewLayoutParams = oldParams
                )
            )
        } else {
            inlineExoPlayer?.pause()
        }
        inlineWebView.onPause()

        // El catálogo global puede contener miles de canales: no lo serializamos en el Intent,
        // porque el tamaño del Bundle/Binder es limitado. Enviamos un token de la lista en memoria.
        val catalogToken = PlayerChannelCatalog.publish(playerChannels)
        val intent = Intent(requireContext(), UnifiedPlayerActivity::class.java).apply {
            putExtra("channel_catalog_token", catalogToken)
            putParcelableExtra("current_channel", channel)
            putExtra("channel_index", channelIndex)
            putExtra("channel_name", channel.name)
            putExtra("channel_logo", channel.logo)
            putExtra("stream_url", channel.streamUrl)
            putExtra("stream_type", channel.streamType ?: StreamType.AUTO)
            putExtra("from_inline_player", fromInline)
            putExtra("force_landscape_fullscreen", fromInline && !isTV)
            putExtra("source_index", inlineSourceIndex)
            putExtra("reuse_inline_player_session", canTransferNativePlayer)
            putExtra("reuse_inline_webview_session", canTransferWebView)
        }
        try {
            startActivity(intent)
            if (!isTV) requireActivity().overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
        } catch (error: Exception) {
            isLaunchingFullscreen = false
            if (canTransferNativePlayer || canTransferWebView) {
                InlinePlayerHandoff.cancelPendingFullscreen()?.let(::restoreInlineSession)
            }
            android.util.Log.e("InlinePlayer", "No se pudo abrir pantalla completa", error)
            Toast.makeText(requireContext(), "No se pudo abrir el reproductor a pantalla completa", Toast.LENGTH_SHORT).show()
        }
    }

    private fun maybeOpenFullscreenAfterRotation(newConfig: Configuration) {
        if (isTV || isHidden || newConfig.orientation != Configuration.ORIENTATION_LANDSCAPE) return
        if (inlineChannel == null || inlinePlayerContainer.visibility != View.VISIBLE || isLaunchingFullscreen) return
        launchPlayerActivity(inlineChannel!!, fromInline = true)
    }

    private fun setupSearch() {
        if (!isTV) {
            btnSearch.setOnClickListener {
                searchInput.requestFocus()
                val imm = requireContext().getSystemService(android.content.Context.INPUT_METHOD_SERVICE) as android.view.inputmethod.InputMethodManager
                imm.showSoftInput(searchInput, android.view.inputmethod.InputMethodManager.SHOW_IMPLICIT)
            }
        }

        searchInput.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                searchRunnable?.let { searchHandler.removeCallbacks(it) }
                searchRunnable = Runnable { applyFiltersAndUpdate() }
                searchHandler.postDelayed(searchRunnable!!, SEARCH_DELAY)
            }
            override fun afterTextChanged(s: Editable?) {}
        })
    }

    /** Opens/closes the search field from the shared header (mobile and Android TV). */
    fun toggleSearchFromHeader() {
        if (!isAdded || isHidden || !::searchInput.isInitialized) return

        if (isTV) {
            val opening = !isSearchVisible
            toggleSearch()
            if (opening) {
                searchInput.requestFocus()
            } else {
                activity?.findViewById<View>(R.id.header_search_button)?.requestFocus()
            }
            return
        }

        if (channelsSearchContainer.visibility == View.VISIBLE) {
            channelsSearchContainer.visibility = View.GONE
            isSearchVisible = false
            searchInput.setText("")
            searchInput.clearFocus()
            val imm = requireContext().getSystemService(android.content.Context.INPUT_METHOD_SERVICE) as android.view.inputmethod.InputMethodManager
            imm.hideSoftInputFromWindow(searchInput.windowToken, 0)
            syncHeaderSearchButton(false)
            applyFiltersAndUpdate()
        } else {
            channelsSearchContainer.visibility = View.VISIBLE
            searchInput.visibility = View.VISIBLE
            isSearchVisible = true
            searchInput.requestFocus()
            val imm = requireContext().getSystemService(android.content.Context.INPUT_METHOD_SERVICE) as android.view.inputmethod.InputMethodManager
            imm.showSoftInput(searchInput, android.view.inputmethod.InputMethodManager.SHOW_IMPLICIT)
            syncHeaderSearchButton(true)
        }
    }

    private fun syncHeaderSearchButton(open: Boolean) {
        val button = activity?.findViewById<ImageButton>(R.id.header_search_button) ?: return
        button.setImageResource(if (open) R.drawable.ic_close else R.drawable.ic_search)
        button.contentDescription = getString(
            if (open) R.string.close_channel_search else R.string.open_channel_search
        )
        button.nextFocusDownId = if (open) R.id.search_input else R.id.inline_player_container
    }

    private fun toggleSearch() {
        if (isTV) {
            isSearchVisible = !isSearchVisible
            channelsSearchContainer.visibility = if (isSearchVisible) View.VISIBLE else View.GONE
            if (isSearchVisible) {
                searchInput.visibility = View.VISIBLE
                syncHeaderSearchButton(true)
            } else {
                searchInput.setText("")
                searchInput.clearFocus()
                syncHeaderSearchButton(false)
                applyFiltersAndUpdate()
            }
            return
        }

        isSearchVisible = !isSearchVisible

        if (isSearchVisible) {
            searchInput.visibility = View.VISIBLE
            searchInput.requestFocus()
            if (!isTV) {
                val imm = requireContext().getSystemService(android.content.Context.INPUT_METHOD_SERVICE) as android.view.inputmethod.InputMethodManager
                imm.showSoftInput(searchInput, android.view.inputmethod.InputMethodManager.SHOW_IMPLICIT)
            } else {
                searchInput.startAnimation(AnimationUtils.loadAnimation(requireContext(), android.R.anim.fade_in))
            }
        } else {
            searchInput.visibility = View.GONE
            searchInput.text.clear()
            if (!isTV) {
                val imm = requireContext().getSystemService(android.content.Context.INPUT_METHOD_SERVICE) as android.view.inputmethod.InputMethodManager
                imm.hideSoftInputFromWindow(searchInput.windowToken, 0)
            }
            applyFiltersAndUpdate()
        }
    }

    private fun applyFiltersAndUpdate(onListCommitted: (() -> Unit)? = null) {
        if (originalChannels.isEmpty()) {
            onListCommitted?.invoke()
            return
        }

        val categoryFiltered = if (currentCategory == "todos") originalChannels else originalChannels.filter { channel ->
            generalCategoryFor(channel.category) == currentCategory
        }
        val countryFiltered = if (currentCountry == "todos") categoryFiltered else categoryFiltered.filter { channel ->
            countryKey(channel.country) == currentCountry
        }
        filteredChannels = ChannelCatalog.searchByName(
            channels = countryFiltered,
            query = searchInput.text.toString()
        )

        channelsAdapter.submitList(filteredChannels, onListCommitted)
        if (isTV) {
            channelsSectionSubtitle.text = if (filteredChannels.isEmpty()) {
                getString(R.string.tv_channels_subtitle_empty)
            } else {
                getString(R.string.tv_channels_subtitle_count, filteredChannels.size)
            }
        }

        if (filteredChannels.isEmpty()) {
            showState("No se encontraron canales", isError = false, showRetry = false)
        } else {
            hideState()
        }
    }

    // La fuente puede traer cientos de group-title. Se agrupan en pocas categorías generales.
    private fun generateCategoriesFromChannels(channels: List<Channel>) {
        if (channels.isEmpty()) return
        categories.clear()
        categories.add("todos" to "Todos")
        val generalKeys = listOf("deportes", "noticias", "peliculas", "series", "infantiles", "musicales", "documentales", "educativos", "entretenimiento", "otros")
        generalKeys.forEach { key ->
            if (channels.any { generalCategoryFor(it.category) == key }) {
                categories.add(key to (categoryNames[key] ?: displayCategoryName(key)))
            }
        }
        val availableCountries = channels.map { countryKey(it.country) }.distinct()
        if (availableCountries.isEmpty()) currentCountry = "todos"
        else if (currentCountry != "todos" && currentCountry !in availableCountries) currentCountry = "todos"
        setupCategories()
    }

    private fun generalCategoryFor(rawCategory: String): String {
        val value = rawCategory.trim().lowercase(Locale.ROOT)
            .replace('_', ' ').replace('-', ' ')
        return when {
            value.contains("sport") || value.contains("deport") || value.contains("football") || value.contains("soccer") || value.contains("basket") || value.contains("racing") || value.contains("motorsport") -> "deportes"
            value.contains("news") || value.contains("noticia") || value.contains("current affairs") || value == "weather" -> "noticias"
            value.contains("movie") || value.contains("film") || value.contains("cinema") || value.contains("pelicula") -> "peliculas"
            value.contains("series") || value.contains("drama") -> "series"
            value.contains("kid") || value.contains("child") || value.contains("cartoon") || value.contains("animation") || value.contains("infantil") -> "infantiles"
            value.contains("music") || value.contains("musica") || value.contains("radio") -> "musicales"
            value.contains("documentary") || value.contains("documental") || value.contains("nature") -> "documentales"
            value.contains("education") || value.contains("educativo") || value.contains("learning") || value.contains("legislative") -> "educativos"
            value.contains("entertainment") || value.contains("comedy") || value.contains("lifestyle") || value.contains("cooking") || value.contains("travel") || value.contains("culture") || value.contains("general") || value.contains("family") -> "entretenimiento"
            else -> "otros"
        }
    }

    private fun countryKey(rawCountry: String): String {
        val value = rawCountry.trim().substringBefore(',')
        if (value.isBlank()) return "sin_pais"
        return value.lowercase(Locale.ROOT).replace(' ', '_')
    }

    private fun countryLabel(key: String): String {
        if (key == "sin_pais") return "Sin país informado"
        val raw = key.replace('_', ' ')
        // IPTV-org normalmente usa códigos ISO de dos letras; nombres ya legibles se conservan.
        return if (raw.length == 2 && raw.all { it.isLetter() }) {
            Locale("", raw.uppercase(Locale.ROOT)).getDisplayCountry(Locale("es", "AR")).ifBlank { raw.uppercase(Locale.ROOT) }
        } else raw.split(' ').joinToString(" ") { it.replaceFirstChar { ch -> ch.uppercase(Locale("es", "AR")) } }
    }

    private fun showCountryPicker() {
        val countries = originalChannels.map { countryKey(it.country) }.distinct()
            .sortedBy { countryLabel(it).lowercase(Locale.ROOT) }
        val keys = listOf("todos") + countries
        val labels = listOf("Todos los países") + countries.map(::countryLabel)
        AlertDialog.Builder(requireContext())
            .setTitle("Filtrar por país")
            .setSingleChoiceItems(labels.toTypedArray(), keys.indexOf(currentCountry).coerceAtLeast(0)) { dialog, which ->
                currentCountry = keys[which]
                updateCountryFilterLabel()
                countryFilterButton?.let { updateChipStyle(it, currentCountry != "todos") }
                dialog.dismiss()
                applyFiltersAndUpdate {
                    if (isTV) focusSelectedCategory()
                }
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    private fun updateCountryFilterLabel() {
        countryFilterButton?.text = "País: " + if (currentCountry == "todos") "Todos" else countryLabel(currentCountry)
    }

    private fun displayCategoryName(categoryKey: String): String {
        categoryNames[categoryKey]?.let { return it }
        val spanishLocale = Locale("es", "AR")
        return categoryKey
            .replace('-', ' ')
            .split(' ')
            .filter { it.isNotBlank() }
            .joinToString(" ") { word ->
                word.lowercase(spanishLocale).replaceFirstChar { first ->
                    if (first.isLowerCase()) first.titlecase(spanishLocale) else first.toString()
                }
            }
    }

    private fun setupCategories() {
        categoriesContainer.removeAllViews()

        if (categories.isEmpty()) {
            // Si no hay categorías, mostrar al menos "todos"
            categories.add("todos" to categoryNames["todos"].orEmpty())
        }

        // Un único selector de países evita convertir la pantalla en otra tira interminable.
        val countryChip = LayoutInflater.from(requireContext())
            .inflate(R.layout.item_category, categoriesContainer, false) as TextView
        countryChip.id = View.generateViewId()
        countryChip.tag = "__country_filter__"
        countryFilterButton = countryChip
        countryFilterButtonId = countryChip.id
        updateCountryFilterLabel()
        countryChip.setOnClickListener { showCountryPicker() }
        if (isTV) {
            countryChip.layoutParams = countryChip.layoutParams.apply { height = dp(38) }
            countryChip.setPadding(dp(12), 0, dp(12), 0)
            countryChip.nextFocusLeftId = R.id.inline_player_container
            setupTVFocusEffect(countryChip)
        }
        updateChipStyle(countryChip, currentCountry != "todos")
        categoriesContainer.addView(countryChip)

        for ((key, label) in categories) {
            val chip = LayoutInflater.from(requireContext())
                .inflate(R.layout.item_category, categoriesContainer, false) as TextView

            chip.text = label
            chip.tag = key
            chip.isSelected = key == currentCategory
            if (isTV) {
                chip.id = View.generateViewId()
                chip.layoutParams = chip.layoutParams.apply { height = dp(38) }
                chip.setPadding(dp(16), 0, dp(16), 0)
                chip.textSize = 13f
                (chip.layoutParams as? ViewGroup.MarginLayoutParams)?.let { params ->
                    params.marginEnd = dp(8)
                    chip.layoutParams = params
                }
            }

            updateChipStyle(chip, chip.isSelected)

            if (isTV) {
                // La categoría está sobre la lista y a la derecha del reproductor: las flechas
                // respetan esa geometría en vez de saltar al rail global desde el primer chip.
                chip.nextFocusLeftId = if (key == categories.firstOrNull()?.first) countryFilterButtonId else View.NO_ID
                chip.setOnKeyListener { _, keyCode, event ->
                    if (event.action == KeyEvent.ACTION_DOWN && event.repeatCount == 0 && keyCode == KeyEvent.KEYCODE_DPAD_DOWN) {
                        focusChannelList()
                        true
                    } else false
                }
                setupTVFocusEffect(chip)
            } else {
                chip.setOnTouchListener { _, _ ->
                    chip.isSelected = true
                    false
                }
            }

            chip.setOnClickListener { selectCategory(key) }
            categoriesContainer.addView(chip)
        }

        if (isTV) {
            val selectedChip = categoriesContainer.findViewWithTag<TextView>(currentCategory)
                ?: categoriesContainer.getChildAt(0) as? TextView
            selectedCategoryFocusViewId = selectedChip?.id ?: View.NO_ID

            // D-pad: buscador ↓ categoría seleccionada ↓ lista. Las categorías mantienen
            // el movimiento lateral entre chips y el primer chip devuelve al reproductor.
            searchInput.nextFocusDownId = selectedCategoryFocusViewId
            channelsRecycler.nextFocusUpId = selectedCategoryFocusViewId
            for (index in 0 until categoriesContainer.childCount) {
                val chip = categoriesContainer.getChildAt(index)
                chip.nextFocusUpId = R.id.search_input
                chip.nextFocusDownId = R.id.channels_recycler
                chip.nextFocusLeftId = if (index == 0) R.id.inline_player_container
                    else categoriesContainer.getChildAt(index - 1).id
            }
            if (::channelsAdapter.isInitialized) {
                channelsAdapter.setCategoryFocusTarget(selectedCategoryFocusViewId)
            }
        }
    }

    private fun updateChipStyle(chip: TextView, isSelected: Boolean) {
        if (isSelected) {
            chip.setBackgroundResource(R.drawable.bg_category_selected)
            chip.setTextColor(ContextCompat.getColor(requireContext(), R.color.text_primary))
        } else {
            chip.setBackgroundResource(R.drawable.bg_category_default)
            chip.setTextColor(ContextCompat.getColor(requireContext(), R.color.text_secondary))
        }
    }

    private fun setupTVFocusEffect(chip: TextView) {
        chip.onFocusChangeListener = View.OnFocusChangeListener { _, hasFocus ->
            // Foco visible sin escalado: evita solapamientos y saltos en TV.
            chip.animate().cancel()
            chip.scaleX = 1f
            chip.scaleY = 1f
            if (hasFocus) {
                val container = chip.parent as? View
                val scroller = container?.parent as? android.widget.HorizontalScrollView
                if (scroller != null) {
                    val leftEdge = scroller.scrollX
                    val rightEdge = leftEdge + scroller.width - scroller.paddingLeft - scroller.paddingRight
                    when {
                        chip.left < leftEdge -> scroller.smoothScrollTo(chip.left, 0)
                        chip.right > rightEdge -> scroller.smoothScrollTo(chip.right - scroller.width + scroller.paddingRight, 0)
                    }
                }
            }
        }
    }

    private fun selectCategory(categoryKey: String) {
        if (currentCategory == categoryKey) return
        val focusedChannelKey = currentFocusedChannelKey()

        currentCategory = categoryKey

        for (i in 0 until categoriesContainer.childCount) {
            val chip = categoriesContainer.getChildAt(i) as TextView
            val selected = chip.tag == categoryKey
            val isCountryChip = chip.tag == "__country_filter__"
            updateChipStyle(chip, if (isCountryChip) currentCountry != "todos" else selected)
            if (selected) selectedCategoryFocusViewId = chip.id
        }
        if (isTV) {
            // El retorno vertical siempre va a la categoría activa tras cambiar el filtro.
            searchInput.nextFocusDownId = selectedCategoryFocusViewId
            channelsRecycler.nextFocusUpId = selectedCategoryFocusViewId
            if (::channelsAdapter.isInitialized) {
                channelsAdapter.setCategoryFocusTarget(selectedCategoryFocusViewId)
            }
        }

        if (isSearchVisible) {
            toggleSearch()
        }

        applyFiltersAndUpdate {
            // Esperar al commit del AsyncListDiffer evita solicitar foco sobre un ViewHolder viejo.
            val key = focusedChannelKey
            if (isTV && key != null && channelsAdapter.getPositionForKey(key) >= 0) {
                restoreTvFocusForChannel(key, scrollIfNeeded = true)
            } else if (isTV) {
                focusSelectedCategory()
            }
        }
        // No desplazar la lista al principio al cambiar de categoría o seleccionar una vista previa.
    }

    private fun setupRecyclerView() {
        channelsRecycler.layoutManager = GridLayoutManager(requireContext(), calculateSpanCount())

        channelsAdapter = ChannelsAdapter(
            onItemClick = { channel, position -> openPlayer(channel, position) },
            channelNumber = { channel -> originalChannels.indexOfFirst { ChannelIdentity.same(it, channel) } + 1 }
        )

        channelsRecycler.adapter = channelsAdapter

        if (isTV) {
            channelsRecycler.isFocusable = true
            channelsRecycler.isFocusableInTouchMode = true
            // El foco inicial va al reproductor; desde allí se entra a la lista con →.
            inlinePlayerContainer.nextFocusRightId = R.id.channels_recycler
            channelsRecycler.nextFocusLeftId = R.id.inline_player_container
        }
    }

    /**
     * Devuelve el foco a un elemento real de la lista en Android TV.
     * El retraso doble permite que RecyclerView procese el scroll y adjunte el ViewHolder,
     * evitando que el mando quede enfocado en el contenedor sin un indicador visible.
     */
    fun requestTvFocus() {
        if (!isTV || !::channelsRecycler.isInitialized || !::channelsAdapter.isInitialized) return
        inlinePlayerContainer.post {
            if (!isAdded || !inlinePlayerContainer.isShown) return@post
            if (retryButton.isShown && channelsAdapter.itemCount == 0) retryButton.requestFocus()
            else inlinePlayerContainer.requestFocus()
        }
    }

    /** Columnas según el ancho disponible: TV por rangos fijos; móvil/tablet una cada ~320dp. */
    private fun calculateSpanCount(): Int {
        if (isTV) return 1
        val dpWidth = resources.configuration.screenWidthDp
        return (dpWidth / 320).coerceAtLeast(1)
    }

    // MainActivity maneja la rotación sin recrearse: recalculamos la lista y ampliamos el reproductor.
    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        if (::channelsRecycler.isInitialized) {
            (channelsRecycler.layoutManager as? GridLayoutManager)?.spanCount = calculateSpanCount()
        }
        maybeOpenFullscreenAfterRotation(newConfig)
    }

    /** Al crear las vistas: muestra la carga en curso o el último resultado que tenga la activity. */
    private fun renderInitialState() {
        val main = activity as? MainActivity
        val result = main?.getLoadResult()
        if (main == null || main.isLoadingChannels() || result == null) {
            showLoading(true)
        } else {
            applyResult(result)
        }
    }

    private fun setupStates() {
        swipeRefresh.setColorSchemeResources(R.color.accent)
        swipeRefresh.setProgressBackgroundColorSchemeResource(R.color.space_surface_raised)
        swipeRefresh.isEnabled = !isTV // en TV no hay gesto: se usa el botón Reintentar
        swipeRefresh.setOnRefreshListener { (activity as? MainActivity)?.reloadChannels() }
        retryButton.setOnClickListener { (activity as? MainActivity)?.reloadChannels() }
    }

    private fun applyResult(result: LoadResult) {
        originalChannels = result.channels
        currentCategory = "todos"
        currentCountry = "todos"
        showLoading(false)
        swipeRefresh.isRefreshing = false

        if (originalChannels.isEmpty()) {
            filteredChannels = emptyList()
            channelsAdapter.submitList(emptyList())
            categoriesContainer.removeAllViews()
            when {
                result.notConfigured ->
                    showState("Todavía no hay una lista de canales configurada.", isError = false, showRetry = false)
                result.failed ->
                    showState("No se pudo cargar la lista de canales.\nRevisá tu conexión e intentá de nuevo.", isError = true, showRetry = true)
                else ->
                    showState("La lista de canales está vacía.", isError = false, showRetry = true)
            }
        } else {
            generateCategoriesFromChannels(originalChannels)
            applyFiltersAndUpdate()
        }
    }

    private fun showState(message: String, isError: Boolean, showRetry: Boolean) {
        errorText.text = message
        errorText.setTextColor(
            ContextCompat.getColor(requireContext(), if (isError) R.color.error else R.color.text_secondary)
        )
        retryButton.isVisible = showRetry
        stateContainer.isVisible = true
        if (showRetry && isTV) retryButton.requestFocus()
    }

    private fun hideState() {
        stateContainer.isVisible = false
    }

    private fun showLoading(show: Boolean) {
        progressBar.isVisible = show
    }

    /** True si las vistas ya existen (entre onViewCreated y onDestroyView). */
    private fun isViewReady() = view != null && ::progressBar.isInitialized && ::channelsAdapter.isInitialized

    /** La activity avisa que empezó (o se repitió) la carga de la lista. */
    fun onLoadStarted() {
        if (!isViewReady()) return
        hideState()
        if (!swipeRefresh.isRefreshing) showLoading(true)
    }

    /**
     * La activity llama a esto cuando termina de cargar. Si el fragmento todavía no creó sus vistas
     * no hay nada que actualizar: [renderInitialState] leerá el resultado desde la activity al crearlas.
     */
    fun showResult(result: LoadResult) {
        if (!isViewReady()) return
        applyResult(result)
    }

    // En TV, al volver del reproductor el foco regresa al canal que se estaba mirando.
    override fun onResume() {
        super.onResume()
        isLaunchingFullscreen = false

        // Do not consume a returned session until this Fragment has a usable view. This avoids
        // losing the transferred engine during transient navigation/lifecycle changes.
        val returnedSession = if (!isHidden && isViewReady()) {
            InlinePlayerHandoff.takeReturnedToInline()
        } else null

        if (returnedSession != null) {
            restoreInlineSession(returnedSession)
            val key = returnedSession.channel.name to returnedSession.channel.logo
            if (channelsAdapter.getPositionForKey(key) >= 0) {
                restoreTvFocusForChannel(key, scrollIfNeeded = true)
            } else {
                focusSelectedCategory()
            }
        } else {
            if (isTV && !isHidden && isViewReady()) restoreTvFocus()
            if (!isHidden && ::inlinePlayerContainer.isInitialized && inlineChannel != null &&
                inlinePlayerContainer.visibility == View.VISIBLE) {
                inlineWebView.onResume()
                val player = inlineExoPlayer
                if (player != null) {
                    player.play()
                } else if (inlineWebView.visibility != View.VISIBLE) {
                    // Fallback for WebView sources or if the native handoff was unavailable.
                    startInlinePlayback(inlineChannel!!, inlineSourceIndex)
                }
            }
        }
        refreshInlineCastAvailability()
    }

    override fun handleBack(): Boolean {
        if (!isTV || !isSearchVisible || !::searchInput.isInitialized) return false
        toggleSearch()
        activity?.findViewById<View>(R.id.header_search_button)?.requestFocus()
        return true
    }

    override fun onPause() {
        super.onPause()
        stopInlineCastDiscovery()
        inlineExoPlayer?.pause()
        if (::inlineWebView.isInitialized) inlineWebView.onPause()
    }

    override fun onHiddenChanged(hidden: Boolean) {
        super.onHiddenChanged(hidden)
        if (hidden) {
            stopInlineCastDiscovery()
            inlineExoPlayer?.pause()
            if (::inlineWebView.isInitialized) inlineWebView.onPause()
        } else {
            inlineWebView.onResume()
            inlineExoPlayer?.play()
            refreshInlineCastAvailability()
        }
    }

    private fun restoreTvFocus() {
        val lastKey = channelsAdapter.getLastFocusedChannelKey()
        if (lastKey != null && channelsAdapter.getPositionForKey(lastKey) >= 0) {
            restoreTvFocusForChannel(lastKey, scrollIfNeeded = true)
            return
        }
        val position = channelsAdapter.getLastFocusedPosition()
        if (position < 0 || position >= channelsAdapter.itemCount) return
        channelsRecycler.scrollToPosition(position)
        channelsRecycler.post {
            channelsRecycler.findViewHolderForAdapterPosition(position)?.itemView?.requestFocus()
        }
    }

    private fun isSameActivePreview(channel: Channel): Boolean {
        val current = inlineChannel ?: return false
        if (!ChannelIdentity.same(current, channel)) return false
        if (inlinePlayerContainer.visibility != View.VISIBLE || inlineCurrentStreamUrl.isBlank()) return false
        if (inlineErrorText.visibility == View.VISIBLE) return false
        if (inlineExoPlayer?.playbackState == Player.STATE_ENDED) return false
        return inlineExoPlayer != null || inlineWebView.visibility == View.VISIBLE || inlineProgressBar.visibility == View.VISIBLE
    }

    private fun openPlayer(channel: Channel, position: Int) {
        if (isTV && isSameActivePreview(channel)) {
            // Volver a confirmar explícitamente la fila que ya se está previsualizando abre
            // fullscreen transfiriendo la sesión activa; no reinicia el stream ni el buffer.
            launchPlayerActivity(channel, fromInline = true)
            return
        }
        if (channel.streamUrl.isNullOrEmpty() && channel.options.isNullOrEmpty()) {
            Toast.makeText(requireContext(), "Este canal no tiene fuentes disponibles", Toast.LENGTH_SHORT).show()
            return
        }

        if (isTV) {
            showInlinePlayer(channel)
        } else if (resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE) {
            // Si el móvil ya está en horizontal, abre la pantalla dedicada directamente.
            showInlinePlayer(channel, startPlayback = false)
            launchPlayerActivity(channel, fromInline = true)
        } else {
            // En vertical el canal queda integrado encima de la lista, sin abandonar la pantalla.
            showInlinePlayer(channel)
        }
    }

    override fun onDestroyView() {
        stopInlineCastDiscovery()
        inlineCastController?.dispose()
        inlineCastController = null
        searchRunnable?.let { searchHandler.removeCallbacks(it) }
        hideInlineControlsRunnable?.let { inlineControlsHandler.removeCallbacks(it) }
        stopInlineTimelineUpdates()
        inlineGeneration++
        releaseInlineEngine()
        if (::inlineWebView.isInitialized) {
            inlineWebView.webChromeClient = WebChromeClient()
            inlineWebView.webViewClient = WebViewClient()
            inlineWebView.stopLoading()
            (inlineWebView.parent as? ViewGroup)?.removeView(inlineWebView)
            inlineWebView.removeAllViews()
            inlineWebView.destroy()
        }
        super.onDestroyView()
    }
}