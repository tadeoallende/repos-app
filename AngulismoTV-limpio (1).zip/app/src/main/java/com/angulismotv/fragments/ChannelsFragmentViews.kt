package com.angulismotv.fragments

import android.view.View
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.SeekBar
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout
import com.google.android.exoplayer2.ui.PlayerView
import android.webkit.WebView

/**
 * Strong references to one ChannelsFragment view tree.
 * The Fragment clears this holder in onDestroyView so its instance can survive navigation without
 * retaining the previous Activity's views or their Context.
 */
internal class ChannelsFragmentViews(root: View) {
    val channelsRecycler: RecyclerView = required(root, com.angulismotv.R.id.channels_recycler)
    val progressBar: ProgressBar = required(root, com.angulismotv.R.id.progress_bar)
    val swipeRefresh: SwipeRefreshLayout = required(root, com.angulismotv.R.id.swipe_refresh)
    val stateContainer: LinearLayout = required(root, com.angulismotv.R.id.state_container)
    val retryButton: TextView = required(root, com.angulismotv.R.id.retry_button)
    val errorText: TextView = required(root, com.angulismotv.R.id.error_text)
    val categoriesContainer: LinearLayout = required(root, com.angulismotv.R.id.categories_container)
    val categoriesScroll: HorizontalScrollView = required(root, com.angulismotv.R.id.categories_scroll)
    val searchInput: EditText = required(root, com.angulismotv.R.id.search_input)
    val btnSearch: ImageView = required(root, com.angulismotv.R.id.btn_search)
    val channelsSectionHeader: View = required(root, com.angulismotv.R.id.channels_section_header)
    val channelsSearchContainer: View = required(root, com.angulismotv.R.id.channels_search_container)
    val channelsSectionSubtitle: TextView = required(root, com.angulismotv.R.id.channels_section_subtitle)
    val tvListGuide: TextView? = root.findViewById(com.angulismotv.R.id.tv_list_guide)

    val inlinePlayerContainer: FrameLayout = required(root, com.angulismotv.R.id.inline_player_container)
    val inlinePlayerView: PlayerView = required(root, com.angulismotv.R.id.inline_player_view)
    var inlineWebView: WebView = required(root, com.angulismotv.R.id.inline_web_view)
    val inlineProgressBar: ProgressBar = required(root, com.angulismotv.R.id.inline_progress_bar)
    val inlineErrorText: TextView = required(root, com.angulismotv.R.id.inline_error_text)
    val inlineControlsBar: LinearLayout = required(root, com.angulismotv.R.id.inline_controls_bar)
    val inlineTimelineContainer: View = required(root, com.angulismotv.R.id.inline_timeline_container)
    val inlineSeekBar: SeekBar = required(root, com.angulismotv.R.id.inline_seek_bar)
    val inlineTimeCurrent: TextView = required(root, com.angulismotv.R.id.inline_time_current)
    val inlineTimeDuration: TextView = required(root, com.angulismotv.R.id.inline_time_duration)
    val inlineChannelLogo: ImageView = required(root, com.angulismotv.R.id.inline_channel_logo)
    val inlineChannelName: TextView = required(root, com.angulismotv.R.id.inline_channel_name)
    val inlineBtnPlayPause: ImageButton = required(root, com.angulismotv.R.id.inline_btn_play_pause)
    val inlineBtnSources: ImageButton = required(root, com.angulismotv.R.id.inline_btn_sources)
    val inlineBtnReload: ImageButton = required(root, com.angulismotv.R.id.inline_btn_reload)
    val inlineBtnCast: ImageButton = required(root, com.angulismotv.R.id.inline_btn_cast)
    val inlineBtnFullscreen: ImageButton = required(root, com.angulismotv.R.id.inline_btn_fullscreen)
    val inlineBtnClose: ImageButton = required(root, com.angulismotv.R.id.inline_btn_close)

    private companion object {
        fun <T : View> required(root: View, id: Int): T =
            requireNotNull(root.findViewById<T>(id)) {
                "Falta la vista requerida con id=${root.resources.getResourceEntryName(id)}"
            }
    }
}
