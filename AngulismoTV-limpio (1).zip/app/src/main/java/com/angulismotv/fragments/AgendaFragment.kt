package com.angulismotv.fragments

import android.content.pm.ActivityInfo
import android.content.res.Configuration
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import android.widget.ProgressBar
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import com.angulismotv.player.AgendaNavigationPolicy
import com.angulismotv.player.StreamUtils
import com.angulismotv.BuildConfig
import com.angulismotv.R
import com.angulismotv.utils.DeviceHelper

class AgendaFragment : Fragment() {

    private val viewReferences = mutableListOf<AutoClearedViewRef<*>>()
    private fun <T : Any> autoClearedViewRef(): AutoClearedViewRef<T> =
        AutoClearedViewRef<T>().also(viewReferences::add)

    private val _webViewRef = autoClearedViewRef<WebView>()
    private var webView: WebView by _webViewRef
    private val _progressBarRef = autoClearedViewRef<ProgressBar>()
    private var progressBar: ProgressBar by _progressBarRef
    private val _errorTextRef = autoClearedViewRef<TextView>()
    private var errorText: TextView by _errorTextRef
    private val _customViewContainerRef = autoClearedViewRef<FrameLayout>()
    private var customViewContainer: FrameLayout by _customViewContainerRef
    private var customView: View? = null
    private var originalOrientation = 0
    private var isInFullscreen = false
    private val mainHandler = Handler(Looper.getMainLooper())

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        return inflater.inflate(R.layout.fragment_agenda, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        webView = view.findViewById(R.id.web_view)
        progressBar = view.findViewById(R.id.progress_bar)
        errorText = view.findViewById(R.id.error_text)
        customViewContainer = view.findViewById(R.id.custom_view_container)

        setupWebView()
        loadAgenda()
    }

    private fun setupWebView() {
        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            loadWithOverviewMode = true
            useWideViewPort = true
            setSupportZoom(false)
            builtInZoomControls = false
            displayZoomControls = false
            mediaPlaybackRequiresUserGesture = false
            // La Agenda solo necesita HTTPS y almacenamiento web; no necesita abrir archivos locales.
            allowFileAccess = false
            allowContentAccess = false
            cacheMode = WebSettings.LOAD_DEFAULT

            javaScriptCanOpenWindowsAutomatically = false
            setSupportMultipleWindows(false)
        }

        webView.webViewClient = object : WebViewClient() {

            override fun onPageFinished(view: WebView?, url: String?) {
                if (!_progressBarRef.isInitialized || !_errorTextRef.isInitialized) return
                val blockPopupsScript = """
                    (function() {
                        window.open = function() { 
                            console.log('Popup bloqueado');
                            return null; 
                        };
                        window.alert = function() { return null; };
                        window.confirm = function() { return false; };
                        window.prompt = function() { return null; };
                        
                        var originalAppendChild = document.body.appendChild;
                        document.body.appendChild = function(element) {
                            if (element.tagName === 'IFRAME') {
                                var src = element.src || '';
                                if (src.includes('ads') || src.includes('popup') || 
                                    src.includes('adservice') || src.includes('doubleclick') ||
                                    src.includes('googlesyndication')) {
                                    console.log('iframe publicitario bloqueado');
                                    return null;
                                }
                            }
                            return originalAppendChild.call(this, element);
                        };
                        
                        setTimeout(function() {
                            var iframes = document.querySelectorAll('iframe');
                            for(var i = 0; i < iframes.length; i++) {
                                var src = iframes[i].src;
                                if (src.includes('ads') || src.includes('popup') || 
                                    src.includes('adservice') || src.includes('doubleclick')) {
                                    iframes[i].remove();
                                }
                            }
                        }, 2000);
                    })();
                """.trimIndent()
                view?.loadUrl("javascript:$blockPopupsScript")

                val ensureButtonScript = """
                    (function() {
                        var btn = document.getElementById('fullscreen');
                        if (btn && !btn._patched) {
                            btn._patched = true;
                            btn.addEventListener('click', function(e) {
                                e.preventDefault();
                                e.stopPropagation();
                                if (window.AgendaFullscreen) {
                                    if (window.AgendaFullscreen.isFullscreen && window.AgendaFullscreen.isFullscreen()) {
                                        window.AgendaFullscreen.exit();
                                    } else {
                                        window.AgendaFullscreen.enter();
                                    }
                                }
                                return false;
                            });
                        }
                    })();
                """.trimIndent()
                view?.loadUrl("javascript:$ensureButtonScript")
                progressBar.visibility = View.GONE
            }

            override fun onReceivedError(view: WebView?, errorCode: Int, description: String?, failingUrl: String?) {
                if (!_progressBarRef.isInitialized || !_errorTextRef.isInitialized) return
                errorText.text = "Error al cargar la agenda: $description"
                errorText.visibility = View.VISIBLE
                progressBar.visibility = View.GONE
            }

            override fun shouldOverrideUrlLoading(
                view: WebView?,
                request: android.webkit.WebResourceRequest?
            ): Boolean {
                request ?: return true
                // Las subsolicitudes (iframes de transmisión) pertenecen al contenido; la lista
                // blanca se aplica solo a la navegación principal que podría reemplazar la Agenda.
                if (!request.isForMainFrame) return false
                return shouldBlockAgendaNavigation(request.url.toString())
            }

            @Suppress("DEPRECATION")
            override fun shouldOverrideUrlLoading(view: WebView?, url: String?): Boolean {
                return shouldBlockAgendaNavigation(url)
            }
        }

        webView.addJavascriptInterface(AgendaFullscreenInterface(), "AgendaFullscreen")

        webView.webChromeClient = object : WebChromeClient() {
            override fun onCreateWindow(
                view: WebView?,
                isDialog: Boolean,
                isUserGesture: Boolean,
                resultMsg: android.os.Message?
            ): Boolean {
                android.util.Log.d("AgendaFragment", "Nueva ventana bloqueada")
                return false
            }

            override fun onShowCustomView(view: View?, callback: CustomViewCallback?) {
                if (isInFullscreen) {
                    callback?.onCustomViewHidden()
                    return
                }

                isInFullscreen = true
                customView = view
                originalOrientation = activity?.requestedOrientation ?: 0

                mainHandler.post {
                    if (this@AgendaFragment.view != null && _customViewContainerRef.isInitialized) enterFullscreen()
                    else callback?.onCustomViewHidden()
                }
            }

            override fun onHideCustomView() {
                if (!isInFullscreen) return

                mainHandler.post {
                    if (view != null && _customViewContainerRef.isInitialized) exitFullscreen()
                }
            }

            override fun onProgressChanged(view: WebView?, newProgress: Int) {
                if (!_progressBarRef.isInitialized || !_errorTextRef.isInitialized) return
                if (newProgress < 100) {
                    progressBar.visibility = View.VISIBLE
                    errorText.visibility = View.GONE
                } else {
                    progressBar.visibility = View.GONE
                }
            }

            override fun onJsAlert(view: WebView?, url: String?, message: String?, result: android.webkit.JsResult?): Boolean {
                result?.confirm()
                return true
            }

            override fun onJsConfirm(view: WebView?, url: String?, message: String?, result: android.webkit.JsResult?): Boolean {
                result?.confirm()
                return true
            }
        }
    }

    private fun enterFullscreen() {
        isInFullscreen = true

        // Ocultar la UI de la app y retirar los márgenes del shell para que el vídeo sí ocupe toda la pantalla.
        activity?.window?.addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN)
        (activity as? AppCompatActivity)?.supportActionBar?.hide()
        activity?.findViewById<View>(R.id.bottom_navigation)?.visibility = View.GONE
        activity?.findViewById<View>(R.id.side_menu)?.visibility = View.GONE
        activity?.findViewById<View>(R.id.header_container)?.visibility = View.GONE
        activity?.findViewById<View>(R.id.logo_image)?.visibility = View.GONE
        activity?.findViewById<View>(R.id.main_container)?.let { main ->
            (main.layoutParams as? android.widget.FrameLayout.LayoutParams)?.let { params ->
                params.topMargin = 0
                params.marginStart = 0
                main.layoutParams = params
            }
        }

        // Cambiar orientación
        activity?.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE

        // Mostrar contenedor personalizado
        customViewContainer.visibility = View.VISIBLE
        customView?.let { customViewContainer.addView(it) }
        webView.visibility = View.GONE
    }

    private fun exitFullscreen() {
        isInFullscreen = false

        // Restaurar UI de la app
        activity?.window?.clearFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN)
        (activity as? AppCompatActivity)?.supportActionBar?.show()

        // Restaurar la geometría normal del shell y la navegación correspondiente al dispositivo.
        val isTV = activity?.let { DeviceHelper.isTV(it) } == true
        activity?.findViewById<View>(R.id.bottom_navigation)?.visibility = if (isTV) View.GONE else View.VISIBLE
        activity?.findViewById<View>(R.id.side_menu)?.visibility = if (isTV) View.VISIBLE else View.GONE
        activity?.findViewById<View>(R.id.header_container)?.visibility = View.VISIBLE
        activity?.findViewById<View>(R.id.logo_image)?.visibility = View.VISIBLE
        activity?.findViewById<View>(R.id.main_container)?.let { main ->
            (main.layoutParams as? android.widget.FrameLayout.LayoutParams)?.let { params ->
                params.topMargin = (64 * resources.displayMetrics.density + 0.5f).toInt()
                params.marginStart = if (isTV) (72 * resources.displayMetrics.density + 0.5f).toInt() else 0
                main.layoutParams = params
            }
        }

        // Restaurar orientación
        activity?.requestedOrientation = originalOrientation

        // Restaurar WebView
        customViewContainer.removeAllViews()
        customViewContainer.visibility = View.GONE
        webView.visibility = View.VISIBLE

        customView = null
    }

    inner class AgendaFullscreenInterface {
        @android.webkit.JavascriptInterface
        fun enter() {
            activity?.runOnUiThread {
                if (view != null && _customViewContainerRef.isInitialized && !isInFullscreen) {
                    enterFullscreen()
                }
            }
        }

        @android.webkit.JavascriptInterface
        fun exit() {
            activity?.runOnUiThread {
                if (view != null && _customViewContainerRef.isInitialized && isInFullscreen) {
                    exitFullscreen()
                }
            }
        }

        @android.webkit.JavascriptInterface
        fun isFullscreen(): Boolean {
            return isInFullscreen
        }
    }

    private fun shouldBlockAgendaNavigation(url: String?): Boolean {
        if (AgendaNavigationPolicy.isAllowedMainFrameUrl(url, BuildConfig.WEB_BASE_URL)) return false
        android.util.Log.d(
            "AgendaFragment",
            "Navegación principal bloqueada para host ${StreamUtils.hostForLog(url.orEmpty())}"
        )
        return true
    }

    private fun loadAgenda() {
        progressBar.visibility = View.VISIBLE
        errorText.visibility = View.GONE
        webView.loadUrl(BuildConfig.WEB_BASE_URL.trimEnd('/') + "/agenda")
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        if (isInFullscreen) {
            activity?.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
        }
    }

    override fun onDestroyView() {
        // These delayed transitions and JavaScript callbacks must not touch a new/destroyed view.
        mainHandler.removeCallbacksAndMessages(null)
        if (isInFullscreen && _webViewRef.isInitialized && _customViewContainerRef.isInitialized) {
            exitFullscreen()
        }

        if (_webViewRef.isInitialized) {
            webView.apply {
                stopLoading()
                removeJavascriptInterface("AgendaFullscreen")
                webViewClient = WebViewClient()
                webChromeClient = WebChromeClient()
                (parent as? ViewGroup)?.removeView(this)
                onPause()
                removeAllViews()
                destroy()
            }
        }
        customView = null
        isInFullscreen = false
        viewReferences.forEach { it.clear() }
        super.onDestroyView()
    }
}