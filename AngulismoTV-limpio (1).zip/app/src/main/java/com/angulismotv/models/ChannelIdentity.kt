package com.angulismotv.models

/**
 * Identidad lógica de una señal. La URL/tipo de reproducción tienen prioridad sobre
 * el logo, que puede repetirse o cambiar entre actualizaciones del catálogo.
 */
object ChannelIdentity {
    fun key(channel: Channel): String {
        val streamUrl = channel.streamUrl?.trim().orEmpty()
        val streamType = channel.streamType?.trim()?.lowercase().orEmpty()
        if (streamUrl.isNotEmpty()) return "stream|$streamType|$streamUrl"

        val options = channel.options.orEmpty()
            .joinToString("\u001e") { option ->
                "${option.streamType.trim().lowercase()}\u001f${option.iframe.trim()}"
            }
        if (options.isNotEmpty()) return "options|${channel.name.trim().lowercase()}|$options"

        // Canales sin URL ni opciones: último recurso para datos incompletos.
        return "fallback|${channel.name.trim().lowercase()}|${channel.logo.trim()}|${channel.category.trim().lowercase()}"
    }

    fun same(first: Channel, second: Channel): Boolean = key(first) == key(second)
}
