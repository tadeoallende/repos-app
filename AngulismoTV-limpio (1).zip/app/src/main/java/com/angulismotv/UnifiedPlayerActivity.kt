package com.angulismotv

import android.content.pm.ActivityInfo
import android.content.res.Configuration
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.Editable
import android.text.TextWatcher
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.OrientationEventListener
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import android.webkit.WebView
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.SeekBar
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.exoplayer2.C
import com.google.android.exoplayer2.ExoPlayer
import com.google.android.exoplayer2.PlaybackException
import com.google.android.exoplayer2.Player
import com.google.android.exoplayer2.Tracks
import com.google.android.exoplayer2.audio.AudioAttributes
import com.google.android.exoplayer2.ui.PlayerView
import com.angulismotv.adapters.SideChannelsAdapter
import com.angulismotv.player.PlayerAudioDiagnostics
import com.angulismotv.player.PlayerAudioDiagnosticPolicy
import com.angulismotv.player.CastController
import com.angulismotv.player.ChannelNumberEntryController
import com.angulismotv.player.ChannelOptionFallbackController
import com.angulismotv.player.ChannelZappingQueue
import com.angulismotv.player.TvRemoteKeyController
import com.angulismotv.player.SidePanelLayoutPolicy
import com.angulismotv.player.TvSidePanelFocusController
import com.angulismotv.player.PlayerChannelCatalog
import com.angulismotv.player.CastStream
import com.angulismotv.player.InlinePlayerHandoff
import com.angulismotv.player.InlineSessionReturnPolicy
import com.angulismotv.player.FullscreenOrientationPolicy
import com.angulismotv.player.PlaybackRecoveryController
import com.angulismotv.player.PlayerTimelineController
import com.angulismotv.player.StreamUtils
import com.angulismotv.player.StreamMediaSourceFactory
import com.angulismotv.player.StreamUrlPolicy
import com.angulismotv.player.WebViewPlayerBridge
import com.angulismotv.player.WebViewPlaybackController
import com.angulismotv.player.applyPlayerSettings
import com.angulismotv.utils.NetworkUtils
import com.angulismotv.utils.loadChannelLogo
import com.angulismotv.adapters.CategoriesAdapter
import com.angulismotv.adapters.ChannelsAdapter
import com.angulismotv.models.Channel
import com.angulismotv.models.ChannelIdentity
import com.angulismotv.data.FavoritesStore
import com.angulismotv.data.ChannelCatalog
import com.angulismotv.models.StreamType
import com.angulismotv.utils.DeviceHelper
import com.angulismotv.utils.UiDimensions

private const val PORTRAIT_EXIT_DEBOUNCE_MS = 550L

class UnifiedPlayerActivity : AppCompatActivity() {

    // ==================== VIEWS ====================
    private lateinit var btnMenu: ImageButton
    private lateinit var playerView: PlayerView
    private lateinit var playerContainer: FrameLayout
    private lateinit var webView: WebView
    private lateinit var webViewTouchBlocker: View
    private lateinit var progressBar: ProgressBar
    private lateinit var errorText: TextView
    private lateinit var controlsOverlay: View
    private lateinit var bottomControls: View
    private lateinit var playerRemoteHelp: TextView
    private lateinit var btnRewind: ImageButton
    private lateinit var btnForward: ImageButton
    private lateinit var btnPlayPause: ImageButton
    private lateinit var btnClose: ImageButton
    private lateinit var btnOptions: ImageButton
    private lateinit var btnAudioInfo: ImageButton
    private lateinit var btnReloadStream: ImageButton
    private lateinit var btnFavoriteChannel: ImageButton
    private lateinit var favoritesStore: FavoritesStore
    private lateinit var mediaRouteButton: ImageButton
    private lateinit var channelLogo: ImageView
    private lateinit var channelNameText: TextView
    private lateinit var channelCategoryText: TextView
    private lateinit var playerControlsMainRow: LinearLayout
    private lateinit var playerActionGroupsRow: LinearLayout
    private lateinit var playerChannelIdentity: LinearLayout
    private lateinit var playerTransportControls: LinearLayout
    private lateinit var playerUtilityControls: LinearLayout
    private lateinit var playerTimelineContainer: View
    private lateinit var playerSeekBar: SeekBar
    private lateinit var playerTimeCurrent: TextView
    private lateinit var playerTimeDuration: TextView
    private lateinit var timelineController: PlayerTimelineController

    // Panel lateral
    private lateinit var channelsPanelContainer: LinearLayout
    private lateinit var panelMenuColumn: LinearLayout
    private lateinit var panelContentColumn: LinearLayout
    private lateinit var channelsList: RecyclerView
    private lateinit var sideChannelsAdapter: SideChannelsAdapter
    private lateinit var btnClosePanel: ImageButton
    private lateinit var contentTitle: TextView
    private lateinit var channelsCountText: TextView
    private lateinit var btnAllChannels: LinearLayout
    private lateinit var allChannelsMarker: View
    private lateinit var allChannelsIcon: ImageView
    private lateinit var allChannelsText: TextView

    // Búsqueda
    private lateinit var btnSearchTrigger: LinearLayout
    private lateinit var searchTriggerText: TextView
    private lateinit var searchInputContainer: View
    private lateinit var menuSearchInput: EditText
    private lateinit var menuSearchResults: RecyclerView
    private lateinit var searchEmptyText: TextView
    private lateinit var searchAdapter: ChannelsAdapter

    // Categorías
    private lateinit var menuCategoriesList: RecyclerView
    private lateinit var categoriesAdapter: CategoriesAdapter

    // Minimal channel identity shown briefly while zapping on TV and mobile.
    private var zappingOverlay: LinearLayout? = null
    private var zappingLogo: ImageView? = null
    private var zappingChannelName: TextView? = null

    // ==================== STATE ====================
    private var exoPlayer: ExoPlayer? = null
    private var playerListener: Player.Listener? = null
    private var inlineSessionReturned = false
    private var inlineWebViewOrigin: InlinePlayerHandoff.Session? = null
    private var reuseInlineWebViewOnLoad = false
    private var inlineWebViewReturnedToFragment = false
    private lateinit var webBridge: WebViewPlayerBridge
    private lateinit var cast: CastController
    private var isTV = false
    private var currentChannel: Channel? = null
    private var controlsVisible = false
    // Conserva el último control enfocado para que el mando no vuelva siempre al inicio.
    private var lastFocusedControlId: Int = View.NO_ID
    private var isPanelOpen = false
    private var currentIsLive = false
    private var streamIsLive = false
    private var currentStreamUrl: String = ""
    private var currentStreamType: String = StreamType.AUTO
    private var isZapping = false
    private val pendingChannelZaps = ChannelZappingQueue()
    private var currentCategory = "todos"
    private var isSearchActive = false

    // Entrada numérica desde el mando; la gestión del buffer, overlay y timeout está aislada.
    private lateinit var channelNumberOverlay: TextView
    private lateinit var channelNumberEntryController: ChannelNumberEntryController
    private lateinit var tvRemoteKeyController: TvRemoteKeyController
    private lateinit var sidePanelFocusController: TvSidePanelFocusController

    // RECONEXION
    private var playerGeneration = 0
    private var lastAudioError: String? = null
    private var lastAudioErrorHost: String? = null
    private var audioNoticeGeneration = -1
    // Channels
    private var allChannels: List<Channel> = emptyList()
    private var currentChannelIndex: Int = 0
    private var currentFilteredChannels: List<Channel> = emptyList()

    // Handlers
    private val mainHandler = Handler(Looper.getMainLooper())
    private val optionFallbackController = ChannelOptionFallbackController(
        handler = mainHandler,
        isGenerationCurrent = { generation -> generation == playerGeneration },
        isZapping = { isZapping },
        currentChannel = { currentChannel },
        currentOptionIndex = { currentOptionIndex },
        playerProvider = { exoPlayer },
        releasePlayer = ::releasePlayer,
        tryOption = ::tryOption,
        showError = ::showError
    )
    private var physicalOrientationListener: OrientationEventListener? = null
    private val fullscreenOrientationPolicy = FullscreenOrientationPolicy()
    private var portraitExitPending = false
    private var lastPhysicalOrientationDegrees = OrientationEventListener.ORIENTATION_UNKNOWN
    private val exitFullscreenAfterPortraitRunnable = Runnable {
        portraitExitPending = false
        if (isFinishing || isDestroyed) return@Runnable
        if (fullscreenOrientationPolicy.shouldExitToInline(lastPhysicalOrientationDegrees)) {
            // Retornar a la pantalla integrada después de una rotación física real a vertical.
            finish()
            overridePendingTransition(0, 0)
        }
    }
    private val recoveryDelegate = lazy(LazyThreadSafetyMode.NONE) {
        PlaybackRecoveryController(
            handler = mainHandler,
            isGenerationCurrent = { generation -> generation == playerGeneration },
            isZapping = { isZapping },
            playerProvider = { exoPlayer },
            streamProvider = { currentStreamUrl to currentStreamType },
            networkAvailable = { NetworkUtils.isAvailable(this) },
            releasePlayer = ::releasePlayer,
            replayStream = ::showExoPlayer,
            showError = ::showError,
            showLoading = {
                progressBar.visibility = View.VISIBLE
                errorText.visibility = View.GONE
            }
        )
    }
    private val recovery by recoveryDelegate
    private var hideControlsRunnable: Runnable? = null
    private var zapRunnable: Runnable? = null
    private var stableStreamRunnable: Runnable? = null
    private lateinit var webViewPlaybackController: WebViewPlaybackController

    private lateinit var insetsController: WindowInsetsControllerCompat

    // ==================== LIFECYCLE ====================

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (!DeviceHelper.isTV(this)) enableImmersiveFullscreen()
        setContentView(R.layout.activity_unified_player)

        isTV = DeviceHelper.isTV(this)
        bindViews()
        channelNumberEntryController = ChannelNumberEntryController(
            handler = mainHandler,
            overlay = channelNumberOverlay,
            channelCountProvider = { allChannels.size },
            canCommit = { !isZapping },
            onNumberConfirmed = ::selectChannelByNumber
        )
        timelineController = PlayerTimelineController(
            handler = mainHandler,
            container = playerTimelineContainer,
            seekBar = playerSeekBar,
            currentTime = playerTimeCurrent,
            durationTime = playerTimeDuration,
            playerProvider = { exoPlayer },
            isTimelineEnabled = { !isTV && currentStreamType != StreamType.IFRAME && controlsVisible },
            shouldContinueUpdates = { controlsVisible && exoPlayer != null }
        )
        updateControlLayoutForConfiguration()
        // En móvil, el fullscreen forzado permanece en horizontal. No se debe desbloquear
        // a FULL_SENSOR al llegar a landscape: si el teléfono aún está físicamente en vertical,
        // Android vuelve a girar inmediatamente la Activity. El regreso al mini-player se detecta
        // por orientación física real con OrientationEventListener.
        val inlineMobileFullscreen = !isTV &&
            intent.getBooleanExtra("from_inline_player", false) &&
            intent.getBooleanExtra("force_landscape_fullscreen", false)
        requestedOrientation = when {
            isTV -> ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
            inlineMobileFullscreen -> ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
            else -> ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
        }
        setupPhysicalOrientationListener(inlineMobileFullscreen)

        webBridge = WebViewPlayerBridge(
            webView = webView,
            handler = mainHandler,
            isIframeActive = { currentStreamType == StreamType.IFRAME },
            onStateChanged = ::updateWebViewControls
        )
        webViewPlaybackController = WebViewPlaybackController(
            webView = webView,
            touchBlocker = webViewTouchBlocker,
            playerView = playerView,
            playerContainer = playerContainer,
            progressBar = progressBar,
            controlsOverlay = controlsOverlay,
            bottomControls = bottomControls,
            bridge = webBridge,
            isTV = { isTV },
            currentStreamType = { currentStreamType },
            updateControlsVisibility = ::updateControlsVisibility,
            lockWebViewFocus = ::lockWebViewFocus,
            showControlsTemporarily = ::showControlsTemporarily,
            onMainFrameError = ::handleWebViewMainFrameError
        )
        cast = CastController(
            activity = this,
            button = mediaRouteButton,
            handler = mainHandler,
            currentStream = {
                if (currentStreamUrl.isEmpty()) null
                else {
                    // Antes de STATE_READY, ExoPlayer todavía puede no saber si una lista HLS/DASH
                    // es en vivo o bajo demanda. Dejarlo indefinido conserva el valor por defecto
                    // de Cast para streams live, en vez de marcar por error el arranque como VOD.
                    val liveStatus: Boolean? = when {
                        currentIsLive || streamIsLive -> true
                        exoPlayer?.playbackState == Player.STATE_READY -> false
                        else -> null
                    }
                    CastStream(currentStreamUrl, currentStreamType, currentChannel?.name ?: "Canal", liveStatus)
                }
            },
            onCastStarted = { exoPlayer?.pause() },
            onStatusChanged = { message ->
                mediaRouteButton.contentDescription = message
                if (isTV) playerRemoteHelp.text = message
                else android.widget.Toast.makeText(this, message, android.widget.Toast.LENGTH_SHORT).show()
            }
        )
        cast.setup(isTV)
        setupWebViewForTV()
        setupWebViewTouchBlocker()
        setupSidePanel()
        setupControls()
        setupTvRemoteKeyController()
        loadChannelData()
    }

    private var resumePlaybackAfterPause = false

    override fun onResume() {
        super.onResume()
        physicalOrientationListener?.enable()
        // Si la Activity se reanudó después de una pausa justo cuando el teléfono ya estaba
        // vertical, no dependemos de que el sensor emita un evento adicional para completar el regreso.
        if (fullscreenOrientationPolicy.shouldExitToInline(lastPhysicalOrientationDegrees)) {
            schedulePortraitExitCheck()
        }
        if (!isTV) enableImmersiveFullscreen()
        cast.startDiscovery()
        webView.onResume()
        if (resumePlaybackAfterPause && !isZapping) exoPlayer?.play()
        resumePlaybackAfterPause = false
    }

    override fun onPause() {
        // Pausar el sensor mientras la Activity no está visible; al volver se comprobará de nuevo
        // la orientación física actual sin perder el hecho de que ya se había girado a landscape.
        physicalOrientationListener?.disable()
        cancelPortraitExitCheck()
        // Recordar la intención de reproducción antes de pausar o transferir la sesión.
        resumePlaybackAfterPause = !isZapping && exoPlayer?.playWhenReady == true
        super.onPause()
        if (isFinishing && intent.getBooleanExtra("from_inline_player", false)) {
            returnSessionToInline()
        } else if (!isZapping) {
            exoPlayer?.pause()
        }
        cast.stopDiscovery()
        webView.onPause()
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus && !isTV) enableImmersiveFullscreen()
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        updateControlLayoutForConfiguration()
        // No desbloquear a FULL_SENSOR aquí: la configuración visible puede cambiar a landscape
        // mientras el dispositivo sigue físicamente en portrait. El sensor dedicado distingue
        // ese giro impuesto del posterior regreso físico a vertical.
        if (!isTV) enableImmersiveFullscreen()
    }

    private fun setupPhysicalOrientationListener(enabledForThisActivity: Boolean) {
        if (!enabledForThisActivity) return
        physicalOrientationListener = object : OrientationEventListener(this) {
            override fun onOrientationChanged(orientation: Int) {
                if (isFinishing || isDestroyed) return
                lastPhysicalOrientationDegrees = orientation
                when (fullscreenOrientationPolicy.classify(orientation)) {
                    FullscreenOrientationPolicy.Position.PORTRAIT_AFTER_LANDSCAPE -> schedulePortraitExitCheck()
                    // Un movimiento intermedio o una lectura desconocida cancela la salida pendiente;
                    // solo una postura vertical estable puede cerrar el fullscreen.
                    FullscreenOrientationPolicy.Position.LANDSCAPE,
                    FullscreenOrientationPolicy.Position.PORTRAIT_BEFORE_LANDSCAPE,
                    FullscreenOrientationPolicy.Position.TRANSITION,
                    FullscreenOrientationPolicy.Position.UNKNOWN -> cancelPortraitExitCheck()
                }
            }
        }.also { listener ->
            if (!listener.canDetectOrientation()) {
                listener.disable()
                physicalOrientationListener = null
            }
        }
    }

    private fun schedulePortraitExitCheck() {
        if (portraitExitPending || isFinishing || isDestroyed) return
        portraitExitPending = true
        // Filtrar lecturas intermedias del sensor antes de salir.
        mainHandler.postDelayed(exitFullscreenAfterPortraitRunnable, PORTRAIT_EXIT_DEBOUNCE_MS)
    }

    private fun cancelPortraitExitCheck() {
        mainHandler.removeCallbacks(exitFullscreenAfterPortraitRunnable)
        portraitExitPending = false
    }

    /** Adapta el overlay al ancho disponible: en vertical los datos y acciones se apilan. */
    private fun updateControlLayoutForConfiguration() {
        if (!::playerControlsMainRow.isInitialized) return
        val compactPortrait = !isTV && resources.configuration.orientation == Configuration.ORIENTATION_PORTRAIT
        val identityParams = playerChannelIdentity.layoutParams as LinearLayout.LayoutParams
        val actionParams = playerActionGroupsRow.layoutParams as LinearLayout.LayoutParams
        val transportParams = playerTransportControls.layoutParams as LinearLayout.LayoutParams
        val utilityParams = playerUtilityControls.layoutParams as LinearLayout.LayoutParams

        if (compactPortrait) {
            playerControlsMainRow.orientation = LinearLayout.VERTICAL
            identityParams.width = ViewGroup.LayoutParams.MATCH_PARENT
            identityParams.weight = 0f
            identityParams.marginEnd = 0
            playerChannelIdentity.layoutParams = identityParams
            actionParams.width = ViewGroup.LayoutParams.MATCH_PARENT
            actionParams.height = ViewGroup.LayoutParams.WRAP_CONTENT
            playerActionGroupsRow.layoutParams = actionParams
            transportParams.marginStart = 0
            playerTransportControls.layoutParams = transportParams
            utilityParams.marginStart = UiDimensions.px(resources, R.dimen.player_controls_group_margin_compact)
            playerUtilityControls.layoutParams = utilityParams
            bottomControls.setPadding(
                UiDimensions.px(resources, R.dimen.player_controls_padding_horizontal_compact),
                UiDimensions.px(resources, R.dimen.player_controls_padding_top),
                UiDimensions.px(resources, R.dimen.player_controls_padding_horizontal_compact),
                UiDimensions.px(resources, R.dimen.player_controls_padding_bottom)
            )
        } else {
            playerControlsMainRow.orientation = LinearLayout.HORIZONTAL
            identityParams.width = 0
            identityParams.weight = 1f
            identityParams.marginEnd = 0
            playerChannelIdentity.layoutParams = identityParams
            actionParams.width = ViewGroup.LayoutParams.WRAP_CONTENT
            actionParams.height = ViewGroup.LayoutParams.WRAP_CONTENT
            playerActionGroupsRow.layoutParams = actionParams
            transportParams.marginStart = UiDimensions.px(resources, R.dimen.player_controls_group_margin_wide)
            playerTransportControls.layoutParams = transportParams
            utilityParams.marginStart = UiDimensions.px(resources, R.dimen.player_controls_group_margin_wide)
            playerUtilityControls.layoutParams = utilityParams
            bottomControls.setPadding(
                UiDimensions.px(resources, R.dimen.player_controls_padding_horizontal_wide),
                UiDimensions.px(resources, R.dimen.player_controls_padding_top),
                UiDimensions.px(resources, R.dimen.player_controls_padding_horizontal_wide),
                UiDimensions.px(resources, R.dimen.player_controls_padding_bottom)
            )
        }
    }

    override fun onStop() {
        super.onStop()
        exoPlayer?.pause()
    }

    override fun onDestroy() {
        physicalOrientationListener?.disable()
        physicalOrientationListener = null
        cancelPortraitExitCheck()
        pendingChannelZaps.clear()
        isZapping = false
        playerGeneration++
        if (::webViewPlaybackController.isInitialized) webViewPlaybackController.invalidatePendingLoad()
        if (::channelNumberEntryController.isInitialized) channelNumberEntryController.dispose()
        // No crear el controlador de recuperación por primera vez durante onDestroy().
        if (recoveryDelegate.isInitialized()) recovery.dispose()
        optionFallbackController.dispose()
        mainHandler.removeCallbacksAndMessages(null)
        stopTimelineUpdates()
        if (isFinishing && intent.getBooleanExtra("from_inline_player", false) && !inlineSessionReturned) {
            returnSessionToInline()
        }
        if (::cast.isInitialized) cast.dispose()
        releasePlayer()
        if (::webBridge.isInitialized) {
            webBridge.stopMonitor()
            webBridge.detach()
        }
        if (::webViewPlaybackController.isInitialized) {
            webViewPlaybackController.dispose(destroyWebView = !inlineWebViewReturnedToFragment)
        }
        super.onDestroy()
    }

    override fun onBackPressed() {
        if (!isTV) super.onBackPressed()
    }

    // ==================== BIND VIEWS ====================

    private fun bindViews() {
        btnMenu = findViewById(R.id.btn_menu)
        playerView = findViewById(R.id.player_view)
        playerContainer = findViewById(R.id.player_container)
        if (isTV) {
            // Superficie de foco de respaldo cuando el stream se reproduce dentro de WebView.
            playerContainer.isFocusable = true
            playerContainer.isFocusableInTouchMode = true
        }
        val webViewPlaceholder = findViewById<WebView>(R.id.web_view)
        val handedOffWebViewSession = if (intent.getBooleanExtra("reuse_inline_webview_session", false)) {
            InlinePlayerHandoff.takePendingWebViewForFullscreen()
        } else null
        if (handedOffWebViewSession?.webView != null) {
            val parent = webViewPlaceholder.parent as? ViewGroup
            val childIndex = parent?.indexOfChild(webViewPlaceholder) ?: -1
            val activityLayoutParams = webViewPlaceholder.layoutParams
            parent?.removeView(webViewPlaceholder)
            val transferred = handedOffWebViewSession.webView
            (transferred.parent as? ViewGroup)?.removeView(transferred)
            if (parent != null) parent.addView(transferred, childIndex.coerceAtLeast(0), activityLayoutParams)
            runCatching { webViewPlaceholder.stopLoading(); webViewPlaceholder.removeAllViews(); webViewPlaceholder.destroy() }
            webView = transferred
            inlineWebViewOrigin = handedOffWebViewSession
            reuseInlineWebViewOnLoad = true
        } else {
            webView = webViewPlaceholder
        }
        webViewTouchBlocker = findViewById(R.id.web_view_touch_blocker)
        progressBar = findViewById(R.id.progress_bar)
        errorText = findViewById(R.id.error_text)
        controlsOverlay = findViewById(R.id.controls_overlay)
        bottomControls = findViewById(R.id.bottom_controls)
        playerRemoteHelp = findViewById(R.id.player_remote_help)
        playerRemoteHelp.visibility = if (isTV) View.VISIBLE else View.GONE
        btnRewind = findViewById(R.id.btn_rewind)
        btnForward = findViewById(R.id.btn_forward)
        btnPlayPause = findViewById(R.id.btn_play_pause)
        btnClose = findViewById(R.id.btn_close_player)
        btnOptions = findViewById(R.id.btn_options)
        btnAudioInfo = findViewById(R.id.btn_audio_info)
        btnReloadStream = findViewById(R.id.btn_reload_stream)
        btnFavoriteChannel = findViewById(R.id.btn_favorite_channel)
        favoritesStore = FavoritesStore(this)
        mediaRouteButton = findViewById(R.id.media_route_button)
        channelLogo = findViewById(R.id.channel_logo)
        channelNameText = findViewById(R.id.channel_name)
        channelCategoryText = findViewById(R.id.channel_category)
        playerControlsMainRow = findViewById(R.id.player_controls_main_row)
        playerActionGroupsRow = findViewById(R.id.player_action_groups_row)
        playerChannelIdentity = findViewById(R.id.player_channel_identity)
        playerTransportControls = findViewById(R.id.player_transport_controls)
        playerUtilityControls = findViewById(R.id.player_utility_controls)
        playerTimelineContainer = findViewById(R.id.player_timeline_container)
        playerSeekBar = findViewById(R.id.player_seek_bar)
        playerTimeCurrent = findViewById(R.id.player_time_current)
        playerTimeDuration = findViewById(R.id.player_time_duration)
        channelsPanelContainer = findViewById(R.id.channels_panel_container)
        channelsList = findViewById(R.id.channels_list)
        panelMenuColumn = findViewById(R.id.panel_menu_column)
        panelContentColumn = findViewById(R.id.panel_content_column)
        btnClosePanel = findViewById(R.id.btn_close_panel)
        contentTitle = findViewById(R.id.content_title)
        channelsCountText = findViewById(R.id.channels_count)
        btnAllChannels = findViewById(R.id.btn_all_channels)
        allChannelsMarker = findViewById(R.id.all_channels_marker)
        allChannelsIcon = findViewById(R.id.all_channels_icon)
        allChannelsText = findViewById(R.id.all_channels_text)
        btnSearchTrigger = findViewById(R.id.btn_search_trigger)
        searchTriggerText = findViewById(R.id.search_trigger_text)
        searchInputContainer = findViewById(R.id.search_input_container)
        menuSearchInput = findViewById(R.id.menu_search_input)
        menuSearchResults = findViewById(R.id.menu_search_results)
        searchEmptyText = findViewById(R.id.search_empty_text)
        menuCategoriesList = findViewById(R.id.menu_categories_list)

        zappingOverlay = findViewById(R.id.zapping_overlay)
        zappingLogo = findViewById(R.id.zapping_logo)
        zappingChannelName = findViewById(R.id.zapping_channel_name)
        channelNumberOverlay = findViewById(R.id.channel_number_overlay)
    }

    // ==================== FULLSCREEN ====================

    private fun enableImmersiveFullscreen() {
        WindowCompat.setDecorFitsSystemWindows(window, false)
        insetsController = WindowInsetsControllerCompat(window, window.decorView).apply {
            hide(WindowInsetsCompat.Type.systemBars())
            systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        }
        @Suppress("DEPRECATION")
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.R) {
            window.decorView.systemUiVisibility = (
                    View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                            or View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                            or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                            or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                            or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                            or View.SYSTEM_UI_FLAG_FULLSCREEN
                    )
        }
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
    }

    // ==================== WEBVIEW ====================

    private fun setupWebViewForTV() {
        if (!isTV) return
        webView.apply {
            isFocusable = false
            isFocusableInTouchMode = false
            isClickable = false
            isLongClickable = false
            applyPlayerSettings()
        }
    }

    private fun setupWebViewTouchBlocker() {
        webViewTouchBlocker.apply {
            setOnTouchListener { _, event ->
                if (!isTV && event.action == MotionEvent.ACTION_UP) {
                    if (controlsVisible) hideControls() else showControlsTemporarily()
                }
                true
            }
            visibility = View.GONE
        }
    }

    /**
     * Actualiza los controles según el estado del WebView
     */
    private fun updateWebViewControls() {
        runOnUiThread {
            if (currentStreamType == StreamType.IFRAME) {
                if (isTV && webBridge.isControllable) {
                    // TV: Mostrar controles traducidos
                    btnPlayPause.visibility = View.VISIBLE
                    updatePlayPauseButton(webBridge.isPlaying)

                    val showSeek = webBridge.duration > 0
                    btnRewind.visibility = if (showSeek) View.VISIBLE else View.GONE
                    btnForward.visibility = if (showSeek) View.VISIBLE else View.GONE

                    // Habilitar foco para navegación con D-Pad
                    if (isTV) {
                        btnPlayPause.isFocusable = true
                        btnRewind.isFocusable = showSeek
                        btnForward.isFocusable = showSeek
                    }
                } else if (!isTV) {
                    // Móvil: Ocultar controles nativos, usar los del iframe
                    btnPlayPause.visibility = View.GONE
                    btnRewind.visibility = View.GONE
                    btnForward.visibility = View.GONE
                }

                // Actualizar estado de los botones
                btnOptions.visibility = if (hasMultipleOptions()) View.VISIBLE else View.GONE
                btnAudioInfo.visibility = if (exoPlayer != null) View.VISIBLE else View.GONE

                if (isTV) {
                    btnMenu.visibility = View.VISIBLE
                    btnMenu.isFocusable = true
                    btnClose.isFocusable = true
                }
                if (controlsVisible) {
                    bottomControls.visibility = View.VISIBLE
                    bottomControls.bringToFront()
                }
                updateControlFocusOrder()
            }
        }
    }

    // ==================== SIDE PANEL ====================

    private fun setupSidePanel() {
        if (!isTV) return
        sideChannelsAdapter = SideChannelsAdapter(
            onItemClick = { channel, _ -> selectChannelFromSidePanel(channel) },
            channelNumber = { channel -> allChannels.indexOfFirst { ChannelIdentity.same(it, channel) } + 1 }
        )
        categoriesAdapter = CategoriesAdapter { categoryKey -> onCategorySelected(categoryKey) }
        channelsList.apply {
            layoutManager = LinearLayoutManager(this@UnifiedPlayerActivity)
            isFocusable = true
            isFocusableInTouchMode = true
            descendantFocusability = ViewGroup.FOCUS_BEFORE_DESCENDANTS
            adapter = sideChannelsAdapter
        }
        menuCategoriesList.apply {
            layoutManager = LinearLayoutManager(this@UnifiedPlayerActivity)
            adapter = categoriesAdapter
        }
        btnAllChannels.apply {
            isFocusable = true
            isFocusableInTouchMode = true
            isClickable = true
            setOnClickListener { showAllChannels() }
        }
        btnSearchTrigger.apply {
            isFocusable = true
            isFocusableInTouchMode = true
            setOnClickListener { activateSearchMode() }
        }
        btnClosePanel.setOnClickListener { closeSidePanel() }
        setupSearchInput()
        sidePanelFocusController = TvSidePanelFocusController(
            channelsList = channelsList,
            menuSearchResults = menuSearchResults,
            menuSearchInput = menuSearchInput,
            searchEmptyText = searchEmptyText,
            menuCategoriesList = menuCategoriesList,
            btnAllChannels = btnAllChannels,
            btnSearchTrigger = btnSearchTrigger,
            btnClosePanel = btnClosePanel,
            categoriesAdapterProvider = { categoriesAdapter },
            searchAdapterProvider = { searchAdapter },
            isSearchActive = { isSearchActive },
            currentCategory = { currentCategory },
            currentChannel = { currentChannel },
            currentFilteredChannels = { currentFilteredChannels }
        )
    }

    private fun activateSearchMode() {
        isSearchActive = true
        searchInputContainer.visibility = View.VISIBLE
        contentTitle.text = "BUSCAR"
        channelsCountText.text = ""
        categoriesAdapter.clearSelection()
        menuSearchInput.text.clear()
        menuSearchResults.visibility = View.GONE
        searchEmptyText.visibility = View.GONE
        channelsList.visibility = View.VISIBLE
        updateAllChannelsSelection()
        menuSearchInput.post { menuSearchInput.requestFocus() }
    }

    private fun deactivateSearchMode() {
        if (!isSearchActive) return
        isSearchActive = false
        searchInputContainer.visibility = View.GONE
        menuSearchInput.text.clear()
        menuSearchResults.visibility = View.GONE
        searchEmptyText.visibility = View.GONE
        channelsList.visibility = View.VISIBLE
        updateContentTitle()
        updateCategoriesList()
        updateChannelsList(scrollToSelected = true)
        updateAllChannelsSelection()
    }

    private fun updateContentTitle() {
        contentTitle.text = if (currentCategory.equals("todos", ignoreCase = true)) {
            "Todos los canales"
        } else {
            formatCategoryLabel(currentCategory)
        }
    }

    private fun setupSearchInput() {
        searchAdapter = ChannelsAdapter(
            onItemClick = { channel, _ ->
                val index = allChannels.indexOfFirst { ChannelIdentity.same(it, channel) }
                if (index != -1) { deactivateSearchMode(); selectChannelFromSidePanel(channel) }
            },
            channelNumber = { channel -> allChannels.indexOfFirst { ChannelIdentity.same(it, channel) } + 1 }
        )
        menuSearchResults.apply {
            layoutManager = LinearLayoutManager(this@UnifiedPlayerActivity)
            adapter = searchAdapter
        }
        menuSearchInput.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: Editable?) {
                val query = s?.toString()?.lowercase()?.trim() ?: ""
                if (query.isNotEmpty()) {
                    val results = ChannelCatalog.searchByName(allChannels, query)
                    searchAdapter.submitList(results)
                    channelsList.visibility = View.GONE
                    menuSearchResults.visibility = if (results.isNotEmpty()) View.VISIBLE else View.GONE
                    searchEmptyText.visibility = if (results.isEmpty()) View.VISIBLE else View.GONE
                    channelsCountText.text = results.size.toString()
                    contentTitle.text = "RESULTADOS: \"$query\""
                } else {
                    searchAdapter.submitList(emptyList())
                    menuSearchResults.visibility = View.GONE
                    searchEmptyText.visibility = View.GONE
                    channelsList.visibility = View.VISIBLE
                    contentTitle.text = "BUSCAR"
                    channelsCountText.text = ""
                }
            }
        })
        menuSearchInput.setOnEditorActionListener { _, actionId, _ -> actionId == EditorInfo.IME_ACTION_SEARCH }
    }

    private fun updateCategoriesList() {
        if (!::categoriesAdapter.isInitialized || allChannels.isEmpty()) return
        // «Lista de canales» es una acción fija; la lista dinámica solo contiene categorías reales.
        val uniqueCategories = ChannelCatalog.uniqueCategories(
            channels = allChannels,
            trimValues = true,
            ignoreCase = true,
            sortIgnoreCase = true
        )
        val items = uniqueCategories.map { key ->
            CategoriesAdapter.CategoryItem(
                key = key,
                name = formatCategoryLabel(key),
                count = allChannels.count { it.category.equals(key, ignoreCase = true) }
            )
        }
        val selected = if (currentCategory.equals("todos", ignoreCase = true)) "" else currentCategory
        categoriesAdapter.submitList(items, selected)
        updateAllChannelsSelection()
    }

    private fun updateChannelsList(scrollToSelected: Boolean = false) {
        if (!::sideChannelsAdapter.isInitialized) return
        currentFilteredChannels = ChannelCatalog.filterByCategory(
            channels = allChannels,
            category = currentCategory,
            ignoreCase = true
        )
        val selectedChannel = currentChannel
        val selectedInFiltered = currentFilteredChannels.indexOfFirst { selectedChannel != null && ChannelIdentity.same(it, selectedChannel) }
        sideChannelsAdapter.submitList(currentFilteredChannels, selectedInFiltered)
        channelsCountText.text = "${currentFilteredChannels.size}"
        if (scrollToSelected && selectedInFiltered >= 0) {
            channelsList.post { (channelsList.layoutManager as? LinearLayoutManager)?.scrollToPositionWithOffset(selectedInFiltered, 0) }
        }
    }

    private fun onCategorySelected(categoryKey: String) {
        deactivateSearchMode()
        currentCategory = categoryKey
        updateContentTitle()
        updateCategoriesList()
        updateChannelsList(scrollToSelected = true)
        updateAllChannelsSelection()
        // Entra en la lista de canales de forma determinista: canal actual si pertenece
        // a esta categoría; de lo contrario, primer canal disponible.
        moveFocusToChannelsList()
    }

    /** Selecciona la vista completa de canales, acción fija equivalente a «Lista de canales». */
    private fun showAllChannels() {
        if (isSearchActive) deactivateSearchMode()
        currentCategory = "todos"
        updateContentTitle()
        updateCategoriesList()
        updateChannelsList(scrollToSelected = true)
        updateAllChannelsSelection()
        moveFocusToChannelsList()
    }

    private fun updateAllChannelsSelection() {
        if (!::btnAllChannels.isInitialized) return
        val selected = !isSearchActive && currentCategory.equals("todos", ignoreCase = true)
        btnAllChannels.isSelected = selected
        btnAllChannels.refreshDrawableState()
        btnAllChannels.setBackgroundResource(
            if (selected) R.drawable.side_category_item_selected
            else R.drawable.side_menu_item_bg
        )
        allChannelsMarker.visibility = if (selected) View.VISIBLE else View.INVISIBLE
        val accent = androidx.core.content.ContextCompat.getColor(this, R.color.accent)
        val primary = androidx.core.content.ContextCompat.getColor(this, R.color.text_primary)
        val secondary = androidx.core.content.ContextCompat.getColor(this, R.color.text_secondary)
        allChannelsIcon.setColorFilter(if (selected) accent else secondary)
        allChannelsText.setTextColor(if (selected) accent else primary)
        btnAllChannels.contentDescription = if (selected) {
            "Lista de canales, seleccionada"
        } else {
            "Lista de canales"
        }
    }

    /** Convierte «estilo-de-vida» en «Estilo de vida» sin alterar la clave de categoría. */
    private fun formatCategoryLabel(raw: String): String = raw
        .trim()
        .replace('-', ' ')
        .replace('_', ' ')
        .split(Regex("\\s+"))
        .filter { it.isNotBlank() }
        .joinToString(" ") { word -> word.lowercase().replaceFirstChar { it.uppercase() } }

    private fun handleBackInPanel(): Boolean {
        return when {
            isSearchActive && menuSearchInput.text.isNotEmpty() -> {
                menuSearchInput.text.clear()
                menuSearchInput.post { menuSearchInput.requestFocus() }
                true
            }
            isSearchActive -> { deactivateSearchMode(); btnSearchTrigger.post { btnSearchTrigger.requestFocus() }; true }
            else -> { closeSidePanel(); true }
        }
    }

    // ==================== CONTROLS ====================

    private fun setupControls() {
        btnClose.setOnClickListener { finish() }
        playerSeekBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onStartTrackingTouch(seekBar: SeekBar?) {
                timelineController.onStartTracking()
                resetAutoHideTimer()
            }

            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                timelineController.onProgressChanged(progress, fromUser)
            }

            override fun onStopTrackingTouch(seekBar: SeekBar?) {
                timelineController.onStopTracking()
                resetAutoHideTimer()
            }
        })

        // Configurar listeners para controles de WebView (TV)
        btnPlayPause.setOnClickListener {
            if (currentStreamType == StreamType.IFRAME && isTV) {
                webBridge.control("toggle")
                resetAutoHideTimer()
            } else if (currentStreamType != StreamType.IFRAME) {
                togglePlayPause()
                resetAutoHideTimer()
            }
        }

        btnRewind.setOnClickListener {
            if (currentStreamType == StreamType.IFRAME && isTV && webBridge.isControllable) {
                val newTime = (webBridge.currentTime - 10).coerceAtLeast(0)
                webBridge.control("seek", newTime.toDouble())
                resetAutoHideTimer()
            } else if (currentStreamType != StreamType.IFRAME) {
                if (!currentIsLive && !streamIsLive) {
                    exoPlayer?.seekTo(((exoPlayer?.currentPosition ?: 0) - 10_000).coerceAtLeast(0))
                    resetAutoHideTimer()
                }
            }
        }

        btnForward.setOnClickListener {
            if (currentStreamType == StreamType.IFRAME && isTV && webBridge.isControllable) {
                val newTime = (webBridge.currentTime + 10).coerceAtMost(webBridge.duration)
                webBridge.control("seek", newTime.toDouble())
                resetAutoHideTimer()
            } else if (currentStreamType != StreamType.IFRAME) {
                if (!currentIsLive && !streamIsLive) {
                    val pos = exoPlayer?.currentPosition ?: 0
                    val dur = exoPlayer?.duration ?: 0
                    if (dur > 0) exoPlayer?.seekTo((pos + 10_000).coerceAtMost(dur))
                    resetAutoHideTimer()
                }
            }
        }

        btnMenu.setOnClickListener { if (isTV) { if (isPanelOpen) closeSidePanel() else openSidePanel() } }
        btnMenu.visibility = View.GONE
        btnOptions.setOnClickListener { showOptionsDialog(currentChannel ?: return@setOnClickListener); resetAutoHideTimer() }
        btnAudioInfo.setOnClickListener { showAudioInfoDialog(); resetAutoHideTimer() }
        btnReloadStream.setOnClickListener { reloadCurrentTransmission() }
        btnFavoriteChannel.setOnClickListener {
            val channel = currentChannel ?: return@setOnClickListener
            val added = favoritesStore.toggle(channel)
            updateFavoriteButton(channel)
            android.widget.Toast.makeText(this, if (added) "Agregado a favoritos" else "Quitado de favoritos", android.widget.Toast.LENGTH_SHORT).show()
            resetAutoHideTimer()
        }

        if (isTV) {
            listOf(btnMenu, btnPlayPause, btnRewind, btnForward, btnAudioInfo, btnOptions, btnFavoriteChannel, btnReloadStream, btnClose, mediaRouteButton).forEach { control ->
                control.isFocusable = true
                control.isFocusableInTouchMode = true
                control.isClickable = true
                val size = UiDimensions.px(resources, R.dimen.player_tv_control_size)
                control.layoutParams = control.layoutParams.apply { width = size; height = size }
                control.setOnFocusChangeListener { view, hasFocus ->
                    if (hasFocus) {
                        lastFocusedControlId = view.id
                        view.animate().scaleX(1.06f).scaleY(1.06f).setDuration(120L).start()
                        if (controlsVisible && !isPanelOpen) resetAutoHideTimer()
                    } else {
                        view.animate().scaleX(1f).scaleY(1f).setDuration(120L).start()
                    }
                }
            }
            controlsOverlay.visibility = View.GONE
            bottomControls.visibility = View.GONE
            controlsVisible = false
        } else {
            playerView.setOnClickListener {
                if (controlsVisible) hideControls() else showControlsTemporarily()
            }
        }
    }

    private fun togglePlayPause() {
        val player = exoPlayer ?: return
        if (player.isPlaying) {
            player.pause()
            updatePlayPauseButton(false)
        } else {
            player.play()
            updatePlayPauseButton(true)
        }
    }

    /** Mantiene icono y etiqueta accesible sincronizados con la acción disponible. */
    private fun updatePlayPauseButton(isPlaying: Boolean) {
        btnPlayPause.setImageResource(if (isPlaying) R.drawable.ic_pause else R.drawable.ic_play)
        btnPlayPause.contentDescription = if (isPlaying) "Pausar" else "Reproducir"
    }

    // ==================== TV KEY HANDLING ====================

    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        if (!isTV) return super.dispatchKeyEvent(event)
        if (event.action != KeyEvent.ACTION_DOWN) return super.dispatchKeyEvent(event)
        if (event.repeatCount > 0 && TvRemoteKeyController.isDigitKey(event.keyCode)) return true
        val handled = handleTVKey(event.keyCode)
        return if (handled) true else super.dispatchKeyEvent(event)
    }

    private fun handleTVKey(keyCode: Int): Boolean =
        if (::tvRemoteKeyController.isInitialized) tvRemoteKeyController.handleKey(keyCode) else false

    private fun setupTvRemoteKeyController() {
        tvRemoteKeyController = TvRemoteKeyController(
            stateProvider = {
                TvRemoteKeyController.State(
                    panelOpen = isPanelOpen,
                    controlsVisible = controlsVisible,
                    hasPendingChannelNumber = channelNumberEntryController.hasPendingInput,
                    rightPanelFocused = isRightPanelFocused(),
                    searchTriggerFocused = currentFocus?.id == R.id.btn_search_trigger,
                    closePanelFocused = currentFocus?.id == R.id.btn_close_panel,
                    iframeActive = currentStreamType == StreamType.IFRAME
                )
            },
            actions = object : TvRemoteKeyController.Actions {
                override fun appendChannelNumberDigit(digit: Int) = this@UnifiedPlayerActivity.appendChannelNumberDigit(digit)
                override fun commitChannelNumber() = channelNumberEntryController.commit()
                override fun handleBackInPanel(): Boolean = this@UnifiedPlayerActivity.handleBackInPanel()
                override fun hideControls() = this@UnifiedPlayerActivity.hideControls()
                override fun finishPlayer() = finish()
                override fun handlePanelVerticalFocus(keyCode: Int): Boolean = this@UnifiedPlayerActivity.handlePanelVerticalFocus(keyCode)
                override fun navigateControlsUp() = this@UnifiedPlayerActivity.navigateControlsUp()
                override fun navigateControlsDown() = this@UnifiedPlayerActivity.navigateControlsDown()
                override fun navigateControlsLeft() = this@UnifiedPlayerActivity.navigateControlsLeft()
                override fun navigateControlsRight() = this@UnifiedPlayerActivity.navigateControlsRight()
                override fun changeChannel(delta: Int) = this@UnifiedPlayerActivity.changeChannel(delta)
                override fun openSidePanel() = this@UnifiedPlayerActivity.openSidePanel()
                override fun moveFocusToCategoriesPanel() = this@UnifiedPlayerActivity.moveFocusToCategoriesPanel()
                override fun closeSidePanel() = this@UnifiedPlayerActivity.closeSidePanel()
                override fun activateSearchMode() = this@UnifiedPlayerActivity.activateSearchMode()
                override fun moveFocusToChannelsList() = this@UnifiedPlayerActivity.moveFocusToChannelsList()
                override fun showControls() = this@UnifiedPlayerActivity.showControls()
                override fun activateFocusedControl() = this@UnifiedPlayerActivity.activateFocusedControl()
                override fun controlIframe(command: String) = webBridge.control(command)
                override fun togglePlayPause() = this@UnifiedPlayerActivity.togglePlayPause()
                override fun playNative() {
                    exoPlayer?.play()
                    updatePlayPauseButton(true)
                }
                override fun pauseNative() {
                    exoPlayer?.pause()
                    updatePlayPauseButton(false)
                }
                override fun fastForward() { btnForward.performClick() }
                override fun rewind() { btnRewind.performClick() }
            }
        )
    }

    private fun appendChannelNumberDigit(digit: Int) {
        channelNumberEntryController.appendDigit(digit)
    }

    private fun selectChannelByNumber(requestedNumber: Int) {
        val index = requestedNumber - 1
        val channel = allChannels.getOrNull(index) ?: return
        if (index != currentChannelIndex) zapTo(index, channel)
    }

    private fun isRightPanelFocused(): Boolean =
        sidePanelFocusController.isRightPanelFocused(currentFocus)

    private fun moveFocusToCategoriesPanel() = sidePanelFocusController.moveFocusToCategoriesPanel()

    private fun moveFocusToChannelsList() = sidePanelFocusController.moveFocusToChannelsList()

    private fun handlePanelVerticalFocus(keyCode: Int): Boolean =
        sidePanelFocusController.handlePanelVerticalFocus(currentFocus, keyCode)

    private fun activateFocusedControl() {
        when (currentFocus?.id) {
            R.id.btn_menu -> btnMenu.performClick()
            R.id.btn_play_pause -> btnPlayPause.performClick()
            R.id.btn_rewind -> btnRewind.performClick()
            R.id.btn_forward -> btnForward.performClick()
            R.id.btn_audio_info -> btnAudioInfo.performClick()
            R.id.btn_options -> btnOptions.performClick()
            R.id.btn_reload_stream -> btnReloadStream.performClick()
            R.id.btn_close_player -> btnClose.performClick()
            else -> requestPreferredControlFocus()
        }
    }

    /**
     * Orden real de izquierda a derecha según activity_unified_player.xml.
     * btnMenu está después de los controles de transporte; ponerlo al principio hacía
     * que el D-pad saltara visualmente ese botón al avanzar desde Adelantar.
     */
    private fun visibleControls(): List<View> = listOf(
        btnRewind,
        btnPlayPause,
        btnForward,
        btnMenu,
        mediaRouteButton,
        btnAudioInfo,
        btnOptions,
        btnReloadStream,
        btnClose
    ).filter { it.visibility == View.VISIBLE && it.isFocusable && it.isEnabled }

    /** Asegura el mismo orden en el foco nativo cuando Android no usa el dispatch manual. */
    private fun updateControlFocusOrder() {
        if (!isTV) return
        val controls = visibleControls()
        controls.forEachIndexed { index, control ->
            control.nextFocusLeftId = controls.getOrNull(index - 1)?.id ?: View.NO_ID
            control.nextFocusRightId = controls.getOrNull(index + 1)?.id ?: View.NO_ID
        }
    }

    /** Prioriza el control que el usuario estaba usando; si desapareció para esta fuente,
     * elige uno visible y enfocable como destino seguro. */
    private fun requestPreferredControlFocus() {
        if (!isTV || !controlsVisible || isPanelOpen) return
        val controls = visibleControls()
        if (controls.isEmpty()) {
            playerContainer.requestFocus()
            return
        }
        val preferred = controls.firstOrNull { it.id == lastFocusedControlId } ?: controls.first()
        preferred.requestFocus()
    }
    private fun navigateControlsRight() {
        val controls = visibleControls()
        if (controls.isEmpty()) return
        val index = controls.indexOfFirst { it.hasFocus() }
        controls.getOrNull(if (index < 0) 0 else (index + 1).coerceAtMost(controls.lastIndex))?.requestFocus()
        resetAutoHideTimer()
    }

    private fun navigateControlsLeft() {
        val controls = visibleControls()
        if (controls.isEmpty()) return
        val index = controls.indexOfFirst { it.hasFocus() }
        controls.getOrNull(if (index < 0) 0 else (index - 1).coerceAtLeast(0))?.requestFocus()
        resetAutoHideTimer()
    }

    private fun navigateControlsUp() = navigateControlsLeft()
    private fun navigateControlsDown() = navigateControlsRight()

    // ==================== CHANNEL SELECTION ====================

    private fun selectChannelFromSidePanel(channel: Channel) {
        val globalIndex = allChannels.indexOfFirst { ChannelIdentity.same(it, channel) }
        closeSidePanel()
        // No iniciar zapping con índice -1: puede ocurrir si una búsqueda antigua queda
        // visible mientras el catálogo se actualiza.
        if (globalIndex < 0 || globalIndex == currentChannelIndex) return
        if (!isZapping) zapTo(globalIndex, allChannels[globalIndex])
    }

    private fun changeChannel(delta: Int) {
        if (allChannels.isEmpty()) return

        // No descartamos CH+/CH- durante la transición. Acumulamos el desplazamiento
        // y lo aplicamos al último canal seleccionado cuando termine la carga actual.
        if (isZapping) {
            pendingChannelZaps.add(delta, allChannels.size)
            return
        }

        val targetIndex = (currentChannelIndex + delta).mod(allChannels.size)
        zapTo(targetIndex, allChannels[targetIndex])
    }

    private fun finishZappingTransition() {
        if (allChannels.isEmpty()) {
            pendingChannelZaps.clear()
            isZapping = false
            return
        }

        val delta = pendingChannelZaps.consume(allChannels.size)
        if (delta == 0) {
            isZapping = false
            return
        }

        // Liberar el bloqueo antes de iniciar la siguiente transición acumulada.
        isZapping = false
        val targetIndex = (currentChannelIndex + delta).mod(allChannels.size)
        zapTo(targetIndex, allChannels[targetIndex])
    }

    private fun zapTo(index: Int, channel: Channel) {
        isZapping = true
        playerGeneration++
        webViewPlaybackController.invalidatePendingLoad()
        recovery.reset(cancelPendingReconnect = true)
        stableStreamRunnable?.let { mainHandler.removeCallbacks(it) }

        releasePlayer()

        // Resetear completamente el WebView
        webView.apply {
            stopLoading()
            loadUrl("about:blank")
            clearHistory()
            // Eliminar el bridge anterior si existe
            webBridge.detach()
        }
        webView.visibility = View.GONE

        // Configurar bloqueo táctil según dispositivo
        if (isTV) {
            webViewTouchBlocker.visibility = View.VISIBLE
            lockWebViewFocus()
        } else {
            // Móvil: SIN BLOQUEO TÁCTIL para usar controles del iframe
            webViewTouchBlocker.visibility = View.GONE
            webView.isClickable = true
            webView.isFocusable = true
            webView.isFocusableInTouchMode = true
        }

        // Resetear estado del WebView
        webBridge.reset()
        webBridge.stopMonitor()

        progressBar.visibility = View.VISIBLE
        errorText.visibility = View.GONE

        showZappingOverlay(channel)

        zapRunnable?.let { mainHandler.removeCallbacks(it) }
        val transition = Runnable {
            currentChannelIndex = index
            currentChannel = channel
            loadChannelInfo(channel)
            updateFavoriteButton(channel)
            playFirstValidOption(channel)
            mainHandler.postDelayed({ finishZappingTransition() }, 200)
        }
        zapRunnable = transition
        mainHandler.postDelayed(transition, 300L)
    }

    // ==================== ZAPPING OVERLAY ====================

    private fun showZappingOverlay(channel: Channel) {
        val overlay = zappingOverlay ?: return
        overlay.visibility = View.VISIBLE
        // Keep the transient identity above any visible player controls without capturing focus.
        overlay.bringToFront()
        zappingChannelName?.apply {
            val number = allChannels.indexOfFirst { ChannelIdentity.same(it, channel) } + 1
            text = if (number > 0) "$number  ·  ${channel.name}" else channel.name
            // Keep the transient label inside the viewport on narrow phones and TV screens.
            val maxNameWidthDimension = if (isTV) {
                R.dimen.zapping_name_max_width_tv
            } else {
                R.dimen.zapping_name_max_width_mobile
            }
            maxWidth = UiDimensions.px(resources, maxNameWidthDimension)
        }
        zappingLogo?.loadChannelLogo(channel.name, channel.logo)
        overlay.removeCallbacks(hideZappingRunnable)
        overlay.postDelayed(hideZappingRunnable, 2_000)
    }

    private val hideZappingRunnable = Runnable { zappingOverlay?.visibility = View.GONE }

    // ==================== CHANNEL INFO ====================

    private fun loadChannelInfo(channel: Channel) {
        channelNameText.text = channel.name
        channelLogo.loadChannelLogo(channel.name, channel.logo)
        val categoryLabel = channel.category.trim().takeIf {
            it.isNotBlank() && !it.equals("todos", ignoreCase = true)
        }?.let(::formatCategoryLabel).orEmpty()
        channelCategoryText.text = categoryLabel
        channelCategoryText.visibility = if (categoryLabel.isBlank()) View.GONE else View.VISIBLE
    }

    // ==================== PLAYBACK ====================

    private var currentOptionIndex: Int = 0

    /** Reintenta la fuente actual sin cambiar de canal ni reiniciar la selección del usuario. */
    private fun reloadCurrentTransmission() {
        val channel = currentChannel
        if (channel == null) {
            showError("No hay ningún canal seleccionado para recargar.")
            return
        }

        playerGeneration++
        isZapping = false
        pendingChannelZaps.clear()
        zapRunnable?.let { mainHandler.removeCallbacks(it) }
        zapRunnable = null
        cancelOptionFallback()
        stableStreamRunnable?.let { mainHandler.removeCallbacks(it) }
        stableStreamRunnable = null
        recovery.reset(cancelPendingReconnect = true)
        webViewPlaybackController.invalidatePendingLoad()
        errorText.visibility = View.GONE
        progressBar.visibility = View.VISIBLE

        val url = currentStreamUrl
        val type = currentStreamType
        if (url.isNotBlank() && StreamUrlPolicy.isHttpUrl(url)) {
            // La URL y el tipo ya representan la fuente seleccionada; no reasignarlos aquí.
            if (type == StreamType.IFRAME) {
                // Forzar navegación nueva; no reutilizar el documento del iframe que pudo fallar.
                reuseInlineWebViewOnLoad = false
                webViewPlaybackController.load(url, reuseLoadedPage = false)
            } else {
                playStream(url, type)
            }
        } else {
            playFirstValidOption(channel)
        }

        if (controlsVisible) resetAutoHideTimer()
    }

    private fun playFirstValidOption(channel: Channel) {
        errorText.visibility = View.GONE
        currentOptionIndex = 0
        if (!channel.options.isNullOrEmpty()) {
            tryOption(channel, 0)
        } else {
            val url = channel.streamUrl ?: ""
            val type = StreamUtils.resolveType(url, channel.streamType ?: StreamType.AUTO)
            if (url.isNotEmpty()) {
                currentStreamUrl = url
                currentStreamType = type
                playStream(url, type)
            } else {
                showError("No hay fuentes disponibles")
            }
        }
    }

    private fun tryOption(channel: Channel, optionIndex: Int) {
        val options = channel.options ?: return
        if (optionIndex >= options.size) {
            showError("No se pudo reproducir con ninguna fuente disponible")
            return
        }

        val option = options[optionIndex]
        val url = option.iframe
        val type = StreamUtils.resolveType(url, option.streamType)
        if (url.isEmpty()) {
            tryOption(channel, optionIndex + 1)
            return
        }

        currentStreamUrl = url
        currentStreamType = type
        currentOptionIndex = optionIndex
        android.util.Log.d("OPTION_TRY", "Intentando opción ${optionIndex + 1}/${options.size}: ${option.name} (${StreamUtils.hostForLog(url)})")

        playStream(url, type)
        updateControlsVisibility()

        scheduleOptionFallback(channel, optionIndex)
    }

    private fun scheduleOptionFallback(channel: Channel, optionIndex: Int) {
        optionFallbackController.schedule(channel, optionIndex, playerGeneration)
    }

    private fun cancelOptionFallback() {
        optionFallbackController.cancel()
    }

    private fun playStream(url: String, type: String) {
        if (!StreamUrlPolicy.isHttpUrl(url)) {
            showError("La dirección de reproducción no es válida o no está admitida.")
            return
        }
        when (type) {
            StreamType.IFRAME -> showWebView(url)
            StreamType.HLS, StreamType.DASH, StreamType.MP4 -> showExoPlayer(url, type)
            else -> showExoPlayer(url, StreamType.HLS)
        }
    }

    // ==================== EXO PLAYER ====================

    private fun showExoPlayer(url: String, type: String) {
        // Evita que una respuesta tardía de una navegación WebView previa cambie la UI actual.
        playerTimelineContainer.visibility = View.GONE
        stopTimelineUpdates()
        webViewPlaybackController.invalidatePendingLoad()
        stableStreamRunnable?.let { mainHandler.removeCallbacks(it) }
        stableStreamRunnable = null
        recovery.stopWatchdog()
        releasePlayer()

        val myGeneration = playerGeneration
        val hadVisibleWebView = webView.visibility == View.VISIBLE
        playerView.visibility = View.VISIBLE
        webView.visibility = View.GONE
        webViewTouchBlocker.visibility = View.GONE
        progressBar.visibility = View.VISIBLE
        errorText.visibility = View.GONE
        currentIsLive = false
        streamIsLive = false
        if (hadVisibleWebView) {
            // The selected source type may already have been updated by tryOption(). Use the
            // active view instead, or a previous iframe can keep playing audio behind native video.
            webBridge.stopMonitor()
            webBridge.detach()
            webView.stopLoading()
            webView.loadUrl("about:blank")
        }
        currentStreamType = type

        if (isTV) {
            playerView.isFocusable = true
            playerView.isFocusableInTouchMode = true
            playerView.requestFocus()
            lockWebViewFocus()
        }

        val handoff = if (intent.getBooleanExtra("reuse_inline_player_session", false)) {
            InlinePlayerHandoff.takeForFullscreen(url, type)
        } else null

        if (handoff?.player != null) {
            // Reuse the exact same ExoPlayer. Do not set a MediaSource or call prepare():
            // this keeps the live session, buffer, and current playback position.
            val player = handoff.player
            exoPlayer = player
            playerView.player = player
            playerView.useController = false
            attachPlayerListener(player, url, type, myGeneration)
            player.playWhenReady = handoff.wasPlaying
            updatePlayPauseButton(player.isPlaying)
            handlePlayerState(player, url, type, myGeneration, player.playbackState)
            return
        }

        val mediaSource = StreamMediaSourceFactory.create(url, type)

        val audioAttributes = AudioAttributes.Builder()
            .setUsage(C.USAGE_MEDIA)
            .setContentType(C.AUDIO_CONTENT_TYPE_MOVIE)
            .build()
        val player = ExoPlayer.Builder(this, StreamMediaSourceFactory.createRenderersFactory(this))
            .setAudioAttributes(audioAttributes, /* handleAudioFocus= */ true)
            .setHandleAudioBecomingNoisy(true)
            .setLoadControl(StreamMediaSourceFactory.createLoadControl(StreamMediaSourceFactory.BufferProfile.FULLSCREEN))
            .build()
        exoPlayer = player
        playerView.player = player
        playerView.useController = false
        attachPlayerListener(player, url, type, myGeneration)
        player.setMediaSource(mediaSource)
        player.prepare()
        player.playWhenReady = true
    }

    private fun attachPlayerListener(player: ExoPlayer, url: String, type: String, generation: Int) {
        playerListener?.let { previous -> exoPlayer?.let { old -> runCatching { old.removeListener(previous) } } }
        val listener = object : Player.Listener {
            override fun onPlaybackStateChanged(state: Int) {
                if (playerGeneration != generation || exoPlayer !== player) return
                handlePlayerState(player, url, type, generation, state)
            }

            override fun onIsPlayingChanged(isPlaying: Boolean) {
                if (playerGeneration == generation && exoPlayer === player) updatePlayPauseButton(isPlaying)
            }

            override fun onTracksChanged(tracks: Tracks) {
                if (playerGeneration != generation || exoPlayer !== player) return
                val summary = PlayerAudioDiagnostics.logTracks("fullscreen", tracks, type, url)
                if (audioNoticeGeneration != generation && PlayerAudioDiagnosticPolicy.shouldNotifyUser(summary.state)) {
                    audioNoticeGeneration = generation
                    android.widget.Toast.makeText(
                        this@UnifiedPlayerActivity,
                        PlayerAudioDiagnosticPolicy.UNSUPPORTED_AUDIO_NOTICE,
                        android.widget.Toast.LENGTH_LONG
                    ).show()
                }
            }

            override fun onPlayerError(error: PlaybackException) {
                if (playerGeneration != generation || exoPlayer !== player || isZapping) return
                lastAudioError = PlayerAudioDiagnostics.logPlaybackError("fullscreen", type, url, error)
                lastAudioErrorHost = StreamUtils.hostForLog(url)
                stableStreamRunnable?.let { mainHandler.removeCallbacks(it) }
                stableStreamRunnable = null
                recovery.stopWatchdog()
                when (type) {
                    StreamType.HLS, StreamType.DASH -> {
                        progressBar.visibility = View.VISIBLE
                        errorText.visibility = View.GONE
                        recovery.scheduleReconnect(url, type, generation)
                    }
                    StreamType.MP4 -> showError("Error al reproducir. Verificá tu conexión.")
                    else -> {
                        progressBar.visibility = View.VISIBLE
                        errorText.visibility = View.GONE
                        recovery.scheduleReconnect(url, type, generation)
                    }
                }
            }
        }
        playerListener = listener
        player.addListener(listener)
    }

    private fun handlePlayerState(player: ExoPlayer, url: String, type: String, generation: Int, state: Int) {
        if (playerGeneration != generation || exoPlayer !== player) return
        when (state) {
            Player.STATE_BUFFERING -> {
                progressBar.visibility = View.VISIBLE
                errorText.visibility = View.GONE
            }
            Player.STATE_READY -> {
                progressBar.visibility = View.GONE
                errorText.visibility = View.GONE
                currentIsLive = player.isCurrentWindowLive
                streamIsLive = player.isCurrentWindowLive || player.duration == -1L
                recovery.resetReconnectAttempts()
                updateControlsVisibility()
                if (!isTV) {
                    showControlsTemporarily()
                    startTimelineUpdates()
                }
                stableStreamRunnable?.let { mainHandler.removeCallbacks(it) }
                val stablePlayback = Runnable {
                    if (playerGeneration == generation) {
                        recovery.resetReconnectAttempts()
                        errorText.visibility = View.GONE
                    }
                }
                stableStreamRunnable = stablePlayback
                mainHandler.postDelayed(stablePlayback, 8_000)
                cancelOptionFallback()
                recovery.startWatchdog(generation)
            }
            Player.STATE_ENDED -> {
                stableStreamRunnable?.let { mainHandler.removeCallbacks(it) }
                stableStreamRunnable = null
                recovery.stopWatchdog()
                if (type == StreamType.HLS || type == StreamType.DASH || currentIsLive || streamIsLive) {
                    progressBar.visibility = View.VISIBLE
                    errorText.visibility = View.GONE
                    recovery.scheduleReconnect(url, type, generation)
                }
            }
            else -> Unit
        }
    }

    /** Returns the active playback session and latest channel selection before fullscreen exits. */
    private fun returnSessionToInline() {
        if (inlineSessionReturned) return

        // The inline player may have detached its engine before this Activity finished, while
        // loadChannelData()/source resolution never reached takeForFullscreen(). Return that
        // unclaimed session atomically instead of leaving the singleton holding an orphaned player.
        if (InlineSessionReturnPolicy.shouldAttemptUnclaimedRecovery(
                fromInlinePlayer = intent.getBooleanExtra("from_inline_player", false),
                alreadyReturned = inlineSessionReturned
            ) && InlinePlayerHandoff.recoverUnclaimedFullscreenToInline()
        ) {
            inlineSessionReturned = true
            return
        }

        val origin = inlineWebViewOrigin
        @Suppress("DEPRECATION")
        val intentChannel = intent.getParcelableExtra<Channel>("current_channel")
        val channel = currentChannel ?: origin?.channel ?: intentChannel ?: return
        val player = exoPlayer
        val wasPlaying = resumePlaybackAfterPause || (player?.playWhenReady == true)
        if (recoveryDelegate.isInitialized()) {
            recovery.stopWatchdog()
            recovery.cancelPendingReconnect()
        }
        cancelOptionFallback()
        zapRunnable?.let { mainHandler.removeCallbacks(it) }
        zapRunnable = null
        stableStreamRunnable?.let { mainHandler.removeCallbacks(it) }
        stableStreamRunnable = null
        if (player != null) {
            playerListener?.let { listener -> runCatching { player.removeListener(listener) } }
            playerListener = null
            if (::playerView.isInitialized) playerView.player = null
            exoPlayer = null // hand the engine back; releasePlayer() must not release it.
        }
        val returnedMetadata = InlineSessionReturnPolicy.resolveStreamMetadata(
            currentUrl = currentStreamUrl,
            currentType = currentStreamType,
            currentSourceIndex = currentOptionIndex,
            originUrl = origin?.streamUrl,
            originType = origin?.streamType,
            originSourceIndex = origin?.sourceIndex
        )
        val returnWebView = inlineWebViewOrigin?.takeIf { webViewReturnedFromInlineOrigin() }
        if (returnWebView != null) {
            webBridge.stopMonitor()
            webBridge.detach()
            webViewPlaybackController.resetNavigationHandlers()
            // Use the resolved return type, not the Activity's default AUTO value. If startup
            // failed before resolving the iframe source, blanking here would destroy the page
            // that the inline Fragment is expecting to resume.
            if (returnedMetadata.type != StreamType.IFRAME) {
                webView.stopLoading()
                webView.loadUrl("about:blank")
            }
            (webView.parent as? ViewGroup)?.removeView(webView)
            inlineWebViewReturnedToFragment = true
        }
        InlinePlayerHandoff.returnToInline(
            InlinePlayerHandoff.Session(
                player = player,
                channel = channel,
                streamUrl = returnedMetadata.url,
                streamType = returnedMetadata.type,
                sourceIndex = returnedMetadata.sourceIndex,
                wasPlaying = wasPlaying,
                webView = returnWebView?.webView,
                webViewParentIndex = returnWebView?.webViewParentIndex ?: -1,
                webViewLayoutParams = returnWebView?.webViewLayoutParams
            )
        )
        inlineSessionReturned = true
    }

    private fun webViewReturnedFromInlineOrigin(): Boolean =
        inlineWebViewOrigin?.webView === webView && intent.getBooleanExtra("reuse_inline_webview_session", false)

    // ==================== WEBVIEW (IFRAME) ====================

    /**
     * Muestra el WebView con soporte para control híbrido:
     * - TV: Controles nativos traducidos al iframe
     * - Móvil: Sin bloqueo táctil, controles nativos del iframe
     */
    private fun showWebView(url: String) {
        val reuseLoadedPage = reuseInlineWebViewOnLoad && inlineWebViewOrigin?.streamUrl == url
        releasePlayer()
        playerView.visibility = View.GONE
        playerTimelineContainer.visibility = View.GONE
        stopTimelineUpdates()

        // El estado del stream pertenece a la Activity; la configuración y navegación web
        // viven en WebViewPlaybackController.
        currentIsLive = false
        streamIsLive = false
        currentStreamType = StreamType.IFRAME
        if (reuseLoadedPage) reuseInlineWebViewOnLoad = false
        webViewPlaybackController.load(url, reuseLoadedPage)
    }

    /** Un error de la página principal sí permite probar la siguiente fuente del canal. */
    private fun handleWebViewMainFrameError(loadGeneration: Int, failedUrl: String?, description: String?) {
        if (!webViewPlaybackController.isCurrentLoad(loadGeneration) || currentStreamType != StreamType.IFRAME) return
        if (failedUrl == "about:blank") return

        android.util.Log.w("WebView", "Falló la carga de una fuente (${StreamUtils.hostForLog(failedUrl.orEmpty())}); detalle=${description?.take(120).orEmpty()}")
        progressBar.visibility = View.GONE
        // Invalida eventos duplicados/tardíos de esta misma navegación.
        webViewPlaybackController.invalidatePendingLoad()

        val channel = currentChannel
        val nextIndex = currentOptionIndex + 1
        if (channel != null && nextIndex < (channel.options?.size ?: 0)) {
            android.util.Log.w("OPTION_FALLBACK", "Falló la carga del iframe; probando opción ${nextIndex + 1}")
            tryOption(channel, nextIndex)
        } else {
            showError("No se pudo cargar esta fuente. Revisá tu conexión o probá otra opción.")
        }
    }

    // ==================== PLAYER RELEASE ====================

    private fun releasePlayer() {
        // Do not instantiate the lazy recovery controller just to stop a watchdog that never ran.
        if (recoveryDelegate.isInitialized()) recovery.stopWatchdog()
        cancelOptionFallback()
        webBridge.stopMonitor()
        playerListener?.let { listener -> exoPlayer?.let { player -> runCatching { player.removeListener(listener) } } }
        playerListener = null
        if (::playerView.isInitialized) playerView.player = null
        exoPlayer?.run { stop(); clearMediaItems(); release() }
        exoPlayer = null
    }

    // ==================== SIDE PANEL ====================

    private fun openSidePanel() {
        if (!isTV || isPanelOpen) return
        if (!::sideChannelsAdapter.isInitialized || !::categoriesAdapter.isInitialized) return
        isPanelOpen = true
        val screenWidthPx = window.decorView.width.takeIf { it > 0 }
            ?: resources.displayMetrics.widthPixels
        val density = resources.displayMetrics.density
        val screenWidthDp = screenWidthPx / density

        // El cálculo de dimensiones está aislado para probarlo independientemente de la UI.
        val panelDimensions = SidePanelLayoutPolicy.calculate(screenWidthDp)
        val menuWidthDp = panelDimensions.menuWidthDp
        val listWidthDp = panelDimensions.listWidthDp
        searchTriggerText.text = panelDimensions.searchLabel
        allChannelsText.text = panelDimensions.allChannelsLabel
        val menuWidthPx = (menuWidthDp * density + 0.5f).toInt()
        val listWidthPx = (listWidthDp * density + 0.5f).toInt()

        panelMenuColumn.layoutParams = panelMenuColumn.layoutParams.apply {
            width = menuWidthPx
        }
        channelsPanelContainer.layoutParams = channelsPanelContainer.layoutParams.apply {
            width = menuWidthPx + listWidthPx
        }
        channelsPanelContainer.visibility = View.VISIBLE
        if (allChannels.isNotEmpty()) {
            updateCategoriesList()
            updateChannelsList(scrollToSelected = true)
            updateContentTitle()
            // Al abrir el panel, el foco va al canal actual (o al primero disponible).
            // La búsqueda queda a un movimiento arriba para no sumar pasos al zapping.
            moveFocusToChannelsList()
        } else {
            // Si los datos aún no llegaron, el buscador es un destino enfocable estable.
            btnSearchTrigger.post { btnSearchTrigger.requestFocus() }
        }
    }

    private fun closeSidePanel() {
        if (!isTV || !isPanelOpen) return
        deactivateSearchMode()
        channelsPanelContainer.layoutParams = channelsPanelContainer.layoutParams.apply { width = 0 }
        channelsPanelContainer.visibility = View.GONE
        isPanelOpen = false
        restorePlayerFocus()
        // Si el panel quedó abierto más de cinco segundos, el temporizador anterior pudo vencer.
        // Al volver al vídeo lo reiniciamos para que los controles sigan ocultándose correctamente.
        if (controlsVisible) resetAutoHideTimer()
    }

    private fun restorePlayerFocus() {
        if (!isTV) return
        playerContainer.post {
            when {
                controlsVisible && bottomControls.visibility == View.VISIBLE -> {
                    requestPreferredControlFocus()
                }
                playerView.visibility == View.VISIBLE -> {
                    playerView.isFocusable = true
                    playerView.requestFocus()
                }
                else -> playerContainer.requestFocus()
            }
        }
    }

    // ==================== CONTROLS VISIBILITY ====================

    private fun resetAutoHideTimer() {
        hideControlsRunnable?.let { mainHandler.removeCallbacks(it) }
        val hideControlsTask = Runnable { if (controlsVisible && !isPanelOpen) hideControls() }
        hideControlsRunnable = hideControlsTask
        mainHandler.postDelayed(hideControlsTask, 5_000)
    }

    private fun showControls() {
        updateControlsVisibility()
        // El panel de controles es independiente del motor de vídeo: también debe aparecer
        // sobre WebView/iframe, aunque ese reproductor no exponga controles de transporte.
        controlsOverlay.visibility = View.VISIBLE
        bottomControls.visibility = View.VISIBLE
        bottomControls.bringToFront()
        controlsVisible = true
        updatePlayerTimeline()
        if (isTV) requestPreferredControlFocus()
        resetAutoHideTimer()
    }

    private fun showControlsTemporarily() {
        updateControlsVisibility()
        controlsOverlay.visibility = View.VISIBLE
        bottomControls.visibility = View.VISIBLE
        bottomControls.bringToFront()
        controlsVisible = true
        updatePlayerTimeline()
        if (!isTV) startTimelineUpdates()
        resetAutoHideTimer()
    }

    private fun hideControls() {
        controlsOverlay.visibility = View.GONE
        bottomControls.visibility = View.GONE
        controlsVisible = false
        playerTimelineContainer.visibility = View.GONE
        stopTimelineUpdates()
        hideControlsRunnable?.let { mainHandler.removeCallbacks(it) }
        if (isTV) restorePlayerFocus()
    }

    private fun updatePlayerTimeline() {
        if (::timelineController.isInitialized) timelineController.update()
    }

    private fun startTimelineUpdates() {
        if (isTV || !::timelineController.isInitialized) return
        timelineController.startUpdates()
    }

    private fun stopTimelineUpdates() {
        if (::timelineController.isInitialized) timelineController.stopUpdates()
    }

    private fun updateControlsVisibility() {
        mediaRouteButton.visibility = if (
            !isTV && currentStreamType != StreamType.IFRAME && cast.isConfigured
        ) View.VISIBLE else View.GONE

        if (currentStreamType == StreamType.IFRAME) {
            if (isTV) {
                // TV: Mostrar controles si se detectó reproductor en el iframe
                if (webBridge.isControllable) {
                    btnPlayPause.visibility = View.VISIBLE
                    updatePlayPauseButton(webBridge.isPlaying)

                    val showSeek = webBridge.duration > 0
                    btnRewind.visibility = if (showSeek) View.VISIBLE else View.GONE
                    btnForward.visibility = if (showSeek) View.VISIBLE else View.GONE

                    // Actualizar foco para navegación D-Pad
                    btnPlayPause.isFocusable = true
                    btnRewind.isFocusable = showSeek
                    btnForward.isFocusable = showSeek
                } else {
                    // No se detectó reproductor: ocultar controles de reproducción
                    btnPlayPause.visibility = View.GONE
                    btnRewind.visibility = View.GONE
                    btnForward.visibility = View.GONE
                }
            } else {
                // MÓVIL: Ocultar controles nativos, usar los del iframe
                btnPlayPause.visibility = View.GONE
                btnRewind.visibility = View.GONE
                btnForward.visibility = View.GONE
                // El bloqueo táctil ya está desactivado en showWebView
            }
        } else {
            // Comportamiento normal para ExoPlayer
            btnPlayPause.visibility = View.VISIBLE
            val showSeek = !currentIsLive && !streamIsLive
            btnRewind.visibility = if (showSeek) View.VISIBLE else View.GONE
            btnForward.visibility = if (showSeek) View.VISIBLE else View.GONE
        }

        btnOptions.visibility = if (hasMultipleOptions()) View.VISIBLE else View.GONE
        btnAudioInfo.visibility = if (exoPlayer != null) View.VISIBLE else View.GONE

        if (isTV) {
            btnMenu.visibility = View.VISIBLE
            btnMenu.isFocusable = true
            listOf(btnPlayPause, btnRewind, btnForward, btnAudioInfo, btnOptions, btnReloadStream).forEach {
                it.isFocusable = it.visibility == View.VISIBLE
            }
            btnClose.isFocusable = true
            mediaRouteButton.isFocusable = mediaRouteButton.visibility == View.VISIBLE
            updateControlFocusOrder()
        }
    }

    private fun updateFavoriteButton(channel: Channel) {
        if (!::btnFavoriteChannel.isInitialized || !::favoritesStore.isInitialized) return
        val favorite = favoritesStore.contains(channel)
        btnFavoriteChannel.setImageResource(if (favorite) R.drawable.ic_favorite_filled else R.drawable.ic_favorite_outline)
        btnFavoriteChannel.contentDescription = if (favorite) "Quitar canal de favoritos" else "Agregar canal a favoritos"
        btnFavoriteChannel.isSelected = favorite
    }

    private fun hasMultipleOptions() = (currentChannel?.options?.size ?: 0) > 1

    // ==================== DATA LOADING ====================

    private fun loadChannelData() {
        val catalogToken = intent.getLongExtra("channel_catalog_token", -1L)
        val sharedCatalog = PlayerChannelCatalog.get(catalogToken)
        @Suppress("DEPRECATION")
        val legacyCatalog = intent.getParcelableArrayListExtra<Channel>("channels")
        @Suppress("DEPRECATION")
        val singleChannel = intent.getParcelableExtra<Channel>("current_channel")
        val hasInMemoryCatalog = sharedCatalog.isNotEmpty()
        val hasLegacyCatalog = !legacyCatalog.isNullOrEmpty()
        allChannels = when {
            hasInMemoryCatalog -> sharedCatalog
            hasLegacyCatalog -> legacyCatalog.orEmpty()
            singleChannel != null -> listOf(singleChannel)
            else -> emptyList()
        }
        channelNumberEntryController.configureForChannelCount(allChannels.size)
        currentChannelIndex = if (hasInMemoryCatalog || hasLegacyCatalog) {
            intent.getIntExtra("channel_index", 0)
        } else {
            // Si el proceso se recreó y ya no existe el catálogo en memoria, se preserva al
            // menos el canal solicitado por el Intent en lugar de romper la apertura del player.
            0
        }
        currentFilteredChannels = allChannels
        val selectedChannel = allChannels.getOrNull(currentChannelIndex)
        if (selectedChannel != null) {
            currentChannel = selectedChannel
            loadChannelInfo(selectedChannel)
            updateFavoriteButton(selectedChannel)
            val requestedSourceIndex = intent.getIntExtra("source_index", 0)
            val options = selectedChannel.options
            if (!options.isNullOrEmpty() && requestedSourceIndex in options.indices) {
                tryOption(selectedChannel, requestedSourceIndex)
            } else {
                playFirstValidOption(selectedChannel)
            }
        } else {
            showError("No hay canales disponibles")
        }
    }

    // ==================== OPTIONS DIALOG ====================

    private fun showOptionsDialog(channel: Channel) {
        val options = channel.options ?: run { showError("No hay opciones disponibles"); return }
        if (options.isEmpty()) { showError("No hay opciones disponibles"); return }
        AlertDialog.Builder(this)
            .setTitle("Seleccionar fuente — ${channel.name}")
            .setItems(options.map { it.name }.toTypedArray()) { _, which ->
                playerGeneration++
                recovery.reset(cancelPendingReconnect = true)
                val url = options[which].iframe
                val type = StreamUtils.resolveType(url, options[which].streamType)
                currentStreamUrl = url
                currentStreamType = type
                currentOptionIndex = which
                currentChannel = channel
                loadChannelInfo(channel)
                updateFavoriteButton(channel)
                playStream(url, type)
                updateControlsVisibility()
                hideControls()
            }
            .setNegativeButton("Cancelar") { _, _ -> if (currentStreamUrl.isEmpty()) finish() }
            .setCancelable(true)
            .show()
    }

    /** Panel de soporte: muestra el estado del audio nativo para compartirlo con una captura. */
    private fun showAudioInfoDialog() {
        val player = exoPlayer ?: return
        val summary = PlayerAudioDiagnostics.summarize(player.currentTracks)
        val report = PlayerAudioDiagnostics.formatReport(
            channelName = currentChannel?.name,
            type = currentStreamType,
            url = currentStreamUrl,
            summary = summary,
            // Se conserva entre reconexiones, pero solo se muestra si es del mismo servidor.
            lastError = lastAudioError.takeIf { lastAudioErrorHost == StreamUtils.hostForLog(currentStreamUrl) }
        )
        AlertDialog.Builder(this)
            .setTitle("Info de audio")
            .setMessage(report)
            .setPositiveButton("Cerrar", null)
            .show()
    }

    // ==================== HELPERS ====================

    private fun lockWebViewFocus() {
        if (!isTV) return
        webView.apply { isFocusable = false; isFocusableInTouchMode = false; isClickable = false; clearFocus() }
    }

    private fun showError(message: String) {
        progressBar.visibility = View.GONE
        errorText.text = if (isTV) "$message\n\nUsá ↻ Recargar en los controles para volver a intentar." else "$message\n\nPodés tocar Recargar en los controles para volver a intentar."
        errorText.visibility = View.VISIBLE
        updateControlsVisibility()
        // Ante un error dejamos la barra visible para que Recargar siga accesible
        // con el tacto o el mando, sin obligar a salir del reproductor.
        showControlsTemporarily()
        hideControlsRunnable?.let { mainHandler.removeCallbacks(it) }
        hideControlsRunnable = null
    }
}
