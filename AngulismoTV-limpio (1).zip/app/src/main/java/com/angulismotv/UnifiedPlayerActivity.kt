package com.angulismotv

import android.content.pm.ActivityInfo
import android.content.res.Configuration
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.OrientationEventListener
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.webkit.WebView
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.SeekBar
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.exoplayer2.ExoPlayer
import com.google.android.exoplayer2.PlaybackException
import com.google.android.exoplayer2.Player
import com.google.android.exoplayer2.ui.PlayerView
import com.angulismotv.player.CastController
import com.angulismotv.player.ChannelNumberInputBuffer
import com.angulismotv.player.PlayerChannelCatalog
import com.angulismotv.player.CastStream
import com.angulismotv.player.InlinePlayerHandoff
import com.angulismotv.player.FullscreenOrientationPolicy
import com.angulismotv.player.PlaybackRecoveryController
import com.angulismotv.player.PlayerTimelineController
import com.angulismotv.player.StreamUtils
import com.angulismotv.player.StreamMediaSourceFactory
import com.angulismotv.player.StreamUrlPolicy
import com.angulismotv.player.WebViewPlayerBridge
import com.angulismotv.player.WebViewPlaybackController
import com.angulismotv.player.applyPlayerSettings
import com.angulismotv.utils.NetworkUtils
import com.angulismotv.utils.loadChannelLogo
import com.angulismotv.models.Channel
import com.angulismotv.models.ChannelIdentity
import com.angulismotv.data.FavoritesStore
import com.angulismotv.ui.PlayerControlsLayoutController
import com.angulismotv.ui.PlayerChannelPanelController
import com.angulismotv.ui.PlayerPanelLayoutPolicy
import com.angulismotv.models.StreamType
import com.angulismotv.utils.DeviceHelper

private const val PORTRAIT_EXIT_DEBOUNCE_MS = 550L

class UnifiedPlayerActivity : AppCompatActivity() {

    // ==================== VIEWS ====================
    private lateinit var btnMenu: ImageButton
    private lateinit var playerView: PlayerView
    private lateinit var playerContainer: FrameLayout
    private lateinit var webView: WebView
    private lateinit var webViewTouchBlocker: View
    private lateinit var progressBar: ProgressBar
    private lateinit var errorText: TextView
    private lateinit var controlsOverlay: View
    private lateinit var bottomControls: View
    private lateinit var playerRemoteHelp: TextView
    private lateinit var btnRewind: ImageButton
    private lateinit var btnForward: ImageButton
    private lateinit var btnPlayPause: ImageButton
    private lateinit var btnClose: ImageButton
    private lateinit var btnOptions: ImageButton
    private lateinit var btnReloadStream: ImageButton
    private lateinit var btnFavoriteChannel: ImageButton
    private lateinit var favoritesStore: FavoritesStore
    private lateinit var mediaRouteButton: ImageButton
    private lateinit var channelLogo: ImageView
    private lateinit var channelNameText: TextView
    private lateinit var channelCategoryText: TextView
    private lateinit var playerControlsMainRow: LinearLayout
    private lateinit var playerActionGroupsRow: LinearLayout
    private lateinit var playerChannelIdentity: LinearLayout
    private lateinit var playerTransportControls: LinearLayout
    private lateinit var playerUtilityControls: LinearLayout
    private lateinit var playerControlsLayoutController: PlayerControlsLayoutController
    private lateinit var playerTimelineContainer: View
    private lateinit var playerSeekBar: SeekBar
    private lateinit var playerTimeCurrent: TextView
    private lateinit var playerTimeDuration: TextView
    private lateinit var timelineController: PlayerTimelineController

    // Panel lateral
    private lateinit var channelsPanelContainer: LinearLayout
    private lateinit var panelMenuColumn: LinearLayout
    private lateinit var channelsList: RecyclerView
    private lateinit var btnClosePanel: ImageButton
    private lateinit var btnAllChannels: LinearLayout
    private lateinit var allChannelsText: TextView

    // Búsqueda
    private lateinit var btnSearchTrigger: LinearLayout
    private lateinit var searchTriggerText: TextView
    private lateinit var menuSearchInput: EditText
    private lateinit var menuSearchResults: RecyclerView
    private lateinit var searchEmptyText: TextView

    // Categorías
    private lateinit var menuCategoriesList: RecyclerView

    // Minimal channel identity shown briefly while zapping on TV and mobile.
    private var zappingOverlay: LinearLayout? = null
    private var zappingLogo: ImageView? = null
    private var zappingChannelName: TextView? = null

    // ==================== STATE ====================
    private var exoPlayer: ExoPlayer? = null
    private var playerListener: Player.Listener? = null
    private var inlineSessionReturned = false
    private var inlineWebViewOrigin: InlinePlayerHandoff.Session? = null
    private var reuseInlineWebViewOnLoad = false
    private var inlineWebViewReturnedToFragment = false
    private lateinit var webBridge: WebViewPlayerBridge
    private lateinit var cast: CastController
    private var isTV = false
    private var currentChannel: Channel? = null
    private var controlsVisible = false
    // Conserva el último control enfocado para que el mando no vuelva siempre al inicio.
    private var lastFocusedControlId: Int = View.NO_ID
    private var isPanelOpen = false
    private var currentIsLive = false
    private var streamIsLive = false
    private var currentStreamUrl: String = ""
    private var currentStreamType: String = StreamType.AUTO
    private var isZapping = false
    private var clearZappingRunnable: Runnable? = null

    // Entrada de número de canal desde el mando: se confirma con OK o al vencer el tiempo.
    private var channelNumberBuffer = ChannelNumberInputBuffer()
    private val channelNumberTimeoutMs = 1_500L
    private val clearChannelNumberRunnable = Runnable { commitChannelNumberInput() }
    private lateinit var channelNumberOverlay: TextView

    // RECONEXION
    private var playerGeneration = 0
    // Channels
    private var allChannels: List<Channel> = emptyList()
    private var currentChannelIndex: Int = 0

    // Handlers
    private val mainHandler = Handler(Looper.getMainLooper())
    private var physicalOrientationListener: OrientationEventListener? = null
    private val fullscreenOrientationPolicy = FullscreenOrientationPolicy()
    private var portraitExitPending = false
    private var lastPhysicalOrientationDegrees = OrientationEventListener.ORIENTATION_UNKNOWN
    private val exitFullscreenAfterPortraitRunnable = Runnable {
        portraitExitPending = false
        if (isFinishing || isDestroyed) return@Runnable
        if (fullscreenOrientationPolicy.shouldExitToInline(lastPhysicalOrientationDegrees)) {
            // Retornar a la pantalla integrada después de una rotación física real a vertical.
            finish()
            overridePendingTransition(0, 0)
        }
    }
    private val recovery by lazy(LazyThreadSafetyMode.NONE) {
        PlaybackRecoveryController(
            handler = mainHandler,
            isGenerationCurrent = { generation -> generation == playerGeneration },
            isZapping = { isZapping },
            playerProvider = { exoPlayer },
            streamProvider = { currentStreamUrl to currentStreamType },
            networkAvailable = { NetworkUtils.isAvailable(this) },
            releasePlayer = ::releasePlayer,
            replayStream = ::showExoPlayer,
            showError = ::showError,
            showLoading = {
                progressBar.visibility = View.VISIBLE
                errorText.visibility = View.GONE
            }
        )
    }
    private var hideControlsRunnable: Runnable? = null
    private var zapRunnable: Runnable? = null
    private var stableStreamRunnable: Runnable? = null
    private lateinit var webViewPlaybackController: WebViewPlaybackController

    private lateinit var insetsController: WindowInsetsControllerCompat
    private lateinit var channelPanelController: PlayerChannelPanelController

    // ==================== LIFECYCLE ====================

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (!DeviceHelper.isTV(this)) enableImmersiveFullscreen()
        setContentView(R.layout.activity_unified_player)

        isTV = DeviceHelper.isTV(this)
        bindViews()
        playerControlsLayoutController = PlayerControlsLayoutController(
            context = this,
            isTV = isTV,
            playerControlsMainRow = playerControlsMainRow,
            playerChannelIdentity = playerChannelIdentity,
            playerActionGroupsRow = playerActionGroupsRow,
            playerTransportControls = playerTransportControls,
            playerUtilityControls = playerUtilityControls,
            bottomControls = bottomControls
        )
        timelineController = PlayerTimelineController(
            handler = mainHandler,
            container = playerTimelineContainer,
            seekBar = playerSeekBar,
            currentTime = playerTimeCurrent,
            durationTime = playerTimeDuration,
            playerProvider = { exoPlayer },
            isTimelineEnabled = { !isTV && currentStreamType != StreamType.IFRAME && controlsVisible },
            shouldContinueUpdates = { controlsVisible && exoPlayer != null }
        )
        playerControlsLayoutController.apply(resources.configuration.orientation)
        // En móvil, el fullscreen forzado permanece en horizontal. No se debe desbloquear
        // a FULL_SENSOR al llegar a landscape: si el teléfono aún está físicamente en vertical,
        // Android vuelve a girar inmediatamente la Activity. El regreso al mini-player se detecta
        // por orientación física real con OrientationEventListener.
        val inlineMobileFullscreen = !isTV &&
            intent.getBooleanExtra("from_inline_player", false) &&
            intent.getBooleanExtra("force_landscape_fullscreen", false)
        requestedOrientation = when {
            isTV -> ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
            inlineMobileFullscreen -> ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
            else -> ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
        }
        setupPhysicalOrientationListener(inlineMobileFullscreen)

        webBridge = WebViewPlayerBridge(
            webView = webView,
            handler = mainHandler,
            isIframeActive = { currentStreamType == StreamType.IFRAME },
            onStateChanged = ::updateWebViewControls
        )
        webViewPlaybackController = WebViewPlaybackController(
            webView = webView,
            touchBlocker = webViewTouchBlocker,
            playerView = playerView,
            playerContainer = playerContainer,
            progressBar = progressBar,
            controlsOverlay = controlsOverlay,
            bottomControls = bottomControls,
            bridge = webBridge,
            isTV = { isTV },
            currentStreamType = { currentStreamType },
            updateControlsVisibility = ::updateControlsVisibility,
            lockWebViewFocus = ::lockWebViewFocus,
            showControlsTemporarily = ::showControlsTemporarily,
            onMainFrameError = ::handleWebViewMainFrameError
        )
        cast = CastController(
            activity = this,
            button = mediaRouteButton,
            handler = mainHandler,
            currentStream = {
                if (currentStreamUrl.isEmpty()) null
                else {
                    // Antes de STATE_READY, ExoPlayer todavía puede no saber si una lista HLS/DASH
                    // es en vivo o bajo demanda. Dejarlo indefinido conserva el valor por defecto
                    // de Cast para streams live, en vez de marcar por error el arranque como VOD.
                    val liveStatus: Boolean? = when {
                        currentIsLive || streamIsLive -> true
                        exoPlayer?.playbackState == Player.STATE_READY -> false
                        else -> null
                    }
                    CastStream(currentStreamUrl, currentStreamType, currentChannel?.name ?: "Canal", liveStatus)
                }
            },
            onCastStarted = { exoPlayer?.pause() },
            onStatusChanged = { message ->
                mediaRouteButton.contentDescription = message
                if (isTV) playerRemoteHelp.text = message
                else android.widget.Toast.makeText(this, message, android.widget.Toast.LENGTH_SHORT).show()
            }
        )
        cast.setup(isTV)
        setupWebViewForTV()
        setupWebViewTouchBlocker()
        setupSidePanel()
        setupControls()
        loadChannelData()
    }

    private var resumePlaybackAfterPause = false

    override fun onResume() {
        super.onResume()
        physicalOrientationListener?.enable()
        // Si la Activity se reanudó después de una pausa justo cuando el teléfono ya estaba
        // vertical, no dependemos de que el sensor emita un evento adicional para completar el regreso.
        if (fullscreenOrientationPolicy.shouldExitToInline(lastPhysicalOrientationDegrees)) {
            schedulePortraitExitCheck()
        }
        if (!isTV) enableImmersiveFullscreen()
        cast.startDiscovery()
        webView.onResume()
        if (resumePlaybackAfterPause && !isZapping) exoPlayer?.play()
        resumePlaybackAfterPause = false
    }

    override fun onPause() {
        // Pausar el sensor mientras la Activity no está visible; al volver se comprobará de nuevo
        // la orientación física actual sin perder el hecho de que ya se había girado a landscape.
        physicalOrientationListener?.disable()
        cancelPortraitExitCheck()
        // Recordar la intención de reproducción antes de pausar o transferir la sesión.
        resumePlaybackAfterPause = !isZapping && exoPlayer?.playWhenReady == true
        super.onPause()
        if (isFinishing && intent.getBooleanExtra("from_inline_player", false)) {
            returnSessionToInline()
        } else if (!isZapping) {
            exoPlayer?.pause()
        }
        cast.stopDiscovery()
        webView.onPause()
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus && !isTV) enableImmersiveFullscreen()
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        playerControlsLayoutController.apply(newConfig.orientation)
        // No desbloquear a FULL_SENSOR aquí: la configuración visible puede cambiar a landscape
        // mientras el dispositivo sigue físicamente en portrait. El sensor dedicado distingue
        // ese giro impuesto del posterior regreso físico a vertical.
        if (!isTV) enableImmersiveFullscreen()
    }

    private fun setupPhysicalOrientationListener(enabledForThisActivity: Boolean) {
        if (!enabledForThisActivity) return
        physicalOrientationListener = object : OrientationEventListener(this) {
            override fun onOrientationChanged(orientation: Int) {
                if (isFinishing || isDestroyed) return
                lastPhysicalOrientationDegrees = orientation
                when (fullscreenOrientationPolicy.classify(orientation)) {
                    FullscreenOrientationPolicy.Position.PORTRAIT_AFTER_LANDSCAPE -> schedulePortraitExitCheck()
                    // Un movimiento intermedio o una lectura desconocida cancela la salida pendiente;
                    // solo una postura vertical estable puede cerrar el fullscreen.
                    FullscreenOrientationPolicy.Position.LANDSCAPE,
                    FullscreenOrientationPolicy.Position.PORTRAIT_BEFORE_LANDSCAPE,
                    FullscreenOrientationPolicy.Position.TRANSITION,
                    FullscreenOrientationPolicy.Position.UNKNOWN -> cancelPortraitExitCheck()
                }
            }
        }.also { listener ->
            if (!listener.canDetectOrientation()) {
                listener.disable()
                physicalOrientationListener = null
            }
        }
    }

    private fun schedulePortraitExitCheck() {
        if (portraitExitPending || isFinishing || isDestroyed) return
        portraitExitPending = true
        // Filtrar lecturas intermedias del sensor antes de salir.
        mainHandler.postDelayed(exitFullscreenAfterPortraitRunnable, PORTRAIT_EXIT_DEBOUNCE_MS)
    }

    private fun cancelPortraitExitCheck() {
        mainHandler.removeCallbacks(exitFullscreenAfterPortraitRunnable)
        portraitExitPending = false
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density + 0.5f).toInt()

    override fun onStop() {
        super.onStop()
        exoPlayer?.pause()
    }

    override fun onDestroy() {
        physicalOrientationListener?.disable()
        physicalOrientationListener = null
        cancelPortraitExitCheck()
        playerGeneration++
        if (::webViewPlaybackController.isInitialized) webViewPlaybackController.invalidatePendingLoad()
        clearZappingRunnable?.let(mainHandler::removeCallbacks)
        clearZappingRunnable = null
        zappingOverlay?.removeCallbacks(hideZappingRunnable)
        recovery.dispose()
        mainHandler.removeCallbacksAndMessages(null)
        stopTimelineUpdates()
        if (isFinishing && intent.getBooleanExtra("from_inline_player", false) && !inlineSessionReturned) {
            returnSessionToInline()
        }
        if (::cast.isInitialized) cast.dispose()
        releasePlayer()
        if (::webBridge.isInitialized) {
            webBridge.stopMonitor()
            webBridge.detach()
        }
        if (::webViewPlaybackController.isInitialized) {
            webViewPlaybackController.dispose(destroyWebView = !inlineWebViewReturnedToFragment)
        }
        super.onDestroy()
    }

    override fun onBackPressed() {
        if (!isTV) super.onBackPressed()
    }

    // ==================== BIND VIEWS ====================

    private fun bindViews() {
        btnMenu = findViewById(R.id.btn_menu)
        playerView = findViewById(R.id.player_view)
        playerContainer = findViewById(R.id.player_container)
        if (isTV) {
            // Superficie de foco de respaldo cuando el stream se reproduce dentro de WebView.
            playerContainer.isFocusable = true
            playerContainer.isFocusableInTouchMode = true
        }
        val webViewPlaceholder = findViewById<WebView>(R.id.web_view)
        val handedOffWebViewSession = if (intent.getBooleanExtra("reuse_inline_webview_session", false)) {
            InlinePlayerHandoff.takePendingWebViewForFullscreen()
        } else null
        if (handedOffWebViewSession?.webView != null) {
            val parent = webViewPlaceholder.parent as? ViewGroup
            val childIndex = parent?.indexOfChild(webViewPlaceholder) ?: -1
            val activityLayoutParams = webViewPlaceholder.layoutParams
            parent?.removeView(webViewPlaceholder)
            val transferred = handedOffWebViewSession.webView
            (transferred.parent as? ViewGroup)?.removeView(transferred)
            if (parent != null) parent.addView(transferred, childIndex.coerceAtLeast(0), activityLayoutParams)
            runCatching { webViewPlaceholder.stopLoading(); webViewPlaceholder.removeAllViews(); webViewPlaceholder.destroy() }
            webView = transferred
            inlineWebViewOrigin = handedOffWebViewSession
            reuseInlineWebViewOnLoad = true
        } else {
            webView = webViewPlaceholder
        }
        webViewTouchBlocker = findViewById(R.id.web_view_touch_blocker)
        progressBar = findViewById(R.id.progress_bar)
        errorText = findViewById(R.id.error_text)
        controlsOverlay = findViewById(R.id.controls_overlay)
        bottomControls = findViewById(R.id.bottom_controls)
        playerRemoteHelp = findViewById(R.id.player_remote_help)
        playerRemoteHelp.visibility = if (isTV) View.VISIBLE else View.GONE
        btnRewind = findViewById(R.id.btn_rewind)
        btnForward = findViewById(R.id.btn_forward)
        btnPlayPause = findViewById(R.id.btn_play_pause)
        btnClose = findViewById(R.id.btn_close_player)
        btnOptions = findViewById(R.id.btn_options)
        btnReloadStream = findViewById(R.id.btn_reload_stream)
        btnFavoriteChannel = findViewById(R.id.btn_favorite_channel)
        favoritesStore = FavoritesStore(this)
        mediaRouteButton = findViewById(R.id.media_route_button)
        channelLogo = findViewById(R.id.channel_logo)
        channelNameText = findViewById(R.id.channel_name)
        channelCategoryText = findViewById(R.id.channel_category)
        playerControlsMainRow = findViewById(R.id.player_controls_main_row)
        playerActionGroupsRow = findViewById(R.id.player_action_groups_row)
        playerChannelIdentity = findViewById(R.id.player_channel_identity)
        playerTransportControls = findViewById(R.id.player_transport_controls)
        playerUtilityControls = findViewById(R.id.player_utility_controls)
        playerTimelineContainer = findViewById(R.id.player_timeline_container)
        playerSeekBar = findViewById(R.id.player_seek_bar)
        playerTimeCurrent = findViewById(R.id.player_time_current)
        playerTimeDuration = findViewById(R.id.player_time_duration)
        channelsPanelContainer = findViewById(R.id.channels_panel_container)
        channelsList = findViewById(R.id.channels_list)
        panelMenuColumn = findViewById(R.id.panel_menu_column)
        btnClosePanel = findViewById(R.id.btn_close_panel)
        btnAllChannels = findViewById(R.id.btn_all_channels)
        allChannelsText = findViewById(R.id.all_channels_text)
        btnSearchTrigger = findViewById(R.id.btn_search_trigger)
        searchTriggerText = findViewById(R.id.search_trigger_text)
        menuSearchInput = findViewById(R.id.menu_search_input)
        menuSearchResults = findViewById(R.id.menu_search_results)
        searchEmptyText = findViewById(R.id.search_empty_text)
        menuCategoriesList = findViewById(R.id.menu_categories_list)

        zappingOverlay = findViewById(R.id.zapping_overlay)
        zappingLogo = findViewById(R.id.zapping_logo)
        zappingChannelName = findViewById(R.id.zapping_channel_name)
        channelNumberOverlay = findViewById(R.id.channel_number_overlay)
    }

    // ==================== FULLSCREEN ====================

    private fun enableImmersiveFullscreen() {
        WindowCompat.setDecorFitsSystemWindows(window, false)
        insetsController = WindowInsetsControllerCompat(window, window.decorView).apply {
            hide(WindowInsetsCompat.Type.systemBars())
            systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        }
        @Suppress("DEPRECATION")
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.R) {
            window.decorView.systemUiVisibility = (
                    View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                            or View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                            or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                            or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                            or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                            or View.SYSTEM_UI_FLAG_FULLSCREEN
                    )
        }
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
    }

    // ==================== WEBVIEW ====================

    private fun setupWebViewForTV() {
        if (!isTV) return
        webView.apply {
            isFocusable = false
            isFocusableInTouchMode = false
            isClickable = false
            isLongClickable = false
            applyPlayerSettings()
        }
    }

    private fun setupWebViewTouchBlocker() {
        webViewTouchBlocker.apply {
            setOnTouchListener { _, event ->
                if (!isTV && event.action == MotionEvent.ACTION_UP) {
                    if (controlsVisible) hideControls() else showControlsTemporarily()
                }
                true
            }
            visibility = View.GONE
        }
    }

    /**
     * Actualiza los controles según el estado del WebView
     */
    private fun updateWebViewControls() {
        runOnUiThread {
            if (currentStreamType == StreamType.IFRAME) {
                if (isTV && webBridge.isControllable) {
                    // TV: Mostrar controles traducidos
                    btnPlayPause.visibility = View.VISIBLE
                    updatePlayPauseButton(webBridge.isPlaying)

                    val showSeek = webBridge.duration > 0
                    btnRewind.visibility = if (showSeek) View.VISIBLE else View.GONE
                    btnForward.visibility = if (showSeek) View.VISIBLE else View.GONE

                    // Habilitar foco para navegación con D-Pad
                    if (isTV) {
                        btnPlayPause.isFocusable = true
                        btnRewind.isFocusable = showSeek
                        btnForward.isFocusable = showSeek
                    }
                } else if (!isTV) {
                    // Móvil: Ocultar controles nativos, usar los del iframe
                    btnPlayPause.visibility = View.GONE
                    btnRewind.visibility = View.GONE
                    btnForward.visibility = View.GONE
                }

                // Actualizar estado de los botones
                btnOptions.visibility = if (hasMultipleOptions()) View.VISIBLE else View.GONE

                if (isTV) {
                    btnMenu.visibility = View.VISIBLE
                    btnMenu.isFocusable = true
                    btnClose.isFocusable = true
                }
                if (controlsVisible) {
                    bottomControls.visibility = View.VISIBLE
                    bottomControls.bringToFront()
                }
                updateControlFocusOrder()
            }
        }
    }

    // ==================== SIDE PANEL ====================

    private fun setupSidePanel() {
        channelPanelController = PlayerChannelPanelController(
            activity = this,
            channelsList = channelsList,
            menuCategoriesList = menuCategoriesList,
            menuSearchResults = menuSearchResults,
            menuSearchInput = menuSearchInput,
            searchInputContainer = findViewById(R.id.search_input_container),
            searchEmptyText = searchEmptyText,
            contentTitle = findViewById(R.id.content_title),
            channelsCountText = findViewById(R.id.channels_count),
            btnAllChannels = btnAllChannels,
            allChannelsMarker = findViewById(R.id.all_channels_marker),
            allChannelsIcon = findViewById(R.id.all_channels_icon),
            allChannelsText = allChannelsText,
            btnSearchTrigger = btnSearchTrigger,
            btnClosePanel = btnClosePanel,
            getChannels = { allChannels },
            getCurrentChannel = { currentChannel },
            onChannelSelected = ::selectChannelFromSidePanel,
            onFocusChannels = ::moveFocusToChannelsList,
            onClosePanel = ::closeSidePanel
        )
        channelPanelController.initialize(isTV)
    }

    // ==================== CONTROLS ====================

    private fun setupControls() {
        btnClose.setOnClickListener { finish() }
        playerSeekBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onStartTrackingTouch(seekBar: SeekBar?) {
                timelineController.onStartTracking()
                resetAutoHideTimer()
            }

            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                timelineController.onProgressChanged(progress, fromUser)
            }

            override fun onStopTrackingTouch(seekBar: SeekBar?) {
                timelineController.onStopTracking()
                resetAutoHideTimer()
            }
        })

        // Configurar listeners para controles de WebView (TV)
        btnPlayPause.setOnClickListener {
            if (currentStreamType == StreamType.IFRAME && isTV) {
                webBridge.control("toggle")
                resetAutoHideTimer()
            } else if (currentStreamType != StreamType.IFRAME) {
                togglePlayPause()
                resetAutoHideTimer()
            }
        }

        btnRewind.setOnClickListener {
            if (currentStreamType == StreamType.IFRAME && isTV && webBridge.isControllable) {
                val newTime = (webBridge.currentTime - 10).coerceAtLeast(0)
                webBridge.control("seek", newTime.toDouble())
                resetAutoHideTimer()
            } else if (currentStreamType != StreamType.IFRAME) {
                if (!currentIsLive && !streamIsLive) {
                    exoPlayer?.seekTo(((exoPlayer?.currentPosition ?: 0) - 10_000).coerceAtLeast(0))
                    resetAutoHideTimer()
                }
            }
        }

        btnForward.setOnClickListener {
            if (currentStreamType == StreamType.IFRAME && isTV && webBridge.isControllable) {
                val newTime = (webBridge.currentTime + 10).coerceAtMost(webBridge.duration)
                webBridge.control("seek", newTime.toDouble())
                resetAutoHideTimer()
            } else if (currentStreamType != StreamType.IFRAME) {
                if (!currentIsLive && !streamIsLive) {
                    val pos = exoPlayer?.currentPosition ?: 0
                    val dur = exoPlayer?.duration ?: 0
                    if (dur > 0) exoPlayer?.seekTo((pos + 10_000).coerceAtMost(dur))
                    resetAutoHideTimer()
                }
            }
        }

        btnMenu.setOnClickListener { if (isTV) { if (isPanelOpen) closeSidePanel() else openSidePanel() } }
        btnMenu.visibility = View.GONE
        btnOptions.setOnClickListener { showOptionsDialog(currentChannel ?: return@setOnClickListener); resetAutoHideTimer() }
        btnReloadStream.setOnClickListener { reloadCurrentTransmission() }
        btnFavoriteChannel.setOnClickListener {
            val channel = currentChannel ?: return@setOnClickListener
            val added = favoritesStore.toggle(channel)
            updateFavoriteButton(channel)
            android.widget.Toast.makeText(this, if (added) "Agregado a favoritos" else "Quitado de favoritos", android.widget.Toast.LENGTH_SHORT).show()
            resetAutoHideTimer()
        }

        if (isTV) {
            listOf(btnMenu, btnPlayPause, btnRewind, btnForward, btnOptions, btnFavoriteChannel, btnReloadStream, btnClose, mediaRouteButton).forEach { control ->
                control.isFocusable = true
                control.isFocusableInTouchMode = true
                control.isClickable = true
                val size = (48 * resources.displayMetrics.density + 0.5f).toInt()
                control.layoutParams = control.layoutParams.apply { width = size; height = size }
                control.setOnFocusChangeListener { view, hasFocus ->
                    if (hasFocus) {
                        lastFocusedControlId = view.id
                        view.animate().scaleX(1.06f).scaleY(1.06f).setDuration(120L).start()
                        if (controlsVisible && !isPanelOpen) resetAutoHideTimer()
                    } else {
                        view.animate().scaleX(1f).scaleY(1f).setDuration(120L).start()
                    }
                }
            }
            controlsOverlay.visibility = View.GONE
            bottomControls.visibility = View.GONE
            controlsVisible = false
        } else {
            playerView.setOnClickListener {
                if (controlsVisible) hideControls() else showControlsTemporarily()
            }
        }
    }

    private fun togglePlayPause() {
        val player = exoPlayer ?: return
        if (player.isPlaying) {
            player.pause()
            updatePlayPauseButton(false)
        } else {
            player.play()
            updatePlayPauseButton(true)
        }
    }

    /** Mantiene icono y etiqueta accesible sincronizados con la acción disponible. */
    private fun updatePlayPauseButton(isPlaying: Boolean) {
        btnPlayPause.setImageResource(if (isPlaying) R.drawable.ic_pause else R.drawable.ic_play)
        btnPlayPause.contentDescription = if (isPlaying) "Pausar" else "Reproducir"
    }

    // ==================== TV KEY HANDLING ====================

    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        if (!isTV) return super.dispatchKeyEvent(event)
        if (event.action != KeyEvent.ACTION_DOWN) return super.dispatchKeyEvent(event)
        if (event.repeatCount > 0 && keyCodeToDigit(event.keyCode) >= 0) return true
        val handled = handleTVKey(event.keyCode)
        return if (handled) true else super.dispatchKeyEvent(event)
    }

    private fun handleTVKey(keyCode: Int): Boolean {
        if (!isPanelOpen) {
            val digit = keyCodeToDigit(keyCode)
            if (digit >= 0) {
                appendChannelNumberDigit(digit)
                return true
            }
        }

        return when (keyCode) {
            KeyEvent.KEYCODE_BACK -> when {
                isPanelOpen -> channelPanelController.handleBackInPanel()
                controlsVisible -> { hideControls(); true }
                else -> { finish(); true }
            }
            KeyEvent.KEYCODE_DPAD_UP -> when {
                isPanelOpen -> handlePanelVerticalFocus(keyCode)
                controlsVisible -> { navigateControlsUp(); true }
                !isZapping -> { changeChannel(-1); true }
                else -> true
            }
            KeyEvent.KEYCODE_DPAD_DOWN -> when {
                isPanelOpen -> handlePanelVerticalFocus(keyCode)
                controlsVisible -> { navigateControlsDown(); true }
                !isZapping -> { changeChannel(1); true }
                else -> true
            }
            KeyEvent.KEYCODE_DPAD_LEFT -> when {
                isPanelOpen -> {
                    if (isRightPanelFocused()) moveFocusToCategoriesPanel()
                    else closeSidePanel()
                    true
                }
                controlsVisible -> { navigateControlsLeft(); true }
                else -> { openSidePanel(); true }
            }
            KeyEvent.KEYCODE_DPAD_RIGHT -> when {
                isPanelOpen -> {
                    if (currentFocus?.id == R.id.btn_search_trigger) {
                        channelPanelController.activateSearchMode()
                        true
                    } else if (currentFocus?.id == R.id.btn_close_panel) {
                        closeSidePanel()
                        true
                    } else if (!isRightPanelFocused()) {
                        // Categorías/buscador -> lista. Desde la lista, volver al vídeo
                        // cerrando el panel evita que el foco se escape a controles de fondo.
                        moveFocusToChannelsList()
                        true
                    } else {
                        closeSidePanel()
                        true
                    }
                }
                controlsVisible -> { navigateControlsRight(); true }
                else -> { showControls(); true }
            }
            KeyEvent.KEYCODE_DPAD_CENTER, KeyEvent.KEYCODE_ENTER, KeyEvent.KEYCODE_NUMPAD_ENTER -> when {
                channelNumberBuffer.value.isNotEmpty() && !isPanelOpen -> { commitChannelNumberInput(); true }
                isPanelOpen -> false
                !controlsVisible -> { showControls(); true }
                else -> { activateFocusedControl(); true }
            }
            KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE -> {
                if (currentStreamType == StreamType.IFRAME) {
                    webBridge.control("toggle")
                } else {
                    togglePlayPause()
                }
                true
            }
            KeyEvent.KEYCODE_MEDIA_PLAY -> {
                if (currentStreamType == StreamType.IFRAME) {
                    webBridge.control("play")
                } else {
                    exoPlayer?.play()
                    updatePlayPauseButton(true)
                }
                true
            }
            KeyEvent.KEYCODE_MEDIA_PAUSE -> {
                if (currentStreamType == StreamType.IFRAME) {
                    webBridge.control("pause")
                } else {
                    exoPlayer?.pause()
                    updatePlayPauseButton(false)
                }
                true
            }
            KeyEvent.KEYCODE_MEDIA_FAST_FORWARD -> { btnForward.performClick(); true }
            KeyEvent.KEYCODE_MEDIA_REWIND -> { btnRewind.performClick(); true }
            else -> false
        }
    }

    private fun keyCodeToDigit(keyCode: Int): Int = when {
        keyCode in KeyEvent.KEYCODE_0..KeyEvent.KEYCODE_9 -> keyCode - KeyEvent.KEYCODE_0
        keyCode in KeyEvent.KEYCODE_NUMPAD_0..KeyEvent.KEYCODE_NUMPAD_9 -> keyCode - KeyEvent.KEYCODE_NUMPAD_0
        else -> -1
    }

    private fun appendChannelNumberDigit(digit: Int) {
        if (allChannels.isEmpty() || isZapping) return
        val result = channelNumberBuffer.append(digit, allChannels.size) ?: return
        channelNumberOverlay.text = "CANAL  ${result.value}"
        channelNumberOverlay.visibility = View.VISIBLE
        mainHandler.removeCallbacks(clearChannelNumberRunnable)
        mainHandler.postDelayed(clearChannelNumberRunnable, channelNumberTimeoutMs)

        // Para catálogos grandes se permiten 4 o 5 cifras; la entrada completa se aplica
        // al alcanzar el máximo o al vencer el timeout/confirmar con OK.
        if (result.shouldCommitImmediately) commitChannelNumberInput()
    }

    private fun commitChannelNumberInput() {
        mainHandler.removeCallbacks(clearChannelNumberRunnable)
        val requestedNumber = channelNumberBuffer.takeNumber()
        if (::channelNumberOverlay.isInitialized) channelNumberOverlay.visibility = View.GONE
        if (requestedNumber == null || requestedNumber !in 1..allChannels.size || isZapping) return
        val index = requestedNumber - 1
        val channel = allChannels.getOrNull(index) ?: return
        if (index != currentChannelIndex) zapTo(index, channel)
    }

    private fun isDescendantFocused(view: View): Boolean {
        val focused = currentFocus ?: return false
        var parent = focused.parent
        while (parent != null) {
            if (parent === view) return true
            parent = (parent as? View)?.parent
        }
        return false
    }

    private fun isRightPanelFocused(): Boolean =
        channelsList.hasFocus() || isDescendantFocused(channelsList) ||
            menuSearchResults.hasFocus() || isDescendantFocused(menuSearchResults)

    private fun moveFocusToCategoriesPanel() {
        // Al volver desde canales, retomamos la categoría activa (o el campo de búsqueda).
        if (channelPanelController.isSearchActive) {
            menuSearchInput.requestFocus()
            return
        }
        if (channelPanelController.currentCategory.equals("todos", ignoreCase = true)) {
            btnAllChannels.requestFocus()
            return
        }
        val position = channelPanelController.categoriesAdapter.getPositionForKey(channelPanelController.currentCategory)
        if (position < 0) {
            btnAllChannels.requestFocus()
            return
        }
        menuCategoriesList.post {
            (menuCategoriesList.layoutManager as? LinearLayoutManager)?.scrollToPositionWithOffset(position, 0)
            menuCategoriesList.post {
                val item = menuCategoriesList.findViewHolderForAdapterPosition(position)?.itemView
                if (item?.requestFocus() != true) menuCategoriesList.requestFocus()
            }
        }
    }

    private fun moveFocusToChannelsList() {
        // Si la búsqueda no tuvo coincidencias, el destino accionable sigue siendo el campo.
        if (channelPanelController.isSearchActive && searchEmptyText.visibility == View.VISIBLE) {
            menuSearchInput.requestFocus()
            return
        }
        // En modo búsqueda, derecha lleva a los resultados; en navegación normal, a los canales.
        if (channelPanelController.isSearchActive && menuSearchResults.visibility == View.VISIBLE) {
            // La búsqueda usa AsyncListDiffer; esperar a que el primer resultado esté adjunto.
            menuSearchResults.post {
                menuSearchResults.post {
                    val item = if (channelPanelController.searchAdapter.itemCount > 0) {
                        menuSearchResults.findViewHolderForAdapterPosition(0)?.itemView
                    } else null
                    if (item?.requestFocus() != true) menuSearchResults.requestFocus()
                }
            }
            return
        }

        val selectedInFiltered = channelPanelController.filteredChannels.indexOfFirst { currentChannel != null && ChannelIdentity.same(it, currentChannel!!) }
        val targetPosition = if (selectedInFiltered >= 0) selectedInFiltered else 0
        channelsList.post {
            val lm = channelsList.layoutManager as? LinearLayoutManager
            lm?.scrollToPositionWithOffset(targetPosition, 0)
            channelsList.post {
                val item = channelsList.findViewHolderForAdapterPosition(targetPosition)?.itemView
                if (item?.requestFocus() != true) channelsList.requestFocus()
            }
        }
    }

    /** Foco vertical explícito para que las acciones fijas formen parte del mismo rail. */
    private fun handlePanelVerticalFocus(keyCode: Int): Boolean {
        val focused = currentFocus ?: return false
        return when {
            focused.id == R.id.btn_search_trigger && keyCode == KeyEvent.KEYCODE_DPAD_DOWN -> {
                btnAllChannels.requestFocus()
                true
            }
            focused.id == R.id.btn_all_channels && keyCode == KeyEvent.KEYCODE_DPAD_UP -> {
                btnSearchTrigger.requestFocus()
                true
            }
            focused.id == R.id.btn_all_channels && keyCode == KeyEvent.KEYCODE_DPAD_DOWN -> {
                focusFirstCategory()
                true
            }
            focused.id == R.id.btn_close_panel && keyCode == KeyEvent.KEYCODE_DPAD_DOWN -> {
                btnSearchTrigger.requestFocus()
                true
            }
            focused.id == R.id.btn_search_trigger && keyCode == KeyEvent.KEYCODE_DPAD_UP -> {
                btnClosePanel.requestFocus()
                true
            }
            else -> false
        }
    }

    private fun focusFirstCategory() {
        if (channelPanelController.categoriesAdapter.itemCount == 0) {
            moveFocusToChannelsList()
            return
        }
        menuCategoriesList.post {
            (menuCategoriesList.layoutManager as? LinearLayoutManager)?.scrollToPositionWithOffset(0, 0)
            menuCategoriesList.post {
                val first = menuCategoriesList.findViewHolderForAdapterPosition(0)?.itemView
                if (first?.requestFocus() != true) menuCategoriesList.requestFocus()
            }
        }
    }

    private fun activateFocusedControl() {
        when (currentFocus?.id) {
            R.id.btn_menu -> btnMenu.performClick()
            R.id.btn_play_pause -> btnPlayPause.performClick()
            R.id.btn_rewind -> btnRewind.performClick()
            R.id.btn_forward -> btnForward.performClick()
            R.id.btn_options -> btnOptions.performClick()
            R.id.btn_reload_stream -> btnReloadStream.performClick()
            R.id.btn_close_player -> btnClose.performClick()
            else -> requestPreferredControlFocus()
        }
    }

    /**
     * Orden real de izquierda a derecha según activity_unified_player.xml.
     * btnMenu está después de los controles de transporte; ponerlo al principio hacía
     * que el D-pad saltara visualmente ese botón al avanzar desde Adelantar.
     */
    private fun visibleControls(): List<View> = listOf(
        btnRewind,
        btnPlayPause,
        btnForward,
        btnMenu,
        mediaRouteButton,
        btnOptions,
        btnReloadStream,
        btnClose
    ).filter { it.visibility == View.VISIBLE && it.isFocusable && it.isEnabled }

    /** Asegura el mismo orden en el foco nativo cuando Android no usa el dispatch manual. */
    private fun updateControlFocusOrder() {
        if (!isTV) return
        val controls = visibleControls()
        controls.forEachIndexed { index, control ->
            control.nextFocusLeftId = controls.getOrNull(index - 1)?.id ?: View.NO_ID
            control.nextFocusRightId = controls.getOrNull(index + 1)?.id ?: View.NO_ID
        }
    }

    /** Prioriza el control que el usuario estaba usando; si desapareció para esta fuente,
     * elige uno visible y enfocable como destino seguro. */
    private fun requestPreferredControlFocus() {
        if (!isTV || !controlsVisible || isPanelOpen) return
        val controls = visibleControls()
        if (controls.isEmpty()) {
            playerContainer.requestFocus()
            return
        }
        val preferred = controls.firstOrNull { it.id == lastFocusedControlId } ?: controls.first()
        preferred.requestFocus()
    }
    private fun navigateControlsRight() {
        val controls = visibleControls()
        if (controls.isEmpty()) return
        val index = controls.indexOfFirst { it.hasFocus() }
        controls.getOrNull(if (index < 0) 0 else (index + 1).coerceAtMost(controls.lastIndex))?.requestFocus()
        resetAutoHideTimer()
    }

    private fun navigateControlsLeft() {
        val controls = visibleControls()
        if (controls.isEmpty()) return
        val index = controls.indexOfFirst { it.hasFocus() }
        controls.getOrNull(if (index < 0) 0 else (index - 1).coerceAtLeast(0))?.requestFocus()
        resetAutoHideTimer()
    }

    private fun navigateControlsUp() = navigateControlsLeft()
    private fun navigateControlsDown() = navigateControlsRight()

    // ==================== CHANNEL SELECTION ====================

    private fun selectChannelFromSidePanel(channel: Channel, position: Int) {
        val globalIndex = allChannels.indexOfFirst { ChannelIdentity.same(it, channel) }
        closeSidePanel()
        // No iniciar zapping con índice -1: puede ocurrir si una búsqueda antigua queda
        // visible mientras el catálogo se actualiza.
        if (globalIndex < 0 || globalIndex == currentChannelIndex) return
        if (!isZapping) zapTo(globalIndex, allChannels[globalIndex])
    }

    private fun changeChannel(delta: Int) {
        if (allChannels.isEmpty() || isZapping) return
        zapTo((currentChannelIndex + delta).mod(allChannels.size), allChannels[(currentChannelIndex + delta).mod(allChannels.size)])
    }

    private fun zapTo(index: Int, channel: Channel) {
        clearZappingRunnable?.let(mainHandler::removeCallbacks)
        clearZappingRunnable = null
        isZapping = true
        playerGeneration++
        webViewPlaybackController.invalidatePendingLoad()
        recovery.resetReconnectAttempts()
        recovery.cancelPendingReconnect()
        stableStreamRunnable?.let { mainHandler.removeCallbacks(it) }

        releasePlayer()

        // Resetear completamente el WebView
        webView.apply {
            stopLoading()
            loadUrl("about:blank")
            clearHistory()
            // Eliminar el bridge anterior si existe
            webBridge.detach()
        }
        webView.visibility = View.GONE

        // Configurar bloqueo táctil según dispositivo
        if (isTV) {
            webViewTouchBlocker.visibility = View.VISIBLE
            lockWebViewFocus()
        } else {
            // Móvil: SIN BLOQUEO TÁCTIL para usar controles del iframe
            webViewTouchBlocker.visibility = View.GONE
            webView.isClickable = true
            webView.isFocusable = true
            webView.isFocusableInTouchMode = true
        }

        // Resetear estado del WebView
        webBridge.reset()
        webBridge.stopMonitor()

        progressBar.visibility = View.VISIBLE
        errorText.visibility = View.GONE

        showZappingOverlay(channel)

        zapRunnable?.let { mainHandler.removeCallbacks(it) }
        zapRunnable = Runnable {
            currentChannelIndex = index
            currentChannel = channel
            loadChannelInfo(channel)
            updateFavoriteButton(channel)
            playFirstValidOption(channel)
            clearZappingRunnable?.let(mainHandler::removeCallbacks)
            clearZappingRunnable = Runnable {
                isZapping = false
                clearZappingRunnable = null
            }.also { mainHandler.postDelayed(it, 200L) }
        }
        mainHandler.postDelayed(zapRunnable!!, 300L)
    }

    // ==================== ZAPPING OVERLAY ====================

    private fun showZappingOverlay(channel: Channel) {
        val overlay = zappingOverlay ?: return
        overlay.visibility = View.VISIBLE
        // Keep the transient identity above any visible player controls without capturing focus.
        overlay.bringToFront()
        zappingChannelName?.apply {
            val number = allChannels.indexOfFirst { ChannelIdentity.same(it, channel) } + 1
            text = if (number > 0) "$number  ·  ${channel.name}" else channel.name
            // Keep the transient label inside the viewport on narrow phones and TV screens.
            val maxNameWidthDp = if (isTV) 480 else 220
            maxWidth = (maxNameWidthDp * resources.displayMetrics.density).toInt()
        }
        zappingLogo?.loadChannelLogo(channel.name, channel.logo)
        overlay.removeCallbacks(hideZappingRunnable)
        overlay.postDelayed(hideZappingRunnable, 2_000)
    }

    private val hideZappingRunnable = Runnable { zappingOverlay?.visibility = View.GONE }

    // ==================== CHANNEL INFO ====================

    private fun loadChannelInfo(channel: Channel) {
        channelNameText.text = channel.name
        channelLogo.loadChannelLogo(channel.name, channel.logo)
        val categoryLabel = channel.category.trim().takeIf {
            it.isNotBlank() && !it.equals("todos", ignoreCase = true)
        }?.let(::formatCategoryLabel).orEmpty()
        channelCategoryText.text = categoryLabel
        channelCategoryText.visibility = if (categoryLabel.isBlank()) View.GONE else View.VISIBLE
    }

    // ==================== PLAYBACK ====================

    private var currentOptionIndex: Int = 0

    /** Reintenta la fuente actual sin cambiar de canal ni reiniciar la selección del usuario. */
    private fun reloadCurrentTransmission() {
        val channel = currentChannel
        if (channel == null) {
            showError("No hay ningún canal seleccionado para recargar.")
            return
        }

        playerGeneration++
        isZapping = false
        cancelOptionFallback()
        stableStreamRunnable?.let { mainHandler.removeCallbacks(it) }
        stableStreamRunnable = null
        recovery.resetReconnectAttempts()
        recovery.cancelPendingReconnect()
        webViewPlaybackController.invalidatePendingLoad()
        errorText.visibility = View.GONE
        progressBar.visibility = View.VISIBLE

        val url = currentStreamUrl
        val type = currentStreamType
        if (url.isNotBlank() && StreamUrlPolicy.isHttpUrl(url)) {
            currentStreamUrl = url
            currentStreamType = type
            if (type == StreamType.IFRAME) {
                // Forzar navegación nueva; no reutilizar el documento del iframe que pudo fallar.
                reuseInlineWebViewOnLoad = false
                webViewPlaybackController.load(url, reuseLoadedPage = false)
            } else {
                playStream(url, type)
            }
        } else {
            playFirstValidOption(channel)
        }

        if (controlsVisible) resetAutoHideTimer()
    }

    private fun playFirstValidOption(channel: Channel) {
        errorText.visibility = View.GONE
        currentOptionIndex = 0
        if (!channel.options.isNullOrEmpty()) {
            tryOption(channel, 0)
        } else {
            val url = channel.streamUrl ?: ""
            val type = StreamUtils.resolveType(url, channel.streamType ?: StreamType.AUTO)
            if (url.isNotEmpty()) {
                currentStreamUrl = url
                currentStreamType = type
                playStream(url, type)
            } else {
                showError("No hay fuentes disponibles")
            }
        }
    }

    private fun tryOption(channel: Channel, optionIndex: Int) {
        val options = channel.options ?: return
        if (optionIndex >= options.size) {
            showError("No se pudo reproducir con ninguna fuente disponible")
            return
        }

        val option = options[optionIndex]
        val url = option.iframe
        val type = StreamUtils.resolveType(url, option.streamType)
        if (url.isEmpty()) {
            tryOption(channel, optionIndex + 1)
            return
        }

        currentStreamUrl = url
        currentStreamType = type
        currentOptionIndex = optionIndex
        android.util.Log.d("OPTION_TRY", "Intentando opción ${optionIndex + 1}/${options.size}: ${option.name} (${StreamUtils.hostForLog(url)})")

        playStream(url, type)
        updateControlsVisibility()

        scheduleOptionFallback(channel, optionIndex)
    }

    private var optionFallbackRunnable: Runnable? = null

    private fun scheduleOptionFallback(channel: Channel, optionIndex: Int) {
        cancelOptionFallback()
        val option = channel.options?.getOrNull(optionIndex) ?: return
        val optionType = StreamUtils.resolveType(option.iframe, option.streamType)

        // Un iframe no utiliza ExoPlayer. Que exoPlayer sea null no significa que esa fuente
        // haya fallado: algunas páginas tardan en iniciar el vídeo y no exponen su estado.
        // En ese caso el respaldo automático se ejecuta solo ante un error real de carga.
        if (optionType == StreamType.IFRAME) return

        val gen = playerGeneration
        optionFallbackRunnable = Runnable {
            if (playerGeneration != gen || isZapping) return@Runnable
            if (currentChannel != channel || currentOptionIndex != optionIndex) return@Runnable
            val player = exoPlayer
            if (player == null || player.playbackState == Player.STATE_IDLE || player.playbackState == Player.STATE_BUFFERING) {
                android.util.Log.w("OPTION_FALLBACK", "Opción ${optionIndex + 1} tardó demasiado, probando la siguiente")
                val nextIndex = optionIndex + 1
                if (nextIndex < (channel.options?.size ?: 0)) {
                    releasePlayer()
                    tryOption(channel, nextIndex)
                }
            }
        }
        mainHandler.postDelayed(optionFallbackRunnable!!, 12_000)
    }

    private fun cancelOptionFallback() {
        optionFallbackRunnable?.let { mainHandler.removeCallbacks(it) }
        optionFallbackRunnable = null
    }

    private fun playStream(url: String, type: String) {
        if (!StreamUrlPolicy.isHttpUrl(url)) {
            showError("La dirección de reproducción no es válida o no está admitida.")
            return
        }
        when (type) {
            StreamType.IFRAME -> showWebView(url)
            StreamType.HLS, StreamType.DASH, StreamType.MP4 -> showExoPlayer(url, type)
            else -> showExoPlayer(url, StreamType.HLS)
        }
    }

    // ==================== EXO PLAYER ====================

    private fun showExoPlayer(url: String, type: String) {
        // Evita que una respuesta tardía de una navegación WebView previa cambie la UI actual.
        playerTimelineContainer.visibility = View.GONE
        stopTimelineUpdates()
        webViewPlaybackController.invalidatePendingLoad()
        stableStreamRunnable?.let { mainHandler.removeCallbacks(it) }
        stableStreamRunnable = null
        recovery.stopWatchdog()
        releasePlayer()

        val myGeneration = playerGeneration
        val hadVisibleWebView = webView.visibility == View.VISIBLE
        playerView.visibility = View.VISIBLE
        webView.visibility = View.GONE
        webViewTouchBlocker.visibility = View.GONE
        progressBar.visibility = View.VISIBLE
        errorText.visibility = View.GONE
        currentIsLive = false
        streamIsLive = false
        if (hadVisibleWebView) {
            // The selected source type may already have been updated by tryOption(). Use the
            // active view instead, or a previous iframe can keep playing audio behind native video.
            webBridge.stopMonitor()
            webBridge.detach()
            webView.stopLoading()
            webView.loadUrl("about:blank")
        }
        currentStreamType = type

        if (isTV) {
            playerView.isFocusable = true
            playerView.isFocusableInTouchMode = true
            playerView.requestFocus()
            lockWebViewFocus()
        }

        val handoff = if (intent.getBooleanExtra("reuse_inline_player_session", false)) {
            InlinePlayerHandoff.takeForFullscreen(url, type)
        } else null

        if (handoff?.player != null) {
            // Reuse the exact same ExoPlayer. Do not set a MediaSource or call prepare():
            // this keeps the live session, buffer, and current playback position.
            val player = handoff.player
            exoPlayer = player
            playerView.player = player
            playerView.useController = false
            attachPlayerListener(player, url, type, myGeneration)
            player.playWhenReady = handoff.wasPlaying
            updatePlayPauseButton(player.isPlaying)
            handlePlayerState(player, url, type, myGeneration, player.playbackState)
            return
        }

        val mediaSource = StreamMediaSourceFactory.create(url, type)

        val player = ExoPlayer.Builder(this)
            .setLoadControl(StreamMediaSourceFactory.createLoadControl(StreamMediaSourceFactory.BufferProfile.FULLSCREEN))
            .build()
        exoPlayer = player
        playerView.player = player
        playerView.useController = false
        attachPlayerListener(player, url, type, myGeneration)
        player.setMediaSource(mediaSource)
        player.prepare()
        player.playWhenReady = true
    }

    private fun attachPlayerListener(player: ExoPlayer, url: String, type: String, generation: Int) {
        playerListener?.let { previous -> exoPlayer?.let { old -> runCatching { old.removeListener(previous) } } }
        val listener = object : Player.Listener {
            override fun onPlaybackStateChanged(state: Int) {
                if (playerGeneration != generation || exoPlayer !== player) return
                handlePlayerState(player, url, type, generation, state)
            }

            override fun onIsPlayingChanged(isPlaying: Boolean) {
                if (playerGeneration == generation && exoPlayer === player) updatePlayPauseButton(isPlaying)
            }

            override fun onPlayerError(error: PlaybackException) {
                if (playerGeneration != generation || exoPlayer !== player || isZapping) return
                stableStreamRunnable?.let { mainHandler.removeCallbacks(it) }
                stableStreamRunnable = null
                recovery.stopWatchdog()
                when (type) {
                    StreamType.HLS, StreamType.DASH -> {
                        progressBar.visibility = View.VISIBLE
                        errorText.visibility = View.GONE
                        recovery.scheduleReconnect(url, type, generation)
                    }
                    StreamType.MP4 -> showError("Error al reproducir. Verificá tu conexión.")
                    else -> {
                        progressBar.visibility = View.VISIBLE
                        errorText.visibility = View.GONE
                        recovery.scheduleReconnect(url, type, generation)
                    }
                }
            }
        }
        playerListener = listener
        player.addListener(listener)
    }

    private fun handlePlayerState(player: ExoPlayer, url: String, type: String, generation: Int, state: Int) {
        if (playerGeneration != generation || exoPlayer !== player) return
        when (state) {
            Player.STATE_BUFFERING -> {
                progressBar.visibility = View.VISIBLE
                errorText.visibility = View.GONE
            }
            Player.STATE_READY -> {
                progressBar.visibility = View.GONE
                errorText.visibility = View.GONE
                currentIsLive = player.isCurrentWindowLive
                streamIsLive = player.isCurrentWindowLive || player.duration == -1L
                recovery.resetReconnectAttempts()
                updateControlsVisibility()
                if (!isTV) {
                    showControlsTemporarily()
                    startTimelineUpdates()
                }
                stableStreamRunnable?.let { mainHandler.removeCallbacks(it) }
                stableStreamRunnable = Runnable {
                    if (playerGeneration == generation) {
                        recovery.resetReconnectAttempts()
                        errorText.visibility = View.GONE
                    }
                }
                mainHandler.postDelayed(stableStreamRunnable!!, 8_000)
                cancelOptionFallback()
                recovery.startWatchdog(generation)
            }
            Player.STATE_ENDED -> {
                stableStreamRunnable?.let { mainHandler.removeCallbacks(it) }
                stableStreamRunnable = null
                recovery.stopWatchdog()
                if (type == StreamType.HLS || type == StreamType.DASH || currentIsLive || streamIsLive) {
                    progressBar.visibility = View.VISIBLE
                    errorText.visibility = View.GONE
                    recovery.scheduleReconnect(url, type, generation)
                }
            }
            else -> Unit
        }
    }

    /** Returns the active playback session and latest channel selection before fullscreen exits. */
    private fun returnSessionToInline() {
        if (inlineSessionReturned) return
        val channel = currentChannel ?: return
        val player = exoPlayer
        val wasPlaying = resumePlaybackAfterPause || (player?.playWhenReady == true)
        recovery.stopWatchdog()
        cancelOptionFallback()
        recovery.cancelPendingReconnect()
        zapRunnable?.let { mainHandler.removeCallbacks(it) }
        zapRunnable = null
        stableStreamRunnable?.let { mainHandler.removeCallbacks(it) }
        stableStreamRunnable = null
        if (player != null) {
            playerListener?.let { listener -> runCatching { player.removeListener(listener) } }
            playerListener = null
            if (::playerView.isInitialized) playerView.player = null
            exoPlayer = null // hand the engine back; releasePlayer() must not release it.
        }
        val returnWebView = inlineWebViewOrigin?.takeIf { webViewReturnedFromInlineOrigin() }
        if (returnWebView != null) {
            webBridge.stopMonitor()
            webBridge.detach()
            webViewPlaybackController.resetNavigationHandlers()
            if (currentStreamType != StreamType.IFRAME) {
                webView.stopLoading()
                webView.loadUrl("about:blank")
            }
            (webView.parent as? ViewGroup)?.removeView(webView)
            inlineWebViewReturnedToFragment = true
        }
        InlinePlayerHandoff.returnToInline(
            InlinePlayerHandoff.Session(
                player = player,
                channel = channel,
                streamUrl = currentStreamUrl,
                streamType = currentStreamType,
                sourceIndex = currentOptionIndex,
                wasPlaying = wasPlaying,
                webView = returnWebView?.webView,
                webViewParentIndex = returnWebView?.webViewParentIndex ?: -1,
                webViewLayoutParams = returnWebView?.webViewLayoutParams
            )
        )
        inlineSessionReturned = true
    }

    private fun webViewReturnedFromInlineOrigin(): Boolean =
        inlineWebViewOrigin?.webView === webView && intent.getBooleanExtra("reuse_inline_webview_session", false)

    // ==================== WEBVIEW (IFRAME) ====================

    /**
     * Muestra el WebView con soporte para control híbrido:
     * - TV: Controles nativos traducidos al iframe
     * - Móvil: Sin bloqueo táctil, controles nativos del iframe
     */
    private fun showWebView(url: String) {
        val reuseLoadedPage = reuseInlineWebViewOnLoad && inlineWebViewOrigin?.streamUrl == url
        releasePlayer()
        playerView.visibility = View.GONE
        playerTimelineContainer.visibility = View.GONE
        stopTimelineUpdates()

        // El estado del stream pertenece a la Activity; la configuración y navegación web
        // viven en WebViewPlaybackController.
        currentIsLive = false
        streamIsLive = false
        currentStreamType = StreamType.IFRAME
        if (reuseLoadedPage) reuseInlineWebViewOnLoad = false
        webViewPlaybackController.load(url, reuseLoadedPage)
    }

    /** Un error de la página principal sí permite probar la siguiente fuente del canal. */
    private fun handleWebViewMainFrameError(loadGeneration: Int, failedUrl: String?, description: String?) {
        if (!webViewPlaybackController.isCurrentLoad(loadGeneration) || currentStreamType != StreamType.IFRAME) return
        if (failedUrl == "about:blank") return

        android.util.Log.w("WebView", "Falló la carga de una fuente (${StreamUtils.hostForLog(failedUrl.orEmpty())}); detalle=${description?.take(120).orEmpty()}")
        progressBar.visibility = View.GONE
        // Invalida eventos duplicados/tardíos de esta misma navegación.
        webViewPlaybackController.invalidatePendingLoad()

        val channel = currentChannel
        val nextIndex = currentOptionIndex + 1
        if (channel != null && nextIndex < (channel.options?.size ?: 0)) {
            android.util.Log.w("OPTION_FALLBACK", "Falló la carga del iframe; probando opción ${nextIndex + 1}")
            tryOption(channel, nextIndex)
        } else {
            showError("No se pudo cargar esta fuente. Revisá tu conexión o probá otra opción.")
        }
    }

    // ==================== PLAYER RELEASE ====================

    private fun releasePlayer() {
        recovery.stopWatchdog()
        cancelOptionFallback()
        webBridge.stopMonitor()
        playerListener?.let { listener -> exoPlayer?.let { player -> runCatching { player.removeListener(listener) } } }
        playerListener = null
        if (::playerView.isInitialized) playerView.player = null
        exoPlayer?.run { stop(); clearMediaItems(); release() }
        exoPlayer = null
    }

    // ==================== SIDE PANEL ====================

    private fun openSidePanel() {
        if (!isTV || isPanelOpen) return
        if (!channelPanelController.isReady) return
        isPanelOpen = true
        val screenWidthPx = window.decorView.width.takeIf { it > 0 }
            ?: resources.displayMetrics.widthPixels
        val density = resources.displayMetrics.density
        val screenWidthDp = screenWidthPx / density

        // Mantiene un ancho mínimo para el vídeo en resoluciones bajas sin desbordar la pantalla.
        val panelDimensions = PlayerPanelLayoutPolicy.calculate(screenWidthDp)
        searchTriggerText.text = if (screenWidthDp < 600f) "Buscar" else "Buscar canales"
        allChannelsText.text = if (screenWidthDp < 600f) "Canales" else "Lista de canales"
        val menuWidthDp = panelDimensions.menuWidthDp
        val listWidthDp = panelDimensions.channelListWidthDp
        val menuWidthPx = (menuWidthDp * density + 0.5f).toInt()
        val listWidthPx = (listWidthDp * density + 0.5f).toInt()

        panelMenuColumn.layoutParams = panelMenuColumn.layoutParams.apply {
            width = menuWidthPx
        }
        channelsPanelContainer.layoutParams = channelsPanelContainer.layoutParams.apply {
            width = menuWidthPx + listWidthPx
        }
        channelsPanelContainer.visibility = View.VISIBLE
        if (allChannels.isNotEmpty()) {
            // El controlador refresca la lista y delega la selección de foco a la Activity.
            channelPanelController.refreshForOpening()
        } else {
            // Si los datos aún no llegaron, el buscador es un destino enfocable estable.
            btnSearchTrigger.post { btnSearchTrigger.requestFocus() }
        }
    }

    private fun closeSidePanel() {
        if (!isTV || !isPanelOpen) return
        channelPanelController.deactivateSearchMode()
        channelsPanelContainer.layoutParams = channelsPanelContainer.layoutParams.apply { width = 0 }
        channelsPanelContainer.visibility = View.GONE
        isPanelOpen = false
        restorePlayerFocus()
        // Si el panel quedó abierto más de cinco segundos, el temporizador anterior pudo vencer.
        // Al volver al vídeo lo reiniciamos para que los controles sigan ocultándose correctamente.
        if (controlsVisible) resetAutoHideTimer()
    }

    private fun restorePlayerFocus() {
        if (!isTV) return
        playerContainer.post {
            when {
                controlsVisible && bottomControls.visibility == View.VISIBLE -> {
                    requestPreferredControlFocus()
                }
                playerView.visibility == View.VISIBLE -> {
                    playerView.isFocusable = true
                    playerView.requestFocus()
                }
                else -> playerContainer.requestFocus()
            }
        }
    }

    // ==================== CONTROLS VISIBILITY ====================

    private fun resetAutoHideTimer() {
        hideControlsRunnable?.let { mainHandler.removeCallbacks(it) }
        hideControlsRunnable = Runnable { if (controlsVisible && !isPanelOpen) hideControls() }
        mainHandler.postDelayed(hideControlsRunnable!!, 5_000)
    }

    private fun showControls() {
        updateControlsVisibility()
        // El panel de controles es independiente del motor de vídeo: también debe aparecer
        // sobre WebView/iframe, aunque ese reproductor no exponga controles de transporte.
        controlsOverlay.visibility = View.VISIBLE
        bottomControls.visibility = View.VISIBLE
        bottomControls.bringToFront()
        controlsVisible = true
        updatePlayerTimeline()
        if (isTV) requestPreferredControlFocus()
        resetAutoHideTimer()
    }

    private fun showControlsTemporarily() {
        updateControlsVisibility()
        controlsOverlay.visibility = View.VISIBLE
        bottomControls.visibility = View.VISIBLE
        bottomControls.bringToFront()
        controlsVisible = true
        updatePlayerTimeline()
        if (!isTV) startTimelineUpdates()
        resetAutoHideTimer()
    }

    private fun hideControls() {
        controlsOverlay.visibility = View.GONE
        bottomControls.visibility = View.GONE
        controlsVisible = false
        playerTimelineContainer.visibility = View.GONE
        stopTimelineUpdates()
        hideControlsRunnable?.let { mainHandler.removeCallbacks(it) }
        if (isTV) restorePlayerFocus()
    }

    private fun updatePlayerTimeline() {
        if (::timelineController.isInitialized) timelineController.update()
    }

    private fun startTimelineUpdates() {
        if (isTV || !::timelineController.isInitialized) return
        timelineController.startUpdates()
    }

    private fun stopTimelineUpdates() {
        if (::timelineController.isInitialized) timelineController.stopUpdates()
    }

    private fun updateControlsVisibility() {
        mediaRouteButton.visibility = if (
            !isTV && currentStreamType != StreamType.IFRAME && cast.isConfigured
        ) View.VISIBLE else View.GONE

        if (currentStreamType == StreamType.IFRAME) {
            if (isTV) {
                // TV: Mostrar controles si se detectó reproductor en el iframe
                if (webBridge.isControllable) {
                    btnPlayPause.visibility = View.VISIBLE
                    updatePlayPauseButton(webBridge.isPlaying)

                    val showSeek = webBridge.duration > 0
                    btnRewind.visibility = if (showSeek) View.VISIBLE else View.GONE
                    btnForward.visibility = if (showSeek) View.VISIBLE else View.GONE

                    // Actualizar foco para navegación D-Pad
                    btnPlayPause.isFocusable = true
                    btnRewind.isFocusable = showSeek
                    btnForward.isFocusable = showSeek
                } else {
                    // No se detectó reproductor: ocultar controles de reproducción
                    btnPlayPause.visibility = View.GONE
                    btnRewind.visibility = View.GONE
                    btnForward.visibility = View.GONE
                }
            } else {
                // MÓVIL: Ocultar controles nativos, usar los del iframe
                btnPlayPause.visibility = View.GONE
                btnRewind.visibility = View.GONE
                btnForward.visibility = View.GONE
                // El bloqueo táctil ya está desactivado en showWebView
            }
        } else {
            // Comportamiento normal para ExoPlayer
            btnPlayPause.visibility = View.VISIBLE
            val showSeek = !currentIsLive && !streamIsLive
            btnRewind.visibility = if (showSeek) View.VISIBLE else View.GONE
            btnForward.visibility = if (showSeek) View.VISIBLE else View.GONE
        }

        btnOptions.visibility = if (hasMultipleOptions()) View.VISIBLE else View.GONE

        if (isTV) {
            btnMenu.visibility = View.VISIBLE
            btnMenu.isFocusable = true
            listOf(btnPlayPause, btnRewind, btnForward, btnOptions, btnReloadStream).forEach {
                it.isFocusable = it.visibility == View.VISIBLE
            }
            btnClose.isFocusable = true
            mediaRouteButton.isFocusable = mediaRouteButton.visibility == View.VISIBLE
            updateControlFocusOrder()
        }
    }

    private fun updateFavoriteButton(channel: Channel) {
        if (!::btnFavoriteChannel.isInitialized || !::favoritesStore.isInitialized) return
        val favorite = favoritesStore.contains(channel)
        btnFavoriteChannel.setImageResource(if (favorite) R.drawable.ic_favorite_filled else R.drawable.ic_favorite_outline)
        val tintColor = if (favorite) R.color.accent else R.color.text_primary
        btnFavoriteChannel.imageTintList = android.content.res.ColorStateList.valueOf(
            androidx.core.content.ContextCompat.getColor(this, tintColor)
        )
        btnFavoriteChannel.contentDescription = if (favorite) "Quitar canal de favoritos" else "Agregar canal a favoritos"
        btnFavoriteChannel.isSelected = favorite
    }

    private fun hasMultipleOptions() = (currentChannel?.options?.size ?: 0) > 1

    // ==================== DATA LOADING ====================

    private fun loadChannelData() {
        val catalogToken = intent.getLongExtra("channel_catalog_token", -1L)
        val sharedCatalog = PlayerChannelCatalog.get(catalogToken)
        @Suppress("DEPRECATION")
        val legacyCatalog = intent.getParcelableArrayListExtra<Channel>("channels")
        @Suppress("DEPRECATION")
        val singleChannel = intent.getParcelableExtra<Channel>("current_channel")
        val hasInMemoryCatalog = sharedCatalog.isNotEmpty()
        val hasLegacyCatalog = !legacyCatalog.isNullOrEmpty()
        allChannels = when {
            hasInMemoryCatalog -> sharedCatalog
            hasLegacyCatalog -> legacyCatalog!!
            singleChannel != null -> listOf(singleChannel)
            else -> emptyList()
        }
        mainHandler.removeCallbacks(clearChannelNumberRunnable)
        channelNumberBuffer = ChannelNumberInputBuffer.forChannelCount(allChannels.size)
        currentChannelIndex = if (hasInMemoryCatalog || hasLegacyCatalog) {
            intent.getIntExtra("channel_index", 0)
        } else {
            // Si el proceso se recreó y ya no existe el catálogo en memoria, se preserva al
            // menos el canal solicitado por el Intent en lugar de romper la apertura del player.
            0
        }
        channelPanelController.setChannelCatalog(allChannels)
        if (allChannels.isNotEmpty() && currentChannelIndex in allChannels.indices) {
            currentChannel = allChannels[currentChannelIndex]
            loadChannelInfo(currentChannel!!)
            updateFavoriteButton(currentChannel!!)
            val requestedSourceIndex = intent.getIntExtra("source_index", 0)
            if (!currentChannel!!.options.isNullOrEmpty() && requestedSourceIndex in currentChannel!!.options!!.indices) {
                tryOption(currentChannel!!, requestedSourceIndex)
            } else {
                playFirstValidOption(currentChannel!!)
            }
        } else {
            showError("No hay canales disponibles")
        }
    }

    // ==================== OPTIONS DIALOG ====================

    private fun showOptionsDialog(channel: Channel) {
        val options = channel.options ?: run { showError("No hay opciones disponibles"); return }
        if (options.isEmpty()) { showError("No hay opciones disponibles"); return }
        AlertDialog.Builder(this)
            .setTitle("Seleccionar fuente — ${channel.name}")
            .setItems(options.map { it.name }.toTypedArray()) { _, which ->
                playerGeneration++
                recovery.reset(cancelPendingReconnect = true)
                val url = options[which].iframe
                val type = StreamUtils.resolveType(url, options[which].streamType)
                currentStreamUrl = url
                currentStreamType = type
                currentOptionIndex = which
                currentChannel = channel
                loadChannelInfo(channel)
                updateFavoriteButton(channel)
                playStream(url, type)
                updateControlsVisibility()
                hideControls()
            }
            .setNegativeButton("Cancelar") { _, _ -> if (currentStreamUrl.isEmpty()) finish() }
            .setCancelable(true)
            .show()
    }

    // ==================== HELPERS ====================

    private fun lockWebViewFocus() {
        if (!isTV) return
        webView.apply { isFocusable = false; isFocusableInTouchMode = false; isClickable = false; clearFocus() }
    }

    private fun showError(message: String) {
        progressBar.visibility = View.GONE
        errorText.text = if (isTV) "$message\n\nUsá ↻ Recargar en los controles para volver a intentar." else "$message\n\nPodés tocar Recargar en los controles para volver a intentar."
        errorText.visibility = View.VISIBLE
        updateControlsVisibility()
        // Ante un error dejamos la barra visible para que Recargar siga accesible
        // con el tacto o el mando, sin obligar a salir del reproductor.
        showControlsTemporarily()
        hideControlsRunnable?.let { mainHandler.removeCallbacks(it) }
        hideControlsRunnable = null
    }
}
