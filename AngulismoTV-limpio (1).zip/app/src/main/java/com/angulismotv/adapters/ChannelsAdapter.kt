package com.angulismotv.adapters

import android.view.LayoutInflater
import android.util.TypedValue
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.AsyncListDiffer
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.RecyclerView
import com.angulismotv.R
import com.angulismotv.models.Channel
import com.angulismotv.models.ChannelIdentity
import com.angulismotv.utils.DeviceHelper
import com.angulismotv.utils.loadChannelLogo
import com.bumptech.glide.Glide

class ChannelsAdapter(
    private val onItemClick: (Channel, Int) -> Unit,
    private val channelNumber: (Channel) -> Int = { 0 }
) : RecyclerView.Adapter<ChannelsAdapter.ChannelViewHolder>() {

    // ✅ AsyncListDiffer para actualizaciones eficientes
    private val differ = AsyncListDiffer(this, object : DiffUtil.ItemCallback<Channel>() {
        override fun areItemsTheSame(oldItem: Channel, newItem: Channel): Boolean {
            return ChannelIdentity.same(oldItem, newItem)
        }

        override fun areContentsTheSame(oldItem: Channel, newItem: Channel): Boolean {
            return oldItem == newItem
        }
    })

    private var isTV = false
    private var lastFocusedPosition = -1
    private var lastFocusedChannelKey: String? = null
    private var categoryFocusTargetId = View.NO_ID
    private var previewChannelKey: String? = null

    fun submitList(newChannels: List<Channel>, onCommitted: (() -> Unit)? = null) {
        differ.submitList(newChannels, Runnable { onCommitted?.invoke() })
    }

    /** Safe snapshot accessors used by focus restoration around AsyncListDiffer updates. */
    fun getChannelAt(position: Int): Channel? = differ.currentList.getOrNull(position)

    fun getPositionForKey(key: String): Int = differ.currentList.indexOfFirst {
        ChannelIdentity.key(it) == key
    }

    fun getLastFocusedChannelKey(): String? = lastFocusedChannelKey

    /** The first channel row returns UP to the currently selected category chip on Android TV. */
    fun setCategoryFocusTarget(viewId: Int) {
        categoryFocusTargetId = viewId
        if (isTV && itemCount > 0) notifyItemRangeChanged(0, itemCount)
    }

    /** Current inline preview remains subtly marked even when D-pad focus moves to another row. */
    fun setPreviewChannel(channel: Channel?) {
        val nextKey = channel?.let(ChannelIdentity::key)
        if (previewChannelKey == nextKey) return
        previewChannelKey = nextKey
        if (itemCount > 0) notifyItemRangeChanged(0, itemCount, PAYLOAD_PREVIEW_STATE)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ChannelViewHolder {
        isTV = DeviceHelper.isTV(parent.context)
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_channel, parent, false)
        return ChannelViewHolder(view, isTV)
    }

    override fun onBindViewHolder(holder: ChannelViewHolder, position: Int) {
        val channel = differ.currentList[position]
        holder.bind(channel, position, channelNumber(channel))
        holder.itemView.isSelected = previewChannelKey == ChannelIdentity.key(channel)

        holder.itemView.setOnClickListener {
            // Long presses/releases can arrive while AsyncListDiffer is dispatching updates.
            // Resolve both the position and item from the current list at click time.
            val currentPosition = holder.bindingAdapterPosition
            if (currentPosition != RecyclerView.NO_POSITION) {
                differ.currentList.getOrNull(currentPosition)?.let { currentChannel ->
                    onItemClick(currentChannel, currentPosition)
                }
            }
        }
        holder.itemView.nextFocusLeftId = if (isTV) R.id.inline_player_container else View.NO_ID
        holder.itemView.nextFocusUpId = if (isTV && position == 0) categoryFocusTargetId else View.NO_ID
        if (isTV) {
            // La lista es la columna más a la derecha. Consumir → evita que Android busque
            // una vista no relacionada cuando no existe otra columna a la derecha.
            holder.itemView.setOnKeyListener { _, keyCode, event ->
                event.action == android.view.KeyEvent.ACTION_DOWN &&
                    keyCode == android.view.KeyEvent.KEYCODE_DPAD_RIGHT
            }
        } else {
            holder.itemView.setOnKeyListener(null)
        }

        // Mejor manejo de foco para TV.
        if (isTV) {
            setupTVFocus(holder)
        }
    }

    override fun onBindViewHolder(holder: ChannelViewHolder, position: Int, payloads: MutableList<Any>) {
        if (payloads.contains(PAYLOAD_PREVIEW_STATE)) {
            val channel = differ.currentList.getOrNull(position)
            holder.itemView.isSelected = channel != null && previewChannelKey == ChannelIdentity.key(channel)
            return
        }
        onBindViewHolder(holder, position)
    }

    private fun setupTVFocus(holder: ChannelViewHolder) {
        holder.itemView.apply {
            isFocusable = true
            isFocusableInTouchMode = true

            nextFocusLeftId = R.id.inline_player_container
            nextFocusUpId = if (holder.bindingAdapterPosition == 0) categoryFocusTargetId else View.NO_ID
            setOnFocusChangeListener { _, hasFocus ->
                // El selector dibuja el foco sin escalar ni desplazar filas vecinas.
                if (hasFocus) {
                    val position = holder.bindingAdapterPosition
                    lastFocusedPosition = position
                    differ.currentList.getOrNull(position)?.let { channel ->
                        lastFocusedChannelKey = ChannelIdentity.key(channel)
                    }
                    nextFocusLeftId = R.id.inline_player_container
                    nextFocusUpId = if (position == 0) categoryFocusTargetId else View.NO_ID
                }
            }
        }
    }

    override fun getItemCount() = differ.currentList.size

    companion object {
        private const val PAYLOAD_PREVIEW_STATE = "preview_state"
    }

    // ✅ Método útil para recuperar el último foco
    fun getLastFocusedPosition(): Int = lastFocusedPosition

    inner class ChannelViewHolder(
        itemView: View,
        private val isTV: Boolean
    ) : RecyclerView.ViewHolder(itemView) {

        private val logo: ImageView = itemView.findViewById(R.id.channel_logo)
        private val channelName: TextView = itemView.findViewById(R.id.channel_name)
        private val channelNumberView: TextView = itemView.findViewById(R.id.channel_number)
        private val optionsIndicator: ImageView = itemView.findViewById(R.id.options_indicator)

        init {
            val density = itemView.resources.displayMetrics.density
            fun dp(value: Int) = (value * density + 0.5f).toInt()

            val rowParams = itemView.layoutParams as? ViewGroup.MarginLayoutParams
            if (isTV) {
                // En TV la lista ocupa una columna lateral: filas compactas, tipografía legible
                // a distancia y margen suficiente para que el contorno de foco no se recorte.
                channelName.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15f)
                channelName.maxLines = 1
                channelName.letterSpacing = 0f
                (channelName.layoutParams as? ViewGroup.MarginLayoutParams)?.let { params ->
                    params.marginStart = dp(9)
                    channelName.layoutParams = params
                }
                logo.layoutParams = logo.layoutParams.apply {
                    width = dp(40)
                    height = dp(40)
                }
                optionsIndicator.layoutParams = optionsIndicator.layoutParams.apply {
                    width = dp(15)
                    height = dp(15)
                }
                (optionsIndicator.layoutParams as? ViewGroup.MarginLayoutParams)?.let { params ->
                    params.marginEnd = dp(5)
                    optionsIndicator.layoutParams = params
                }
                itemView.setPadding(dp(8), dp(4), dp(8), dp(4))
                rowParams?.setMargins(dp(2), dp(2), dp(2), dp(2))
                if (rowParams != null) itemView.layoutParams = rowParams
                itemView.minimumHeight = dp(50)
            } else {
                // Móvil: filas continuas y densas, sin tarjetas separadas ni márgenes sobredimensionados.
                channelName.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
                channelName.maxLines = 1
                channelName.letterSpacing = 0f
                logo.layoutParams = logo.layoutParams.apply {
                    width = dp(30)
                    height = dp(30)
                }
                itemView.setPadding(dp(8), dp(5), dp(8), dp(5))
                itemView.minimumHeight = dp(44)
                rowParams?.setMargins(0, dp(1), 0, dp(1))
                if (rowParams != null) itemView.layoutParams = rowParams
                optionsIndicator.layoutParams = optionsIndicator.layoutParams.apply {
                    width = dp(14)
                    height = dp(14)
                }
                val optionsParams = optionsIndicator.layoutParams as? ViewGroup.MarginLayoutParams
                optionsParams?.marginEnd = dp(4)
                if (optionsParams != null) optionsIndicator.layoutParams = optionsParams
            }
        }

        private var currentChannel: Channel? = null

        fun bind(channel: Channel, position: Int, channelNumber: Int) {
            currentChannel = channel
            channelNumberView.text = if (channelNumber > 0) channelNumber.toString() else "—"

            // Nombre del canal
            channelName.text = channel.name
            channelName.isSelected = isTV  // Para marquee en TV

            // Indicador de opciones múltiples
            val optionCount = channel.options.orEmpty().size
            val hasOptions = optionCount > 0
            optionsIndicator.visibility = if (hasOptions) View.VISIBLE else View.GONE

            val logoRadius = if (isTV) 12 else (6 * itemView.resources.displayMetrics.density + 0.5f).toInt()
            logo.loadChannelLogo(channel.name, channel.logo, cornerRadiusPx = logoRadius)

            val numberDescription = if (channelNumber > 0) "Canal $channelNumber, " else ""
            val hasDirectSource = !channel.streamUrl.isNullOrBlank()
            val sourceCount = optionCount + if (hasDirectSource) 1 else 0
            val sourceDescription = when {
                sourceCount > 1 -> "con $sourceCount fuentes disponibles"
                sourceCount == 1 && optionCount > 0 -> "con una fuente alternativa"
                sourceCount == 1 -> "con reproducción directa"
                else -> "sin fuentes configuradas"
            }
            itemView.contentDescription = "$numberDescription${channel.name}, $sourceDescription"
        }

        fun recycle() {
            Glide.with(itemView.context).clear(logo)
            itemView.isSelected = false
            currentChannel = null
        }
    }

    // ✅ Limpiar recursos cuando el adapter se destruye
    override fun onViewRecycled(holder: ChannelViewHolder) {
        super.onViewRecycled(holder)
        holder.recycle()
    }
}