package com.angulismotv.adapters

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.RecyclerView
import com.angulismotv.R
import com.angulismotv.models.Channel
import com.angulismotv.utils.loadChannelLogo

/** Lista de canales del panel lateral del reproductor. */
class SideChannelsAdapter(
    private val onItemClick: (Channel, Int) -> Unit
) : RecyclerView.Adapter<SideChannelsAdapter.ViewHolder>() {

    private var channels: List<Channel> = emptyList()
    private var selectedIndex: Int = -1

    fun submitList(newChannels: List<Channel>, selectedIdx: Int) {
        val oldChannels = channels
        val oldSelected = selectedIndex
        val nextChannels = newChannels.toList()
        val nextSelected = selectedIdx

        val diff = DiffUtil.calculateDiff(object : DiffUtil.Callback() {
            override fun getOldListSize() = oldChannels.size
            override fun getNewListSize() = nextChannels.size

            override fun areItemsTheSame(oldPosition: Int, newPosition: Int): Boolean =
                oldChannels[oldPosition].name == nextChannels[newPosition].name &&
                    oldChannels[oldPosition].logo == nextChannels[newPosition].logo

            override fun areContentsTheSame(oldPosition: Int, newPosition: Int): Boolean {
                val oldChannel = oldChannels[oldPosition]
                val newChannel = nextChannels[newPosition]
                val oldWasSelected = oldPosition == oldSelected
                val newIsSelected = newPosition == nextSelected
                return oldChannel == newChannel && oldWasSelected == newIsSelected
            }
        })

        channels = nextChannels
        selectedIndex = nextSelected
        diff.dispatchUpdatesTo(this)
    }

    override fun getItemCount() = channels.size

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_channel_side, parent, false)
        view.isFocusable = true
        view.isFocusableInTouchMode = true
        view.isClickable = true
        // El drawable de estado enfocado ofrece una señal estable, sin animación ni solapamientos.
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val channel = channels[position]
        holder.bind(channel, position == selectedIndex)
        holder.itemView.setOnClickListener {
            val currentPosition = holder.bindingAdapterPosition
            if (currentPosition != RecyclerView.NO_POSITION) {
                // Lee el dato vigente de la lista tras un DiffUtil, no una referencia obsoleta.
                channels.getOrNull(currentPosition)?.let { currentChannel ->
                    onItemClick(currentChannel, currentPosition)
                }
            }
        }
    }

    class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val marker: View = itemView.findViewById(R.id.channel_selected_marker)
        private val logo: ImageView = itemView.findViewById(R.id.channel_logo)
        private val name: TextView = itemView.findViewById(R.id.channel_name)
        private val optionsIndicator: ImageView = itemView.findViewById(R.id.options_indicator)

        fun bind(channel: Channel, isSelected: Boolean) {
            itemView.alpha = 1f
            itemView.isSelected = isSelected
            marker.visibility = if (isSelected) View.VISIBLE else View.INVISIBLE
            name.text = channel.name
            optionsIndicator.visibility = if (!channel.options.isNullOrEmpty()) View.VISIBLE else View.GONE
            itemView.setBackgroundResource(
                if (isSelected) R.drawable.side_channel_item_selected
                else R.drawable.side_channel_item_bg
            )
            itemView.contentDescription = buildString {
                append(channel.name)
                if (!channel.options.isNullOrEmpty()) append(", con opciones")
                if (isSelected) append(", en reproducción")
            }
            // Mantiene la forma original de cada logo; el elemento no agrega una tarjeta detrás.
            logo.loadChannelLogo(channel.name, channel.logo)
        }
    }
}
