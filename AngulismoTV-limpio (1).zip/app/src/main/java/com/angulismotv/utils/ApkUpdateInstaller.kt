package com.angulismotv.utils

import android.app.DownloadManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.os.Handler
import android.util.Log
import android.widget.Toast
import java.io.File

/** Owns DownloadManager operations and APK launch; dialogs remain in UpdateManager. */
class ApkUpdateInstaller(
    private val context: Context,
    private val mainHandler: Handler,
    private val listener: Listener
) {
    interface Listener {
        fun onDownloadError()
        fun onInsufficientSpace()
        fun onInstallPermissionRequired()
    }

    fun downloadAndInstall(apkUrl: String, versionName: String, expectedSha256: String) {
        if (!Regex("^[a-fA-F0-9]{64}$").matches(expectedSha256)) {
            Log.e(TAG, "Se rechazó una actualización sin SHA-256 válido")
            listener.onDownloadError()
            return
        }
        pendingExpectedSha256 = expectedSha256.lowercase()
        val apkUri = runCatching { Uri.parse(apkUrl) }.getOrNull()
        if (apkUri?.scheme?.lowercase() != "https" || apkUri.host.isNullOrBlank()) {
            Log.w(TAG, "Se rechazó una URL de APK no segura")
            listener.onDownloadError()
            return
        }

        try {
            val safeVersionName = versionName.replace(Regex("[^A-Za-z0-9._-]"), "_").take(64)
            val fileName = "angulismotv-$safeVersionName.apk"
            cleanOldApks()

            val request = DownloadManager.Request(apkUri).apply {
                setTitle("Descargando AngulismoTV")
                setDescription("Versión $versionName")
                setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, fileName)
                } else {
                    setDestinationInExternalFilesDir(context, Environment.DIRECTORY_DOWNLOADS, fileName)
                }
                setMimeType("application/vnd.android.package-archive")
                setAllowedOverMetered(true)
                setAllowedOverRoaming(false)
            }

            val downloadManager = context.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
            val downloadId = downloadManager.enqueue(request)
            Log.d(TAG, "Descarga iniciada con ID: $downloadId")
            Toast.makeText(context, "Descargando actualización...", Toast.LENGTH_SHORT).show()
            registerDownloadReceiver(downloadId, downloadManager)
        } catch (error: Exception) {
            Log.e(TAG, "No se pudo iniciar la descarga (${error.javaClass.simpleName})")
            listener.onDownloadError()
        }
    }

    private fun registerDownloadReceiver(downloadId: Long, downloadManager: DownloadManager) {
        val receiver = object : BroadcastReceiver() {
            override fun onReceive(ctx: Context, intent: Intent) {
                val receivedId = intent.getLongExtra(DownloadManager.EXTRA_DOWNLOAD_ID, -1)
                if (receivedId != downloadId) return
                runCatching { ctx.unregisterReceiver(this) }
                mainHandler.post { checkDownloadStatus(downloadId, downloadManager) }
            }
        }

        try {
            val filter = IntentFilter(DownloadManager.ACTION_DOWNLOAD_COMPLETE)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                context.registerReceiver(receiver, filter, Context.RECEIVER_NOT_EXPORTED)
            } else {
                @Suppress("UnspecifiedRegisterReceiverFlag")
                context.registerReceiver(receiver, filter)
            }
        } catch (error: Exception) {
            Log.e(TAG, "Error registrando receiver: ${error.javaClass.simpleName}")
            mainHandler.post { listener.onDownloadError() }
        }
    }

    private fun checkDownloadStatus(downloadId: Long, downloadManager: DownloadManager) {
        try {
            val cursor = downloadManager.query(DownloadManager.Query().setFilterById(downloadId))
            cursor.use {
                if (!it.moveToFirst()) {
                    Log.e(TAG, "No se encontró la descarga con ID: $downloadId")
                    mainHandler.post { listener.onDownloadError() }
                    return
                }

                val statusIndex = it.getColumnIndex(DownloadManager.COLUMN_STATUS)
                val reasonIndex = it.getColumnIndex(DownloadManager.COLUMN_REASON)
                val status = if (statusIndex >= 0) it.getInt(statusIndex) else -1
                val reason = if (reasonIndex >= 0) it.getInt(reasonIndex) else -1
                when (status) {
                    DownloadManager.STATUS_SUCCESSFUL -> {
                        Log.d(TAG, "Descarga completada exitosamente")
                        installApk(downloadId, downloadManager)
                    }
                    DownloadManager.STATUS_FAILED -> handleDownloadError(reason)
                    DownloadManager.STATUS_PAUSED -> {
                        Log.d(TAG, "Descarga pausada. Reason: $reason")
                        mainHandler.post {
                            Toast.makeText(context, "Descarga pausada. Verificá tu conexión.", Toast.LENGTH_LONG).show()
                        }
                    }
                    DownloadManager.STATUS_PENDING -> mainHandler.postDelayed({
                        checkDownloadStatus(downloadId, downloadManager)
                    }, PENDING_RECHECK_DELAY_MS)
                    DownloadManager.STATUS_RUNNING -> Log.d(TAG, "Descarga en progreso")
                    else -> {
                        Log.w(TAG, "Estado de descarga desconocido: $status")
                        mainHandler.post { listener.onDownloadError() }
                    }
                }
            }
        } catch (error: Exception) {
            Log.e(TAG, "No se pudo consultar el estado de la descarga (${error.javaClass.simpleName})")
            mainHandler.post { listener.onDownloadError() }
        }
    }

    private fun handleDownloadError(reason: Int) {
        val message = when (reason) {
            DownloadManager.ERROR_CANNOT_RESUME -> "No se puede reanudar la descarga"
            DownloadManager.ERROR_DEVICE_NOT_FOUND -> "Dispositivo de almacenamiento no encontrado"
            DownloadManager.ERROR_FILE_ALREADY_EXISTS -> "El archivo ya existe"
            DownloadManager.ERROR_FILE_ERROR -> "Problema con el archivo"
            DownloadManager.ERROR_HTTP_DATA_ERROR -> "Datos HTTP incorrectos"
            DownloadManager.ERROR_INSUFFICIENT_SPACE -> "Espacio insuficiente en el dispositivo"
            DownloadManager.ERROR_TOO_MANY_REDIRECTS -> "Demasiadas redirecciones"
            DownloadManager.ERROR_UNHANDLED_HTTP_CODE -> "Código HTTP no manejado"
            DownloadManager.ERROR_UNKNOWN -> "Error desconocido"
            else -> "Error: $reason"
        }
        Log.e(TAG, "Error de descarga: $message")
        if (reason == DownloadManager.ERROR_INSUFFICIENT_SPACE) listener.onInsufficientSpace()
        else listener.onDownloadError()
    }

    private var pendingExpectedSha256: String = ""

    private fun installApk(downloadId: Long, downloadManager: DownloadManager) {
        try {
            val uri = downloadManager.getUriForDownloadedFile(downloadId)
            if (uri == null) {
                Log.e(TAG, "URI de archivo descargado es null")
                listener.onDownloadError()
                return
            }

            val expectedHash = pendingExpectedSha256
            val actualHash = context.contentResolver.openInputStream(uri)?.use { input ->
                val digest = java.security.MessageDigest.getInstance("SHA-256")
                val buffer = ByteArray(64 * 1024)
                while (true) {
                    val count = input.read(buffer)
                    if (count < 0) break
                    digest.update(buffer, 0, count)
                }
                digest.digest().joinToString("") { byte -> "%02x".format(byte) }
            }
            if (actualHash.isNullOrBlank() || expectedHash.isBlank() ||
                !java.security.MessageDigest.isEqual(actualHash.toByteArray(Charsets.US_ASCII), expectedHash.toByteArray(Charsets.US_ASCII))) {
                Log.e(TAG, "La verificación SHA-256 del APK falló; se cancela la instalación")
                runCatching { context.contentResolver.delete(uri, null, null) }
                listener.onDownloadError()
                return
            }

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O &&
                !context.packageManager.canRequestPackageInstalls()) {
                listener.onInstallPermissionRequired()
                return
            }

            val intent = Intent(Intent.ACTION_VIEW).apply {
                setDataAndType(uri, APK_MIME_TYPE)
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_GRANT_READ_URI_PERMISSION
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            if (intent.resolveActivity(context.packageManager) != null) context.startActivity(intent)
            else {
                Log.e(TAG, "No se encontró app para instalar APK")
                listener.onDownloadError()
            }
        } catch (error: Exception) {
            Log.e(TAG, "No se pudo abrir el instalador (${error.javaClass.simpleName})")
            if (error is SecurityException) listener.onInstallPermissionRequired()
            else listener.onDownloadError()
        }
    }

    private fun cleanOldApks() {
        try {
            val dirs = mutableListOf<File?>()
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                dirs.add(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS))
            }
            dirs.add(context.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS))
            dirs.filterNotNull().forEach { dir ->
                dir.listFiles { file -> file.name.startsWith(APK_FILE_PREFIX) && file.name.endsWith(".apk") }
                    ?.forEach { file ->
                        try {
                            val deleted = file.delete()
                            Log.d(TAG, "APK viejo eliminado: ${file.name} - $deleted")
                        } catch (error: Exception) {
                            Log.w(TAG, "No se pudo eliminar ${file.name}: ${error.message}")
                        }
                    }
            }
        } catch (error: Exception) {
            Log.w(TAG, "Error limpiando APKs viejos: ${error.message}")
        }
    }

    companion object {
        private const val TAG = "ApkUpdateInstaller"
        private const val APK_MIME_TYPE = "application/vnd.android.package-archive"
        private const val APK_FILE_PREFIX = "angulismotv-"
        private const val PENDING_RECHECK_DELAY_MS = 2_000L
    }
}
