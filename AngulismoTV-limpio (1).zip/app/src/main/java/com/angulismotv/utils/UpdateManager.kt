package com.angulismotv.utils

import android.app.DownloadManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.util.Log
import androidx.appcompat.app.AlertDialog
import com.angulismotv.BuildConfig
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors

class UpdateManager(private val context: Context) {

    companion object {
        private const val TAG = "UpdateManager"

        private const val PREFS_NAME = "update_prefs"
        private const val KEY_LAST_CHECK = "last_check_ms"
        private const val KEY_IGNORED_VERSION = "ignored_version_code"
        private const val CHECK_INTERVAL_MS = 60 * 60 * 1000L
        private const val MAX_VERSION_RESPONSE_BYTES = 256 * 1024
        // Compartido para no crear un hilo persistente por instancia de UpdateManager.
        private val executor = Executors.newSingleThreadExecutor { runnable ->
            Thread(runnable, "AngulismoTV-update-check").apply { isDaemon = true }
        }
    }

    private val mainHandler = Handler(Looper.getMainLooper())
    private val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    data class VersionInfo(
        val versionCode: Int,
        val versionName: String,
        val apkUrl: String,
        val releaseNotes: String,
        val hasUpdate: Boolean,
        val forceUpdate: Boolean,
    )

    fun checkForUpdates(silent: Boolean = true) {
        if (BuildConfig.UPDATE_URL.isBlank()) return
        if (silent && !shouldCheck()) return

        executor.execute {
            try {
                val info = BuildConfig.UPDATE_URL.takeIf { it.isNotBlank() }?.let { fetchVersionInfo(it) }

                // Si todo falla
                if (info == null) {
                    Log.e(TAG, "No se pudo obtener la información de versión")
                    if (!silent) {
                        mainHandler.post { showErrorDialog() }
                    }
                    return@execute
                }

                prefs.edit().putLong(KEY_LAST_CHECK, System.currentTimeMillis()).apply()

                mainHandler.post {
                    when {
                        info.forceUpdate -> showUpdateDialog(info, forced = true)
                        info.hasUpdate && !isIgnored(info.versionCode) -> showUpdateDialog(info, forced = false)
                        !silent -> showUpToDateDialog()
                    }
                }
            } catch (e: Exception) {
                Log.e(TAG, "Falló la comprobación de actualizaciones (${e.javaClass.simpleName})")
                if (!silent) {
                    mainHandler.post { showErrorDialog() }
                }
            }
        }
    }

    private fun fetchVersionInfo(endpointUrl: String): VersionInfo? {
        val endpoint = runCatching { Uri.parse(endpointUrl) }.getOrNull()
        if (endpoint?.scheme?.lowercase() != "https" || endpoint.host.isNullOrBlank()) {
            Log.w(TAG, "La URL del manifiesto de actualización debe ser HTTPS")
            return null
        }
        val requestUrl = endpoint.buildUpon()
            .appendQueryParameter("versionCode", BuildConfig.VERSION_CODE.toString())
            .build()
            .toString()

        val connection = try {
            (URL(requestUrl).openConnection() as HttpURLConnection).apply {
                requestMethod = "GET"
                connectTimeout = 8_000
                readTimeout = 8_000
                doInput = true
                setRequestProperty("User-Agent", "AngulismoTV/${BuildConfig.VERSION_NAME}")
                setRequestProperty("Cache-Control", "no-cache")
            }
        } catch (e: Exception) {
            Log.e(TAG, "No se pudo abrir la conexión de actualización (${e.javaClass.simpleName})")
            return null
        }

        return try {
            val responseCode = connection.responseCode
            if (responseCode != HttpURLConnection.HTTP_OK) {
                Log.w(TAG, "El servidor de actualización respondió HTTP $responseCode")
                return null
            }
            // Se aceptan redirecciones HTTPS (habituales en releases), nunca una degradación a HTTP.
            if (!connection.url.protocol.equals("https", ignoreCase = true)) {
                Log.w(TAG, "Se rechazó una redirección insegura del manifiesto")
                return null
            }
            if (connection.contentLength > MAX_VERSION_RESPONSE_BYTES) {
                Log.w(TAG, "El manifiesto de actualización supera el tamaño permitido")
                return null
            }

            val body = connection.inputStream.use { input ->
                val output = java.io.ByteArrayOutputStream()
                val buffer = ByteArray(4 * 1024)
                var total = 0
                while (true) {
                    val count = input.read(buffer)
                    if (count < 0) break
                    total += count
                    if (total > MAX_VERSION_RESPONSE_BYTES) return null
                    output.write(buffer, 0, count)
                }
                output.toString(Charsets.UTF_8.name())
            }

            val json = JSONObject(body)
            val remoteVersionCode = json.optInt("versionCode", -1)
            val remoteVersionName = json.optString("versionName", "").trim()
            val apkUrl = json.optString("apkUrl", "").trim()
            val apkUri = runCatching { Uri.parse(apkUrl) }.getOrNull()
            if (remoteVersionCode <= 0 || remoteVersionName.isBlank() ||
                apkUri?.scheme?.lowercase() != "https" || apkUri.host.isNullOrBlank()) {
                Log.w(TAG, "El manifiesto de actualización tiene campos inválidos")
                return null
            }

            val localHasUpdate = remoteVersionCode > BuildConfig.VERSION_CODE
            val serverSaysForce = json.optBoolean("forceUpdate", false)
            VersionInfo(
                versionCode = remoteVersionCode,
                versionName = remoteVersionName.take(64),
                apkUrl = apkUri.toString(),
                releaseNotes = json.optString("releaseNotes", "").take(4_000),
                hasUpdate = localHasUpdate,
                forceUpdate = localHasUpdate && serverSaysForce
            )
        } catch (e: Exception) {
            Log.e(TAG, "No se pudo validar el manifiesto (${e.javaClass.simpleName})")
            null
        } finally {
            connection.disconnect()
        }
    }

    private fun showUpdateDialog(info: VersionInfo, forced: Boolean) {
        val activity = context as? androidx.appcompat.app.AppCompatActivity ?: return
        if (activity.isFinishing || activity.isDestroyed) return

        val message = buildString {
            append("Versión ${info.versionName} disponible")
            if (info.releaseNotes.isNotEmpty()) {
                append("\n\n")
                append(info.releaseNotes)
            }
            if (forced) {
                append("\n\n⚠️ Esta actualización es obligatoria.")
            }
        }

        try {
            val dialog = AlertDialog.Builder(context)
                .setTitle("🔄 Nueva actualización")
                .setMessage(message)
                .setCancelable(false)
                .setPositiveButton("Actualizar ahora") { _, _ ->
                    downloadAndInstall(info.apkUrl, info.versionName)
                }
                .apply {
                    if (!forced) {
                        setNegativeButton("Más tarde") { dialog, _ -> dialog.dismiss() }
                        setNeutralButton("Ignorar esta versión") { _, _ ->
                            ignoreVersion(info.versionCode)
                        }
                    }
                }
                .create()

            dialog.show()
        } catch (e: Exception) {
            Log.e(TAG, "Error mostrando diálogo de actualización: ${e.message}", e)
        }
    }

    private fun showUpToDateDialog() {
        val activity = context as? androidx.appcompat.app.AppCompatActivity ?: return
        if (activity.isFinishing || activity.isDestroyed) return

        try {
            AlertDialog.Builder(context)
                .setTitle("✅ Sin actualizaciones")
                .setMessage("Ya tenés la versión más reciente (${BuildConfig.VERSION_NAME}).")
                .setPositiveButton("OK") { dialog, _ -> dialog.dismiss() }
                .show()
        } catch (e: Exception) {
            Log.e(TAG, "Error mostrando diálogo: ${e.message}", e)
        }
    }

    private fun showErrorDialog() {
        val activity = context as? androidx.appcompat.app.AppCompatActivity ?: return
        if (activity.isFinishing || activity.isDestroyed) return

        try {
            AlertDialog.Builder(context)
                .setTitle("❌ Error al verificar")
                .setMessage("No se pudo verificar si hay actualizaciones.\n\nRevisá tu conexión a internet e intentá de nuevo.")
                .setPositiveButton("OK") { dialog, _ -> dialog.dismiss() }
                .show()
        } catch (e: Exception) {
            Log.e(TAG, "Error mostrando diálogo de error: ${e.message}", e)
        }
    }

    private fun showDownloadErrorDialog() {
        val activity = context as? androidx.appcompat.app.AppCompatActivity ?: return
        if (activity.isFinishing || activity.isDestroyed) return

        try {
            AlertDialog.Builder(context)
                .setTitle("❌ Error al descargar")
                .setMessage("No se pudo descargar la actualización.\n\nPosibles causas:\n• Sin espacio en el dispositivo\n• Conexión a internet inestable\n• Permisos de almacenamiento denegados\n\nIntentá de nuevo más tarde.")
                .setPositiveButton("Reintentar") { _, _ ->
                    // Volver a intentar la descarga
                    checkForUpdates(silent = false)
                }
                .setNegativeButton("Cancelar") { dialog, _ -> dialog.dismiss() }
                .show()
        } catch (e: Exception) {
            Log.e(TAG, "Error mostrando diálogo de error de descarga: ${e.message}", e)
        }
    }

    private fun downloadAndInstall(apkUrl: String, versionName: String) {
        val apkUri = runCatching { Uri.parse(apkUrl) }.getOrNull()
        if (apkUri?.scheme?.lowercase() != "https" || apkUri.host.isNullOrBlank()) {
            Log.w(TAG, "Se rechazó una URL de APK no segura")
            showDownloadErrorDialog()
            return
        }

        // DownloadManager escribe en una carpeta pública gestionada por el sistema (Android 10+)
        // o en el directorio externo privado de la app (versiones anteriores); no requiere
        // WRITE_EXTERNAL_STORAGE en estos destinos.
        try {
            val safeVersionName = versionName.replace(Regex("[^A-Za-z0-9._-]"), "_").take(64)
            val fileName = "angulismotv-$safeVersionName.apk"
            cleanOldApks()

            val request = DownloadManager.Request(apkUri).apply {
                setTitle("Descargando AngulismoTV")
                setDescription("Versión $versionName")
                setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)

                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, fileName)
                } else {
                    setDestinationInExternalFilesDir(context, Environment.DIRECTORY_DOWNLOADS, fileName)
                }

                setMimeType("application/vnd.android.package-archive")
                setAllowedOverMetered(true)
                setAllowedOverRoaming(false)
            }

            val downloadManager = context.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
            val downloadId = downloadManager.enqueue(request)

            Log.d(TAG, "Descarga iniciada con ID: $downloadId")

            try {
                val activity = context as? androidx.appcompat.app.AppCompatActivity
                activity?.let {
                    android.widget.Toast.makeText(it, "Descargando actualización...", android.widget.Toast.LENGTH_SHORT).show()
                }
            } catch (_: Exception) {}

            registerDownloadReceiver(downloadId, downloadManager)

        } catch (e: Exception) {
            Log.e(TAG, "No se pudo iniciar la descarga (${e.javaClass.simpleName})")

            when {
                e is SecurityException -> showStoragePermissionDialog()
                else -> showDownloadErrorDialog()
            }
        }
    }

    private fun registerDownloadReceiver(downloadId: Long, downloadManager: DownloadManager) {
        val receiver = object : BroadcastReceiver() {
            override fun onReceive(ctx: Context, intent: Intent) {
                val receivedId = intent.getLongExtra(DownloadManager.EXTRA_DOWNLOAD_ID, -1)
                if (receivedId != downloadId) return

                // Desregistrar el receiver inmediatamente
                try {
                    ctx.unregisterReceiver(this)
                } catch (_: Exception) {}

                mainHandler.post {
                    checkDownloadStatus(downloadId, downloadManager)
                }
            }
        }

        val filter = IntentFilter(DownloadManager.ACTION_DOWNLOAD_COMPLETE)

        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                context.registerReceiver(receiver, filter, Context.RECEIVER_NOT_EXPORTED)
            } else {
                @Suppress("UnspecifiedRegisterReceiverFlag")
                context.registerReceiver(receiver, filter)
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error registrando receiver: ${e.message}", e)
            mainHandler.post { showDownloadErrorDialog() }
        }
    }

    private fun checkDownloadStatus(downloadId: Long, downloadManager: DownloadManager) {
        try {
            val query = DownloadManager.Query().setFilterById(downloadId)
            val cursor = downloadManager.query(query)

            cursor.use {
                if (it.moveToFirst()) {
                    val statusIndex = it.getColumnIndex(DownloadManager.COLUMN_STATUS)
                    val reasonIndex = it.getColumnIndex(DownloadManager.COLUMN_REASON)
                    val titleIndex = it.getColumnIndex(DownloadManager.COLUMN_TITLE)

                    val status = if (statusIndex >= 0) it.getInt(statusIndex) else -1
                    val reason = if (reasonIndex >= 0) it.getInt(reasonIndex) else -1

                    when (status) {
                        DownloadManager.STATUS_SUCCESSFUL -> {
                            Log.d(TAG, "Descarga completada exitosamente")
                            installApk(downloadId, downloadManager)
                        }
                        DownloadManager.STATUS_FAILED -> {
                            Log.e(TAG, "Descarga fallida. Status: $status, Reason: $reason")
                            handleDownloadError(reason)
                        }
                        DownloadManager.STATUS_PAUSED -> {
                            Log.d(TAG, "Descarga pausada. Reason: $reason")
                            mainHandler.post {
                                try {
                                    android.widget.Toast.makeText(
                                        context,
                                        "Descarga pausada. Verificá tu conexión.",
                                        android.widget.Toast.LENGTH_LONG
                                    ).show()
                                } catch (_: Exception) {}
                            }
                        }
                        DownloadManager.STATUS_PENDING -> {
                            Log.d(TAG, "Descarga pendiente")
                            // Re-check después de un tiempo
                            mainHandler.postDelayed({
                                checkDownloadStatus(downloadId, downloadManager)
                            }, 2000)
                        }
                        DownloadManager.STATUS_RUNNING -> {
                            Log.d(TAG, "Descarga en progreso")
                        }
                        else -> {
                            Log.w(TAG, "Estado de descarga desconocido: $status")
                            mainHandler.post { showDownloadErrorDialog() }
                        }
                    }
                } else {
                    Log.e(TAG, "No se encontró la descarga con ID: $downloadId")
                    mainHandler.post { showDownloadErrorDialog() }
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "No se pudo consultar el estado de la descarga (${e.javaClass.simpleName})")
            mainHandler.post { showDownloadErrorDialog() }
        }
    }

    private fun handleDownloadError(reason: Int) {
        val message = when (reason) {
            DownloadManager.ERROR_CANNOT_RESUME -> "Error: No se puede reanudar la descarga"
            DownloadManager.ERROR_DEVICE_NOT_FOUND -> "Error: Dispositivo de almacenamiento no encontrado"
            DownloadManager.ERROR_FILE_ALREADY_EXISTS -> "Error: El archivo ya existe"
            DownloadManager.ERROR_FILE_ERROR -> "Error: Problema con el archivo"
            DownloadManager.ERROR_HTTP_DATA_ERROR -> "Error: Datos HTTP incorrectos"
            DownloadManager.ERROR_INSUFFICIENT_SPACE -> "Error: Espacio insuficiente en el dispositivo"
            DownloadManager.ERROR_TOO_MANY_REDIRECTS -> "Error: Demasiadas redirecciones"
            DownloadManager.ERROR_UNHANDLED_HTTP_CODE -> "Error: Código HTTP no manejado"
            DownloadManager.ERROR_UNKNOWN -> "Error desconocido"
            else -> "Error: $reason"
        }

        Log.e(TAG, "Error de descarga: $message")

        if (reason == DownloadManager.ERROR_INSUFFICIENT_SPACE) {
            showInsufficientSpaceDialog()
        } else {
            showDownloadErrorDialog()
        }
    }

    private fun showInsufficientSpaceDialog() {
        val activity = context as? androidx.appcompat.app.AppCompatActivity ?: return
        if (activity.isFinishing || activity.isDestroyed) return

        try {
            AlertDialog.Builder(context)
                .setTitle("💾 Espacio insuficiente")
                .setMessage("No hay suficiente espacio en tu dispositivo para descargar la actualización.\n\nLiberá espacio e intentá de nuevo.")
                .setPositiveButton("OK") { dialog, _ -> dialog.dismiss() }
                .show()
        } catch (e: Exception) {
            Log.e(TAG, "Error mostrando diálogo: ${e.message}", e)
        }
    }

    private fun showPermissionErrorDialog() {
        val activity = context as? androidx.appcompat.app.AppCompatActivity ?: return
        if (activity.isFinishing || activity.isDestroyed) return

        val canRequestUnknownSources = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
        val title = if (canRequestUnknownSources) "Permitir instalación" else "Permiso necesario"
        val message = if (canRequestUnknownSources) {
            "Android necesita que autorices a AngulismoTV a instalar actualizaciones descargadas desde esta app."
        } else {
            "No se pudo abrir el instalador. Revisá los permisos de la aplicación e intentá de nuevo."
        }
        try {
            AlertDialog.Builder(activity)
                .setTitle(title)
                .setMessage(message)
                .setPositiveButton("Abrir configuración") { _, _ ->
                    try {
                        val action = if (canRequestUnknownSources) {
                            android.provider.Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES
                        } else {
                            android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS
                        }
                        val intent = Intent(action).apply {
                            data = Uri.parse("package:${context.packageName}")
                        }
                        activity.startActivity(intent)
                    } catch (e: Exception) {
                        Log.e(TAG, "No se pudo abrir la configuración (${e.javaClass.simpleName})")
                    }
                }
                .setNegativeButton("Cancelar", null)
                .show()
        } catch (e: Exception) {
            Log.e(TAG, "Error mostrando diálogo de permisos (${e.javaClass.simpleName})", e)
        }
    }

    private fun installApk(downloadId: Long, downloadManager: DownloadManager) {
        try {
            val uri = downloadManager.getUriForDownloadedFile(downloadId)

            if (uri == null) {
                Log.e(TAG, "URI de archivo descargado es null")
                showDownloadErrorDialog()
                return
            }

            Log.d(TAG, "Descarga lista; abriendo instalador del sistema")

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O &&
                !context.packageManager.canRequestPackageInstalls()) {
                showPermissionErrorDialog()
                return
            }

            val intent = Intent(Intent.ACTION_VIEW).apply {
                setDataAndType(uri, "application/vnd.android.package-archive")
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_GRANT_READ_URI_PERMISSION

                // Para Android 7.0+, necesario para FileProvider
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                }
            }

            // Verificar que hay una app que pueda manejar la instalación
            if (intent.resolveActivity(context.packageManager) != null) {
                context.startActivity(intent)
            } else {
                Log.e(TAG, "No se encontró app para instalar APK")
                showDownloadErrorDialog()
            }
        } catch (e: Exception) {
            Log.e(TAG, "No se pudo abrir el instalador (${e.javaClass.simpleName})")

            if (e is SecurityException) {
                showPermissionErrorDialog()
            } else {
                showDownloadErrorDialog()
            }
        }
    }

    private fun cleanOldApks() {
        try {
            val dirs = mutableListOf<File?>()

            // Directorio público (Android 10+)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                dirs.add(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS))
            }

            // Directorio privado
            dirs.add(context.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS))

            dirs.filterNotNull().forEach { dir ->
                dir.listFiles { file ->
                    file.name.startsWith("angulismotv-") && file.name.endsWith(".apk")
                }?.forEach { file ->
                    try {
                        val deleted = file.delete()
                        Log.d(TAG, "APK viejo eliminado: ${file.name} - $deleted")
                    } catch (e: Exception) {
                        Log.w(TAG, "No se pudo eliminar ${file.name}: ${e.message}")
                    }
                }
            }
        } catch (e: Exception) {
            Log.w(TAG, "Error limpiando APKs viejos: ${e.message}")
        }
    }

    private fun shouldCheck(): Boolean {
        val lastCheck = prefs.getLong(KEY_LAST_CHECK, 0L)
        return System.currentTimeMillis() - lastCheck > CHECK_INTERVAL_MS
    }

    private fun isIgnored(versionCode: Int): Boolean {
        return prefs.getInt(KEY_IGNORED_VERSION, 0) == versionCode
    }

    private fun ignoreVersion(versionCode: Int) {
        prefs.edit().putInt(KEY_IGNORED_VERSION, versionCode).apply()
        Log.d(TAG, "Versión $versionCode ignorada")
    }
}