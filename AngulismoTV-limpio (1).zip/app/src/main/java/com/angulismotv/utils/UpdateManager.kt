package com.angulismotv.utils

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.util.Log
import androidx.appcompat.app.AlertDialog
import com.angulismotv.BuildConfig
import java.util.concurrent.Executors

class UpdateManager(private val context: Context) {

    companion object {
        private const val TAG = "UpdateManager"

        private const val PREFS_NAME = "update_prefs"
        private const val KEY_LAST_CHECK = "last_check_ms"
        private const val KEY_IGNORED_VERSION = "ignored_version_code"
        private const val CHECK_INTERVAL_MS = 60 * 60 * 1000L
        // Compartido para no crear un hilo persistente por instancia de UpdateManager.
        private val executor = Executors.newSingleThreadExecutor { runnable ->
            Thread(runnable, "AngulismoTV-update-check").apply { isDaemon = true }
        }
    }

    private val mainHandler = Handler(Looper.getMainLooper())
    private val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    private val manifestClient = UpdateManifestClient()
    private val apkInstaller by lazy(LazyThreadSafetyMode.NONE) {
        ApkUpdateInstaller(context, mainHandler, object : ApkUpdateInstaller.Listener {
            override fun onDownloadError() = showDownloadErrorDialog()
            override fun onInsufficientSpace() = showInsufficientSpaceDialog()
            override fun onInstallPermissionRequired() = showPermissionErrorDialog()
        })
    }

    fun checkForUpdates(silent: Boolean = true) {
        if (BuildConfig.UPDATE_URL.isBlank()) return
        if (silent && !shouldCheck()) return

        executor.execute {
            try {
                val info = BuildConfig.UPDATE_URL.takeIf { it.isNotBlank() }?.let { manifestClient.fetch(it) }

                // Si todo falla
                if (info == null) {
                    Log.e(TAG, "No se pudo obtener la información de versión")
                    if (!silent) {
                        mainHandler.post { showErrorDialog() }
                    }
                    return@execute
                }

                prefs.edit().putLong(KEY_LAST_CHECK, System.currentTimeMillis()).apply()

                mainHandler.post {
                    when {
                        info.forceUpdate -> showUpdateDialog(info, forced = true)
                        info.hasUpdate && !isIgnored(info.versionCode) -> showUpdateDialog(info, forced = false)
                        !silent -> showUpToDateDialog()
                    }
                }
            } catch (e: Exception) {
                Log.e(TAG, "Falló la comprobación de actualizaciones (${e.javaClass.simpleName})")
                if (!silent) {
                    mainHandler.post { showErrorDialog() }
                }
            }
        }
    }

    private fun showUpdateDialog(info: UpdateInfo, forced: Boolean) {
        val activity = context as? androidx.appcompat.app.AppCompatActivity ?: return
        if (activity.isFinishing || activity.isDestroyed) return

        val message = buildString {
            append("Versión ${info.versionName} disponible")
            if (info.releaseNotes.isNotEmpty()) {
                append("\n\n")
                append(info.releaseNotes)
            }
            if (forced) {
                append("\n\n⚠️ Esta actualización es obligatoria.")
            }
        }

        try {
            val dialog = AlertDialog.Builder(context)
                .setTitle("🔄 Nueva actualización")
                .setMessage(message)
                .setCancelable(false)
                .setPositiveButton("Actualizar ahora") { _, _ ->
                    apkInstaller.downloadAndInstall(info.apkUrl, info.versionName)
                }
                .apply {
                    if (!forced) {
                        setNegativeButton("Más tarde") { dialog, _ -> dialog.dismiss() }
                        setNeutralButton("Ignorar esta versión") { _, _ ->
                            ignoreVersion(info.versionCode)
                        }
                    }
                }
                .create()

            dialog.show()
        } catch (e: Exception) {
            Log.e(TAG, "Error mostrando diálogo de actualización: ${e.message}", e)
        }
    }

    private fun showUpToDateDialog() {
        val activity = context as? androidx.appcompat.app.AppCompatActivity ?: return
        if (activity.isFinishing || activity.isDestroyed) return

        try {
            AlertDialog.Builder(context)
                .setTitle("✅ Sin actualizaciones")
                .setMessage("Ya tenés la versión más reciente (${BuildConfig.VERSION_NAME}).")
                .setPositiveButton("OK") { dialog, _ -> dialog.dismiss() }
                .show()
        } catch (e: Exception) {
            Log.e(TAG, "Error mostrando diálogo: ${e.message}", e)
        }
    }

    private fun showErrorDialog() {
        val activity = context as? androidx.appcompat.app.AppCompatActivity ?: return
        if (activity.isFinishing || activity.isDestroyed) return

        try {
            AlertDialog.Builder(context)
                .setTitle("❌ Error al verificar")
                .setMessage("No se pudo verificar si hay actualizaciones.\n\nRevisá tu conexión a internet e intentá de nuevo.")
                .setPositiveButton("OK") { dialog, _ -> dialog.dismiss() }
                .show()
        } catch (e: Exception) {
            Log.e(TAG, "Error mostrando diálogo de error: ${e.message}", e)
        }
    }

    private fun showDownloadErrorDialog() {
        val activity = context as? androidx.appcompat.app.AppCompatActivity ?: return
        if (activity.isFinishing || activity.isDestroyed) return

        try {
            AlertDialog.Builder(context)
                .setTitle("❌ Error al descargar")
                .setMessage("No se pudo descargar la actualización.\n\nPosibles causas:\n• Sin espacio en el dispositivo\n• Conexión a internet inestable\n• Permisos de almacenamiento denegados\n\nIntentá de nuevo más tarde.")
                .setPositiveButton("Reintentar") { _, _ ->
                    // Volver a intentar la descarga
                    checkForUpdates(silent = false)
                }
                .setNegativeButton("Cancelar") { dialog, _ -> dialog.dismiss() }
                .show()
        } catch (e: Exception) {
            Log.e(TAG, "Error mostrando diálogo de error de descarga: ${e.message}", e)
        }
    }

    private fun showInsufficientSpaceDialog() {
        val activity = context as? androidx.appcompat.app.AppCompatActivity ?: return
        if (activity.isFinishing || activity.isDestroyed) return

        try {
            AlertDialog.Builder(context)
                .setTitle("💾 Espacio insuficiente")
                .setMessage("No hay suficiente espacio en tu dispositivo para descargar la actualización.\n\nLiberá espacio e intentá de nuevo.")
                .setPositiveButton("OK") { dialog, _ -> dialog.dismiss() }
                .show()
        } catch (e: Exception) {
            Log.e(TAG, "Error mostrando diálogo: ${e.message}", e)
        }
    }

    private fun showPermissionErrorDialog() {
        val activity = context as? androidx.appcompat.app.AppCompatActivity ?: return
        if (activity.isFinishing || activity.isDestroyed) return

        val canRequestUnknownSources = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
        val title = if (canRequestUnknownSources) "Permitir instalación" else "Permiso necesario"
        val message = if (canRequestUnknownSources) {
            "Android necesita que autorices a AngulismoTV a instalar actualizaciones descargadas desde esta app."
        } else {
            "No se pudo abrir el instalador. Revisá los permisos de la aplicación e intentá de nuevo."
        }
        try {
            AlertDialog.Builder(activity)
                .setTitle(title)
                .setMessage(message)
                .setPositiveButton("Abrir configuración") { _, _ ->
                    try {
                        val action = if (canRequestUnknownSources) {
                            android.provider.Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES
                        } else {
                            android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS
                        }
                        val intent = Intent(action).apply {
                            data = Uri.parse("package:${context.packageName}")
                        }
                        activity.startActivity(intent)
                    } catch (e: Exception) {
                        Log.e(TAG, "No se pudo abrir la configuración (${e.javaClass.simpleName})")
                    }
                }
                .setNegativeButton("Cancelar", null)
                .show()
        } catch (e: Exception) {
            Log.e(TAG, "Error mostrando diálogo de permisos (${e.javaClass.simpleName})", e)
        }
    }

    private fun shouldCheck(): Boolean {
        val lastCheck = prefs.getLong(KEY_LAST_CHECK, 0L)
        return System.currentTimeMillis() - lastCheck > CHECK_INTERVAL_MS
    }

    private fun isIgnored(versionCode: Int): Boolean {
        return prefs.getInt(KEY_IGNORED_VERSION, 0) == versionCode
    }

    private fun ignoreVersion(versionCode: Int) {
        prefs.edit().putInt(KEY_IGNORED_VERSION, versionCode).apply()
        Log.d(TAG, "Versión $versionCode ignorada")
    }
}