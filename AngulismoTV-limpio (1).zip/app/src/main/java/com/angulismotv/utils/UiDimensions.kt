package com.angulismotv.utils

import android.content.res.Resources

/** Converts shared dimens.xml tokens to pixels without duplicating density math in UI code. */
object UiDimensions {
    fun px(resources: Resources, dimensionId: Int): Int =
        resources.getDimensionPixelSize(dimensionId)
}
