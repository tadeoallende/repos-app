package com.angulismotv.utils

import java.io.InputStream
import java.security.MessageDigest

/** SHA-256 helpers used to verify a downloaded APK against the value published in the manifest. */
object ApkIntegrity {
    private val SHA256_REGEX = Regex("^[0-9a-f]{64}$")

    /**
     * Normalizes a manifest value to 64 lowercase hex chars.
     * Accepts surrounding whitespace, uppercase, and an optional "sha256:" prefix. Returns null if invalid.
     */
    fun normalizeSha256(raw: String?): String? {
        val value = raw.orEmpty().trim().lowercase().removePrefix("sha256:").trim()
        return value.takeIf { SHA256_REGEX.matches(it) }
    }

    /** Streams [input] through SHA-256 and returns the lowercase hex digest. Does not close the stream. */
    fun sha256Hex(input: InputStream): String {
        val digest = MessageDigest.getInstance("SHA-256")
        val buffer = ByteArray(64 * 1024)
        while (true) {
            val count = input.read(buffer)
            if (count < 0) break
            digest.update(buffer, 0, count)
        }
        return digest.digest().joinToString("") { "%02x".format(it) }
    }

    /** Constant-time comparison of two hex digests (both must already be normalized). */
    fun matches(expectedHex: String, actualHex: String): Boolean =
        MessageDigest.isEqual(expectedHex.toByteArray(Charsets.US_ASCII), actualHex.toByteArray(Charsets.US_ASCII))
}
