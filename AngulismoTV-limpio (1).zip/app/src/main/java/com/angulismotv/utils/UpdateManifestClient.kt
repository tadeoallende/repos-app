package com.angulismotv.utils

import android.net.Uri
import android.util.Log
import com.angulismotv.BuildConfig
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale

/** Validated update information returned by the remote release manifest. */
data class UpdateInfo(
    val versionCode: Int,
    val versionName: String,
    val apkUrl: String,
    val apkSha256: String,
    val releaseNotes: String,
    val hasUpdate: Boolean,
    val forceUpdate: Boolean
)

/** Performs HTTPS-only manifest retrieval, size limiting, and payload validation. */
class UpdateManifestClient(
    private val currentVersionCode: Int = BuildConfig.VERSION_CODE,
    private val currentVersionName: String = BuildConfig.VERSION_NAME
) {
    fun fetch(endpointUrl: String): UpdateInfo? {
        val endpoint = runCatching { Uri.parse(endpointUrl) }.getOrNull()
        if (endpoint?.scheme?.equals("https", ignoreCase = true) != true || endpoint.host.isNullOrBlank()) {
            Log.w(TAG, "La URL del manifiesto de actualización debe ser HTTPS")
            return null
        }
        val requestUrl = endpoint.buildUpon()
            .appendQueryParameter("versionCode", currentVersionCode.toString())
            .build()
            .toString()

        val connection = try {
            (URL(requestUrl).openConnection() as HttpURLConnection).apply {
                requestMethod = "GET"
                connectTimeout = CONNECTION_TIMEOUT_MS
                readTimeout = READ_TIMEOUT_MS
                doInput = true
                setRequestProperty("User-Agent", "AngulismoTV/$currentVersionName")
                setRequestProperty("Cache-Control", "no-cache")
            }
        } catch (error: Exception) {
            Log.e(TAG, "No se pudo abrir la conexión de actualización (${error.javaClass.simpleName})")
            return null
        }

        return try {
            val responseCode = connection.responseCode
            if (responseCode != HttpURLConnection.HTTP_OK) {
                Log.w(TAG, "El servidor de actualización respondió HTTP $responseCode")
                return null
            }
            // HTTPS redirections are allowed; a downgrade to HTTP is never accepted.
            if (!connection.url.protocol.equals("https", ignoreCase = true)) {
                Log.w(TAG, "Se rechazó una redirección insegura del manifiesto")
                return null
            }
            if (connection.contentLength > MAX_RESPONSE_BYTES) {
                Log.w(TAG, "El manifiesto de actualización supera el tamaño permitido")
                return null
            }

            val body = connection.inputStream.use { input ->
                val output = java.io.ByteArrayOutputStream()
                val buffer = ByteArray(4 * 1024)
                var total = 0
                while (true) {
                    val count = input.read(buffer)
                    if (count < 0) break
                    total += count
                    if (total > MAX_RESPONSE_BYTES) return null
                    output.write(buffer, 0, count)
                }
                output.toString(Charsets.UTF_8.name())
            }

            val json = JSONObject(body)
            val remoteVersionCode = json.optInt("versionCode", -1)
            val remoteVersionName = json.optString("versionName", "").trim()
            val apkUrl = json.optString("apkUrl", "").trim()
            val apkSha256 = json.optString("sha256", "").trim().lowercase(Locale.ROOT)
            val apkUri = runCatching { Uri.parse(apkUrl) }.getOrNull()
            if (remoteVersionCode <= 0 || remoteVersionName.isBlank() ||
                apkUri?.scheme?.equals("https", ignoreCase = true) != true || apkUri.host.isNullOrBlank() ||
                !ApkIntegrityVerifier.isValidSha256(apkSha256)) {
                Log.w(TAG, "El manifiesto de actualización tiene campos inválidos")
                return null
            }

            val localHasUpdate = remoteVersionCode > currentVersionCode
            UpdateInfo(
                versionCode = remoteVersionCode,
                versionName = remoteVersionName.take(MAX_VERSION_NAME_LENGTH),
                apkUrl = apkUri.toString(),
                apkSha256 = apkSha256,
                releaseNotes = json.optString("releaseNotes", "").take(MAX_RELEASE_NOTES_LENGTH),
                hasUpdate = localHasUpdate,
                forceUpdate = localHasUpdate && json.optBoolean("forceUpdate", false)
            )
        } catch (error: Exception) {
            Log.e(TAG, "No se pudo validar el manifiesto (${error.javaClass.simpleName})")
            null
        } finally {
            connection.disconnect()
        }
    }

    companion object {
        private const val TAG = "UpdateManifestClient"
        private const val CONNECTION_TIMEOUT_MS = 8_000
        private const val READ_TIMEOUT_MS = 8_000
        private const val MAX_RESPONSE_BYTES = 256 * 1024
        private const val MAX_VERSION_NAME_LENGTH = 64
        private const val MAX_RELEASE_NOTES_LENGTH = 4_000
    }
}
