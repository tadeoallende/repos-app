package com.angulismotv.utils

import android.content.Context
import android.net.Uri
import android.util.Log
import com.angulismotv.BuildConfig
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale

/** Validated update information returned by the remote release manifest. */
data class UpdateInfo(
    val versionCode: Int,
    val versionName: String,
    val apkUrl: String,
    val apkSha256: String,
    val releaseNotes: String,
    val hasUpdate: Boolean,
    val forceUpdate: Boolean
)

/** Fetches a manifest and its detached signature, then validates the signature before parsing JSON. */
class UpdateManifestClient(
    context: Context,
    private val currentVersionCode: Int = BuildConfig.VERSION_CODE,
    private val currentVersionName: String = BuildConfig.VERSION_NAME
) {
    private val appContext = context.applicationContext

    fun fetch(endpointUrl: String): UpdateInfo? {
        val endpoint = runCatching { Uri.parse(endpointUrl) }.getOrNull()
        if (endpoint?.scheme?.equals("https", ignoreCase = true) != true || endpoint.host.isNullOrBlank()) {
            Log.w(TAG, "La URL del manifiesto de actualización debe ser HTTPS")
            return null
        }

        val manifestUri = endpoint.buildUpon()
            .appendQueryParameter("versionCode", currentVersionCode.toString())
            .build()
        val signaturePath = (endpoint.encodedPath?.takeIf { it.isNotBlank() } ?: "/") + ".sig"
        val signatureUri = endpoint.buildUpon()
            .encodedPath(signaturePath)
            .appendQueryParameter("versionCode", currentVersionCode.toString())
            .build()

        val manifestBytes = downloadHttpsBytes(manifestUri.toString(), MAX_MANIFEST_BYTES) ?: return null
        val signatureBytes = downloadHttpsBytes(signatureUri.toString(), MAX_SIGNATURE_BYTES) ?: run {
            Log.w(TAG, "No se pudo obtener la firma del manifiesto")
            return null
        }
        val signatureText = String(signatureBytes, Charsets.US_ASCII).trim()
        if (!UpdateManifestSignatureVerifier.verify(appContext, manifestBytes, signatureText)) {
            Log.w(TAG, "Se rechazó el manifiesto: la firma digital no es válida")
            return null
        }

        return try {
            // Verify the original bytes before parsing; do not reserialize JSON before validation.
            val json = JSONObject(String(manifestBytes, Charsets.UTF_8))
            val remoteVersionCode = json.optInt("versionCode", -1)
            val remoteVersionName = json.optString("versionName", "").trim()
            val apkUrl = json.optString("apkUrl", "").trim()
            val apkSha256 = json.optString("sha256", "").trim().lowercase(Locale.ROOT)
            val apkUri = runCatching { Uri.parse(apkUrl) }.getOrNull()
            if (remoteVersionCode <= 0 || remoteVersionName.isBlank() ||
                apkUri?.scheme?.equals("https", ignoreCase = true) != true || apkUri.host.isNullOrBlank() ||
                !ApkIntegrityVerifier.isValidSha256(apkSha256)) {
                Log.w(TAG, "El manifiesto firmado contiene campos inválidos")
                return null
            }

            val localHasUpdate = remoteVersionCode > currentVersionCode
            UpdateInfo(
                versionCode = remoteVersionCode,
                versionName = remoteVersionName.take(MAX_VERSION_NAME_LENGTH),
                apkUrl = apkUri.toString(),
                apkSha256 = apkSha256,
                releaseNotes = json.optString("releaseNotes", "").take(MAX_RELEASE_NOTES_LENGTH),
                hasUpdate = localHasUpdate,
                forceUpdate = localHasUpdate && json.optBoolean("forceUpdate", false)
            )
        } catch (error: Exception) {
            Log.e(TAG, "No se pudo validar el manifiesto firmado (${error.javaClass.simpleName})")
            null
        }
    }

    private fun downloadHttpsBytes(requestUrl: String, maxBytes: Int): ByteArray? {
        var currentUrl = try {
            URL(requestUrl)
        } catch (error: Exception) {
            Log.e(TAG, "URL de actualización inválida (${error.javaClass.simpleName})")
            return null
        }

        for (redirectCount in 0..MAX_REDIRECTS) {
            if (!currentUrl.protocol.equals("https", ignoreCase = true)) {
                Log.w(TAG, "Se rechazó una URL o redirección de actualización sin HTTPS")
                return null
            }

            val connection = try {
                (currentUrl.openConnection() as HttpURLConnection).apply {
                    requestMethod = "GET"
                    connectTimeout = CONNECTION_TIMEOUT_MS
                    readTimeout = READ_TIMEOUT_MS
                    doInput = true
                    // Redirects are validated manually so HTTPS can never downgrade to HTTP.
                    instanceFollowRedirects = false
                    setRequestProperty("User-Agent", "AngulismoTV/$currentVersionName")
                    setRequestProperty("Cache-Control", "no-cache")
                }
            } catch (error: Exception) {
                Log.e(TAG, "No se pudo abrir una conexión de actualización (${error.javaClass.simpleName})")
                return null
            }

            try {
                val responseCode = connection.responseCode
                if (responseCode in REDIRECT_STATUS_CODES) {
                    val location = connection.getHeaderField("Location")
                    if (location.isNullOrBlank() || redirectCount == MAX_REDIRECTS) {
                        Log.w(TAG, "La redirección de actualización no es válida o superó el límite")
                        return null
                    }
                    currentUrl = try {
                        URL(currentUrl, location)
                    } catch (_: Exception) {
                        Log.w(TAG, "La URL de redirección de actualización no es válida")
                        return null
                    }
                    if (!currentUrl.protocol.equals("https", ignoreCase = true)) {
                        Log.w(TAG, "Se rechazó una redirección de actualización a HTTP")
                        return null
                    }
                    continue
                }
                if (responseCode != HttpURLConnection.HTTP_OK) {
                    Log.w(TAG, "El servidor de actualización respondió HTTP $responseCode")
                    return null
                }
                if (connection.contentLength > maxBytes) {
                    Log.w(TAG, "La respuesta de actualización supera el tamaño permitido")
                    return null
                }

                return connection.inputStream.use { input ->
                    val output = ByteArrayOutputStream(minOf(maxBytes, 8 * 1024))
                    val buffer = ByteArray(4 * 1024)
                    var total = 0
                    while (true) {
                        val count = input.read(buffer)
                        if (count < 0) break
                        total += count
                        if (total > maxBytes) {
                            Log.w(TAG, "La respuesta de actualización supera el tamaño permitido")
                            return null
                        }
                        output.write(buffer, 0, count)
                    }
                    output.toByteArray()
                }
            } catch (error: Exception) {
                Log.e(TAG, "Falló la descarga de actualización (${error.javaClass.simpleName})")
                return null
            } finally {
                connection.disconnect()
            }
        }
        return null
    }

    companion object {
        private const val TAG = "UpdateManifestClient"
        private const val CONNECTION_TIMEOUT_MS = 8_000
        private const val READ_TIMEOUT_MS = 8_000
        private const val MAX_MANIFEST_BYTES = 256 * 1024
        private const val MAX_SIGNATURE_BYTES = 8 * 1024
        private const val MAX_REDIRECTS = 5
        private val REDIRECT_STATUS_CODES = setOf(301, 302, 303, 307, 308)
        private const val MAX_VERSION_NAME_LENGTH = 64
        private const val MAX_RELEASE_NOTES_LENGTH = 4_000
    }
}
