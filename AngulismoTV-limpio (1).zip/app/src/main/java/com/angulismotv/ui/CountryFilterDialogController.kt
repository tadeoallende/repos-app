package com.angulismotv.ui

import android.content.Context
import androidx.appcompat.app.AlertDialog
import com.angulismotv.data.CountryFilterOptionsPolicy

/** Owns the lifecycle of the modal country picker without owning the selected country state. */
class CountryFilterDialogController(
    private val context: Context,
    private val availableCountryKeys: () -> List<String>,
    private val countryLabel: (String) -> String
) {
    private var activeDialog: AlertDialog? = null

    fun show(selectedCountryKey: String, onCountrySelected: (String) -> Unit) {
        // Avoid stacking multiple dialogs if a remote key or touch arrives twice.
        activeDialog?.dismiss()
        val options = CountryFilterOptionsPolicy.build(availableCountryKeys(), countryLabel)
        val labels = options.map { it.label }.toTypedArray()
        val dialog = AlertDialog.Builder(context)
            .setTitle("Filtrar por país")
            .setSingleChoiceItems(
                labels,
                CountryFilterOptionsPolicy.selectedIndex(options, selectedCountryKey)
            ) { selectedDialog, which ->
                CountryFilterOptionsPolicy.keyAt(options, which)?.let(onCountrySelected)
                selectedDialog.dismiss()
            }
            .setNegativeButton("Cancelar", null)
            .create()

        activeDialog = dialog
        dialog.setOnDismissListener {
            if (activeDialog === dialog) activeDialog = null
        }
        dialog.show()
    }

    /** Close an open picker when a catalog refresh starts or completes. */
    fun dismiss() {
        activeDialog?.dismiss()
    }

    fun dispose() {
        activeDialog?.setOnDismissListener(null)
        activeDialog?.dismiss()
        activeDialog = null
    }
}
