package com.angulismotv.ui

import android.view.View

/** Tracks View.post callbacks for one view lifecycle and removes them on teardown. */
class ViewPostCallbackRegistry {
    private val pendingCallbacks = linkedMapOf<View, MutableSet<Runnable>>()
    private var disposed = false

    /** Posts one callback, forgetting its reference as soon as it runs. */
    fun post(view: View, action: () -> Unit): Boolean {
        if (disposed) return false
        val callback = object : Runnable {
            override fun run() {
                pendingCallbacks[view]?.let { callbacks ->
                    callbacks.remove(this)
                    if (callbacks.isEmpty()) pendingCallbacks.remove(view)
                }
                if (!disposed) action()
            }
        }
        pendingCallbacks.getOrPut(view) { linkedSetOf() }.add(callback)
        val posted = view.post(callback)
        if (!posted) {
            pendingCallbacks[view]?.let { callbacks ->
                callbacks.remove(callback)
                if (callbacks.isEmpty()) pendingCallbacks.remove(view)
            }
        }
        return posted
    }

    /** Cancels all pending posts and releases references to views in this lifecycle. */
    fun dispose() {
        if (disposed) return
        disposed = true
        pendingCallbacks.forEach { (view, callbacks) ->
            callbacks.forEach { callback -> view.removeCallbacks(callback) }
        }
        pendingCallbacks.clear()
    }
}
