package com.angulismotv.ui

import android.view.View
import android.widget.ImageButton
import com.angulismotv.models.StreamType

/**
 * Projects the current playback mode into the fullscreen player's control visibility and focus.
 *
 * The Activity remains the owner of playback/session state and supplies it through callbacks.
 */
class PlayerControlStateController(
    private val isTv: () -> Boolean,
    private val streamType: () -> String,
    private val castConfigured: () -> Boolean,
    private val hasMultipleOptions: () -> Boolean,
    private val currentIsLive: () -> Boolean,
    private val streamIsLive: () -> Boolean,
    private val iframeIsControllable: () -> Boolean,
    private val iframeIsPlaying: () -> Boolean,
    private val iframeDuration: () -> Long,
    private val menuButton: ImageButton,
    private val playPauseButton: ImageButton,
    private val rewindButton: ImageButton,
    private val forwardButton: ImageButton,
    private val optionsButton: ImageButton,
    private val audioInfoButton: ImageButton,
    private val reloadButton: ImageButton,
    private val closeButton: ImageButton,
    private val castButton: ImageButton,
    private val onPlayStateChanged: (Boolean) -> Unit,
    private val updateControlFocusOrder: () -> Unit
) {

    fun updateControlsVisibility() {
        updateCastButtonVisibility()
        updateTransportControlsVisibility()
        optionsButton.visibility = if (hasMultipleOptions()) View.VISIBLE else View.GONE
        // El audio de una fuente iframe lo gestiona la página: no hay pistas nativas que mostrar.
        audioInfoButton.visibility = if (streamType() != StreamType.IFRAME) View.VISIBLE else View.GONE
        if (isTv()) configureTvControlFocusOrder()
    }

    fun updateCastButtonVisibility() {
        castButton.visibility = if (
            !isTv() && streamType() != StreamType.IFRAME && castConfigured()
        ) View.VISIBLE else View.GONE
    }

    fun updateTransportControlsVisibility() {
        when (streamType()) {
            StreamType.IFRAME -> updateIframeTransportControls()
            else -> updateNativeTransportControls()
        }
    }

    fun updateIframeTransportControls() {
        // El overlay de AngulismoTV reemplaza los controles del proveedor tanto en TV
        // como en móvil. Solo se muestran cuando el puente confirmó un reproductor
        // realmente controlable; así no quedan botones que no puedan ejecutar acciones.
        if (!iframeIsControllable()) {
            playPauseButton.visibility = View.GONE
            rewindButton.visibility = View.GONE
            forwardButton.visibility = View.GONE
            return
        }

        playPauseButton.visibility = View.VISIBLE
        onPlayStateChanged(iframeIsPlaying())
        val showSeek = iframeDuration() > 0L
        rewindButton.visibility = if (showSeek) View.VISIBLE else View.GONE
        forwardButton.visibility = if (showSeek) View.VISIBLE else View.GONE

        if (isTv()) {
            playPauseButton.isFocusable = true
            rewindButton.isFocusable = showSeek
            forwardButton.isFocusable = showSeek
        }
    }

    fun updateNativeTransportControls() {
        playPauseButton.visibility = View.VISIBLE
        val showSeek = !currentIsLive() && !streamIsLive()
        rewindButton.visibility = if (showSeek) View.VISIBLE else View.GONE
        forwardButton.visibility = if (showSeek) View.VISIBLE else View.GONE
    }

    fun configureTvControlFocusOrder() {
        menuButton.visibility = View.VISIBLE
        menuButton.isFocusable = true
        listOf(playPauseButton, rewindButton, forwardButton, audioInfoButton, optionsButton, reloadButton).forEach {
            it.isFocusable = it.visibility == View.VISIBLE
        }
        closeButton.isFocusable = true
        castButton.isFocusable = castButton.visibility == View.VISIBLE
        updateControlFocusOrder()
    }
}
