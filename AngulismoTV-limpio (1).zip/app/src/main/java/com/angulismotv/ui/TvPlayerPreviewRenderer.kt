package com.angulismotv.ui

import android.view.View
import android.widget.ImageView
import android.widget.TextView
import com.angulismotv.R
import com.angulismotv.models.Channel
import com.angulismotv.utils.loadChannelLogo

/** Renders the TV-only preview identity and contextual guide; playback stays owned elsewhere. */
class TvPlayerPreviewRenderer(
    private val emptyState: View?,
    private val currentChannelInfo: View?,
    private val channelLogo: ImageView?,
    private val channelName: TextView?,
    private val channelCategory: TextView?,
    private val guide: TextView?,
    private val keysHint: TextView?,
    private val footerHint: TextView?,
    private val displayCategoryName: (String) -> String
) {
    fun showIdle() {
        emptyState?.visibility = View.VISIBLE
        currentChannelInfo?.visibility = View.GONE
        channelLogo?.setImageResource(R.drawable.ic_channel_placeholder)
        channelName?.setText(R.string.tv_channel_not_selected)
        channelCategory?.setText(R.string.tv_live_category)
        guide?.setText(R.string.tv_player_idle_guide)
        keysHint?.setText(R.string.tv_player_keys_hint)
        footerHint?.setText(R.string.tv_player_footer_hint)
    }

    fun showChannel(channel: Channel) {
        emptyState?.visibility = View.GONE
        currentChannelInfo?.visibility = View.VISIBLE
        channelLogo?.loadChannelLogo(channel.name, channel.logo)
        channelName?.text = channel.name
        val category = channel.category.takeIf { it.isNotBlank() }
        if (category == null) channelCategory?.setText(R.string.tv_live_category)
        else channelCategory?.text = displayCategoryName(category)
        guide?.setText(R.string.tv_player_active_guide)
        footerHint?.setText(R.string.tv_player_footer_hint)
    }

    fun renderFocus(hasFocus: Boolean, hasChannel: Boolean) {
        val guideResource = when {
            hasFocus && hasChannel -> R.string.tv_player_active_guide
            hasFocus -> R.string.tv_player_idle_guide
            hasChannel -> R.string.tv_player_preview_ready_guide
            else -> R.string.tv_player_idle_guide
        }
        guide?.setText(guideResource)
    }

    fun showNoChannelSelected() {
        guide?.setText(R.string.tv_player_no_channel_selected)
    }

    fun showStatus(message: String) {
        guide?.text = message
    }
}
