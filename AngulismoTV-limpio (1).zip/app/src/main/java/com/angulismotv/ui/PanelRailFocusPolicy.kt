package com.angulismotv.ui

/** Reglas de foco vertical de las acciones fijas del panel del reproductor. */
object PanelRailFocusPolicy {
    enum class Item { CLOSE, SEARCH, FAVORITES, ALL_CHANNELS }
    enum class Direction { UP, DOWN }
    enum class Target { CLOSE, SEARCH, FAVORITES, ALL_CHANNELS, FIRST_CATEGORY }

    fun next(from: Item, direction: Direction): Target? = when (from to direction) {
        Item.CLOSE to Direction.DOWN -> Target.SEARCH
        Item.SEARCH to Direction.UP -> Target.CLOSE
        Item.SEARCH to Direction.DOWN -> Target.FAVORITES
        Item.FAVORITES to Direction.UP -> Target.SEARCH
        Item.FAVORITES to Direction.DOWN -> Target.ALL_CHANNELS
        Item.ALL_CHANNELS to Direction.UP -> Target.FAVORITES
        Item.ALL_CHANNELS to Direction.DOWN -> Target.FIRST_CATEGORY
        else -> null
    }
}
