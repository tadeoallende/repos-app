package com.angulismotv.ui

/**
 * Owns query synchronization and debounce behavior independently from Android views.
 * The current query is published immediately so a category/country action can apply it before
 * the debounce expires; the expensive list update is delayed until the latest query settles.
 */
class ChannelSearchQueryController(
    delayMillis: Long,
    postDelayed: (Runnable, Long) -> Unit,
    removeCallbacks: (Runnable) -> Unit,
    private val onQueryChanged: (String) -> Unit,
    private val onApply: () -> Unit
) {
    private val debounce = DebouncedActionController(delayMillis, postDelayed, removeCallbacks)
    private var disposed = false

    var query: String = ""
        private set

    /** Synchronize state without scheduling a list update (used when binding a recreated view). */
    fun syncQuery(value: String) {
        if (disposed) return
        updateQuery(value)
    }

    /** Publish the new text immediately and apply the list after the latest debounce window. */
    fun onTextChanged(value: String) {
        if (disposed) return
        updateQuery(value)
        debounce.schedule {
            if (!disposed) onApply()
        }
    }

    /** Apply the supplied/current query now and invalidate any pending delayed apply. */
    fun applyImmediately(value: String = query) {
        if (disposed) return
        debounce.cancel()
        updateQuery(value)
        onApply()
    }

    /** Clear the query, optionally applying it now; false is useful when a caller applies filters itself. */
    fun clear(applyImmediately: Boolean) {
        if (disposed) return
        debounce.cancel()
        updateQuery("")
        if (applyImmediately) onApply()
    }

    fun cancelPending() {
        if (!disposed) debounce.cancel()
    }

    fun dispose() {
        if (disposed) return
        disposed = true
        debounce.dispose()
    }

    private fun updateQuery(value: String) {
        if (query == value) return
        query = value
        onQueryChanged(value)
    }
}
