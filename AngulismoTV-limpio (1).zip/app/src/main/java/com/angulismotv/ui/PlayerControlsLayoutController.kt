package com.angulismotv.ui

import android.content.Context
import android.content.res.Configuration
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout

/** Owns only the responsive arrangement of the fullscreen player's control rows. */
class PlayerControlsLayoutController(
    private val context: Context,
    private val isTV: Boolean,
    private val playerControlsMainRow: LinearLayout,
    private val playerChannelIdentity: LinearLayout,
    private val playerActionGroupsRow: LinearLayout,
    private val playerTransportControls: LinearLayout,
    private val playerUtilityControls: LinearLayout,
    private val bottomControls: View
) {
    fun apply(orientation: Int = context.resources.configuration.orientation) {
        val compactPortrait = !isTV && orientation == Configuration.ORIENTATION_PORTRAIT
        val identityParams = playerChannelIdentity.layoutParams as LinearLayout.LayoutParams
        val actionParams = playerActionGroupsRow.layoutParams as LinearLayout.LayoutParams
        val transportParams = playerTransportControls.layoutParams as LinearLayout.LayoutParams
        val utilityParams = playerUtilityControls.layoutParams as LinearLayout.LayoutParams

        if (compactPortrait) {
            playerControlsMainRow.orientation = LinearLayout.VERTICAL
            identityParams.width = ViewGroup.LayoutParams.MATCH_PARENT
            identityParams.weight = 0f
            identityParams.marginEnd = 0
            playerChannelIdentity.layoutParams = identityParams
            actionParams.width = ViewGroup.LayoutParams.MATCH_PARENT
            actionParams.height = ViewGroup.LayoutParams.WRAP_CONTENT
            playerActionGroupsRow.layoutParams = actionParams
            transportParams.marginStart = 0
            playerTransportControls.layoutParams = transportParams
            utilityParams.marginStart = dp(8)
            playerUtilityControls.layoutParams = utilityParams
            bottomControls.setPadding(dp(16), dp(10), dp(16), dp(12))
        } else {
            playerControlsMainRow.orientation = LinearLayout.HORIZONTAL
            identityParams.width = 0
            identityParams.weight = 1f
            identityParams.marginEnd = 0
            playerChannelIdentity.layoutParams = identityParams
            actionParams.width = ViewGroup.LayoutParams.WRAP_CONTENT
            actionParams.height = ViewGroup.LayoutParams.WRAP_CONTENT
            playerActionGroupsRow.layoutParams = actionParams
            transportParams.marginStart = dp(12)
            playerTransportControls.layoutParams = transportParams
            utilityParams.marginStart = dp(12)
            playerUtilityControls.layoutParams = utilityParams
            bottomControls.setPadding(dp(22), dp(10), dp(22), dp(12))
        }
    }

    private fun dp(value: Int): Int =
        (value * context.resources.displayMetrics.density + 0.5f).toInt()
}
