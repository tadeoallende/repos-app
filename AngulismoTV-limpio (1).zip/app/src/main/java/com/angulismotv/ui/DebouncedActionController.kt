package com.angulismotv.ui

/**
 * Lifecycle-friendly debounce helper. The owner supplies a scheduler (typically a main-thread
 * Handler), making stale callbacks and disposal testable without Android dependencies.
 */
class DebouncedActionController(
    private val delayMillis: Long,
    private val postDelayed: (Runnable, Long) -> Unit,
    private val removeCallbacks: (Runnable) -> Unit
) {
    private var pendingTask: Runnable? = null
    private var disposed = false

    fun schedule(action: () -> Unit) {
        if (disposed) return
        cancel()
        lateinit var task: Runnable
        task = Runnable {
            if (disposed || pendingTask !== task) return@Runnable
            pendingTask = null
            action()
        }
        pendingTask = task
        postDelayed(task, delayMillis)
    }

    fun cancel() {
        pendingTask?.let(removeCallbacks)
        pendingTask = null
    }

    fun dispose() {
        if (disposed) return
        disposed = true
        cancel()
    }
}
