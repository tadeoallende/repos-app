package com.angulismotv.ui

import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.content.ContextCompat
import androidx.core.widget.TextViewCompat
import androidx.recyclerview.widget.RecyclerView
import com.angulismotv.R
import com.angulismotv.adapters.ChannelsAdapter
import com.angulismotv.utils.UiDimensions
import java.util.Locale

/** Builds and updates the category/country chip rail, including Android TV focus navigation. */
class ChannelCategoryRailRenderer(
    private val container: LinearLayout,
    private val searchInput: EditText,
    private val channelsRecycler: RecyclerView,
    private val adapterProvider: () -> ChannelsAdapter?,
    private val isTv: () -> Boolean,
    private val onCategoryClick: (String) -> Unit,
    private val onCountryClick: () -> Unit,
    private val onFocusChannelList: () -> Unit
) {
    companion object {
        const val COUNTRY_FILTER_TAG = "__country_filter__"
        private const val ALL_KEY = ChannelCategoryRailPolicy.ALL_CATEGORY_KEY
    }

    private var countryChip: TextView? = null
    private var selectedCategoryFocusViewId: Int = View.NO_ID

    fun render(
        categories: List<Pair<String, String>>,
        selectedCategory: String,
        selectedCountry: String,
        countryLabel: (String) -> String
    ) {
        container.removeAllViews()
        countryChip = null
        selectedCategoryFocusViewId = View.NO_ID

        val safeCategories = ChannelCategoryRailPolicy.normalize(categories)

        val context = container.context
        val country = (LayoutInflater.from(context)
            .inflate(R.layout.item_category, container, false) as TextView).apply {
            id = View.generateViewId()
            tag = COUNTRY_FILTER_TAG
            text = "País: " + if (selectedCountry == ALL_KEY) "Todos" else countryLabel(selectedCountry)
            setOnClickListener { onCountryClick() }
            if (isTv()) {
                TextViewCompat.setTextAppearance(this, R.style.TextAppearance_AngulismoTV_CategoryChip_TV)
                layoutParams = layoutParams.apply { height = UiDimensions.px(container.resources, R.dimen.category_chip_height_tv) }
                setPadding(
                    UiDimensions.px(container.resources, R.dimen.category_country_padding_horizontal_tv), 0,
                    UiDimensions.px(container.resources, R.dimen.category_country_padding_horizontal_tv), 0
                )
                nextFocusLeftId = R.id.inline_player_container
                configureTvFocusEffect(this)
            }
        }
        countryChip = country
        updateChipStyle(country, selectedCountry != ALL_KEY)
        container.addView(country)

        safeCategories.forEachIndexed { index, (key, label) ->
            val chip = LayoutInflater.from(context)
                .inflate(R.layout.item_category, container, false) as TextView
            chip.text = label
            chip.tag = key
            chip.isSelected = key.equals(selectedCategory, ignoreCase = true)

            if (isTv()) {
                chip.id = View.generateViewId()
                chip.layoutParams = chip.layoutParams.apply { height = UiDimensions.px(container.resources, R.dimen.category_chip_height_tv) }
                TextViewCompat.setTextAppearance(chip, R.style.TextAppearance_AngulismoTV_CategoryChip_TV)
                chip.setPadding(
                    UiDimensions.px(container.resources, R.dimen.category_chip_padding_horizontal_tv), 0,
                    UiDimensions.px(container.resources, R.dimen.category_chip_padding_horizontal_tv), 0
                )
                (chip.layoutParams as? ViewGroup.MarginLayoutParams)?.let { params ->
                    params.marginEnd = UiDimensions.px(container.resources, R.dimen.category_chip_margin_end_tv)
                    chip.layoutParams = params
                }
                chip.nextFocusLeftId = if (index == 0) country.id else View.NO_ID
                chip.setOnKeyListener { _, keyCode, event ->
                    if (event.action == KeyEvent.ACTION_DOWN && event.repeatCount == 0 &&
                        keyCode == KeyEvent.KEYCODE_DPAD_DOWN
                    ) {
                        onFocusChannelList()
                        true
                    } else false
                }
                configureTvFocusEffect(chip)
            } else {
                chip.setOnTouchListener { _, _ ->
                    chip.isSelected = true
                    false
                }
            }

            updateChipStyle(chip, chip.isSelected)
            chip.setOnClickListener { onCategoryClick(key) }
            container.addView(chip)
        }

        if (isTv()) {
            selectedCategoryFocusViewId = container.findViewWithTag<TextView>(selectedCategory)?.id
                ?: container.findViewWithTag<TextView>(ALL_KEY)?.id
                ?: country.id
            searchInput.nextFocusDownId = selectedCategoryFocusViewId
            channelsRecycler.nextFocusUpId = selectedCategoryFocusViewId
            for (index in 0 until container.childCount) {
                val chip = container.getChildAt(index)
                chip.nextFocusUpId = R.id.search_input
                chip.nextFocusDownId = R.id.channels_recycler
                chip.nextFocusLeftId = if (index == 0) R.id.inline_player_container
                else container.getChildAt(index - 1).id
            }
            adapterProvider()?.setCategoryFocusTarget(selectedCategoryFocusViewId)
        }
    }

    fun selectCategory(categoryKey: String, selectedCountry: String) {
        for (index in 0 until container.childCount) {
            val chip = container.getChildAt(index) as? TextView ?: continue
            val isCountry = chip.tag == COUNTRY_FILTER_TAG
            val selected = chip.tag?.toString().equals(categoryKey, ignoreCase = true)
            chip.isSelected = !isCountry && selected
            updateChipStyle(chip, if (isCountry) selectedCountry != ALL_KEY else selected)
            if (selected) selectedCategoryFocusViewId = chip.id
        }
        if (isTv()) {
            searchInput.nextFocusDownId = selectedCategoryFocusViewId
            channelsRecycler.nextFocusUpId = selectedCategoryFocusViewId
            adapterProvider()?.setCategoryFocusTarget(selectedCategoryFocusViewId)
        }
    }

    fun updateCountry(selectedCountry: String, labelFor: (String) -> String) {
        countryChip?.let { chip ->
            chip.text = "País: " + if (selectedCountry == ALL_KEY) "Todos" else labelFor(selectedCountry)
            updateChipStyle(chip, selectedCountry != ALL_KEY)
        }
    }

    fun clear() {
        container.removeAllViews()
        countryChip = null
        selectedCategoryFocusViewId = View.NO_ID
        searchInput.nextFocusDownId = View.NO_ID
        channelsRecycler.nextFocusUpId = View.NO_ID
    }

    fun focusSelectedCategory(selectedCategory: String): Boolean {
        if (!isTv()) return false
        val target = container.findViewWithTag<TextView>(selectedCategory)
            ?: container.findViewWithTag<TextView>(ALL_KEY)
        return target?.requestFocus() == true
    }

    private fun updateChipStyle(chip: TextView, selected: Boolean) {
        chip.setBackgroundResource(if (selected) R.drawable.bg_category_selected else R.drawable.bg_category_default)
        chip.setTextColor(
            ContextCompat.getColor(
                container.context,
                if (selected) R.color.text_primary else R.color.text_secondary
            )
        )
    }

    private fun configureTvFocusEffect(chip: TextView) {
        chip.onFocusChangeListener = View.OnFocusChangeListener { view, hasFocus ->
            view.animate().cancel()
            view.scaleX = 1f
            view.scaleY = 1f
            if (!hasFocus) return@OnFocusChangeListener
            val scroller = (view.parent as? View)?.parent as? android.widget.HorizontalScrollView ?: return@OnFocusChangeListener
            val leftEdge = scroller.scrollX
            val rightEdge = leftEdge + scroller.width - scroller.paddingLeft - scroller.paddingRight
            when {
                view.left < leftEdge -> scroller.smoothScrollTo(view.left, 0)
                view.right > rightEdge -> scroller.smoothScrollTo(view.right - scroller.width + scroller.paddingRight, 0)
            }
        }
    }

}
