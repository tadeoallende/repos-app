package com.angulismotv.ui

import android.text.Editable
import java.util.Locale
import android.text.TextWatcher
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.angulismotv.R
import com.angulismotv.adapters.CategoriesAdapter
import com.angulismotv.adapters.ChannelsAdapter
import com.angulismotv.adapters.SideChannelsAdapter
import com.angulismotv.data.ChannelCatalog
import com.angulismotv.data.ChannelFilterEngine
import com.angulismotv.models.Channel
import com.angulismotv.models.ChannelIdentity

/**
 * Coordina el catálogo, las categorías y la búsqueda del panel lateral del reproductor.
 * La Activity conserva el ciclo de vida del player y la navegación del mando; este controlador
 * mantiene la lógica de presentación y filtrado propia del panel.
 */
class PlayerChannelPanelController(
    private val activity: AppCompatActivity,
    private val channelsList: RecyclerView,
    private val menuCategoriesList: RecyclerView,
    private val menuSearchResults: RecyclerView,
    private val menuSearchInput: EditText,
    private val searchInputContainer: View,
    private val searchEmptyText: View,
    private val contentTitle: TextView,
    private val channelsCountText: TextView,
    private val btnAllChannels: LinearLayout,
    private val allChannelsMarker: View,
    private val allChannelsIcon: ImageView,
    private val allChannelsText: TextView,
    private val btnSearchTrigger: LinearLayout,
    private val btnClosePanel: View,
    private val getChannels: () -> List<Channel>,
    private val getCurrentChannel: () -> Channel?,
    private val onChannelSelected: (Channel, Int) -> Unit,
    private val onFocusChannels: () -> Unit,
    private val onClosePanel: () -> Unit
) {
    lateinit var sideChannelsAdapter: SideChannelsAdapter
        private set
    lateinit var categoriesAdapter: CategoriesAdapter
        private set
    lateinit var searchAdapter: ChannelsAdapter
        private set

    var currentCategory: String = ALL_CHANNELS_CATEGORY
        private set
    var isSearchActive: Boolean = false
        private set
    var filteredChannels: List<Channel> = emptyList()
        private set
    private var channelNumbersByIdentity: Map<String, Int> = emptyMap()
    private var catalogGeneration = 0
    private var channelListJob: Job? = null
    private var searchJob: Job? = null
    private var searchGeneration = 0
    private var preparedCatalog: List<Channel>? = null
    private var preparedCategoryItems: List<CategoriesAdapter.CategoryItem> = emptyList()

    val isReady: Boolean
        get() = ::sideChannelsAdapter.isInitialized && ::categoriesAdapter.isInitialized && ::searchAdapter.isInitialized

    fun initialize(isTV: Boolean) {
        if (!isTV || isReady) return

        sideChannelsAdapter = SideChannelsAdapter(
            onItemClick = { channel, position -> onChannelSelected(channel, position) },
            channelNumber = { channel -> channelNumbersByIdentity[ChannelIdentity.key(channel)] ?: 0 }
        )
        categoriesAdapter = CategoriesAdapter(::onCategorySelected)
        channelsList.apply {
            layoutManager = LinearLayoutManager(activity)
            isFocusable = true
            isFocusableInTouchMode = true
            descendantFocusability = ViewGroup.FOCUS_BEFORE_DESCENDANTS
            adapter = sideChannelsAdapter
        }
        menuCategoriesList.apply {
            layoutManager = LinearLayoutManager(activity)
            adapter = categoriesAdapter
        }
        btnAllChannels.apply {
            isFocusable = true
            isFocusableInTouchMode = true
            isClickable = true
            setOnClickListener { showAllChannels() }
        }
        btnSearchTrigger.apply {
            isFocusable = true
            isFocusableInTouchMode = true
            setOnClickListener { activateSearchMode() }
        }
        btnClosePanel.setOnClickListener { onClosePanel() }
        setupSearchInput()
        filteredChannels = getChannels()
    }

    fun setChannelCatalog(channels: List<Channel>) {
        filteredChannels = channels
        val requestGeneration = ++catalogGeneration
        searchGeneration++
        searchJob?.cancel()
        channelListJob?.cancel()
        preparedCatalog = null
        preparedCategoryItems = emptyList()
        channelNumbersByIdentity = emptyMap()
        val snapshot = channels

        activity.lifecycleScope.launch {
            val prepared = withContext(Dispatchers.Default) {
                val countsByCategory = snapshot.groupingBy {
                    ChannelFilterEngine.categoryKey(it.category)
                }.eachCount()
                val categoryItems = ChannelFilterEngine.availableCategories(snapshot).map { (key, label) ->
                    CategoriesAdapter.CategoryItem(key, label, countsByCategory[key] ?: 0)
                }
                Triple(ChannelCatalog.channelNumbersByIdentity(snapshot), categoryItems, snapshot)
            }
            if (requestGeneration != catalogGeneration || activity.isFinishing || activity.isDestroyed ||
                getChannels() !== snapshot) return@launch

            channelNumbersByIdentity = prepared.first
            preparedCategoryItems = prepared.second
            preparedCatalog = prepared.third
            if (isReady) {
                updateCategoriesList()
                updateChannelsList(scrollToSelected = true)
                if (isSearchActive) scheduleSearch(menuSearchInput.text.toString())
            }
        }
    }

    /** Actualiza la vista del panel al abrirlo, incluyendo el canal actualmente reproducido. */
    fun refreshForOpening() {
        if (!isReady) return
        updateCategoriesList()
        updateChannelsList(scrollToSelected = true)
        updateContentTitle()
        onFocusChannels()
    }

    fun activateSearchMode() {
        if (!isReady) return
        isSearchActive = true
        searchInputContainer.visibility = View.VISIBLE
        contentTitle.text = "BUSCAR"
        channelsCountText.text = ""
        categoriesAdapter.clearSelection()
        menuSearchInput.text.clear()
        menuSearchResults.visibility = View.GONE
        searchEmptyText.visibility = View.GONE
        channelsList.visibility = View.VISIBLE
        updateAllChannelsSelection()
        menuSearchInput.post { menuSearchInput.requestFocus() }
    }

    fun deactivateSearchMode() {
        if (!isSearchActive) return
        isSearchActive = false
        searchInputContainer.visibility = View.GONE
        menuSearchInput.text.clear()
        menuSearchResults.visibility = View.GONE
        searchEmptyText.visibility = View.GONE
        channelsList.visibility = View.VISIBLE
        updateContentTitle()
        updateCategoriesList()
        updateChannelsList(scrollToSelected = true)
        updateAllChannelsSelection()
    }

    fun handleBackInPanel(): Boolean = when {
        isSearchActive && menuSearchInput.text.isNotEmpty() -> {
            menuSearchInput.text.clear()
            menuSearchInput.post { menuSearchInput.requestFocus() }
            true
        }
        isSearchActive -> {
            deactivateSearchMode()
            btnSearchTrigger.post { btnSearchTrigger.requestFocus() }
            true
        }
        else -> {
            onClosePanel()
            true
        }
    }

    private fun setupSearchInput() {
        searchAdapter = ChannelsAdapter(
            onItemClick = { channel, _ ->
                val index = getChannels().indexOfFirst { ChannelIdentity.same(it, channel) }
                if (index != INVALID_CHANNEL_INDEX) {
                    deactivateSearchMode()
                    onChannelSelected(channel, index)
                }
            },
            channelNumber = { channel -> channelNumbersByIdentity[ChannelIdentity.key(channel)] ?: 0 }
        )
        menuSearchResults.apply {
            layoutManager = LinearLayoutManager(activity)
            adapter = searchAdapter
        }
        menuSearchInput.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) = Unit
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) = Unit

            override fun afterTextChanged(s: Editable?) {
                scheduleSearch(s?.toString().orEmpty())
            }
        })
        menuSearchInput.setOnEditorActionListener { _, actionId, _ -> actionId == EditorInfo.IME_ACTION_SEARCH }
    }

    private fun scheduleSearch(rawQuery: String) {
        val query = rawQuery.trim()
        val requestGeneration = ++searchGeneration
        searchJob?.cancel()

        if (query.isEmpty()) {
            searchAdapter.submitList(emptyList())
            menuSearchResults.visibility = View.GONE
            searchEmptyText.visibility = View.GONE
            channelsList.visibility = View.VISIBLE
            contentTitle.text = if (isSearchActive) "BUSCAR" else contentTitle.text
            channelsCountText.text = if (isSearchActive) "" else filteredChannels.size.toString()
            return
        }

        // Keep input responsive while the previous query is cancelled and the new query settles.
        channelsList.visibility = View.GONE
        menuSearchResults.visibility = View.GONE
        searchEmptyText.visibility = View.GONE
        contentTitle.text = "BUSCAR"
        channelsCountText.text = ""

        val channels = getChannels()
        val expectedCatalogGeneration = catalogGeneration
        searchJob = activity.lifecycleScope.launch {
            delay(180)
            val results = withContext(Dispatchers.Default) {
                ChannelCatalog.searchByName(channels, query)
            }
            if (requestGeneration != searchGeneration || expectedCatalogGeneration != catalogGeneration ||
                !isSearchActive || channels !== getChannels() || activity.isFinishing || activity.isDestroyed) {
                return@launch
            }
            searchAdapter.submitList(results)
            menuSearchResults.visibility = if (results.isNotEmpty()) View.VISIBLE else View.GONE
            searchEmptyText.visibility = if (results.isEmpty()) View.VISIBLE else View.GONE
            channelsCountText.text = results.size.toString()
            contentTitle.text = "RESULTADOS: \"$query\""
        }
    }

    private fun updateCategoriesList() {
        val channels = getChannels()
        if (!isReady || channels.isEmpty() || preparedCatalog !== channels) return

        // The category labels and counts were prepared once off the UI thread for this catalogue.
        val items = preparedCategoryItems
        val selected = if (currentCategory.equals(ALL_CHANNELS_CATEGORY, ignoreCase = true)) "" else currentCategory
        categoriesAdapter.submitList(items, selected)
        updateAllChannelsSelection()
    }

    private fun updateChannelsList(scrollToSelected: Boolean = false) {
        if (!isReady) return
        val channels = getChannels()
        if (preparedCatalog !== channels) return
        val expectedCatalogGeneration = catalogGeneration
        val requestedCategory = currentCategory
        val current = getCurrentChannel()
        channelListJob?.cancel()
        channelListJob = activity.lifecycleScope.launch {
            val result = withContext(Dispatchers.Default) {
                ChannelFilterEngine.filter(
                    channels = channels,
                    category = requestedCategory,
                    country = ChannelFilterEngine.ALL_COUNTRIES,
                    query = ""
                )
            }
            if (expectedCatalogGeneration != catalogGeneration || requestedCategory != currentCategory ||
                channels !== getChannels() || isSearchActive || activity.isFinishing || activity.isDestroyed) {
                return@launch
            }
            filteredChannels = result
            val selectedIndex = result.indexOfFirst { current != null && ChannelIdentity.same(it, current) }
            sideChannelsAdapter.submitList(result, selectedIndex)
            channelsCountText.text = result.size.toString()
            if (scrollToSelected && selectedIndex >= 0) {
                channelsList.post {
                    if (expectedCatalogGeneration == catalogGeneration && requestedCategory == currentCategory) {
                        (channelsList.layoutManager as? LinearLayoutManager)?.scrollToPositionWithOffset(selectedIndex, 0)
                    }
                }
            }
        }
    }

    private fun onCategorySelected(categoryKey: String) {
        deactivateSearchMode()
        currentCategory = categoryKey
        updateContentTitle()
        updateCategoriesList()
        updateChannelsList(scrollToSelected = true)
        updateAllChannelsSelection()
        onFocusChannels()
    }

    private fun showAllChannels() {
        if (isSearchActive) deactivateSearchMode()
        currentCategory = ALL_CHANNELS_CATEGORY
        updateContentTitle()
        updateCategoriesList()
        updateChannelsList(scrollToSelected = true)
        updateAllChannelsSelection()
        onFocusChannels()
    }

    private fun updateContentTitle() {
        contentTitle.text = if (currentCategory.equals(ALL_CHANNELS_CATEGORY, ignoreCase = true)) {
            "Todos los canales"
        } else {
            formatCategoryLabel(currentCategory)
        }
    }

    private fun updateAllChannelsSelection() {
        if (!isReady) return
        val selected = !isSearchActive && currentCategory.equals(ALL_CHANNELS_CATEGORY, ignoreCase = true)
        btnAllChannels.isSelected = selected
        btnAllChannels.refreshDrawableState()
        btnAllChannels.setBackgroundResource(
            if (selected) R.drawable.side_category_item_selected else R.drawable.side_menu_item_bg
        )
        allChannelsMarker.visibility = if (selected) View.VISIBLE else View.INVISIBLE
        val accent = ContextCompat.getColor(activity, R.color.accent)
        val primary = ContextCompat.getColor(activity, R.color.text_primary)
        val secondary = ContextCompat.getColor(activity, R.color.text_secondary)
        allChannelsIcon.setColorFilter(if (selected) accent else secondary)
        allChannelsText.setTextColor(if (selected) accent else primary)
        btnAllChannels.contentDescription = if (selected) "Lista de canales, seleccionada" else "Lista de canales"
    }

    private fun formatCategoryLabel(raw: String): String =
        ChannelFilterEngine.displayCategoryName(raw)

    private companion object {
        const val ALL_CHANNELS_CATEGORY = "todos"
        const val INVALID_CHANNEL_INDEX = -1
    }

}
