package com.angulismotv.ui

/**
 * Issues a unique token for each Fragment view tree and invalidates it on teardown.
 * Delayed callbacks must check the token they captured, not just whether some view is active;
 * otherwise work queued by an old RecyclerView can run against a newly-created view tree.
 */
class ViewLifecycleGate {
    private var generation: Int = 0
    private var activeGeneration: Int? = null

    fun activate(): Int {
        generation += 1
        activeGeneration = generation
        return generation
    }

    fun invalidate() {
        generation += 1
        activeGeneration = null
    }

    fun isActive(expectedGeneration: Int? = null): Boolean {
        val active = activeGeneration ?: return false
        return expectedGeneration == null || active == expectedGeneration
    }
}
