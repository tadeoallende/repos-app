package com.angulismotv.ui

import android.text.Editable
import android.text.TextWatcher
import android.view.View
import android.widget.EditText

/**
 * Binds an EditText lifecycle to [ChannelSearchQueryController]. The watcher is explicitly
 * removed when the fragment's view is destroyed so the old view cannot retain the fragment.
 */
class ChannelSearchInputBinding(
    private val input: EditText,
    private val queryController: ChannelSearchQueryController,
    private val onFocusChanged: (Boolean) -> Unit = {}
) {
    private var disposed = false

    private val watcher = object : TextWatcher {
        override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) = Unit

        override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
            if (!disposed) queryController.onTextChanged(s?.toString().orEmpty())
        }

        override fun afterTextChanged(s: Editable?) = Unit
    }

    private val focusListener = View.OnFocusChangeListener { _, hasFocus ->
        if (!disposed) onFocusChanged(hasFocus)
    }

    init {
        queryController.syncQuery(input.text.toString())
        input.addTextChangedListener(watcher)
        input.onFocusChangeListener = focusListener
        onFocusChanged(input.hasFocus())
    }

    fun clear(applyImmediately: Boolean) {
        if (disposed) return
        input.setText("")
        queryController.clear(applyImmediately)
    }

    fun applyImmediately() {
        if (disposed) return
        queryController.applyImmediately(input.text.toString())
    }

    fun cancelPending() {
        if (!disposed) queryController.cancelPending()
    }

    fun dispose() {
        if (disposed) return
        disposed = true
        input.removeTextChangedListener(watcher)
        input.onFocusChangeListener = null
        onFocusChanged(false)
        queryController.dispose()
    }
}
