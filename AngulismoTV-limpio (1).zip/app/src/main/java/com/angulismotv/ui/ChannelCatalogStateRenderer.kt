package com.angulismotv.ui

import android.content.Context
import android.view.View
import android.widget.ProgressBar
import android.widget.TextView
import androidx.core.content.ContextCompat
import androidx.core.view.isVisible
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout
import com.angulismotv.R

/** Renders loading/retry/empty states for the channel catalog without owning catalog data. */
class ChannelCatalogStateRenderer(
    context: Context,
    private val progressBar: ProgressBar,
    private val swipeRefresh: SwipeRefreshLayout,
    private val stateContainer: View,
    private val retryButton: TextView,
    private val errorText: TextView,
    private val isTv: () -> Boolean,
    private val reloadChannels: () -> Unit
) {
    private val appContext = context.applicationContext
    private var disposed = false

    fun bind() {
        if (disposed) return
        swipeRefresh.setColorSchemeResources(R.color.accent)
        swipeRefresh.setProgressBackgroundColorSchemeResource(R.color.space_surface_raised)
        swipeRefresh.isEnabled = !isTv()
        swipeRefresh.setOnRefreshListener { if (!disposed) reloadChannels() }
        retryButton.setOnClickListener { if (!disposed) reloadChannels() }
    }

    fun showLoading(show: Boolean) {
        if (!disposed) progressBar.isVisible = show
    }

    fun finishLoading() {
        if (disposed) return
        showLoading(false)
        swipeRefresh.isRefreshing = false
    }

    fun beginLoading() {
        if (disposed) return
        hideState()
        if (!swipeRefresh.isRefreshing) showLoading(true)
    }

    fun showState(message: String, isError: Boolean, showRetry: Boolean) {
        if (disposed) return
        errorText.text = message
        errorText.setTextColor(
            ContextCompat.getColor(
                appContext,
                if (isError) R.color.error else R.color.text_secondary
            )
        )
        retryButton.isVisible = showRetry
        stateContainer.isVisible = true
        if (showRetry && isTv()) retryButton.requestFocus()
    }

    fun hideState() {
        if (!disposed) stateContainer.isVisible = false
    }

    fun dispose() {
        if (disposed) return
        disposed = true
        swipeRefresh.setOnRefreshListener(null)
        retryButton.setOnClickListener(null)
    }
}
