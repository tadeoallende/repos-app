package com.angulismotv.ui

import android.view.View
import android.widget.LinearLayout
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.angulismotv.adapters.ChannelsAdapter
import com.angulismotv.models.Channel
import com.angulismotv.models.ChannelIdentity

/** Coordinates focus restoration for the inline catalogue without owning filter or player state. */
class ChannelCatalogFocusController(
    private val channelsRecycler: RecyclerView,
    private val categoriesContainer: LinearLayout,
    private val adapterProvider: () -> ChannelsAdapter,
    private val filteredChannelsProvider: () -> List<Channel>,
    private val selectedChannelProvider: () -> Channel?,
    private val selectedCategoryProvider: () -> String,
    private val isTv: () -> Boolean,
    private val isActive: () -> Boolean,
    private val emptyListFallbackProvider: () -> View?
) {
    private val callbackRegistry = ViewPostCallbackRegistry()

    /** Focus operations use the shared per-view-lifecycle callback queue. */
    private fun postTracked(view: View, action: () -> Unit) {
        callbackRegistry.post(view, action)
    }

    /** Cancels pending focus work and releases queued references to the old view tree. */
    fun dispose() = callbackRegistry.dispose()
    fun focusChannelList() {
        if (!isTv() || !isActive()) return
        val adapter = adapterProvider()
        val itemCount = adapter.itemCount
        if (itemCount <= 0) {
            emptyListFallbackProvider()?.requestFocus()
            return
        }
        val filtered = filteredChannelsProvider()
        val selectedPosition = selectedChannelProvider()?.let { channel ->
            filtered.indexOfFirst { ChannelIdentity.same(it, channel) }
        } ?: -1
        val remembered = adapter.getLastFocusedPosition()
        val targetPosition = ChannelListFocusPolicy.targetPosition(itemCount, selectedPosition, remembered) ?: return

        postTracked(channelsRecycler) outerFocus@{
            if (!isActive() || !channelsRecycler.isShown) return@outerFocus
            channelsRecycler.scrollToPosition(targetPosition)
            postTracked(channelsRecycler) itemFocus@{
                if (!isActive() || !channelsRecycler.isShown) return@itemFocus
                val target = channelsRecycler.findViewHolderForAdapterPosition(targetPosition)?.itemView
                if (target?.isShown == true && target.requestFocus()) return@itemFocus
                channelsRecycler.requestFocus()
            }
        }
    }

    fun focusSelectedCategory() {
        if (!isTv() || !isActive()) return
        val selected = categoriesContainer.findViewWithTag<TextView>(selectedCategoryProvider())
            ?: categoriesContainer.getChildAt(0) as? TextView
        selected?.requestFocus()
    }

    /** Focus is restored by stable channel identity rather than a position that filters can change. */
    fun restoreChannelForKey(key: String, scrollIfNeeded: Boolean) {
        if (!isTv() || !isActive()) return
        postTracked(channelsRecycler) restoreRequest@{
            if (!isActive() || !channelsRecycler.isShown) return@restoreRequest
            postTracked(channelsRecycler) secondFocusRestore@{
                if (!isActive() || !channelsRecycler.isShown) return@secondFocusRestore
                val position = adapterProvider().getPositionForKey(key)
                if (position < 0) return@secondFocusRestore
                val row = channelsRecycler.findViewHolderForAdapterPosition(position)?.itemView
                if (row?.isShown == true) {
                    if (!row.hasFocus()) row.requestFocus()
                    return@secondFocusRestore
                }
                if (scrollIfNeeded) {
                    channelsRecycler.scrollToPosition(position)
                    postTracked(channelsRecycler) attachedRowFocus@{
                        if (!isActive() || !channelsRecycler.isShown) return@attachedRowFocus
                        val attachedRow = channelsRecycler.findViewHolderForAdapterPosition(position)?.itemView
                        if (attachedRow?.isShown == true && !attachedRow.hasFocus()) attachedRow.requestFocus()
                    }
                }
            }
        }
    }

    fun currentFocusedChannelKey(): String? {
        if (!isTv() || !isActive()) return null
        val focusedView = channelsRecycler.findFocus() ?: return null
        val holder = channelsRecycler.findContainingViewHolder(focusedView) ?: return null
        val channel = adapterProvider().getChannelAt(holder.bindingAdapterPosition) ?: return null
        return ChannelIdentity.key(channel)
    }

    fun restoreLastFocus() {
        if (!isTv() || !isActive()) return
        val adapter = adapterProvider()
        val lastKey = adapter.getLastFocusedChannelKey()
        if (lastKey != null && adapter.getPositionForKey(lastKey) >= 0) {
            restoreChannelForKey(lastKey, scrollIfNeeded = true)
            return
        }
        val position = adapter.getLastFocusedPosition()
        if (position < 0 || position >= adapter.itemCount) return
        channelsRecycler.scrollToPosition(position)
        postTracked(channelsRecycler) {
            if (!isActive() || !channelsRecycler.isShown) return@postTracked
            channelsRecycler.findViewHolderForAdapterPosition(position)?.itemView?.requestFocus()
        }
    }
}

/** Pure target selection, shared by the UI controller tests and the actual focus path. */
object ChannelListFocusPolicy {
    fun targetPosition(itemCount: Int, selectedPosition: Int, rememberedPosition: Int): Int? {
        if (itemCount <= 0) return null
        return when {
            selectedPosition in 0 until itemCount -> selectedPosition
            rememberedPosition in 0 until itemCount -> rememberedPosition
            else -> 0
        }
    }
}
