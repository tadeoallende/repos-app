package com.angulismotv.ui

import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

/** Applies device-specific sizing and spacing without coupling layout details to playback logic. */
class ChannelScreenLayoutController(
    private val root: View,
    private val isTV: Boolean,
    private val channelsSectionHeader: View,
    private val channelsSearchContainer: View,
    private val btnSearch: ImageView,
    private val searchInput: EditText,
    private val categoriesScroll: HorizontalScrollView,
    private val channelsRecycler: RecyclerView,
    private val inlinePlayerContainer: FrameLayout,
    private val inlineControlsBar: LinearLayout,
    private val inlineChannelLogo: ImageView,
    private val inlineChannelName: TextView,
    private val inlineTimelineContainer: View,
    private val inlineTimeCurrent: TextView,
    private val inlineTimeDuration: TextView,
    private val inlineSeekBar: SeekBar,
    private val onSearchVisibilityChanged: (Boolean) -> Unit
) {
    fun applyDeviceSpecificLayout() {
        val density = root.resources.displayMetrics.density
        fun dp(value: Int) = (value * density + 0.5f).toInt()

        val listContainer = root.findViewById<FrameLayout>(com.angulismotv.R.id.channels_list_container)
        val searchRow = channelsSearchContainer as? ViewGroup
        val searchField = searchRow?.getChildAt(0) as? ViewGroup
        val searchParams = searchField?.layoutParams
        val listContainerPadding = if (isTV) 0 else dp(8)

        if (isTV) {
            // En TV se priorizan el área de vídeo y las filas visibles, conservando lectura a distancia.
            channelsSectionHeader.visibility = View.VISIBLE
            channelsSearchContainer.visibility = View.GONE
            onSearchVisibilityChanged(false)
            btnSearch.isFocusable = false
            btnSearch.isClickable = false
            btnSearch.setOnClickListener(null)
            channelsSearchContainer.setPadding(dp(4), dp(4), dp(4), dp(4))
            if (searchParams != null) {
                searchParams.height = dp(46)
                searchField?.layoutParams = searchParams
            }
            searchField?.setPadding(dp(12), 0, dp(12), 0)
            searchInput.textSize = 15f
            (searchInput.layoutParams as? ViewGroup.MarginLayoutParams)?.let { params ->
                params.marginStart = dp(8)
                searchInput.layoutParams = params
            }
            categoriesScroll.setPadding(dp(4), dp(4), dp(4), dp(4))
            listContainer?.setPadding(listContainerPadding, 0, 0, 0)
            channelsRecycler.setPadding(dp(2), dp(4), dp(2), dp(6))
            categoriesScroll.isFillViewport = false
        } else {
            // En móvil la cabecera global identifica la sección; se evita repetir un título grande.
            channelsSectionHeader.visibility = View.GONE
            channelsSectionHeader.layoutParams = channelsSectionHeader.layoutParams.apply { height = 0 }
            channelsSearchContainer.visibility = View.GONE
            channelsSearchContainer.setPadding(dp(8), dp(3), dp(8), dp(2))
            if (searchParams != null) {
                searchParams.height = dp(38)
                searchField?.layoutParams = searchParams
            }
            searchField?.setPadding(dp(12), 0, dp(12), 0)
            searchInput.textSize = 14f
            (searchInput.layoutParams as? ViewGroup.MarginLayoutParams)?.let { params ->
                params.marginStart = dp(8)
                searchInput.layoutParams = params
            }
            categoriesScroll.setPadding(dp(8), dp(2), dp(8), dp(2))
            listContainer?.setPadding(0, 0, 0, 0)
            channelsRecycler.setPadding(dp(4), dp(1), dp(4), dp(8))
            channelsRecycler.clipToPadding = false

            val playerParams = inlinePlayerContainer.layoutParams as? ViewGroup.MarginLayoutParams
            playerParams?.setMargins(dp(2), dp(2), dp(2), 0)
            if (playerParams != null) inlinePlayerContainer.layoutParams = playerParams
            inlinePlayerContainer.elevation = 0f
            inlineControlsBar.apply {
                minimumHeight = dp(44)
                setPadding(dp(6), dp(2), dp(6), dp(2))
            }
            inlineChannelLogo.layoutParams = inlineChannelLogo.layoutParams.apply {
                width = dp(28)
                height = dp(28)
            }
            inlineChannelName.apply {
                textSize = 12f
                (layoutParams as? ViewGroup.MarginLayoutParams)?.let { params ->
                    params.marginStart = dp(6)
                    layoutParams = params
                }
            }
            (inlineTimelineContainer.layoutParams as? FrameLayout.LayoutParams)?.let { params ->
                params.height = dp(24)
                params.leftMargin = dp(8)
                params.rightMargin = dp(8)
                params.bottomMargin = dp(46)
                inlineTimelineContainer.layoutParams = params
            }
            inlineTimeCurrent.layoutParams = inlineTimeCurrent.layoutParams.apply { width = dp(32) }
            inlineTimeDuration.layoutParams = inlineTimeDuration.layoutParams.apply { width = dp(32) }
            inlineTimeCurrent.textSize = 9f
            inlineTimeDuration.textSize = 9f
            inlineSeekBar.layoutParams = inlineSeekBar.layoutParams.apply { height = dp(20) }
            listContainer?.clipToPadding = false
        }
    }
}
