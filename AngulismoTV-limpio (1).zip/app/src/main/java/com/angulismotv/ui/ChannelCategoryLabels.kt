package com.angulismotv.ui

import java.util.Locale

/** Spanish display labels for the general categories shown by the channel catalogue. */
object ChannelCategoryLabels {
    val names: Map<String, String> = mapOf(
        "todos" to "Todos",
        "deportes" to "Deportes",
        "noticias" to "Noticias",
        "peliculas" to "Películas",
        "series" to "Series",
        "infantiles" to "Infantiles",
        "educativos" to "Educativos",
        "internacionales" to "Internacionales",
        "estilo-vida" to "Estilo de vida",
        "musicales" to "Musicales",
        "documentales" to "Documentales",
        "entretenimiento" to "Entretenimiento",
        "otros" to "Otros",
        "eventos" to "Eventos"
    )

    fun displayName(rawKey: String): String {
        names[rawKey]?.let { return it }
        val spanishLocale = Locale.forLanguageTag("es-AR")
        return rawKey
            .trim()
            .replace('-', ' ')
            .replace('_', ' ')
            .split(' ')
            .filter { it.isNotBlank() }
            .joinToString(" ") { word ->
                word.lowercase(spanishLocale).replaceFirstChar { first ->
                    if (first.isLowerCase()) first.titlecase(spanishLocale) else first.toString()
                }
            }
    }
}
