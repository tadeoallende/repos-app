package com.angulismotv.ui

import android.os.Handler
import android.os.Looper
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import android.widget.EditText

/** Owns debounced search input work, leaving filter rendering and category UI to the Fragment. */
internal class DebouncedChannelSearchController(
    private val searchInput: EditText,
    private val isSearchActive: () -> Boolean,
    private val viewGeneration: () -> Int,
    private val currentCategory: () -> String,
    private val resetCategoryToAll: () -> Unit,
    private val applyFilters: () -> Unit,
    private val delayMs: Long = DEFAULT_DELAY_MS,
    private val handler: Handler = Handler(Looper.getMainLooper())
) {
    private var pendingFilter: Runnable? = null
    private var attached = false

    private val textWatcher = object : TextWatcher {
        override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) = Unit

        override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
            cancelPendingFilter()
            if (!isSearchActive() || searchInput.visibility != View.VISIBLE) return

            // An explicit query is global; reflect that in the category selected in the UI.
            if (!s.isNullOrBlank() && currentCategory() != ALL_CATEGORIES_KEY) {
                resetCategoryToAll()
            }

            val expectedGeneration = viewGeneration()
            val task = Runnable {
                if (expectedGeneration == viewGeneration() && isSearchActive() &&
                    searchInput.visibility == View.VISIBLE) {
                    applyFilters()
                }
            }
            pendingFilter = task
            handler.postDelayed(task, delayMs)
        }

        override fun afterTextChanged(s: Editable?) = Unit
    }

    fun attach() {
        if (attached) return
        searchInput.addTextChangedListener(textWatcher)
        attached = true
    }

    fun cancelPendingFilter() {
        pendingFilter?.let(handler::removeCallbacks)
        pendingFilter = null
    }

    fun dispose() {
        cancelPendingFilter()
        if (attached) searchInput.removeTextChangedListener(textWatcher)
        attached = false
    }

    private companion object {
        const val DEFAULT_DELAY_MS = 300L
        const val ALL_CATEGORIES_KEY = "todos"
    }
}
