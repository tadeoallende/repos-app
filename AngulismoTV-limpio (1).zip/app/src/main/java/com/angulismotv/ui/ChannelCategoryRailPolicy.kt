package com.angulismotv.ui

import java.util.Locale

/** Keeps the category rail deterministic even when a future catalogue source provides odd labels. */
object ChannelCategoryRailPolicy {
    const val ALL_CATEGORY_KEY = "todos"

    fun normalize(categories: List<Pair<String, String>>): List<Pair<String, String>> {
        val normalized = linkedMapOf<String, Pair<String, String>>()
        categories.forEach { (rawKey, rawLabel) ->
            val key = rawKey.trim().lowercase(Locale.ROOT)
            if (key.isBlank() || key == ALL_CATEGORY_KEY) return@forEach
            normalized.putIfAbsent(key, key to rawLabel.trim().ifBlank { fallbackLabel(key) })
        }
        val providedAllLabel = categories.firstOrNull {
            it.first.trim().equals(ALL_CATEGORY_KEY, ignoreCase = true)
        }?.second?.trim()?.takeIf { it.isNotEmpty() }
        return buildList(normalized.size + 1) {
            add(ALL_CATEGORY_KEY to (providedAllLabel ?: "Todos"))
            addAll(normalized.values)
        }
    }

    private fun fallbackLabel(key: String): String = key
        .replace('-', ' ')
        .split(' ')
        .filter(String::isNotBlank)
        .joinToString(" ") { word ->
            word.replaceFirstChar { first ->
                if (first.isLowerCase()) first.titlecase(Locale.forLanguageTag("es-AR")) else first.toString()
            }
        }
}
