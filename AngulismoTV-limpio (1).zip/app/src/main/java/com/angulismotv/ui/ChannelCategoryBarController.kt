package com.angulismotv.ui

import android.content.Context
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.View
import android.widget.EditText
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.recyclerview.widget.RecyclerView
import com.angulismotv.R
import com.angulismotv.data.ChannelFilterEngine
import com.angulismotv.models.Channel

/**
 * Presentación e interacción de la barra de categorías/países de Canales.
 * El Fragment sigue siendo dueño del filtrado aplicado y del estado de búsqueda.
 */
class ChannelCategoryBarController(
    private val context: Context,
    private val container: LinearLayout,
    private val searchInput: EditText,
    private val channelsRecycler: RecyclerView,
    private val topFilterAnchor: View,
    private val inlinePlayerContainer: View,
    private val isTV: Boolean,
    private val getChannels: () -> List<Channel>,
    private val getCurrentCategory: () -> String,
    private val getCurrentCountry: () -> String,
    private val setCurrentCountry: (String) -> Unit,
    private val onCategorySelected: (String) -> Unit,
    private val onCountryChanged: () -> Unit,
    private val onFocusChannelList: () -> Unit,
    private val onCategoryFocusTargetChanged: (Int) -> Unit
) {
    private var countryFilterButton: TextView? = null
    private var countryFilterButtonId: Int = View.NO_ID
    private var selectedCategoryFocusViewId: Int = View.NO_ID
    private var availableCountryKeys: List<String> = emptyList()

    fun clear() {
        container.removeAllViews()
        countryFilterButton = null
        countryFilterButtonId = View.NO_ID
        selectedCategoryFocusViewId = View.NO_ID
        availableCountryKeys = emptyList()
    }

    fun render(
        preparedCategories: List<Pair<String, String>>? = null,
        preparedCountries: List<String>? = null
    ) {
        val categories = (preparedCategories ?: ChannelFilterEngine.availableCategories(getChannels()))
            .ifEmpty { listOf(ChannelFilterEngine.ALL_COUNTRIES to "Todos") }
        if (preparedCountries != null) availableCountryKeys = preparedCountries
        container.removeAllViews()
        container.addView(createCountryFilterChip())
        categories.forEachIndexed { index, (key, label) ->
            container.addView(createCategoryChip(index, key, label))
        }
        if (isTV) updateSelectedTvCategoryFocus()
    }

    private fun createCountryFilterChip(): TextView {
        val chip = LayoutInflater.from(context)
            .inflate(if (isTV) R.layout.item_category_tv else R.layout.item_category, container, false) as TextView
        chip.id = View.generateViewId()
        chip.tag = COUNTRY_FILTER_TAG
        countryFilterButton = chip
        countryFilterButtonId = chip.id
        updateCountryFilterLabel()
        chip.setOnClickListener { showCountryPicker() }
        if (isTV) {
            chip.nextFocusLeftId = inlinePlayerContainer.id
            setupTVFocusEffect(chip)
        }
        return chip
    }

    private fun createCategoryChip(index: Int, key: String, label: String): TextView {
        val chip = LayoutInflater.from(context)
            .inflate(if (isTV) R.layout.item_category_tv else R.layout.item_category, container, false) as TextView
        chip.text = label
        chip.tag = key
        chip.isSelected = key == getCurrentCategory()
        if (isTV) configureTvCategoryChip(chip, index)
        chip.setOnClickListener { onCategorySelected(key) }
        return chip
    }

    private fun configureTvCategoryChip(chip: TextView, index: Int) {
        chip.id = View.generateViewId()
        // The first category returns to country selection; later chips move across the bar.
        chip.nextFocusLeftId = if (index == 0) countryFilterButtonId else View.NO_ID
        chip.setOnKeyListener { _, keyCode, event ->
            if (event.action == KeyEvent.ACTION_DOWN && event.repeatCount == 0 &&
                keyCode == KeyEvent.KEYCODE_DPAD_DOWN
            ) {
                onFocusChannelList()
                true
            } else false
        }
        setupTVFocusEffect(chip)
    }

    private fun updateSelectedTvCategoryFocus() {
        val selectedChip = container.findViewWithTag<TextView>(getCurrentCategory())
            ?: container.getChildAt(1) as? TextView
        selectedCategoryFocusViewId = selectedChip?.id ?: View.NO_ID
        configureVerticalFocusLinks()
    }

    /** Actualiza el resaltado y los destinos de foco sin reconstruir la barra completa. */
    fun selectCategory(categoryKey: String) {
        for (index in 0 until container.childCount) {
            val chip = container.getChildAt(index) as? TextView ?: continue
            val isCountryChip = chip.tag == COUNTRY_FILTER_TAG
            val selected = if (isCountryChip) {
                getCurrentCountry() != ChannelFilterEngine.ALL_COUNTRIES
            } else {
                chip.tag == categoryKey
            }
            chip.isSelected = selected
            if (!isCountryChip && selected) {
                selectedCategoryFocusViewId = chip.id
                if (!isTV) centerChip(chip)
            }
        }
        if (isTV) configureVerticalFocusLinks()
    }

    /** En el celular, la categoría elegida se acerca al centro de la barra para ver las vecinas. */
    private fun centerChip(chip: View) {
        val scroller = container.parent as? HorizontalScrollView ?: return
        scroller.post {
            val target = chip.left - (scroller.width - chip.width) / 2
            scroller.smoothScrollTo(target.coerceAtLeast(0), 0)
        }
    }

    fun focusSelectedCategory() {
        if (!isTV) return
        val selected = container.findViewWithTag<TextView>(getCurrentCategory())
            ?: container.getChildAt(0) as? TextView
        selected?.requestFocus()
    }

    private fun configureVerticalFocusLinks() {
        // En Android TV la barra de categorías permanece oculta: las dos pestañas
        // (Canales/Favoritos) conectan directamente con la lista real de canales.
        val categoriesHost = container.parent as? View
        val categoriesVisible = categoriesHost?.visibility == View.VISIBLE &&
            selectedCategoryFocusViewId != View.NO_ID
        val listUpTarget = if (categoriesVisible) selectedCategoryFocusViewId else topFilterAnchor.id
        val tabDownTarget = if (categoriesVisible) selectedCategoryFocusViewId else R.id.channels_recycler

        searchInput.nextFocusDownId = tabDownTarget
        channelsRecycler.nextFocusUpId = listUpTarget
        topFilterAnchor.nextFocusDownId = tabDownTarget
        for (index in 0 until container.childCount) {
            val chip = container.getChildAt(index)
            chip.nextFocusUpId = topFilterAnchor.id
            chip.nextFocusDownId = R.id.channels_recycler
            chip.nextFocusLeftId = if (index == 0) inlinePlayerContainer.id else container.getChildAt(index - 1).id
        }
        onCategoryFocusTargetChanged(listUpTarget)
    }

    private fun showCountryPicker() {
        val countries = availableCountryKeys.ifEmpty { ChannelFilterEngine.availableCountries(getChannels()) }
        val keys = listOf(ChannelFilterEngine.ALL_COUNTRIES) + countries
        val labels = listOf("Todos los países") + countries.map(ChannelFilterEngine::countryLabel)
        AlertDialog.Builder(context)
            .setTitle("Filtrar por país")
            .setSingleChoiceItems(labels.toTypedArray(), keys.indexOf(getCurrentCountry()).coerceAtLeast(0)) { dialog, which ->
                setCurrentCountry(keys[which])
                updateCountryFilterLabel()
                dialog.dismiss()
                onCountryChanged()
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    private fun updateCountryFilterLabel() {
        val isFiltered = getCurrentCountry() != ChannelFilterEngine.ALL_COUNTRIES
        countryFilterButton?.apply {
            text = "País: " + if (isFiltered) {
                ChannelFilterEngine.countryLabel(getCurrentCountry())
            } else {
                "Todos"
            }
            isSelected = isFiltered
        }
    }

    private fun setupTVFocusEffect(chip: TextView) {
        chip.onFocusChangeListener = View.OnFocusChangeListener { _, hasFocus ->
            chip.animate().cancel()
            val targetScale = if (hasFocus) 1.035f else 1f
            chip.animate().scaleX(targetScale).scaleY(targetScale).setDuration(110L).start()
            // El color del texto lo resuelve category_chip_text_selector (foco / seleccionado / normal).
            if (hasFocus) {
                val scroller = container.parent as? HorizontalScrollView
                if (scroller != null) {
                    val leftEdge = scroller.scrollX
                    val rightEdge = leftEdge + scroller.width - scroller.paddingLeft - scroller.paddingRight
                    when {
                        chip.left < leftEdge -> scroller.smoothScrollTo(chip.left, 0)
                        chip.right > rightEdge -> scroller.smoothScrollTo(
                            chip.right - scroller.width + scroller.paddingRight,
                            0
                        )
                    }
                }
            }
        }
    }

    private companion object {
        const val COUNTRY_FILTER_TAG = "__country_filter__"
    }
}
