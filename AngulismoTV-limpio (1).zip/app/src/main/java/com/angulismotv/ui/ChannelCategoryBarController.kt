package com.angulismotv.ui

import android.content.Context
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.RecyclerView
import com.angulismotv.R
import com.angulismotv.data.ChannelFilterEngine
import com.angulismotv.models.Channel

/**
 * Presentación e interacción de la barra de categorías/países de Canales.
 * El Fragment sigue siendo dueño del filtrado aplicado y del estado de búsqueda.
 */
class ChannelCategoryBarController(
    private val context: Context,
    private val container: LinearLayout,
    private val searchInput: EditText,
    private val channelsRecycler: RecyclerView,
    private val inlinePlayerContainer: View,
    private val isTV: Boolean,
    private val getChannels: () -> List<Channel>,
    private val getCurrentCategory: () -> String,
    private val getCurrentCountry: () -> String,
    private val setCurrentCountry: (String) -> Unit,
    private val onCategorySelected: (String) -> Unit,
    private val onCountryChanged: () -> Unit,
    private val onFocusChannelList: () -> Unit,
    private val onCategoryFocusTargetChanged: (Int) -> Unit
) {
    private var countryFilterButton: TextView? = null
    private var countryFilterButtonId: Int = View.NO_ID
    private var selectedCategoryFocusViewId: Int = View.NO_ID

    fun clear() {
        container.removeAllViews()
        countryFilterButton = null
        countryFilterButtonId = View.NO_ID
        selectedCategoryFocusViewId = View.NO_ID
    }

    fun render() {
        val categories = ChannelFilterEngine.availableCategories(getChannels())
            .ifEmpty { listOf(ChannelFilterEngine.ALL_COUNTRIES to "Todos") }
        container.removeAllViews()
        container.addView(createCountryFilterChip())
        categories.forEachIndexed { index, (key, label) ->
            container.addView(createCategoryChip(index, key, label))
        }
        if (isTV) updateSelectedTvCategoryFocus()
    }

    private fun createCountryFilterChip(): TextView {
        val chip = LayoutInflater.from(context)
            .inflate(R.layout.item_category, container, false) as TextView
        chip.id = View.generateViewId()
        chip.tag = COUNTRY_FILTER_TAG
        countryFilterButton = chip
        countryFilterButtonId = chip.id
        updateCountryFilterLabel()
        chip.setOnClickListener { showCountryPicker() }
        if (isTV) {
            chip.layoutParams = chip.layoutParams.apply { height = dp(TV_CHIP_HEIGHT_DP) }
            chip.setPadding(dp(12), 0, dp(12), 0)
            chip.nextFocusLeftId = inlinePlayerContainer.id
            setupTVFocusEffect(chip)
        }
        return chip
    }

    private fun createCategoryChip(index: Int, key: String, label: String): TextView {
        val chip = LayoutInflater.from(context)
            .inflate(R.layout.item_category, container, false) as TextView
        chip.text = label
        chip.tag = key
        chip.isSelected = key == getCurrentCategory()
        if (isTV) configureTvCategoryChip(chip, index) else configureMobileCategoryChip(chip)
        updateChipStyle(chip, chip.isSelected)
        chip.setOnClickListener { onCategorySelected(key) }
        return chip
    }

    private fun configureTvCategoryChip(chip: TextView, index: Int) {
        chip.id = View.generateViewId()
        chip.layoutParams = chip.layoutParams.apply { height = dp(TV_CHIP_HEIGHT_DP) }
        chip.setPadding(dp(16), 0, dp(16), 0)
        chip.textSize = TV_CHIP_TEXT_SIZE_SP
        (chip.layoutParams as? ViewGroup.MarginLayoutParams)?.let { params ->
            params.marginEnd = dp(TV_CHIP_MARGIN_END_DP)
            chip.layoutParams = params
        }
        // The first category returns to country selection; later chips move across the bar.
        chip.nextFocusLeftId = if (index == 0) countryFilterButtonId else View.NO_ID
        chip.setOnKeyListener { _, keyCode, event ->
            if (event.action == KeyEvent.ACTION_DOWN && event.repeatCount == 0 &&
                keyCode == KeyEvent.KEYCODE_DPAD_DOWN
            ) {
                onFocusChannelList()
                true
            } else false
        }
        setupTVFocusEffect(chip)
    }

    private fun configureMobileCategoryChip(chip: TextView) {
        chip.setOnTouchListener { _, _ ->
            chip.isSelected = true
            false
        }
    }

    private fun updateSelectedTvCategoryFocus() {
        val selectedChip = container.findViewWithTag<TextView>(getCurrentCategory())
            ?: container.getChildAt(1) as? TextView
        selectedCategoryFocusViewId = selectedChip?.id ?: View.NO_ID
        configureVerticalFocusLinks()
    }

    /** Actualiza el resaltado y los destinos de foco sin reconstruir la barra completa. */
    fun selectCategory(categoryKey: String) {
        for (index in 0 until container.childCount) {
            val chip = container.getChildAt(index) as? TextView ?: continue
            val isCountryChip = chip.tag == COUNTRY_FILTER_TAG
            val selected = if (isCountryChip) {
                getCurrentCountry() != ChannelFilterEngine.ALL_COUNTRIES
            } else {
                chip.tag == categoryKey
            }
            chip.isSelected = selected
            updateChipStyle(chip, selected)
            if (!isCountryChip && selected) selectedCategoryFocusViewId = chip.id
        }
        if (isTV) configureVerticalFocusLinks()
    }

    fun focusSelectedCategory() {
        if (!isTV) return
        val selected = container.findViewWithTag<TextView>(getCurrentCategory())
            ?: container.getChildAt(0) as? TextView
        selected?.requestFocus()
    }

    private fun configureVerticalFocusLinks() {
        searchInput.nextFocusDownId = selectedCategoryFocusViewId
        channelsRecycler.nextFocusUpId = selectedCategoryFocusViewId
        for (index in 0 until container.childCount) {
            val chip = container.getChildAt(index)
            chip.nextFocusUpId = R.id.search_input
            chip.nextFocusDownId = R.id.channels_recycler
            chip.nextFocusLeftId = if (index == 0) inlinePlayerContainer.id else container.getChildAt(index - 1).id
        }
        onCategoryFocusTargetChanged(selectedCategoryFocusViewId)
    }

    private fun showCountryPicker() {
        val countries = ChannelFilterEngine.availableCountries(getChannels())
        val keys = listOf(ChannelFilterEngine.ALL_COUNTRIES) + countries
        val labels = listOf("Todos los países") + countries.map(ChannelFilterEngine::countryLabel)
        AlertDialog.Builder(context)
            .setTitle("Filtrar por país")
            .setSingleChoiceItems(labels.toTypedArray(), keys.indexOf(getCurrentCountry()).coerceAtLeast(0)) { dialog, which ->
                setCurrentCountry(keys[which])
                updateCountryFilterLabel()
                dialog.dismiss()
                onCountryChanged()
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    private fun updateCountryFilterLabel() {
        val isFiltered = getCurrentCountry() != ChannelFilterEngine.ALL_COUNTRIES
        countryFilterButton?.apply {
            text = "País: " + if (isFiltered) {
                ChannelFilterEngine.countryLabel(getCurrentCountry())
            } else {
                "Todos"
            }
            isSelected = isFiltered
            updateChipStyle(this, isFiltered)
        }
    }

    private fun updateChipStyle(chip: TextView, isSelected: Boolean) {
        if (isSelected) {
            chip.setBackgroundResource(R.drawable.bg_category_selected)
            chip.setTextColor(ContextCompat.getColor(context, R.color.text_primary))
        } else {
            chip.setBackgroundResource(R.drawable.bg_category_default)
            chip.setTextColor(ContextCompat.getColor(context, R.color.text_secondary))
        }
    }

    private fun setupTVFocusEffect(chip: TextView) {
        chip.onFocusChangeListener = View.OnFocusChangeListener { _, hasFocus ->
            chip.animate().cancel()
            chip.scaleX = 1f
            chip.scaleY = 1f
            if (hasFocus) {
                val scroller = container.parent as? HorizontalScrollView
                if (scroller != null) {
                    val leftEdge = scroller.scrollX
                    val rightEdge = leftEdge + scroller.width - scroller.paddingLeft - scroller.paddingRight
                    when {
                        chip.left < leftEdge -> scroller.smoothScrollTo(chip.left, 0)
                        chip.right > rightEdge -> scroller.smoothScrollTo(
                            chip.right - scroller.width + scroller.paddingRight,
                            0
                        )
                    }
                }
            }
        }
    }

    private fun dp(value: Int): Int = (value * context.resources.displayMetrics.density + 0.5f).toInt()

    private companion object {
        const val COUNTRY_FILTER_TAG = "__country_filter__"
        const val TV_CHIP_HEIGHT_DP = 38
        const val TV_CHIP_TEXT_SIZE_SP = 13f
        const val TV_CHIP_MARGIN_END_DP = 8
    }
}
