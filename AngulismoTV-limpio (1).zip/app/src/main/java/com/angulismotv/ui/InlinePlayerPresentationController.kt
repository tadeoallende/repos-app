package com.angulismotv.ui

import android.content.Context
import android.view.View
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.TextView
import com.angulismotv.R
import com.angulismotv.data.ChannelFilterEngine
import com.angulismotv.models.Channel
import com.angulismotv.utils.loadChannelLogo

/**
 * Owns the inline player's visible presentation after a channel is selected.
 * Playback creation, selected-channel state, and TV focus restoration remain in ChannelsFragment.
 */
internal class InlinePlayerPresentationController(
    private val contextProvider: () -> Context,
    private val isTV: () -> Boolean,
    private val inlinePlayerContainer: View,
    private val channelsSectionHeader: View,
    private val channelsSearchContainer: View,
    private val searchInput: EditText,
    private val channelsSectionSubtitle: TextView,
    private val inlineChannelName: TextView,
    private val inlineChannelLogo: ImageView,
    private val inlineBtnSources: ImageButton,
    private val inlineErrorText: View,
    private val inlinePlayerView: View,
    private val inlineWebView: View,
    private val tvPlayerEmptyState: View?,
    private val tvCurrentChannelInfo: View?,
    private val tvCurrentChannelLogo: ImageView?,
    private val tvCurrentChannelName: TextView?,
    private val tvCurrentChannelCategory: TextView?,
    private val tvPlayerGuide: TextView?,
    private val tvPlayerFooterHint: TextView?,
    private val filteredChannelCount: () -> Int,
    private val searchIsVisible: () -> Boolean,
    private val onMobileSearchHidden: () -> Unit,
    private val showControlsTemporarily: () -> Unit
) {
    fun showSelectedChannel(channel: Channel) {
        inlinePlayerContainer.visibility = View.VISIBLE
        if (!isTV()) {
            channelsSectionHeader.visibility = View.GONE
            channelsSearchContainer.visibility = View.GONE
            onMobileSearchHidden()
            searchInput.clearFocus()
            val inputMethodManager = contextProvider()
                .getSystemService(Context.INPUT_METHOD_SERVICE) as? InputMethodManager
            inputMethodManager?.hideSoftInputFromWindow(searchInput.windowToken, 0)
        } else {
            channelsSectionHeader.visibility = View.VISIBLE
            channelsSearchContainer.visibility = if (searchIsVisible()) View.VISIBLE else View.GONE
            updateTvPreviewIdentity(channel)
            channelsSectionSubtitle.text = contextProvider().getString(
                R.string.tv_channels_subtitle_count,
                filteredChannelCount()
            )
        }

        inlineChannelName.text = channel.name
        inlineChannelLogo.loadChannelLogo(channel.name, channel.logo)
        inlineBtnSources.visibility = if ((channel.options?.size ?: 0) > 1) View.VISIBLE else View.GONE
        inlineErrorText.visibility = View.GONE
        inlinePlayerView.visibility = View.GONE
        inlineWebView.visibility = View.GONE
        showControlsTemporarily()
    }

    fun updateTvPreviewIdentity(channel: Channel) {
        if (!isTV()) return
        tvPlayerEmptyState?.visibility = View.GONE
        tvCurrentChannelInfo?.visibility = View.VISIBLE
        tvCurrentChannelLogo?.loadChannelLogo(channel.name, channel.logo)
        tvCurrentChannelName?.text = channel.name
        tvCurrentChannelCategory?.text = channel.category?.takeIf { it.isNotBlank() }
            ?.let(ChannelFilterEngine::displayCategoryName)
            ?: contextProvider().getString(R.string.tv_live_category)
        tvPlayerGuide?.setText(R.string.tv_player_active_guide)
        tvPlayerFooterHint?.setText(R.string.tv_player_footer_hint)
    }
}
