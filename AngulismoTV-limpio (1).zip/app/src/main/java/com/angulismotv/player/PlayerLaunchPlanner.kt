package com.angulismotv.player

/** Claves de los extras con los que se abre la pantalla completa; las comparten quien lanza y quien lee. */
internal object PlayerLaunchExtras {
    const val CATALOG_TOKEN = "channel_catalog_token"
    const val CURRENT_CHANNEL = "current_channel"
    const val CHANNEL_INDEX = "channel_index"
    const val CHANNEL_NAME = "channel_name"
    const val CHANNEL_LOGO = "channel_logo"
    const val STREAM_URL = "stream_url"
    const val STREAM_TYPE = "stream_type"
    const val FROM_INLINE_PLAYER = "from_inline_player"
    const val FORCE_LANDSCAPE_FULLSCREEN = "force_landscape_fullscreen"
    const val SOURCE_INDEX = "source_index"
    const val REUSE_INLINE_PLAYER_SESSION = "reuse_inline_player_session"
    const val REUSE_INLINE_WEBVIEW_SESSION = "reuse_inline_webview_session"
    const val OPEN_CHANNEL_PANEL = "open_channel_panel"
    const val OPEN_CHANNEL_SEARCH = "open_channel_search"
    const val OPEN_CHANNEL_FAVORITES = "open_channel_favorites"

    /** Catálogo completo dentro del Intent: formato antiguo, solo se lee. */
    const val LEGACY_CHANNELS = "channels"
}

/** Qué reproducir al abrir el player, ya resuelto y con índices válidos. */
internal data class PlayerLaunchPlan<T>(
    val channels: List<T>,
    val channelIndex: Int,
    /** Fuente pedida si es válida para el canal; null significa "usar la primera fuente válida". */
    val sourceIndex: Int?,
    val openChannelPanel: Boolean,
    val openChannelSearch: Boolean
) {
    val selectedChannel: T? get() = channels.getOrNull(channelIndex)
}

/**
 * Decide qué catálogo, canal y fuente usar a partir de lo que llegó en el Intent.
 * No conoce Android ni el modelo de canal, así que se verifica en JVM.
 */
internal object PlayerLaunchPlanner {

    fun <T> plan(
        sharedCatalog: List<T>,
        legacyCatalog: List<T>?,
        singleChannel: T?,
        requestedIndex: Int,
        requestedSourceIndex: Int,
        sourceCountOf: (T) -> Int,
        openChannelPanel: Boolean,
        openChannelSearch: Boolean
    ): PlayerLaunchPlan<T> {
        val hasShared = sharedCatalog.isNotEmpty()
        val hasLegacy = !legacyCatalog.isNullOrEmpty()
        val channels = when {
            hasShared -> sharedCatalog
            hasLegacy -> legacyCatalog.orEmpty()
            singleChannel != null -> listOf(singleChannel)
            else -> emptyList()
        }
        // Si el proceso se recreó y el catálogo en memoria ya no existe, se conserva al menos el
        // canal pedido por el Intent en lugar de romper la apertura del player.
        val index = if (hasShared || hasLegacy) requestedIndex else 0
        // Un índice fuera de rango no debe mostrar "sin canales" si el catálogo tiene contenido.
        val channelIndex = if (channels.isNotEmpty()) index.coerceIn(0, channels.lastIndex) else index

        val sourceIndex = channels.getOrNull(channelIndex)?.let { channel ->
            requestedSourceIndex.takeIf { it in 0 until sourceCountOf(channel) }
        }
        return PlayerLaunchPlan(channels, channelIndex, sourceIndex, openChannelPanel, openChannelSearch)
    }
}
