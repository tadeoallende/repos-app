package com.angulismotv.player

/** Pure guard for the inline player's startup watchdog. */
object InlineStartupTimeoutPolicy {
    fun shouldFire(
        generationIsCurrent: Boolean,
        playerIsCurrent: Boolean,
        playbackFinished: Boolean
    ): Boolean = generationIsCurrent && playerIsCurrent && !playbackFinished
}
