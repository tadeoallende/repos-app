package com.angulismotv.player

/** Pure, bounded conversions used by the seek bar and its time labels. */
object PlayerTimelineMath {
    const val SEEK_SCALE = 1_000

    fun progressToPosition(progress: Int, durationMs: Long, scale: Int = SEEK_SCALE): Long {
        if (durationMs <= 0L || scale <= 0) return 0L
        val boundedProgress = progress.coerceIn(0, scale).toLong()
        val boundedScale = scale.toLong()
        // Split the multiplication so even very long media durations cannot overflow Long.
        return (durationMs / boundedScale) * boundedProgress +
            ((durationMs % boundedScale) * boundedProgress) / boundedScale
    }

    fun positionToProgress(positionMs: Long, durationMs: Long, scale: Int = SEEK_SCALE): Int {
        if (durationMs <= 0L || scale <= 0) return 0
        val boundedPosition = positionMs.coerceIn(0L, durationMs)
        return ((boundedPosition.toDouble() / durationMs.toDouble()) * scale)
            .toInt()
            .coerceIn(0, scale)
    }
}
