package com.angulismotv.player

import android.os.Handler
import com.google.android.exoplayer2.Player

/**
 * Owns the retry timer and playback watchdog independently from the player screen.
 * UI work and player replacement remain injected callbacks so this class is easy to test
 * and does not own an Activity, View, or ExoPlayer lifecycle.
 */
class PlaybackRecoveryController(
    private val handler: Handler,
    private val isGenerationCurrent: (Int) -> Boolean,
    private val isZapping: () -> Boolean,
    private val playerProvider: () -> Player?,
    private val streamProvider: () -> Pair<String, String>,
    private val networkAvailable: () -> Boolean,
    private val releasePlayer: () -> Unit,
    private val replayStream: (String, String) -> Unit,
    private val showError: (String) -> Unit,
    private val showLoading: () -> Unit
) {
    private var reconnectAttempts = 0
    private var watchdogRunnable: Runnable? = null
    private var reconnectRunnable: Runnable? = null
    private var lastKnownPosition = -1L
    private var frozenPositionCount = 0

    fun resetReconnectAttempts() {
        reconnectAttempts = 0
    }

    /** Reset retry state and cancel a retry scheduled for the previously selected channel. */
    fun reset(cancelPendingReconnect: Boolean = false) {
        reconnectAttempts = 0
        if (cancelPendingReconnect) cancelPendingReconnect()
    }

    fun cancelPendingReconnect() {
        reconnectRunnable?.let { runnable -> handler.removeCallbacks(runnable) }
        reconnectRunnable = null
    }

    fun startWatchdog(generation: Int) {
        stopWatchdog()
        val watchdogTask = object : Runnable {
            override fun run() {
                if (!isGenerationCurrent(generation) || isZapping()) return
                val player = playerProvider() ?: return

                if (player.playbackState == Player.STATE_BUFFERING) {
                    frozenPositionCount++
                    if (frozenPositionCount >= PlaybackRecoveryPolicy.BUFFERING_TICKS_BEFORE_RECONNECT) {
                        frozenPositionCount = 0
                        val (url, type) = streamProvider()
                        scheduleReconnect(url, type, generation)
                        return
                    }
                    handler.postDelayed(this, PlaybackRecoveryPolicy.WATCHDOG_INTERVAL_MS)
                    return
                }

                if (!player.isPlaying) {
                    handler.postDelayed(this, PlaybackRecoveryPolicy.WATCHDOG_INTERVAL_MS)
                    return
                }

                val position = player.currentPosition
                if (position == lastKnownPosition && lastKnownPosition >= 0) {
                    frozenPositionCount++
                    if (frozenPositionCount >= PlaybackRecoveryPolicy.FROZEN_TICKS_BEFORE_RECONNECT) {
                        frozenPositionCount = 0
                        lastKnownPosition = -1L
                        val (url, type) = streamProvider()
                        scheduleReconnect(url, type, generation)
                        return
                    }
                } else {
                    frozenPositionCount = 0
                    lastKnownPosition = position
                }
                handler.postDelayed(this, PlaybackRecoveryPolicy.WATCHDOG_INTERVAL_MS)
            }
        }
        watchdogRunnable = watchdogTask
        handler.postDelayed(watchdogTask, PlaybackRecoveryPolicy.WATCHDOG_INTERVAL_MS)
    }

    fun stopWatchdog() {
        watchdogRunnable?.let { runnable -> handler.removeCallbacks(runnable) }
        watchdogRunnable = null
        lastKnownPosition = -1L
        frozenPositionCount = 0
    }

    fun scheduleReconnect(url: String, type: String, generation: Int) {
        if (!isGenerationCurrent(generation) || isZapping()) return

        reconnectAttempts++
        if (reconnectAttempts > PlaybackRecoveryPolicy.MAX_RECONNECT_ATTEMPTS) {
            if (PlaybackRecoveryPolicy.retryBeyondLimit(type)) {
                reconnectAttempts = 1
            } else {
                showError("No se pudo reconectar después de varios intentos")
                reconnectAttempts = 0
                return
            }
        }

        val delay = PlaybackRecoveryPolicy.reconnectDelayMs(reconnectAttempts)
        showLoading()
        cancelPendingReconnect()
        val reconnectTask = Runnable {
            if (!isGenerationCurrent(generation) || isZapping()) return@Runnable
            if (!networkAvailable()) {
                scheduleReconnect(url, type, generation)
                return@Runnable
            }
            releasePlayer()
            replayStream(url, type)
        }
        reconnectRunnable = reconnectTask
        handler.postDelayed(reconnectTask, delay)
    }

    fun dispose() {
        stopWatchdog()
        cancelPendingReconnect()
    }

}
