package com.angulismotv.player

/** Preserves the user's play/pause choice across Fragment pause/hide callbacks. */
class InlinePlaybackResumeIntent {
    private var pendingIntent: Boolean? = null

    /** Capture only once: onPause and onHiddenChanged can describe the same transition. */
    fun capture(playWhenReady: Boolean) {
        if (pendingIntent == null) pendingIntent = playWhenReady
    }

    /** Returns the captured intent once; null means no lifecycle transition was captured. */
    fun consume(): Boolean? {
        val intent = pendingIntent
        pendingIntent = null
        return intent
    }

    fun clear() {
        pendingIntent = null
    }
}
