package com.angulismotv.player

/**
 * Scripts JavaScript que se inyectan en el WebView de los embeds (iframes).
 * Se mantienen acá, separados de la lógica de la pantalla del reproductor.
 */
object WebViewScripts {

    /** Nombre del objeto nativo Java -> JavaScript, registrado antes de navegar. */
    const val NATIVE_BRIDGE_NAME = "AngulismoTVNativeBridge"

    /** Nombre de la API JavaScript inyectada que controla el reproductor de la página. */
    const val PLAYER_API_NAME = "__angulismoTVPlayer"

    /** Consulta el estado actual del reproductor detectado dentro del embed. */
    const val GET_STATE =
        "window.__angulismoTVPlayer && window.__angulismoTVPlayer.getState ? window.__angulismoTVPlayer.getState() : null;"

    /** Detecta Bitmovin y reproductores basados en HTML5 dentro del documento WebView. */
    const val BRIDGE = """
        (function() {
            console.log('AngulismoTV WebView: iniciando detección de reproductores...');
            
            // Variable para guardar la instancia de Bitmovin
            var bitmovinPlayer = null;
            var html5Video = null;
            var lastHtml5Playing = null;
            if (window.__angulismoTVVideoMonitor) clearInterval(window.__angulismoTVVideoMonitor);
            if (window.__angulismoTVBitmovinMonitor) clearInterval(window.__angulismoTVBitmovinMonitor);
            window.__angulismoTVVideoMonitor = null;
            window.__angulismoTVBitmovinMonitor = null;
            // Re-evaluating the script (after a recovered page) must rebind the API
            // to this execution's player references instead of keeping stale closures.
            window.__angulismoTVPlayer = null;
            
            function isBitmovinApi(candidate) {
                return !!candidate &&
                    typeof candidate.play === 'function' &&
                    typeof candidate.pause === 'function' &&
                    typeof candidate.seek === 'function' &&
                    typeof candidate.getCurrentTime === 'function' &&
                    typeof candidate.getDuration === 'function' &&
                    typeof candidate.on === 'function';
            }

            // Función para detectar Bitmovin Player sin confundir otros objetos window.player.
            function detectBitmovinPlayer() {
                try {
                    // Buscar el contenedor del player
                    var playerContainer = document.getElementById('player');
                    if (!playerContainer) {
                        // Buscar cualquier elemento que pueda contener Bitmovin
                        var containers = document.querySelectorAll('[class*="bmpui"]');
                        if (containers.length > 0) {
                            playerContainer = containers[0];
                        }
                    }
                    
                    if (!playerContainer) return null;
                    
                    // Buscar la instancia de Bitmovin en el objeto window
                    // Bitmovin normalmente se guarda en window.player o window.bitmovin
                    if (isBitmovinApi(window.player)) {
                        bitmovinPlayer = window.player;
                        console.log('Bitmovin Player detectado en window.player');
                        return bitmovinPlayer;
                    }
                    
                    // Buscar en otras ubicaciones comunes
                    if (isBitmovinApi(window.bitmovin)) {
                        bitmovinPlayer = window.bitmovin;
                        console.log('Bitmovin Player detectado en window.bitmovin');
                        return bitmovinPlayer;
                    }
                    
                    // Intentar obtener la instancia desde el contenedor
                    if (isBitmovinApi(playerContainer.bitmovin)) {
                        bitmovinPlayer = playerContainer.bitmovin;
                        console.log('Bitmovin Player detectado en contenedor');
                        return bitmovinPlayer;
                    }
                    
                    return null;
                } catch(e) {
                    console.log('Error detectando Bitmovin:', e);
                    return null;
                }
            }
            
            // Fallback universal: HLS.js, Shaka, Clappr, Video.js y otros suelen
            // utilizar un HTMLVideoElement como motor real aunque dibujen controles propios.
            function detectHtml5Video() {
                try {
                    var videos = document.querySelectorAll('video');
                    var selected = null;
                    var bestScore = -1;
                    for (var i = 0; i < videos.length; i++) {
                        var video = videos[i];
                        if (!video || !document.documentElement.contains(video)) continue;
                        var hasSource = !!(video.currentSrc || video.src ||
                            video.querySelector('source[src]') || video.readyState > 0);
                        if (!hasSource) continue;
                        var rect = video.getBoundingClientRect();
                        var visible = rect.width >= 80 && rect.height >= 60;
                        var score = (visible ? 1000 : 0) +
                            (!video.paused && !video.ended ? 100 : 0) +
                            (video.readyState >= 2 ? 10 : 0);
                        if (score > bestScore) { selected = video; bestScore = score; }
                    }
                    return selected;
                } catch (e) {
                    console.log('AngulismoTV: error detectando video HTML5', e);
                    return null;
                }
            }

            function suppressProviderControls(video) {
                if (video) video.controls = false;
                if (!document.head || document.getElementById('angulismo-tv-provider-controls')) return;
                var style = document.createElement('style');
                style.id = 'angulismo-tv-provider-controls';
                // Se ocultan solo los controles de transporte duplicados. Los botones
                // de subtítulos, calidad y configuración del proveedor se conservan hasta
                // que exista un adaptador nativo para esas opciones.
                style.textContent = [
                    '.shaka-play-button, .shaka-seek-bar-container, .shaka-current-time, .shaka-duration',
                    '.media-control-button[data-media-control="play_pause"], .seekbar[data-seekbar]',
                    '.vjs-play-control, .vjs-progress-control, .vjs-current-time, .vjs-duration',
                    '.jw-icon-playback, .jw-slider-time, .jw-text-elapsed, .jw-text-duration',
                    '.plyr__controls [data-plyr="play"], .plyr__progress, .plyr__time',
                    '.bmpui-ui-playbacktogglebutton, .bmpui-ui-seekbar, .bmpui-ui-playbacktimelabel'
                ].join(',') + '{visibility:hidden!important;opacity:0!important;pointer-events:none!important}';
                document.head.appendChild(style);
            }

            function notifyHtml5State() {
                if (!html5Video) return;
                var playing = !html5Video.paused && !html5Video.ended;
                if (lastHtml5Playing !== playing) {
                    lastHtml5Playing = playing;
                    window.AngulismoTVNativeBridge?.onPlayStateChanged(playing);
                }
                var duration = Number(html5Video.duration);
                if (!isFinite(duration) || duration < 0) duration = 0;
                window.AngulismoTVNativeBridge?.onTimeUpdate(
                    Number(html5Video.currentTime) || 0,
                    duration
                );
            }

            function setupHtml5Monitoring(video) {
                if (!video) return;
                html5Video = video;
                lastHtml5Playing = null;
                suppressProviderControls(video);
                if (!video.__angulismoTVEventsBound) {
                    video.__angulismoTVEventsBound = true;
                    ['play', 'playing', 'pause', 'ended', 'timeupdate', 'durationchange',
                     'loadedmetadata', 'seeking', 'seeked', 'progress'].forEach(function(eventName) {
                        video.addEventListener(eventName, notifyHtml5State, { passive: true });
                    });
                }
                window.AngulismoTVNativeBridge?.onPlayerDetected(true);
                notifyHtml5State();
                window.AngulismoTVNativeBridge?.onDurationChanged(
                    isFinite(Number(video.duration)) ? Number(video.duration) : 0
                );
                if (!window.__angulismoTVVideoMonitor) {
                    window.__angulismoTVVideoMonitor = setInterval(function() {
                        var nextVideo = detectHtml5Video();
                        if (nextVideo && nextVideo !== html5Video) setupHtml5Monitoring(nextVideo);
                        if (!html5Video || !document.documentElement.contains(html5Video)) {
                            html5Video = null;
                            window.AngulismoTVNativeBridge?.onPlayerDetected(false);
                        } else {
                            notifyHtml5State();
                        }
                    }, 1000);
                }
            }

            // Función para esperar a que Bitmovin o un video HTML5 estén listos
            function waitForWebPlayer(callback, attempts) {
                attempts = attempts || 0;
                if (attempts > 30) {
                    console.log('No se detectó un reproductor web después de 30 intentos');
                    window.AngulismoTVNativeBridge?.onPlayerDetected(false);
                    return;
                }
                
                var player = detectBitmovinPlayer();
                if (player) {
                    console.log('Bitmovin Player encontrado!');
                    callback(player);
                    return;
                }
                var video = detectHtml5Video();
                if (video) {
                    console.log('Reproductor HTML5 detectado');
                    html5Video = video;
                    callback(null);
                    return;
                }
                
                console.log('Esperando reproductor web... intento ' + (attempts + 1));
                setTimeout(function() {
                    waitForWebPlayer(callback, attempts + 1);
                }, 500);
            }
            
            // API única consumida por el overlay nativo. Prioriza Bitmovin y utiliza
            // HTMLVideoElement como fallback para los reproductores web habituales.
            if (!window.__angulismoTVPlayer) {
                window.__angulismoTVPlayer = {
                    play: function() {
                        if (bitmovinPlayer && bitmovinPlayer.play) { bitmovinPlayer.play(); return true; }
                        if (html5Video) {
                            var result = html5Video.play();
                            if (result && result.catch) result.catch(function() {});
                            return true;
                        }
                        return false;
                    },
                    pause: function() {
                        if (bitmovinPlayer && bitmovinPlayer.pause) { bitmovinPlayer.pause(); return true; }
                        if (html5Video) { html5Video.pause(); return true; }
                        return false;
                    },
                    togglePlayPause: function() {
                        if (bitmovinPlayer) {
                            if (bitmovinPlayer.isPlaying && bitmovinPlayer.isPlaying()) bitmovinPlayer.pause();
                            else bitmovinPlayer.play();
                            return true;
                        }
                        if (html5Video) {
                            if (html5Video.paused || html5Video.ended) {
                                var result = html5Video.play();
                                if (result && result.catch) result.catch(function() {});
                            } else html5Video.pause();
                            return true;
                        }
                        return false;
                    },
                    seekTo: function(seconds) {
                        var target = Math.max(0, Number(seconds) || 0);
                        if (bitmovinPlayer && bitmovinPlayer.seek) { bitmovinPlayer.seek(target); return true; }
                        if (html5Video) {
                            var duration = Number(html5Video.duration);
                            if (isFinite(duration) && duration > 0) target = Math.min(target, duration);
                            try { html5Video.currentTime = target; return true; } catch (e) { return false; }
                        }
                        return false;
                    },
                    getCurrentTime: function() {
                        if (bitmovinPlayer && bitmovinPlayer.getCurrentTime) return bitmovinPlayer.getCurrentTime();
                        return html5Video ? (Number(html5Video.currentTime) || 0) : 0;
                    },
                    getDuration: function() {
                        if (bitmovinPlayer && bitmovinPlayer.getDuration) return bitmovinPlayer.getDuration();
                        if (html5Video) {
                            var duration = Number(html5Video.duration);
                            return isFinite(duration) && duration > 0 ? duration : 0;
                        }
                        return 0;
                    },
                    isPlaying: function() {
                        if (bitmovinPlayer && bitmovinPlayer.isPlaying) return bitmovinPlayer.isPlaying();
                        return !!(html5Video && !html5Video.paused && !html5Video.ended);
                    },
                    getState: function() {
                        try {
                            var detected = !!(bitmovinPlayer || html5Video);
                            return JSON.stringify({
                                playing: detected ? this.isPlaying() : false,
                                currentTime: detected ? this.getCurrentTime() : 0,
                                duration: detected ? this.getDuration() : 0,
                                detected: detected,
                                isBitmovin: !!bitmovinPlayer,
                                adapter: bitmovinPlayer ? 'bitmovin' : (html5Video ? 'html5' : null)
                            });
                        } catch(e) {
                            return JSON.stringify({ playing: false, currentTime: 0, duration: 0, detected: false, isBitmovin: false, adapter: null });
                        }
                    }
                };
                console.log('AngulismoTV WebView: API de control creada');
            }

            // Configurar monitoreo de eventos para Bitmovin
            function setupBitmovinMonitoring(player) {
                console.log('Configurando monitoreo de eventos Bitmovin');
                suppressProviderControls(null);
                
                // Evento cuando el player está listo
                player.on('ready', function() {
                    console.log('Bitmovin: Evento READY');
                    window.AngulismoTVNativeBridge?.onPlayerDetected(true);
                    // Enviar estado inicial
                    window.AngulismoTVNativeBridge?.onPlayStateChanged(player.isPlaying());
                    window.AngulismoTVNativeBridge?.onDurationChanged(player.getDuration());
                });
                
                // Evento de reproducción
                player.on('playing', function() {
                    console.log('Bitmovin: Evento PLAYING');
                    window.AngulismoTVNativeBridge?.onPlayStateChanged(true);
                });
                
                // Evento de pausa
                player.on('paused', function() {
                    console.log('Bitmovin: Evento PAUSED');
                    window.AngulismoTVNativeBridge?.onPlayStateChanged(false);
                });
                
                // Evento de fin
                player.on('finished', function() {
                    console.log('Bitmovin: Evento FINISHED');
                    window.AngulismoTVNativeBridge?.onPlayStateChanged(false);
                });
                
                // Evento de error
                player.on('error', function(error) {
                    console.log('Bitmovin: Evento ERROR', error);
                });
                
                // Monitoreo de tiempo (cada segundo)
                window.__angulismoTVBitmovinMonitor = setInterval(function() {
                    if (player && player.getCurrentTime) {
                        window.AngulismoTVNativeBridge?.onTimeUpdate(
                            player.getCurrentTime(),
                            player.getDuration() || 0
                        );
                    }
                }, 1000);
            }
            
            // Inicializar
            function initialize() {
                console.log('AngulismoTV WebView: inicializando detección de reproductores...');
                
                waitForWebPlayer(function(player) {
                    if (player) {
                        bitmovinPlayer = player;
                        setupBitmovinMonitoring(player);
                        window.AngulismoTVNativeBridge?.onPlayerDetected(true);
                        setTimeout(function() {
                            window.AngulismoTVNativeBridge?.onPlayStateChanged(player.isPlaying());
                            window.AngulismoTVNativeBridge?.onDurationChanged(player.getDuration());
                        }, 500);
                    } else if (html5Video) {
                        setupHtml5Monitoring(html5Video);
                    }
                });
            }
            
            // Ejecutar cuando la página esté lista
            if (document.readyState === 'complete') {
                initialize();
            } else {
                window.addEventListener('load', function() {
                    setTimeout(initialize, 1000);
                });
            }
            
            console.log('AngulismoTV WebView: inicialización Bitmovin completada');
        })();
"""

    /** CSS/JS para forzar el video a pantalla completa dentro del WebView. */
    const val FULLSCREEN = """(function(){
            var s=document.createElement('style');
            s.innerHTML='*{margin:0!important;padding:0!important;box-sizing:border-box!important}'
            +'html,body{width:100%!important;height:100%!important;background:#000!important;overflow:hidden!important}'
            +'body{display:flex!important;align-items:center!important;justify-content:center!important}'
            +'iframe,video,embed,object{position:fixed!important;top:0!important;left:0!important;'
            +'width:100vw!important;height:100vh!important;object-fit:contain!important}';
            document.head.appendChild(s);
            function fix(){document.querySelectorAll('iframe,video,embed').forEach(function(e){
            e.style.cssText+='position:fixed!important;top:0!important;left:0!important;'
            +'width:100%!important;height:100%!important;object-fit:contain!important'});}
            fix();new MutationObserver(fix).observe(document.body,{childList:true,subtree:true});
        })();"""
}
