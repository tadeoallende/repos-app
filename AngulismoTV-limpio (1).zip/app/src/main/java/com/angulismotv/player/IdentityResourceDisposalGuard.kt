package com.angulismotv.player

import java.util.IdentityHashMap

/** Prevents one owned Android resource from being disposed more than once per handoff transaction. */
internal class IdentityResourceDisposalGuard {
    private val disposed = IdentityHashMap<Any, Boolean>()

    /** Returns true only for the first claim of this exact instance (not merely an equal object). */
    fun claim(resource: Any): Boolean = disposed.put(resource, true) == null
}
