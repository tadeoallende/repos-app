package com.angulismotv.player

import android.net.Uri
import com.angulismotv.models.StreamType
import com.angulismotv.network.HttpClient
import com.google.android.exoplayer2.MediaItem
import com.google.android.exoplayer2.DefaultLoadControl
import com.google.android.exoplayer2.source.MediaSource
import com.google.android.exoplayer2.source.dash.DashMediaSource
import com.google.android.exoplayer2.source.hls.HlsMediaSource
import com.google.android.exoplayer2.source.ProgressiveMediaSource
import com.google.android.exoplayer2.ext.okhttp.OkHttpDataSource

/** Construye fuentes nativas de forma consistente para el mini reproductor y pantalla completa. */
object StreamMediaSourceFactory {

    enum class BufferProfile { INLINE, FULLSCREEN }

    /** Presets explícitos: la vista previa usa menos memoria que el reproductor principal. */
    fun createLoadControl(profile: BufferProfile): DefaultLoadControl {
        val durations = when (profile) {
            BufferProfile.INLINE -> intArrayOf(10_000, 45_000, 1_000, 3_000)
            BufferProfile.FULLSCREEN -> intArrayOf(15_000, 60_000, 1_500, 5_000)
        }
        return DefaultLoadControl.Builder()
            .setBufferDurationsMs(durations[0], durations[1], durations[2], durations[3])
            .build()
    }

    fun create(url: String, type: String): MediaSource {
        val uri = StreamUrlPolicy.parseHttpUrl(url)
            ?: throw IllegalArgumentException("La dirección de reproducción no es válida o no está admitida.")
        val dataSourceFactory = OkHttpDataSource.Factory(HttpClient.shared)
            .setUserAgent(HttpClient.USER_AGENT)
        val mediaItem = MediaItem.fromUri(uri)

        return when (type.lowercase()) {
            StreamType.DASH -> DashMediaSource.Factory(dataSourceFactory).createMediaSource(mediaItem)
            StreamType.MP4 -> ProgressiveMediaSource.Factory(dataSourceFactory).createMediaSource(mediaItem)
            StreamType.IFRAME -> throw IllegalArgumentException("Una fuente iframe no puede reproducirse con ExoPlayer.")
            StreamType.HLS, StreamType.AUTO -> HlsMediaSource.Factory(dataSourceFactory)
                .setAllowChunklessPreparation(true)
                .createMediaSource(mediaItem)
            else -> HlsMediaSource.Factory(dataSourceFactory)
                .setAllowChunklessPreparation(true)
                .createMediaSource(mediaItem)
        }
    }
}
