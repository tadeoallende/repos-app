package com.angulismotv.player

import android.view.KeyEvent

/**
 * Owns Android TV remote-key routing for the fullscreen player.
 * UI and playback effects stay injected so this controller never owns an Activity or a Player.
 */
class TvRemoteKeyController(
    private val stateProvider: () -> State,
    private val actions: Actions
) {
    data class State(
        val panelOpen: Boolean,
        val controlsVisible: Boolean,
        val hasPendingChannelNumber: Boolean,
        val rightPanelFocused: Boolean,
        val searchTriggerFocused: Boolean,
        val closePanelFocused: Boolean,
        val iframeActive: Boolean
    )

    interface Actions {
        fun appendChannelNumberDigit(digit: Int) {}
        fun commitChannelNumber() {}
        fun handleBackInPanel(): Boolean = false
        fun hideControls() {}
        fun finishPlayer() {}
        fun handlePanelVerticalFocus(keyCode: Int): Boolean = false
        fun navigateControlsUp() {}
        fun navigateControlsDown() {}
        fun navigateControlsLeft() {}
        fun navigateControlsRight() {}
        fun changeChannel(delta: Int) {}
        fun openSidePanel() {}
        fun moveFocusToCategoriesPanel() {}
        fun closeSidePanel() {}
        fun activateSearchMode() {}
        fun moveFocusToChannelsList() {}
        fun showControls() {}
        fun activateFocusedControl() {}
        fun controlIframe(command: String) {}
        fun togglePlayPause() {}
        fun playNative() {}
        fun pauseNative() {}
        fun fastForward() {}
        fun rewind() {}
    }

    /** Returns false only when the key must fall through to Android's normal dispatch. */
    fun handleKey(keyCode: Int): Boolean {
        val state = stateProvider()
        val digit = keyCodeToDigit(keyCode)
        if (!state.panelOpen && digit >= 0) {
            actions.appendChannelNumberDigit(digit)
            return true
        }

        return when (keyCode) {
            KeyEvent.KEYCODE_BACK -> when {
                state.panelOpen -> actions.handleBackInPanel()
                state.controlsVisible -> {
                    actions.hideControls()
                    true
                }
                else -> {
                    actions.finishPlayer()
                    true
                }
            }

            KeyEvent.KEYCODE_DPAD_UP -> when {
                state.panelOpen -> actions.handlePanelVerticalFocus(keyCode)
                state.controlsVisible -> {
                    actions.navigateControlsUp()
                    true
                }
                else -> {
                    actions.changeChannel(-1)
                    true
                }
            }

            KeyEvent.KEYCODE_DPAD_DOWN -> when {
                state.panelOpen -> actions.handlePanelVerticalFocus(keyCode)
                state.controlsVisible -> {
                    actions.navigateControlsDown()
                    true
                }
                else -> {
                    actions.changeChannel(1)
                    true
                }
            }

            KeyEvent.KEYCODE_DPAD_LEFT -> when {
                state.panelOpen -> {
                    if (state.rightPanelFocused) actions.moveFocusToCategoriesPanel()
                    else actions.closeSidePanel()
                    true
                }
                state.controlsVisible -> {
                    actions.navigateControlsLeft()
                    true
                }
                else -> {
                    actions.openSidePanel()
                    true
                }
            }

            KeyEvent.KEYCODE_DPAD_RIGHT -> when {
                state.panelOpen -> {
                    when {
                        state.searchTriggerFocused -> actions.activateSearchMode()
                        state.closePanelFocused -> actions.closeSidePanel()
                        !state.rightPanelFocused -> actions.moveFocusToChannelsList()
                        else -> actions.closeSidePanel()
                    }
                    true
                }
                state.controlsVisible -> {
                    actions.navigateControlsRight()
                    true
                }
                else -> {
                    actions.showControls()
                    true
                }
            }

            KeyEvent.KEYCODE_DPAD_CENTER,
            KeyEvent.KEYCODE_ENTER,
            KeyEvent.KEYCODE_NUMPAD_ENTER -> when {
                state.hasPendingChannelNumber && !state.panelOpen -> {
                    actions.commitChannelNumber()
                    true
                }
                state.panelOpen -> false
                !state.controlsVisible -> {
                    actions.showControls()
                    true
                }
                else -> {
                    actions.activateFocusedControl()
                    true
                }
            }

            KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE -> {
                if (state.iframeActive) actions.controlIframe("toggle") else actions.togglePlayPause()
                true
            }

            KeyEvent.KEYCODE_MEDIA_PLAY -> {
                if (state.iframeActive) actions.controlIframe("play") else actions.playNative()
                true
            }

            KeyEvent.KEYCODE_MEDIA_PAUSE -> {
                if (state.iframeActive) actions.controlIframe("pause") else actions.pauseNative()
                true
            }

            KeyEvent.KEYCODE_MEDIA_FAST_FORWARD -> {
                actions.fastForward()
                true
            }

            KeyEvent.KEYCODE_MEDIA_REWIND -> {
                actions.rewind()
                true
            }

            else -> false
        }
    }

    private fun keyCodeToDigit(keyCode: Int): Int = when {
        keyCode in KeyEvent.KEYCODE_0..KeyEvent.KEYCODE_9 -> keyCode - KeyEvent.KEYCODE_0
        keyCode in KeyEvent.KEYCODE_NUMPAD_0..KeyEvent.KEYCODE_NUMPAD_9 -> keyCode - KeyEvent.KEYCODE_NUMPAD_0
        else -> -1
    }

    companion object {
        fun isDigitKey(keyCode: Int): Boolean = when {
            keyCode in KeyEvent.KEYCODE_0..KeyEvent.KEYCODE_9 -> true
            keyCode in KeyEvent.KEYCODE_NUMPAD_0..KeyEvent.KEYCODE_NUMPAD_9 -> true
            else -> false
        }
    }
}
