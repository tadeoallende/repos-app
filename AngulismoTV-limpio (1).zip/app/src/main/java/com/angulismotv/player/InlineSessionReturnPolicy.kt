package com.angulismotv.player

/** Pure decisions used when returning a fullscreen playback session to its inline owner. */
object InlineSessionReturnPolicy {
    data class StreamMetadata(
        val url: String,
        val type: String,
        val sourceIndex: Int
    )

    fun shouldAttemptUnclaimedRecovery(fromInlinePlayer: Boolean, alreadyReturned: Boolean): Boolean =
        fromInlinePlayer && !alreadyReturned

    /** Keep the original inline source when fullscreen exits before selecting/loading a source. */
    fun resolveStreamMetadata(
        currentUrl: String,
        currentType: String,
        currentSourceIndex: Int,
        originUrl: String?,
        originType: String?,
        originSourceIndex: Int?
    ): StreamMetadata {
        if (currentUrl.isNotBlank()) {
            return StreamMetadata(currentUrl, currentType, currentSourceIndex.coerceAtLeast(0))
        }
        return StreamMetadata(
            url = originUrl.orEmpty(),
            type = originType?.takeIf { it.isNotBlank() } ?: currentType,
            sourceIndex = (originSourceIndex ?: currentSourceIndex).coerceAtLeast(0)
        )
    }
}
