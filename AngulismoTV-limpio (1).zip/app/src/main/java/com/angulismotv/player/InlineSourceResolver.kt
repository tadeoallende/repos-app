package com.angulismotv.player

import com.angulismotv.models.Channel
import com.angulismotv.models.StreamType

/** Pure resolution of the selected source for the inline player. Does not mutate playback state. */
object InlineSourceResolver {
    enum class FailureReason {
        INVALID_SOURCE_INDEX,
        EMPTY_URL
    }

    sealed class Result {
        data class Resolved(
            val url: String,
            val type: String
        ) : Result()

        data class Unavailable(val reason: FailureReason) : Result()
    }

    /**
     * When a channel has alternate options, the selected option is authoritative: an invalid
     * index is rejected instead of silently falling back to the channel's primary URL. This keeps
     * reload and source-picker behavior consistent.
     */
    fun resolve(channel: Channel, sourceIndex: Int): Result {
        val options = channel.options.orEmpty()
        val url: String
        val type: String

        if (options.isNotEmpty()) {
            if (sourceIndex !in options.indices) {
                return Result.Unavailable(FailureReason.INVALID_SOURCE_INDEX)
            }
            val option = options[sourceIndex]
            url = option.iframe
            type = StreamUtils.resolveType(url, option.streamType)
        } else {
            url = channel.streamUrl.orEmpty()
            type = StreamUtils.resolveType(url, channel.streamType ?: StreamType.AUTO)
        }

        if (url.isBlank()) return Result.Unavailable(FailureReason.EMPTY_URL)
        return Result.Resolved(url = url, type = type)
    }
}
