package com.angulismotv.player

import com.angulismotv.models.Channel
import com.angulismotv.models.StreamType

/**
 * Main-thread state for the inline playback session. It is deliberately UI/engine agnostic:
 * it tracks identity, selected source and callback generations, not Android views or players.
 */
class InlinePlaybackSessionState {
    var channel: Channel? = null
        private set
    var sourceIndex: Int = 0
        private set
    var streamUrl: String = ""
        private set
    var streamType: String = StreamType.AUTO
        private set
    var generation: Int = 0
        private set
    private var sourceFailed: Boolean = false

    /** Starts a different channel and invalidates all callbacks from the prior channel/source. */
    fun beginChannel(channel: Channel): Int {
        generation++
        this.channel = channel
        sourceIndex = 0
        clearResolvedSource()
        sourceFailed = false
        return generation
    }

    /** Begins a source load/reload while preserving channel identity. */
    fun beginSourceSelection(sourceIndex: Int): Int {
        generation++
        this.sourceIndex = sourceIndex
        clearResolvedSource()
        sourceFailed = false
        return generation
    }

    /** Stores the actual resolved source. Empty URLs never become the active stream. */
    fun setResolvedSource(url: String, type: String): Boolean {
        if (url.isBlank()) {
            clearResolvedSource()
            return false
        }
        streamUrl = url
        streamType = type.ifBlank { StreamType.AUTO }
        sourceFailed = false
        return true
    }

    /** Restores session metadata before reattaching a player or WebView from fullscreen. */
    fun restore(channel: Channel, sourceIndex: Int, url: String, type: String): Int {
        generation++
        this.channel = channel
        this.sourceIndex = sourceIndex.coerceAtLeast(0)
        clearResolvedSource()
        sourceFailed = false
        setResolvedSource(url, type)
        return generation
    }

    /** Invalidates pending callbacks without changing the visible/selected channel metadata. */
    fun advanceGeneration(): Int {
        generation++
        return generation
    }

    /** Closes the preview and removes all source/channel state. */
    fun clear(): Int {
        generation++
        channel = null
        sourceIndex = 0
        clearResolvedSource()
        sourceFailed = false
        return generation
    }

    fun isCurrent(candidateGeneration: Int): Boolean = candidateGeneration == generation

    /** Marks only the currently active attempt as failed and invalidates its remaining callbacks. */
    fun failSource(candidateGeneration: Int): Boolean {
        if (!isCurrent(candidateGeneration)) return false
        sourceFailed = true
        generation++
        return true
    }

    fun canCast(): Boolean =
        !sourceFailed && channel != null && streamUrl.isNotBlank() && streamType != StreamType.IFRAME

    private fun clearResolvedSource() {
        streamUrl = ""
        streamType = StreamType.AUTO
    }
}
