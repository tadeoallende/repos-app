package com.angulismotv.player

/** Delivers at most one terminal outcome for a WebView load generation. */
class WebViewLoadEventGate {
    private var activeGeneration = INVALID_GENERATION
    private var terminalGeneration = INVALID_GENERATION

    fun begin(generation: Int) {
        activeGeneration = generation
        terminalGeneration = INVALID_GENERATION
    }

    fun shouldDeliverPageLoaded(generation: Int, isGenerationCurrent: Boolean): Boolean {
        if (!isGenerationCurrent || generation != activeGeneration || terminalGeneration == generation) {
            return false
        }
        terminalGeneration = generation
        return true
    }

    fun shouldDeliverFailure(generation: Int, isGenerationCurrent: Boolean): Boolean {
        if (!isGenerationCurrent || generation != activeGeneration || terminalGeneration == generation) {
            return false
        }
        terminalGeneration = generation
        return true
    }

    private companion object {
        const val INVALID_GENERATION = -1
    }
}
