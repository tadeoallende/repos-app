package com.angulismotv.player

import android.os.Handler
import android.util.Log
import android.webkit.JavascriptInterface
import android.webkit.WebView
import org.json.JSONObject
import org.json.JSONTokener

/**
 * Puente entre la app y el reproductor que vive dentro de un iframe (WebView).
 *
 * Mantiene el estado reportado por la página (reproduciendo, tiempo, duración) y permite
 * controlarla desde los botones nativos, que es lo que se necesita con el control remoto de TV.
 * Todos los callbacks y [onStateChanged] se ejecutan en el hilo principal.
 */
class WebViewPlayerBridge(
    private val webView: WebView,
    private val handler: Handler,
    private val isIframeActive: () -> Boolean,
    private val onStateChanged: () -> Unit
) {

    var isPlaying = false
        private set
    var currentTime = 0L
        private set
    var duration = 0L
        private set
    var isControllable = false
        private set
    var playerDetected = false
        private set

    private var monitorRunnable: Runnable? = null

    // ---------- Ciclo de vida ----------

    /** Limpia el estado (al cargar un embed nuevo). */
    fun reset() {
        isControllable = false
        playerDetected = false
        isPlaying = false
        currentTime = 0L
        duration = 0L
    }

    /** Expone el receptor de eventos JS → app. Visible para la página en la próxima carga. */
    fun attach() {
        webView.addJavascriptInterface(JsReceiver(), WebViewScripts.BRIDGE_NAME)
    }

    fun detach() {
        webView.removeJavascriptInterface(WebViewScripts.BRIDGE_NAME)
    }

    /** Inyecta el script que detecta y controla el reproductor de la página. */
    fun injectScript() {
        webView.evaluateJavascript(WebViewScripts.BRIDGE, null)
    }

    // ---------- Detección ----------

    /** Intenta detectar el reproductor tras cargar la página (reintenta una vez). */
    fun detectAfterLoad() {
        handler.postDelayed({ queryInitialState(attempt = 1) }, DETECTION_DELAY_MS)
    }

    private fun queryInitialState(attempt: Int) {
        webView.evaluateJavascript(WebViewScripts.GET_STATE) { value ->
            val json = parseState(value)
            if (json != null) {
                playerDetected = json.optBoolean("detected", false)
                isControllable = playerDetected
                applyState(json)
                Log.d(TAG, "Estado detectado - detected: $playerDetected, playing: $isPlaying")
                onStateChanged()
                if (playerDetected) startMonitor()
            } else if (attempt < MAX_DETECTION_ATTEMPTS) {
                handler.postDelayed({ queryInitialState(attempt + 1) }, DETECTION_DELAY_MS)
            } else {
                Log.w(TAG, "No se detectó reproductor controlable")
                isControllable = false
                onStateChanged()
            }
        }
    }

    // ---------- Control ----------

    /** Acciones soportadas: play, pause, toggle, seek (param = segundos). */
    fun control(action: String, param: Double? = null) {
        if (!isControllable) return

        val safeSeek = param?.takeIf { it.isFinite() && it >= 0.0 } ?: 0.0
        val js = when (action) {
            "play" -> "AndroidWebViewBridge.play();"
            "pause" -> "AndroidWebViewBridge.pause();"
            "toggle" -> "AndroidWebViewBridge.togglePlayPause();"
            "seek" -> "AndroidWebViewBridge.seekTo($safeSeek);"
            else -> return
        }
        webView.evaluateJavascript(js, null)

        // Feedback inmediato en la UI, sin esperar al próximo ciclo del monitor
        if (action == "toggle") {
            isPlaying = !isPlaying
            onStateChanged()
        }
    }

    // ---------- Monitoreo periódico ----------

    fun startMonitor() {
        stopMonitor()
        val runnable = object : Runnable {
            override fun run() {
                if (isIframeActive() && isControllable) pollState()
                handler.postDelayed(this, MONITOR_INTERVAL_MS)
            }
        }
        monitorRunnable = runnable
        handler.postDelayed(runnable, MONITOR_INTERVAL_MS)
    }

    fun stopMonitor() {
        monitorRunnable?.let { handler.removeCallbacks(it) }
        monitorRunnable = null
    }

    private fun pollState() {
        webView.evaluateJavascript(WebViewScripts.GET_STATE) { value ->
            val json = parseState(value)
            if (json == null) {
                // El script se perdió (p. ej. la página recargó): se vuelve a inyectar
                if (isControllable) injectScript()
                return@evaluateJavascript
            }
            val wasPlaying = isPlaying
            applyState(json)
            if (wasPlaying != isPlaying) onStateChanged()

            if (!json.optBoolean("detected", true) && isControllable) {
                Log.w(TAG, "Pérdida de detección, reintentando...")
                injectScript()
            }
        }
    }

    // ---------- Helpers ----------

    private fun applyState(json: JSONObject) {
        isPlaying = json.optBoolean("playing", false)
        duration = safeSeconds(json.optDouble("duration", 0.0))
        currentTime = safeSeconds(json.optDouble("currentTime", 0.0))
            .let { if (duration > 0) it.coerceAtMost(duration) else it }
    }

    private fun safeSeconds(value: Double): Long = when {
        !value.isFinite() || value <= 0.0 -> 0L
        value >= Long.MAX_VALUE.toDouble() -> Long.MAX_VALUE
        else -> value.toLong()
    }

    /**
     * evaluateJavascript devuelve el resultado como JSON; si el script retornó un string
     * (JSON.stringify), llega entre comillas y escapado, así que hay que decodificarlo dos veces.
     */
    private fun parseState(value: String?): JSONObject? {
        if (value.isNullOrEmpty() || value == "null") return null
        return try {
            when (val parsed = JSONTokener(value).nextValue()) {
                is JSONObject -> parsed
                is String -> JSONObject(parsed)
                else -> null
            }
        } catch (e: Exception) {
            Log.w(TAG, "Error parseando estado: ${e.message}")
            null
        }
    }

    /** Métodos que la página invoca desde JavaScript (llegan en un hilo del WebView). */
    private inner class JsReceiver {

        @JavascriptInterface
        fun onPlayerDetected(detected: Boolean) {
            handler.post {
                playerDetected = detected
                isControllable = detected
                if (detected) {
                    webView.evaluateJavascript(WebViewScripts.GET_STATE) { value ->
                        parseState(value)?.let { applyState(it) }
                        onStateChanged()
                    }
                } else {
                    Log.d(TAG, "No se detectó reproductor en el iframe")
                    onStateChanged()
                }
            }
        }

        @JavascriptInterface
        fun onPlayStateChanged(isPlaying: Boolean) {
            handler.post {
                this@WebViewPlayerBridge.isPlaying = isPlaying
                onStateChanged()
            }
        }

        @JavascriptInterface
        fun onTimeUpdate(currentTime: Double, duration: Double) {
            handler.post {
                val safeDuration = safeSeconds(duration)
                this@WebViewPlayerBridge.duration = safeDuration
                this@WebViewPlayerBridge.currentTime = safeSeconds(currentTime)
                    .let { if (safeDuration > 0) it.coerceAtMost(safeDuration) else it }
            }
        }

        @JavascriptInterface
        fun onDurationChanged(duration: Double) {
            handler.post {
                this@WebViewPlayerBridge.duration = safeSeconds(duration)
                if (this@WebViewPlayerBridge.duration > 0) {
                    this@WebViewPlayerBridge.currentTime = this@WebViewPlayerBridge.currentTime
                        .coerceAtMost(this@WebViewPlayerBridge.duration)
                }
                onStateChanged()
            }
        }
    }

    private companion object {
        const val TAG = "WebViewBridge"
        const val DETECTION_DELAY_MS = 3_000L
        const val MAX_DETECTION_ATTEMPTS = 2
        const val MONITOR_INTERVAL_MS = 2_000L
    }
}
