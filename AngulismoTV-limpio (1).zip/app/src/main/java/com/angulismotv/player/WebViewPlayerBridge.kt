package com.angulismotv.player

import android.os.Handler
import android.util.Log
import android.webkit.JavascriptInterface
import android.webkit.WebView
import org.json.JSONObject
import org.json.JSONTokener

/**
 * Puente entre la app y el reproductor que vive dentro de un iframe (WebView).
 *
 * Mantiene el estado reportado por la página (reproduciendo, tiempo, duración) y permite
 * controlarla desde los botones nativos, que es lo que se necesita con el control remoto de TV.
 * Los callbacks de estado y línea de tiempo se ejecutan en el hilo principal.
 */
class WebViewPlayerBridge(
    private val webView: WebView,
    private val handler: Handler,
    private val isIframeActive: () -> Boolean,
    private val onStateChanged: () -> Unit,
    private val onTimelineChanged: () -> Unit = {}
) {

    var isPlaying = false
        private set
    var currentTime = 0L
        private set
    var duration = 0L
        private set
    var isControllable = false
        private set
    var playerDetected = false
        private set

    private var monitorRunnable: Runnable? = null
    private var detectionRunnable: Runnable? = null
    private var attachmentGeneration = 0
    private var detectionGeneration = 0
    private var attached = false

    // ---------- Ciclo de vida ----------

    /** Limpia el estado (al cargar un embed nuevo). */
    fun reset() {
        cancelDetection()
        stopMonitor()
        isControllable = false
        playerDetected = false
        isPlaying = false
        currentTime = 0L
        duration = 0L
    }

    /** Expone el receptor de eventos JS → app. Visible para la página en la próxima carga. */
    fun attach() {
        cancelDetection()
        stopMonitor()
        attachmentGeneration++
        attached = true
        webView.addJavascriptInterface(JsReceiver(attachmentGeneration), WebViewScripts.NATIVE_BRIDGE_NAME)
    }

    fun detach() {
        attached = false
        attachmentGeneration++ // invalida también los callbacks JS que ya estaban encolados
        cancelDetection()
        stopMonitor()
        webView.removeJavascriptInterface(WebViewScripts.NATIVE_BRIDGE_NAME)
    }

    /** Inyecta el script que detecta y controla el reproductor de la página. */
    fun injectScript() {
        if (!attached) return
        webView.evaluateJavascript(WebViewScripts.BRIDGE, null)
    }

    // ---------- Detección ----------

    /** Intenta detectar el reproductor tras cargar la página (reintenta una vez). */
    fun detectAfterLoad() {
        cancelDetection()
        if (!attached) return
        val expectedAttachment = attachmentGeneration
        val expectedDetection = detectionGeneration
        scheduleDetection(attempt = 1, expectedAttachment, expectedDetection)
    }

    private fun scheduleDetection(attempt: Int, expectedAttachment: Int, expectedDetection: Int) {
        if (!isCurrent(expectedAttachment, expectedDetection)) return
        detectionRunnable?.let(handler::removeCallbacks)
        val runnable = object : Runnable {
            override fun run() {
                if (detectionRunnable === this) detectionRunnable = null
                queryInitialState(attempt, expectedAttachment, expectedDetection)
            }
        }
        detectionRunnable = runnable
        handler.postDelayed(runnable, DETECTION_DELAY_MS)
    }

    private fun queryInitialState(attempt: Int, expectedAttachment: Int, expectedDetection: Int) {
        if (!isCurrent(expectedAttachment, expectedDetection)) return
        webView.evaluateJavascript(WebViewScripts.GET_STATE) { value ->
            if (!isCurrent(expectedAttachment, expectedDetection)) return@evaluateJavascript
            val json = parseState(value)
            if (json != null) {
                playerDetected = json.optBoolean("detected", false)
                isControllable = playerDetected
                applyState(json)
                Log.d(TAG, "Estado detectado - detected: $playerDetected, playing: $isPlaying")
                onStateChanged()
                if (playerDetected) startMonitor() else stopMonitor()
            } else if (attempt < MAX_DETECTION_ATTEMPTS) {
                scheduleDetection(attempt + 1, expectedAttachment, expectedDetection)
            } else {
                Log.w(TAG, "No se detectó reproductor controlable")
                isControllable = false
                onStateChanged()
            }
        }
    }

    private fun isCurrent(expectedAttachment: Int, expectedDetection: Int): Boolean =
        attached && expectedAttachment == attachmentGeneration && expectedDetection == detectionGeneration

    private fun cancelDetection() {
        detectionGeneration++
        detectionRunnable?.let(handler::removeCallbacks)
        detectionRunnable = null
    }

    // ---------- Control ----------

    /** Acciones soportadas: play, pause, toggle, seek (param = segundos). */
    fun control(action: String, param: Double? = null) {
        if (!isControllable) return

        val safeSeek = param?.takeIf { it.isFinite() && it >= 0.0 } ?: 0.0
        val playerApi = WebViewScripts.PLAYER_API_NAME
        val js = when (action) {
            "play" -> "window.$playerApi.play();"
            "pause" -> "window.$playerApi.pause();"
            "toggle" -> "window.$playerApi.togglePlayPause();"
            "seek" -> "window.$playerApi.seekTo($safeSeek);"
            else -> return
        }
        webView.evaluateJavascript(js, null)

        // Feedback inmediato en la UI, sin esperar al próximo ciclo del monitor
        if (action == "toggle") {
            isPlaying = !isPlaying
            onStateChanged()
        }
    }

    // ---------- Monitoreo periódico ----------

    fun startMonitor() {
        stopMonitor()
        if (!attached) return
        val expectedAttachment = attachmentGeneration
        val runnable = object : Runnable {
            override fun run() {
                if (monitorRunnable !== this || !isCurrentAttachment(expectedAttachment)) return
                if (isIframeActive() && isControllable) pollState(expectedAttachment)
                if (monitorRunnable === this && isCurrentAttachment(expectedAttachment)) {
                    handler.postDelayed(this, MONITOR_INTERVAL_MS)
                }
            }
        }
        monitorRunnable = runnable
        handler.postDelayed(runnable, MONITOR_INTERVAL_MS)
    }

    fun stopMonitor() {
        monitorRunnable?.let { handler.removeCallbacks(it) }
        monitorRunnable = null
    }

    private fun pollState(expectedAttachment: Int) {
        if (!isCurrentAttachment(expectedAttachment)) return
        webView.evaluateJavascript(WebViewScripts.GET_STATE) { value ->
            if (!isCurrentAttachment(expectedAttachment)) return@evaluateJavascript
            val json = parseState(value)
            if (json == null) {
                // El script se perdió (p. ej. la página recargó): se vuelve a inyectar
                if (isControllable) injectScript()
                return@evaluateJavascript
            }
            val wasPlaying = isPlaying
            applyState(json)
            if (wasPlaying != isPlaying) onStateChanged()

            if (!json.optBoolean("detected", true) && isControllable) {
                Log.w(TAG, "Pérdida de detección, reintentando...")
                injectScript()
            }
        }
    }

    private fun isCurrentAttachment(expectedAttachment: Int): Boolean =
        attached && expectedAttachment == attachmentGeneration

    // ---------- Helpers ----------

    private fun applyState(json: JSONObject) {
        isPlaying = json.optBoolean("playing", false)
        duration = safeSeconds(json.optDouble("duration", 0.0))
        currentTime = safeSeconds(json.optDouble("currentTime", 0.0))
            .let { if (duration > 0) it.coerceAtMost(duration) else it }
    }

    private fun safeSeconds(value: Double): Long = when {
        !value.isFinite() || value <= 0.0 -> 0L
        value >= Long.MAX_VALUE.toDouble() -> Long.MAX_VALUE
        else -> value.toLong()
    }

    /**
     * evaluateJavascript devuelve el resultado como JSON; si el script retornó un string
     * (JSON.stringify), llega entre comillas y escapado, así que hay que decodificarlo dos veces.
     */
    private fun parseState(value: String?): JSONObject? {
        if (value.isNullOrEmpty() || value == "null") return null
        return try {
            when (val parsed = JSONTokener(value).nextValue()) {
                is JSONObject -> parsed
                is String -> JSONObject(parsed)
                else -> null
            }
        } catch (e: Exception) {
            Log.w(TAG, "Error parseando estado: ${e.message}")
            null
        }
    }

    /** Métodos que la página invoca desde JavaScript (llegan en un hilo del WebView). */
    private inner class JsReceiver(private val receiverGeneration: Int) {

        @JavascriptInterface
        fun onPlayerDetected(detected: Boolean) {
            handler.post {
                if (!isCurrentAttachment(receiverGeneration)) return@post
                playerDetected = detected
                isControllable = detected
                if (detected) {
                    webView.evaluateJavascript(WebViewScripts.GET_STATE) { value ->
                        if (!isCurrentAttachment(receiverGeneration)) return@evaluateJavascript
                        parseState(value)?.let { applyState(it) }
                        onStateChanged()
                    }
                } else {
                    stopMonitor()
                    Log.d(TAG, "No se detectó reproductor en el iframe")
                    onStateChanged()
                }
            }
        }

        @JavascriptInterface
        fun onPlayStateChanged(isPlaying: Boolean) {
            handler.post {
                if (!isCurrentAttachment(receiverGeneration)) return@post
                this@WebViewPlayerBridge.isPlaying = isPlaying
                onStateChanged()
            }
        }

        @JavascriptInterface
        fun onTimeUpdate(currentTime: Double, duration: Double) {
            handler.post {
                if (!isCurrentAttachment(receiverGeneration)) return@post
                val safeDuration = safeSeconds(duration)
                val safeCurrent = safeSeconds(currentTime)
                    .let { if (safeDuration > 0) it.coerceAtMost(safeDuration) else it }
                val durationChanged = this@WebViewPlayerBridge.duration != safeDuration
                val timeChanged = this@WebViewPlayerBridge.currentTime != safeCurrent
                this@WebViewPlayerBridge.duration = safeDuration
                this@WebViewPlayerBridge.currentTime = safeCurrent
                if (durationChanged) onStateChanged()
                if (timeChanged || durationChanged) onTimelineChanged()
            }
        }

        @JavascriptInterface
        fun onDurationChanged(duration: Double) {
            handler.post {
                if (!isCurrentAttachment(receiverGeneration)) return@post
                this@WebViewPlayerBridge.duration = safeSeconds(duration)
                if (this@WebViewPlayerBridge.duration > 0) {
                    this@WebViewPlayerBridge.currentTime = this@WebViewPlayerBridge.currentTime
                        .coerceAtMost(this@WebViewPlayerBridge.duration)
                }
                onStateChanged()
            }
        }
    }

    private companion object {
        const val TAG = "WebViewBridge"
        const val DETECTION_DELAY_MS = 3_000L
        const val MAX_DETECTION_ATTEMPTS = 2
        const val MONITOR_INTERVAL_MS = 2_000L
    }
}
