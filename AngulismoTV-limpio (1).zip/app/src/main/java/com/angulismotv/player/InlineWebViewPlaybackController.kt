package com.angulismotv.player

import android.annotation.TargetApi
import android.os.Build
import android.view.View
import android.view.ViewGroup
import android.webkit.PermissionRequest
import android.webkit.SslErrorHandler
import android.webkit.WebChromeClient
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import android.net.http.SslError
import android.util.Log

/**
 * Owns the embedded iframe WebView's navigation callbacks and lifecycle operations.
 * Fragment/UI state is kept outside and is delivered through generation-guarded callbacks.
 * The provider is intentional: fullscreen handoff can replace the WebView instance on return.
 */
class InlineWebViewPlaybackController(
    private val webViewProvider: () -> WebView,
    private val isTV: () -> Boolean,
    private val isGenerationCurrent: (Int) -> Boolean,
    private val onPageLoaded: (Int) -> Unit,
    private val onMainFrameFailure: (Int) -> Unit
) {
    private val loadEventGate = WebViewLoadEventGate()

    data class DetachedSession(
        val webView: WebView,
        val parentIndex: Int,
        val layoutParams: ViewGroup.LayoutParams?
    )

    /** Installs guarded clients for a new URL or rebinds a page returned from fullscreen. */
    fun load(url: String, generation: Int, loadUrl: Boolean = true) {
        loadEventGate.begin(generation)
        val initialHost = StreamUrlPolicy.parseHttpUrl(url)?.host.orEmpty()
        try {
            val webView = webViewProvider()
            webView.applyPlayerSettings()
            webView.isFocusable = !isTV()
            webView.isFocusableInTouchMode = !isTV()
            webView.isClickable = !isTV()

            webView.webChromeClient = object : WebChromeClient() {
                override fun onPermissionRequest(request: PermissionRequest?) {
                    request?.deny()
                }

                override fun onCreateWindow(
                    view: WebView?,
                    isDialog: Boolean,
                    isUserGesture: Boolean,
                    resultMsg: android.os.Message?
                ): Boolean = false
            }

            webView.webViewClient = object : WebViewClient() {
                override fun onPageFinished(view: WebView?, url: String?) {
                    // Ignore neutral/invalid documents before claiming the generation's one
                    // terminal event; otherwise an about:blank callback could suppress the
                    // real source's first successful finish.
                    if (url.isNullOrBlank() || url == "about:blank") return
                    if (!loadEventGate.shouldDeliverPageLoaded(generation, isCurrent(generation))) return
                    onPageLoaded(generation)
                }

                @TargetApi(Build.VERSION_CODES.M)
                override fun onReceivedError(
                    view: WebView?,
                    request: WebResourceRequest?,
                    error: WebResourceError?
                ) {
                    val failedRequest = request ?: return
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && failedRequest.isForMainFrame &&
                        failedRequest.url.toString() != "about:blank" && isCurrent(generation)) {
                        reportMainFrameFailure(generation)
                    }
                }

                @Suppress("DEPRECATION")
                override fun onReceivedError(view: WebView?, code: Int, description: String?, failedUrl: String?) {
                    if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M &&
                        !failedUrl.isNullOrBlank() && failedUrl != "about:blank" && isCurrent(generation)) {
                        reportMainFrameFailure(generation)
                    }
                }

                @TargetApi(Build.VERSION_CODES.M)
                override fun onReceivedHttpError(
                    view: WebView?,
                    request: WebResourceRequest?,
                    errorResponse: WebResourceResponse?
                ) {
                    val failedRequest = request ?: return
                    val statusCode = errorResponse?.statusCode ?: 0
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && failedRequest.isForMainFrame &&
                        statusCode >= 400 && failedRequest.url.toString() != "about:blank" && isCurrent(generation)) {
                        reportMainFrameFailure(generation)
                    }
                }

                override fun onReceivedSslError(view: WebView?, handler: SslErrorHandler?, error: SslError?) {
                    // Never allow a certificate error to downgrade transport security.
                    handler?.cancel()
                }

                override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                    request ?: return false
                    val requestedHost = request.url.host.orEmpty()
                    val blockNavigation = WebViewNavigationPolicy.shouldBlockTopLevelNavigation(
                        initialHost = initialHost,
                        requestedHost = requestedHost,
                        isMainFrame = request.isForMainFrame,
                        isRedirect = Build.VERSION.SDK_INT >= Build.VERSION_CODES.N && request.isRedirect
                    )
                    if (blockNavigation) Log.d(TAG, "Navegación superior bloqueada para host $requestedHost")
                    return blockNavigation
                }
            }

            if (loadUrl) webView.loadUrl(url)
        } catch (error: Exception) {
            Log.w(TAG, "No se pudo iniciar la carga del WebView integrado", error)
            reportMainFrameFailure(generation)
        }
    }

    /** Stops the current page, hides the view, and optionally navigates to a neutral document. */
    fun stopAndHide(clearDocument: Boolean) {
        val webView = try {
            webViewProvider()
        } catch (error: Exception) {
            Log.w(TAG, "No se pudo obtener el WebView para detenerlo", error)
            return
        }
        safeWebViewOperation("detener carga") { webView.stopLoading() }
        safeWebViewOperation("ocultar vista") { webView.visibility = View.GONE }
        if (clearDocument) safeWebViewOperation("limpiar documento") { webView.loadUrl("about:blank") }
    }

    fun onPause() = safeWebViewOperation("pausar") { webViewProvider().onPause() }

    fun onResume() = safeWebViewOperation("reanudar") { webViewProvider().onResume() }

    /** Restores default clients before a WebView is used for a non-iframe source. */
    fun resetForNativePlayback() {
        val webView = try {
            webViewProvider()
        } catch (error: Exception) {
            Log.w(TAG, "No se pudo obtener el WebView para reiniciarlo", error)
            return
        }
        safeWebViewOperation("restaurar cliente de navegación") { webView.webViewClient = WebViewClient() }
        safeWebViewOperation("restaurar cliente de ventana") { webView.webChromeClient = WebChromeClient() }
        safeWebViewOperation("detener carga") { webView.stopLoading() }
        safeWebViewOperation("limpiar documento") { webView.loadUrl("about:blank") }
        safeWebViewOperation("ocultar vista") { webView.visibility = View.GONE }
    }

    /** Pauses and detaches the live WebView while preserving the loaded iframe document. */
    fun detachForHandoff(): DetachedSession {
        val webView = webViewProvider()
        val parent = webView.parent as? ViewGroup
        val snapshot = DetachedSession(
            webView = webView,
            parentIndex = parent?.indexOfChild(webView) ?: -1,
            layoutParams = webView.layoutParams
        )
        webView.onPause()
        parent?.removeView(webView)
        return snapshot
    }

    /** Reattaches a returned view at its previous position and resumes its WebView lifecycle. */
    fun attachReturnedView(parent: ViewGroup, parentIndex: Int, layoutParams: ViewGroup.LayoutParams?) {
        val webView = webViewProvider()
        (webView.parent as? ViewGroup)?.removeView(webView)
        val params = layoutParams ?: ViewGroup.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.MATCH_PARENT
        )
        parent.addView(webView, parentIndex.coerceIn(0, parent.childCount), params)
        webView.onResume()
    }

    /** Destroys only a WebView still owned by this Fragment, never one transferred to fullscreen. */
    fun dispose(destroyWebView: Boolean) {
        if (destroyWebView) disposeSpecificView(webViewProvider())
    }

    /** Releases the placeholder WebView inflated with a recreated Fragment view. */
    fun disposeSpecificView(webView: WebView) {
        // Each operation is isolated so a partially torn-down WebView still reaches destroy().
        safeWebViewOperation("restaurar cliente de ventana") { webView.webChromeClient = WebChromeClient() }
        safeWebViewOperation("restaurar cliente de navegación") { webView.webViewClient = WebViewClient() }
        safeWebViewOperation("detener carga") { webView.stopLoading() }
        safeWebViewOperation("desadjuntar vista") { (webView.parent as? ViewGroup)?.removeView(webView) }
        safeWebViewOperation("limpiar vistas hijas") { webView.removeAllViews() }
        safeWebViewOperation("destruir vista") { webView.destroy() }
    }

    private inline fun safeWebViewOperation(label: String, operation: () -> Unit) {
        runCatching(operation).onFailure { error ->
            Log.w(TAG, "No se pudo $label en WebView integrado", error)
        }
    }

    private fun reportMainFrameFailure(generation: Int) {
        if (!loadEventGate.shouldDeliverFailure(generation, isCurrent(generation))) return
        onMainFrameFailure(generation)
    }

    private fun isCurrent(generation: Int): Boolean = isGenerationCurrent(generation)

    private companion object {
        const val TAG = "InlineWebView"
    }
}
