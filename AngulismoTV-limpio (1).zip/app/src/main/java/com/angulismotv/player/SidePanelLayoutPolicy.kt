package com.angulismotv.player

/** Screen-width-based dimensions and labels for the TV player's side panel. */
object SidePanelLayoutPolicy {
    data class Dimensions(
        val menuWidthDp: Int,
        val listWidthDp: Float,
        val searchLabel: String,
        val allChannelsLabel: String
    )

    fun calculate(screenWidthDp: Float): Dimensions {
        val menuWidthDp = when {
            screenWidthDp < 420f -> 120
            screenWidthDp < 600f -> 144
            screenWidthDp < 900f -> 168
            else -> 208
        }
        val searchLabel = if (screenWidthDp < 600f) "Buscar" else "Buscar canales"
        val allChannelsLabel = if (screenWidthDp < 600f) "Canales" else "Lista de canales"
        val minListWidthDp = when {
            screenWidthDp < 420f -> 96
            screenWidthDp < 600f -> 140
            screenWidthDp < 900f -> 160
            else -> 240
        }
        val maxListWidthDp = when {
            screenWidthDp < 600f -> 220
            screenWidthDp < 900f -> 300
            else -> 420
        }
        val minPlayerWidthDp = when {
            screenWidthDp < 420f -> 104
            screenWidthDp < 600f -> 150
            screenWidthDp < 760f -> 180
            screenWidthDp < 1_000f -> 260
            else -> 360
        }
        val maxListWidthForScreenDp = (screenWidthDp - menuWidthDp - minPlayerWidthDp)
            .coerceAtLeast(minListWidthDp.toFloat())
            .coerceAtMost((screenWidthDp - menuWidthDp).coerceAtLeast(0f))
        val desiredListWidthDp = (screenWidthDp * 0.27f)
            .coerceIn(minListWidthDp.toFloat(), maxListWidthDp.toFloat())
        return Dimensions(
            menuWidthDp = menuWidthDp,
            listWidthDp = desiredListWidthDp.coerceAtMost(maxListWidthForScreenDp),
            searchLabel = searchLabel,
            allChannelsLabel = allChannelsLabel
        )
    }
}
