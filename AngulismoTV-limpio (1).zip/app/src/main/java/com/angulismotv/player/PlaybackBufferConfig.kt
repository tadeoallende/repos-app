package com.angulismotv.player

import com.google.android.exoplayer2.DefaultLoadControl

/**
 * Perfil Equilibrado: reserva mayor para tolerar variaciones de red.
 */
internal object PlaybackBufferConfig {
    fun createBalancedLoadControl(): DefaultLoadControl =
        DefaultLoadControl.Builder()
            .setBufferDurationsMs(30_000, 60_000, 2_500, 7_500)
            .setPrioritizeTimeOverSizeThresholds(true)
            .build()
}
