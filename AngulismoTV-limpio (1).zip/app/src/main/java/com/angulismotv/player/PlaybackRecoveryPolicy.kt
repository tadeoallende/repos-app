package com.angulismotv.player

import com.angulismotv.models.StreamType

/** Deterministic playback recovery limits, kept free of Android and player dependencies. */
object PlaybackRecoveryPolicy {
    const val MAX_RECONNECT_ATTEMPTS = 10
    const val WATCHDOG_INTERVAL_MS = 5_000L
    const val FROZEN_TICKS_BEFORE_RECONNECT = 2
    const val BUFFERING_TICKS_BEFORE_RECONNECT = 3

    private val reconnectDelaysMs = longArrayOf(500, 1_000, 2_000, 3_000, 5_000, 8_000, 12_000)

    fun reconnectDelayMs(attempt: Int): Long {
        require(attempt >= 1) { "El intento de reconexión debe ser mayor que cero" }
        return reconnectDelaysMs[(attempt - 1).coerceAtMost(reconnectDelaysMs.lastIndex)]
    }

    /** Live manifests may retry indefinitely; finite media surfaces the terminal error. */
    fun retryBeyondLimit(type: String): Boolean = type == StreamType.HLS || type == StreamType.DASH
}
