package com.angulismotv.player

import android.view.KeyEvent
import android.view.View
import android.widget.EditText
import android.widget.TextView
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.angulismotv.R
import com.angulismotv.adapters.CategoriesAdapter
import com.angulismotv.adapters.ChannelsAdapter
import com.angulismotv.models.Channel
import com.angulismotv.models.ChannelIdentity

/** Owns focus movement inside the fullscreen player's TV side panel. */
class TvSidePanelFocusController(
    private val channelsList: RecyclerView,
    private val menuSearchResults: RecyclerView,
    private val menuSearchInput: EditText,
    private val searchEmptyText: TextView,
    private val menuCategoriesList: RecyclerView,
    private val btnAllChannels: View,
    private val btnSearchTrigger: View,
    private val btnClosePanel: View,
    private val categoriesAdapterProvider: () -> CategoriesAdapter,
    private val searchAdapterProvider: () -> ChannelsAdapter,
    private val isSearchActive: () -> Boolean,
    private val currentCategory: () -> String,
    private val currentChannel: () -> Channel?,
    private val currentFilteredChannels: () -> List<Channel>
) {
    fun isRightPanelFocused(currentFocus: View?): Boolean =
        channelsList.hasFocus() || isDescendantFocused(currentFocus, channelsList) ||
            menuSearchResults.hasFocus() || isDescendantFocused(currentFocus, menuSearchResults)

    fun moveFocusToCategoriesPanel() {
        if (isSearchActive()) {
            menuSearchInput.requestFocus()
            return
        }
        if (currentCategory().equals("todos", ignoreCase = true)) {
            btnAllChannels.requestFocus()
            return
        }
        val position = categoriesAdapterProvider().getPositionForKey(currentCategory())
        if (position < 0) {
            btnAllChannels.requestFocus()
            return
        }
        menuCategoriesList.post {
            (menuCategoriesList.layoutManager as? LinearLayoutManager)?.scrollToPositionWithOffset(position, 0)
            menuCategoriesList.post {
                val item = menuCategoriesList.findViewHolderForAdapterPosition(position)?.itemView
                if (item?.requestFocus() != true) menuCategoriesList.requestFocus()
            }
        }
    }

    fun moveFocusToChannelsList() {
        // Without search results, keep focus on the actionable search field.
        if (isSearchActive() && searchEmptyText.visibility == View.VISIBLE) {
            menuSearchInput.requestFocus()
            return
        }
        if (isSearchActive() && menuSearchResults.visibility == View.VISIBLE) {
            // AsyncListDiffer may not have attached its first holder yet; retry after layout.
            menuSearchResults.post {
                menuSearchResults.post {
                    val item = if (searchAdapterProvider().itemCount > 0) {
                        menuSearchResults.findViewHolderForAdapterPosition(0)?.itemView
                    } else null
                    if (item?.requestFocus() != true) menuSearchResults.requestFocus()
                }
            }
            return
        }

        val selectedChannel = currentChannel()
        val filtered = currentFilteredChannels()
        val selectedInFiltered = filtered.indexOfFirst {
            selectedChannel != null && ChannelIdentity.same(it, selectedChannel)
        }
        val targetPosition = if (selectedInFiltered >= 0) selectedInFiltered else 0
        channelsList.post {
            val lm = channelsList.layoutManager as? LinearLayoutManager
            lm?.scrollToPositionWithOffset(targetPosition, 0)
            channelsList.post {
                val item = channelsList.findViewHolderForAdapterPosition(targetPosition)?.itemView
                if (item?.requestFocus() != true) channelsList.requestFocus()
            }
        }
    }

    /** Explicit vertical rail: fixed panel actions participate in the same focus path. */
    fun handlePanelVerticalFocus(currentFocus: View?, keyCode: Int): Boolean {
        val focused = currentFocus ?: return false
        return when {
            focused.id == R.id.btn_search_trigger && keyCode == KeyEvent.KEYCODE_DPAD_DOWN -> {
                btnAllChannels.requestFocus()
                true
            }
            focused.id == R.id.btn_all_channels && keyCode == KeyEvent.KEYCODE_DPAD_UP -> {
                btnSearchTrigger.requestFocus()
                true
            }
            focused.id == R.id.btn_all_channels && keyCode == KeyEvent.KEYCODE_DPAD_DOWN -> {
                focusFirstCategory()
                true
            }
            focused.id == R.id.btn_close_panel && keyCode == KeyEvent.KEYCODE_DPAD_DOWN -> {
                btnSearchTrigger.requestFocus()
                true
            }
            focused.id == R.id.btn_search_trigger && keyCode == KeyEvent.KEYCODE_DPAD_UP -> {
                btnClosePanel.requestFocus()
                true
            }
            else -> false
        }
    }

    private fun focusFirstCategory() {
        val categoriesAdapter = categoriesAdapterProvider()
        if (categoriesAdapter.itemCount == 0) {
            moveFocusToChannelsList()
            return
        }
        menuCategoriesList.post {
            (menuCategoriesList.layoutManager as? LinearLayoutManager)?.scrollToPositionWithOffset(0, 0)
            menuCategoriesList.post {
                val first = menuCategoriesList.findViewHolderForAdapterPosition(0)?.itemView
                if (first?.requestFocus() != true) menuCategoriesList.requestFocus()
            }
        }
    }

    private fun isDescendantFocused(currentFocus: View?, ancestor: View): Boolean {
        var parent = currentFocus?.parent
        while (parent != null) {
            if (parent === ancestor) return true
            parent = (parent as? View)?.parent
        }
        return false
    }
}
