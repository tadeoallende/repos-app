package com.angulismotv.player

import android.view.View
import android.webkit.WebView
import android.widget.ImageButton
import android.widget.ProgressBar
import android.widget.TextView
import com.angulismotv.R
import com.google.android.exoplayer2.ui.PlayerView

/**
 * Owns presentation-only changes for the inline player surfaces and overlays.
 * Playback ownership remains in InlinePlaybackEngineController / InlineWebViewPlaybackController.
 * This class never starts, pauses, or releases media; it only renders the current UI state.
 */
class InlinePlayerVisualController(
    private val progressBar: ProgressBar,
    private val errorText: TextView,
    private val playerView: PlayerView,
    private val webView: WebView,
    private val controlsBar: View,
    private val timelineContainer: View,
    private val playPauseButton: ImageButton,
    private val sourcesButton: ImageButton,
    private val isTv: () -> Boolean
) {
    enum class Surface { NONE, NATIVE, WEB }

    private var disposed = false
    var activeSurface: Surface = Surface.NONE
        private set

    val isErrorVisible: Boolean
        get() = !disposed && errorText.visibility == View.VISIBLE

    val isWebVisible: Boolean
        get() = !disposed && webView.visibility == View.VISIBLE

    val isLoading: Boolean
        get() = !disposed && progressBar.visibility == View.VISIBLE

    fun showLoading() {
        if (disposed) return
        progressBar.visibility = View.VISIBLE
        errorText.visibility = View.GONE
    }

    fun showReady() {
        if (disposed) return
        progressBar.visibility = View.GONE
        errorText.visibility = View.GONE
    }

    fun showEnded() {
        if (disposed) return
        progressBar.visibility = View.GONE
    }

    fun clearError() {
        if (!disposed) errorText.visibility = View.GONE
    }

    /** Switches presentation to the native surface without touching player ownership. */
    fun showNativeSurface() {
        if (disposed) return
        activeSurface = Surface.NATIVE
        playerView.visibility = View.VISIBLE
        webView.visibility = View.GONE
        playPauseButton.visibility = if (controlsBar.visibility == View.VISIBLE) View.VISIBLE else View.GONE
        timelineContainer.visibility = View.GONE
    }

    /** Switches presentation to the web surface. The WebView controller owns page operations. */
    fun showWebSurface() {
        if (disposed) return
        activeSurface = Surface.WEB
        playerView.player = null
        playerView.visibility = View.GONE
        webView.visibility = View.VISIBLE
        playPauseButton.visibility = View.GONE
        timelineContainer.visibility = View.GONE
    }

    /** Hides the native surface after engine release without mutating a transferred WebView. */
    fun onNativeEngineReleased(clearWebSurface: Boolean) {
        if (disposed) return
        playerView.visibility = View.GONE
        timelineContainer.visibility = View.GONE
        playPauseButton.visibility = View.GONE
        if (clearWebSurface) {
            webView.visibility = View.GONE
            activeSurface = Surface.NONE
        } else if (activeSurface == Surface.NATIVE) {
            activeSurface = Surface.NONE
        }
    }

    fun showError(message: String) {
        if (disposed) return
        progressBar.visibility = View.GONE
        errorText.text = if (isTv()) {
            "$message\n\nElegí Recargar para volver a intentar."
        } else {
            "$message\n\nTocá ↻ Recargar para volver a intentar."
        }
        errorText.visibility = View.VISIBLE
        playerView.visibility = View.GONE
        webView.visibility = View.GONE
        timelineContainer.visibility = View.GONE
        playPauseButton.visibility = View.GONE
        activeSurface = Surface.NONE
    }

    fun renderControlsVisibility(visible: Boolean) {
        if (disposed) return
        controlsBar.visibility = if (visible) View.VISIBLE else View.GONE
        playPauseButton.visibility = if (visible && playerView.visibility == View.VISIBLE) {
            View.VISIBLE
        } else {
            View.GONE
        }
        if (!visible) timelineContainer.visibility = View.GONE
    }

    fun bringControlsToFront() {
        if (disposed) return
        controlsBar.bringToFront()
        timelineContainer.bringToFront()
    }

    fun renderPlayPause(isPlaying: Boolean) {
        if (disposed) return
        playPauseButton.setImageResource(if (isPlaying) R.drawable.ic_pause else R.drawable.ic_play)
        playPauseButton.contentDescription = if (isPlaying) "Pausar" else "Reproducir"
    }

    fun setSourcesAvailable(available: Boolean) {
        if (!disposed) sourcesButton.visibility = if (available) View.VISIBLE else View.GONE
    }

    /** Hides surfaces for a source switch or explicit close, without releasing media itself. */
    fun hideSurfaces(clearWebSurface: Boolean = true) {
        if (disposed) return
        playerView.visibility = View.GONE
        timelineContainer.visibility = View.GONE
        playPauseButton.visibility = View.GONE
        if (clearWebSurface) webView.visibility = View.GONE
        if (clearWebSurface || activeSurface == Surface.NATIVE) activeSurface = Surface.NONE
    }

    /** Closing a preview resets transient overlays while preserving the fragment's TV idle shell. */
    fun close() {
        if (disposed) return
        progressBar.visibility = View.GONE
        errorText.visibility = View.GONE
        controlsBar.visibility = View.GONE
        hideSurfaces(clearWebSurface = true)
    }

    /** Prevents accidental updates to stale views after onDestroyView. */
    fun dispose() {
        disposed = true
    }
}
