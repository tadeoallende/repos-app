package com.angulismotv.player

import android.net.Uri

/** Política central para validar URLs de streams antes de entregarlas a un motor de reproducción. */
object StreamUrlPolicy {
    fun parseHttpUrl(value: String?): Uri? {
        if (value.isNullOrBlank()) return null
        val uri = runCatching { Uri.parse(value.trim()) }.getOrNull() ?: return null
        val scheme = uri.scheme?.lowercase()
        return uri.takeIf { !it.host.isNullOrBlank() && (scheme == "http" || scheme == "https") }
    }

    fun isHttpUrl(value: String?): Boolean = parseHttpUrl(value) != null
}
