package com.angulismotv.player

import android.os.Handler
import android.util.Log
import com.google.android.exoplayer2.Player
import com.angulismotv.models.Channel
import com.angulismotv.models.StreamType

/**
 * Owns the startup timeout for a native channel option and decides whether to try the next
 * option or surface a terminal error. Activity-specific playback and UI actions are injected.
 */
class ChannelOptionFallbackController(
    private val handler: Handler,
    private val isGenerationCurrent: (Int) -> Boolean,
    private val isZapping: () -> Boolean,
    private val currentChannel: () -> Channel?,
    private val currentOptionIndex: () -> Int,
    private val playerProvider: () -> Player?,
    private val releasePlayer: () -> Unit,
    private val tryOption: (Channel, Int) -> Unit,
    private val showError: (String) -> Unit,
    private val timeoutMs: Long = DEFAULT_TIMEOUT_MS
) {
    private var pendingRunnable: Runnable? = null

    fun schedule(channel: Channel, optionIndex: Int, generation: Int) {
        cancel()
        val option = channel.options?.getOrNull(optionIndex) ?: return
        val optionType = StreamUtils.resolveType(option.iframe, option.streamType)
        // WebView pages do not expose reliable native playback state; errors are handled by WebView.
        if (optionType == StreamType.IFRAME) return

        val timeout = Runnable {
            pendingRunnable = null
            if (!isGenerationCurrent(generation) || isZapping()) return@Runnable
            if (currentChannel() != channel || currentOptionIndex() != optionIndex) return@Runnable

            val player = playerProvider()
            if (player != null && player.playbackState != Player.STATE_IDLE &&
                player.playbackState != Player.STATE_BUFFERING) return@Runnable

            val nextIndex = optionIndex + 1
            val optionCount = channel.options?.size ?: 0
            if (nextIndex < optionCount) {
                Log.w("OPTION_FALLBACK", "Opción ${optionIndex + 1} tardó demasiado; probando la siguiente")
                releasePlayer()
                tryOption(channel, nextIndex)
            } else {
                Log.e("OPTION_FALLBACK", "La última opción no inició a tiempo: ${optionIndex + 1}")
                releasePlayer()
                showError("La fuente tardó demasiado en iniciar. Recargá o elegí otra fuente.")
            }
        }
        pendingRunnable = timeout
        handler.postDelayed(timeout, timeoutMs)
    }

    fun cancel() {
        pendingRunnable?.let(handler::removeCallbacks)
        pendingRunnable = null
    }

    fun dispose() = cancel()

    companion object {
        const val DEFAULT_TIMEOUT_MS = 12_000L
    }
}
