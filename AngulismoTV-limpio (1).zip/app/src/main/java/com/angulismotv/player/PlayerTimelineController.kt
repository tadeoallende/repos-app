package com.angulismotv.player

import android.os.Handler
import android.view.View
import android.widget.SeekBar
import android.widget.TextView
import com.google.android.exoplayer2.Player

/** Coordinates the shared seek bar for native ExoPlayer and external WebView timelines. */
class PlayerTimelineController(
    private val handler: Handler,
    private val container: View,
    private val seekBar: SeekBar,
    private val currentTime: TextView,
    private val durationTime: TextView,
    private val playerProvider: () -> Player?,
    private val isTimelineEnabled: () -> Boolean,
    private val shouldContinueUpdates: () -> Boolean,
    private val canSeekOnStopTracking: (Player) -> Boolean = { it.isCurrentWindowSeekable && it.duration > 0L },
    private val useExternalTimeline: () -> Boolean = { false },
    private val externalTimelineProvider: () -> TimelineSnapshot? = { null },
    private val seekExternalTo: (Long) -> Unit = {}
) {
    /** Timeline supplied by a non-ExoPlayer engine, expressed in milliseconds. */
    data class TimelineSnapshot(
        val currentPositionMs: Long,
        val durationMs: Long,
        val canSeek: Boolean
    )
    private var isUserSeeking = false
    private var updateRunnable: Runnable? = null

    fun onStartTracking() {
        isUserSeeking = true
    }

    fun onProgressChanged(progress: Int, fromUser: Boolean) {
        if (!fromUser) return
        if (useExternalTimeline()) {
            val snapshot = externalTimelineProvider() ?: return
            if (snapshot.durationMs <= 0L) return
            currentTime.text = PlayerTimeFormatter.format(
                snapshot.durationMs * progress.toLong() / SEEK_SCALE
            )
            return
        }
        val duration = playerProvider()?.duration ?: return
        currentTime.text = PlayerTimeFormatter.format(duration * progress.toLong() / SEEK_SCALE)
    }

    fun onStopTracking() {
        if (useExternalTimeline()) {
            val snapshot = externalTimelineProvider()
            if (snapshot != null && snapshot.canSeek && snapshot.durationMs > 0L) {
                seekExternalTo(snapshot.durationMs * seekBar.progress.toLong() / SEEK_SCALE)
            }
            isUserSeeking = false
            update()
            return
        }
        val player = playerProvider()
        if (player != null && canSeekOnStopTracking(player)) {
            player.seekTo(player.duration * seekBar.progress.toLong() / SEEK_SCALE)
        }
        isUserSeeking = false
        update()
    }

    fun update() {
        if (!isTimelineEnabled()) {
            container.visibility = View.GONE
            return
        }
        if (useExternalTimeline()) {
            val snapshot = externalTimelineProvider()
            if (snapshot == null || !snapshot.canSeek || snapshot.durationMs <= 0L) {
                container.visibility = View.GONE
                return
            }
            container.visibility = View.VISIBLE
            seekBar.max = SEEK_SCALE.toInt()
            if (!isUserSeeking) {
                val current = snapshot.currentPositionMs.coerceIn(0L, snapshot.durationMs)
                seekBar.progress = ((current * SEEK_SCALE) / snapshot.durationMs)
                    .toInt().coerceIn(0, SEEK_SCALE.toInt())
                currentTime.text = PlayerTimeFormatter.format(current)
            }
            durationTime.text = PlayerTimeFormatter.format(snapshot.durationMs)
            return
        }

        val player = playerProvider()
        if (player == null) {
            container.visibility = View.GONE
            return
        }
        val duration = player.duration
        val canSeek = player.playbackState == Player.STATE_READY && player.isCurrentWindowSeekable && duration > 0L
        if (!canSeek) {
            container.visibility = View.GONE
            return
        }

        container.visibility = View.VISIBLE
        seekBar.max = SEEK_SCALE.toInt()
        if (!isUserSeeking) {
            seekBar.progress = ((player.currentPosition.coerceAtLeast(0L) * SEEK_SCALE) / duration)
                .toInt().coerceIn(0, SEEK_SCALE.toInt())
            currentTime.text = PlayerTimeFormatter.format(player.currentPosition)
        }
        durationTime.text = PlayerTimeFormatter.format(duration)
    }

    fun startUpdates() {
        stopUpdates()
        updateRunnable = object : Runnable {
            override fun run() {
                update()
                if (shouldContinueUpdates()) handler.postDelayed(this, UPDATE_INTERVAL_MS)
            }
        }
        handler.post(updateRunnable!!)
    }

    fun stopUpdates() {
        updateRunnable?.let { runnable -> handler.removeCallbacks(runnable) }
        updateRunnable = null
        isUserSeeking = false
    }

    companion object {
        private const val SEEK_SCALE = 1_000L
        private const val UPDATE_INTERVAL_MS = 500L
    }
}
