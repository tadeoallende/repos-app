package com.angulismotv.player

import android.os.Handler
import android.view.View
import android.widget.SeekBar
import android.widget.TextView
import com.google.android.exoplayer2.Player

/** Coordinates the native player's seek bar and periodic timeline refresh. */
class PlayerTimelineController(
    private val handler: Handler,
    private val container: View,
    private val seekBar: SeekBar,
    private val currentTime: TextView,
    private val durationTime: TextView,
    private val playerProvider: () -> Player?,
    private val isTimelineEnabled: () -> Boolean,
    private val shouldContinueUpdates: () -> Boolean,
    private val canSeekOnStopTracking: (Player) -> Boolean = { it.isCurrentWindowSeekable && it.duration > 0L }
) {
    private var isUserSeeking = false
    private var updateRunnable: Runnable? = null

    fun onStartTracking() {
        isUserSeeking = true
    }

    fun onProgressChanged(progress: Int, fromUser: Boolean) {
        if (!fromUser) return
        val duration = playerProvider()?.duration?.takeIf { it > 0L } ?: return
        currentTime.text = PlayerTimeFormatter.format(
            PlayerTimelineMath.progressToPosition(progress, duration)
        )
    }

    fun onStopTracking() {
        val player = playerProvider()
        if (player != null && canSeekOnStopTracking(player)) {
            player.seekTo(
                PlayerTimelineMath.progressToPosition(seekBar.progress, player.duration, seekBar.max.coerceAtLeast(1))
            )
        }
        isUserSeeking = false
        update()
    }

    fun update() {
        if (!isTimelineEnabled()) {
            container.visibility = View.GONE
            return
        }
        val player = playerProvider()
        if (player == null) {
            container.visibility = View.GONE
            return
        }
        val duration = player.duration
        val canSeek = player.playbackState == Player.STATE_READY && player.isCurrentWindowSeekable && duration > 0L
        if (!canSeek) {
            container.visibility = View.GONE
            return
        }

        container.visibility = View.VISIBLE
        if (seekBar.max != PlayerTimelineMath.SEEK_SCALE) {
            seekBar.max = PlayerTimelineMath.SEEK_SCALE
        }
        if (!isUserSeeking) {
            seekBar.progress = PlayerTimelineMath.positionToProgress(player.currentPosition, duration)
            currentTime.text = PlayerTimeFormatter.format(player.currentPosition)
        }
        durationTime.text = PlayerTimeFormatter.format(duration)
    }

    fun startUpdates() {
        stopUpdates()
        val updateTask = object : Runnable {
            override fun run() {
                // stopUpdates() may have invalidated this task after it was dequeued.
                if (updateRunnable !== this) return
                update()
                if (updateRunnable !== this) return
                if (shouldContinueUpdates()) {
                    handler.postDelayed(this, UPDATE_INTERVAL_MS)
                } else {
                    updateRunnable = null
                }
            }
        }
        updateRunnable = updateTask
        handler.post(updateTask)
    }

    fun stopUpdates() {
        updateRunnable?.let { runnable -> handler.removeCallbacks(runnable) }
        updateRunnable = null
        isUserSeeking = false
    }

    companion object {
        private const val UPDATE_INTERVAL_MS = 500L
    }
}
