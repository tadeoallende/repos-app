package com.angulismotv.player

/**
 * Controls the visibility policy and auto-hide timer for the inline player's touch controls.
 * Android views stay owned by the Fragment and are updated through callbacks, which keeps this
 * policy deterministic and straightforward to test without a Looper or a real player.
 */
class InlineControlsAutoHideController(
    private val postDelayed: (Runnable, Long) -> Unit,
    private val removeCallbacks: (Runnable) -> Unit,
    private val isTv: () -> Boolean,
    private val canShow: () -> Boolean,
    private val onVisibilityChanged: (Boolean) -> Unit,
    private val onShowRequested: () -> Unit,
    private val autoHideDelayMs: Long = DEFAULT_AUTO_HIDE_DELAY_MS
) {
    private var pendingHide: Runnable? = null
    private var visible = false
    private var disposed = false

    val isVisible: Boolean
        get() = visible

    /** Show controls briefly after touch or a playback event. TV keeps its dedicated layout. */
    fun showTemporarily() {
        if (!canAcceptShow()) return
        reveal()
        scheduleAutoHide()
    }

    /** Keep controls visible until an explicit hide or another playback action. */
    fun showPersistent() {
        if (!canAcceptShow()) return
        cancelAutoHide()
        reveal()
    }

    fun toggleTemporarily() {
        if (isVisible) hide() else showTemporarily()
    }

    fun hide() {
        cancelAutoHide()
        if (disposed) {
            visible = false
            return
        }
        visible = false
        onVisibilityChanged(false)
    }

    /** Cancels only the deadline, preserving the current visual state. */
    fun cancelAutoHide() {
        pendingHide?.let(removeCallbacks)
        pendingHide = null
    }

    /** Do not touch Fragment views after onDestroyView; only invalidate pending work. */
    fun dispose() {
        cancelAutoHide()
        disposed = true
        visible = false
    }

    private fun canAcceptShow(): Boolean = !disposed && !isTv() && canShow()

    private fun reveal() {
        visible = true
        // Reapply visuals even when already visible, because a playback surface may have changed.
        onVisibilityChanged(true)
        onShowRequested()
    }

    private fun scheduleAutoHide() {
        cancelAutoHide()
        val task = object : Runnable {
            override fun run() {
                // A cancelled task may already have been dequeued; it must not hide a newer state.
                if (pendingHide !== this) return
                pendingHide = null
                if (disposed) return
                visible = false
                onVisibilityChanged(false)
            }
        }
        pendingHide = task
        postDelayed(task, autoHideDelayMs.coerceAtLeast(0L))
    }

    companion object {
        const val DEFAULT_AUTO_HIDE_DELAY_MS = 4_000L
    }
}
