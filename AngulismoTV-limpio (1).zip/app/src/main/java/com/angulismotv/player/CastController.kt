package com.angulismotv.player

import android.os.Handler
import android.view.View
import android.widget.ImageButton
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.mediarouter.media.MediaRouteSelector
import androidx.mediarouter.media.MediaRouter
import com.angulismotv.models.StreamType
import com.google.android.gms.cast.CastMediaControlIntent
import com.google.android.gms.cast.MediaInfo
import com.google.android.gms.cast.MediaLoadRequestData
import com.google.android.gms.cast.MediaMetadata
import com.google.android.gms.cast.framework.CastContext
import com.google.android.gms.cast.framework.CastSession

/** Lo que se está reproduciendo y puede enviarse a un Chromecast. */
data class CastStream(val url: String, val type: String, val title: String)

/**
 * Encapsula el descubrimiento de dispositivos y el envío del stream actual a Google Cast.
 * En TV el botón se oculta.
 */
class CastController(
    private val activity: AppCompatActivity,
    private val button: ImageButton,
    private val handler: Handler,
    private val currentStream: () -> CastStream?,
    private val onCastStarted: () -> Unit
) {

    private var selector: MediaRouteSelector? = null
    private var router: MediaRouter? = null
    private var routerCallback: MediaRouter.Callback? = null

    /** True only when Cast was initialized successfully on this device. */
    var isConfigured: Boolean = false
        private set

    fun setup(isTV: Boolean) {
        isConfigured = false
        if (isTV) {
            button.visibility = View.GONE
            return
        }
        try {
            CastContext.getSharedInstance(activity)
            selector = MediaRouteSelector.Builder()
                .addControlCategory(CastMediaControlIntent.categoryForCast(RECEIVER_APP_ID))
                .build()
            router = MediaRouter.getInstance(activity)
            routerCallback = object : MediaRouter.Callback() {}
            isConfigured = true
            button.visibility = View.VISIBLE
            button.setOnClickListener { onButtonClick() }
        } catch (e: Exception) {
            isConfigured = false
            button.visibility = View.GONE
        }
    }

    fun startDiscovery() {
        router?.addCallback(
            selector ?: return,
            routerCallback ?: return,
            MediaRouter.CALLBACK_FLAG_REQUEST_DISCOVERY
        )
    }

    fun stopDiscovery() {
        router?.removeCallback(routerCallback ?: return)
    }

    private fun availableRoutes(router: MediaRouter, selector: MediaRouteSelector) =
        router.routes.filter { !it.isDefault && !it.isBluetooth && it.matchesSelector(selector) }

    private fun onButtonClick() {
        try {
            val session = CastContext.getSharedInstance(activity).sessionManager.currentCastSession
            if (session?.isConnected == true) {
                castCurrentStream(session)
                return
            }
            val mediaRouter = router ?: return
            val routeSelector = selector ?: return
            val routes = availableRoutes(mediaRouter, routeSelector)
            if (routes.isEmpty()) {
                toast("Buscando dispositivos Cast...")
                handler.postDelayed({
                    val fresh = availableRoutes(mediaRouter, routeSelector)
                    if (fresh.isEmpty()) {
                        toast("No se encontraron dispositivos. Asegurate de estar en la misma red Wi-Fi.", long = true)
                    } else {
                        showDeviceDialog(fresh)
                    }
                }, DISCOVERY_RETRY_MS)
            } else {
                showDeviceDialog(routes)
            }
        } catch (e: Exception) {
            toast("Error Cast: ${e.message}")
        }
    }

    private fun showDeviceDialog(routes: List<MediaRouter.RouteInfo>) {
        AlertDialog.Builder(activity)
            .setTitle("Seleccionar dispositivo")
            .setItems(routes.map { it.name }.toTypedArray()) { _, which ->
                router?.selectRoute(routes[which])
                handler.postDelayed({
                    try {
                        val session = CastContext.getSharedInstance(activity).sessionManager.currentCastSession
                        if (session?.isConnected == true) castCurrentStream(session)
                        else toast("Conectando... intentá castear de nuevo.")
                    } catch (e: Exception) {
                        toast("Error al conectar: ${e.message}")
                    }
                }, CONNECT_DELAY_MS)
            }.show()
    }

    private fun castCurrentStream(session: CastSession) {
        val stream = currentStream() ?: return
        try {
            val metadata = MediaMetadata(MediaMetadata.MEDIA_TYPE_MOVIE).apply {
                putString(MediaMetadata.KEY_TITLE, stream.title)
            }
            val contentType = when (stream.type) {
                StreamType.DASH -> "application/dash+xml"
                StreamType.MP4 -> "video/mp4"
                else -> "application/x-mpegURL"
            }
            val isLive = stream.type == StreamType.HLS || stream.type == StreamType.DASH
            val mediaInfo = MediaInfo.Builder(stream.url)
                .setStreamType(if (isLive) MediaInfo.STREAM_TYPE_LIVE else MediaInfo.STREAM_TYPE_BUFFERED)
                .setContentType(contentType)
                .setMetadata(metadata)
                .build()
            session.remoteMediaClient?.load(
                MediaLoadRequestData.Builder().setMediaInfo(mediaInfo).setAutoplay(true).build()
            )
            onCastStarted()
            toast("Enviando a Chromecast...")
        } catch (e: Exception) {
            toast("Error al enviar: ${e.message}")
        }
    }

    private fun toast(message: String, long: Boolean = false) {
        Toast.makeText(activity, message, if (long) Toast.LENGTH_LONG else Toast.LENGTH_SHORT).show()
    }

    private companion object {
        const val RECEIVER_APP_ID = "CC1AD845" // Default Media Receiver
        const val DISCOVERY_RETRY_MS = 2_000L
        const val CONNECT_DELAY_MS = 2_500L
    }
}
