package com.angulismotv.player

import android.os.Handler
import android.view.View
import android.widget.ImageButton
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.mediarouter.media.MediaRouteSelector
import androidx.mediarouter.media.MediaRouter
import com.google.android.gms.cast.CastMediaControlIntent
import com.google.android.gms.cast.MediaInfo
import com.google.android.gms.cast.MediaLoadRequestData
import com.google.android.gms.cast.MediaMetadata
import com.google.android.gms.cast.framework.CastContext
import com.google.android.gms.cast.framework.CastSession
import com.google.android.gms.cast.framework.SessionManagerListener

/**
 * Encapsula el descubrimiento de dispositivos y el envío del stream actual a Google Cast.
 * La carga se dispara desde los eventos de sesión del SDK, no mediante una espera fija.
 */
class CastController(
    private val activity: AppCompatActivity,
    private val button: ImageButton,
    private val handler: Handler,
    private val currentStream: () -> CastStream?,
    private val onCastStarted: () -> Unit,
    private val onStatusChanged: (String) -> Unit = {}
) {

    private var selector: MediaRouteSelector? = null
    private var router: MediaRouter? = null
    private var routerCallback: MediaRouter.Callback? = null
    private var castContext: CastContext? = null
    private var discoveryStarted = false
    private var sessionListenerRegistered = false
    private var pendingStreamOnSessionStart = false
    private var pendingDiscoveryRunnable: Runnable? = null
    private var waitingForRouteDiscovery = false

    /** True only when Cast was initialized successfully on this device. */
    var isConfigured: Boolean = false
        private set

    private val sessionManagerListener = object : SessionManagerListener<CastSession> {
        override fun onSessionStarting(session: CastSession) {
            publishStatus("Conectando con el dispositivo…")
        }

        override fun onSessionStarted(session: CastSession, sessionId: String) {
            publishStatus("Dispositivo conectado; preparando transmisión…")
            loadAfterSessionStarts(session)
        }

        override fun onSessionStartFailed(session: CastSession, error: Int) {
            reportSessionFailure("No se pudo conectar con Chromecast")
        }

        override fun onSessionSuspended(session: CastSession, reason: Int) {
            publishStatus("Conexión interrumpida; intentando recuperar…")
        }
        override fun onSessionResuming(session: CastSession, sessionId: String) {
            publishStatus("Reconectando con el dispositivo…")
        }

        override fun onSessionResumed(session: CastSession, wasSuspended: Boolean) {
            // Si el proceso de selección se completó mientras la pantalla estaba en pausa,
            // el stream pendiente se envía al volver a quedar activa.
            loadAfterSessionStarts(session)
        }

        override fun onSessionResumeFailed(session: CastSession, error: Int) {
            reportSessionFailure("Se perdió la conexión con Chromecast")
        }

        override fun onSessionEnding(session: CastSession) {
            publishStatus("Desconectando Cast…")
        }
        override fun onSessionEnded(session: CastSession, error: Int) {
            publishStatus("Cast desconectado. La reproducción local está disponible.")
        }
    }

    fun setup(isTV: Boolean) {
        isConfigured = false
        if (isTV) {
            button.visibility = View.GONE
            return
        }
        try {
            castContext = CastContext.getSharedInstance(activity)
            selector = MediaRouteSelector.Builder()
                .addControlCategory(CastMediaControlIntent.categoryForCast(RECEIVER_APP_ID))
                .build()
            router = MediaRouter.getInstance(activity)
            routerCallback = object : MediaRouter.Callback() {
                override fun onRouteAdded(router: MediaRouter, route: MediaRouter.RouteInfo) {
                    showRoutesIfWaiting(router)
                }

                override fun onRouteChanged(router: MediaRouter, route: MediaRouter.RouteInfo) {
                    showRoutesIfWaiting(router)
                }
            }
            isConfigured = true
            button.visibility = View.VISIBLE
            button.setOnClickListener { onButtonClick() }
        } catch (e: Exception) {
            isConfigured = false
            button.visibility = View.GONE
            android.util.Log.w(TAG, "No se pudo inicializar Google Cast", e)
        }
    }

    fun startDiscovery() {
        if (!isConfigured || activity.isFinishing || activity.isDestroyed) return
        val mediaRouter = router ?: return
        val routeSelector = selector ?: return
        val callback = routerCallback ?: return

        // La escucha de sesión es independiente del descubrimiento: debe permanecer activa
        // si la Activity/Fragment entra en pausa mientras el receptor termina de conectar.
        val sessionManager = castContext?.sessionManager ?: return
        if (!sessionListenerRegistered) {
            runCatching {
                sessionManager.addSessionManagerListener(sessionManagerListener, CastSession::class.java)
                sessionListenerRegistered = true
            }.onFailure { android.util.Log.w(TAG, "No se pudo registrar el estado de sesión Cast", it) }
        }

        if (!discoveryStarted) {
            runCatching {
                mediaRouter.addCallback(
                    routeSelector,
                    callback,
                    MediaRouter.CALLBACK_FLAG_REQUEST_DISCOVERY
                )
                discoveryStarted = true
            }.onFailure { android.util.Log.w(TAG, "No se pudo iniciar la búsqueda Cast", it) }
        }

        // Cubre el caso en que la sesión se haya conectado mientras el host no estaba activo.
        val session = sessionManager.currentCastSession
        if (pendingStreamOnSessionStart && session?.isConnected == true) {
            loadAfterSessionStarts(session)
        }
    }

    fun stopDiscovery() {
        pendingDiscoveryRunnable?.let(handler::removeCallbacks)
        pendingDiscoveryRunnable = null
        waitingForRouteDiscovery = false
        if (discoveryStarted) {
            router?.let { mediaRouter -> routerCallback?.let(mediaRouter::removeCallback) }
            discoveryStarted = false
        }
        // No se quita aquí el listener de sesión ni se borra la carga pendiente. En Android,
        // onPause/onHiddenChanged puede ocurrir antes de onSessionStarted; hacerlo acá perdía
        // el evento y dejaba el receptor conectado pero sin contenido. dispose() sí lo libera.
    }

    /** Libera todos los callbacks/listeners al destruir definitivamente esta pantalla. */
    fun dispose() {
        stopDiscovery()
        if (sessionListenerRegistered) {
            runCatching {
                castContext?.sessionManager?.removeSessionManagerListener(
                    sessionManagerListener,
                    CastSession::class.java
                )
            }.onFailure { android.util.Log.w(TAG, "No se pudo quitar el listener de sesión Cast", it) }
            sessionListenerRegistered = false
        }
        pendingStreamOnSessionStart = false
    }

    private fun availableRoutes(router: MediaRouter, selector: MediaRouteSelector) =
        router.routes.filter { !it.isDefault && !it.isBluetooth && it.matchesSelector(selector) }

    private fun onButtonClick() {
        if (!isConfigured || activity.isFinishing || activity.isDestroyed) return
        try {
            val context = castContext ?: CastContext.getSharedInstance(activity)
            val session = context.sessionManager.currentCastSession
            if (session?.isConnected == true) {
                showConnectedSessionDialog(session)
                return
            }
            showRoutesOrWait()
        } catch (e: Exception) {
            android.util.Log.w(TAG, "Error al abrir el selector Cast", e)
            toast("No se pudo abrir Cast. Revisá la conexión e intentá de nuevo.")
        }
    }

    private fun showConnectedSessionDialog(session: CastSession) {
        if (activity.isFinishing || activity.isDestroyed) return
        AlertDialog.Builder(activity)
            .setTitle("Transmisión activa")
            .setItems(arrayOf("Recargar transmisión actual", "Cambiar dispositivo", "Detener Cast")) { _, which ->
                when (which) {
                    0 -> castCurrentStream(session)
                    1 -> showRoutesOrWait()
                    2 -> runCatching {
                        castContext?.sessionManager?.endCurrentSession(true)
                        toast("Desconectando Chromecast…")
                    }.onFailure {
                        android.util.Log.w(TAG, "No se pudo detener la sesión Cast", it)
                        toast("No se pudo detener Cast")
                    }
                }
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    private fun showRoutesOrWait() {
        val mediaRouter = router ?: return toast("No se pudo iniciar la búsqueda de dispositivos")
        val routeSelector = selector ?: return toast("Cast no está configurado")
        startDiscovery()
        val routes = availableRoutes(mediaRouter, routeSelector)
        if (routes.isNotEmpty()) {
            waitingForRouteDiscovery = false
            pendingDiscoveryRunnable?.let(handler::removeCallbacks)
            pendingDiscoveryRunnable = null
            showDeviceDialog(routes)
        } else if (!waitingForRouteDiscovery) {
            waitingForRouteDiscovery = true
            publishStatus("Buscando dispositivos Cast…")
            toast("Buscando dispositivos Cast…")
            pendingDiscoveryRunnable?.let(handler::removeCallbacks)
            val timeout = Runnable {
                pendingDiscoveryRunnable = null
                if (!waitingForRouteDiscovery || activity.isFinishing || activity.isDestroyed) return@Runnable
                waitingForRouteDiscovery = false
                val fresh = availableRoutes(mediaRouter, routeSelector)
                if (fresh.isEmpty()) {
                    publishStatus("No se encontraron dispositivos. Revisá la misma red Wi-Fi.")
                    toast("No se encontraron dispositivos. Comprobá que ambos estén en la misma red Wi-Fi.", long = true)
                } else {
                    showDeviceDialog(fresh)
                }
            }
            pendingDiscoveryRunnable = timeout
            handler.postDelayed(timeout, DISCOVERY_TIMEOUT_MS)
        }
    }

    private fun showRoutesIfWaiting(mediaRouter: MediaRouter) {
        if (!waitingForRouteDiscovery || activity.isFinishing || activity.isDestroyed) return
        val routeSelector = selector ?: return
        val routes = availableRoutes(mediaRouter, routeSelector)
        if (routes.isEmpty()) return
        waitingForRouteDiscovery = false
        pendingDiscoveryRunnable?.let(handler::removeCallbacks)
        pendingDiscoveryRunnable = null
        showDeviceDialog(routes)
    }

    private fun showDeviceDialog(routes: List<MediaRouter.RouteInfo>) {
        if (activity.isFinishing || activity.isDestroyed || routes.isEmpty()) return
        try {
            AlertDialog.Builder(activity)
                .setTitle("Seleccionar dispositivo")
                .setItems(routes.map { it.name }.toTypedArray()) { _, which ->
                    val route = routes.getOrNull(which) ?: return@setItems
                    val stream = currentStream()
                    if (stream == null || !isSupportedStream(stream)) {
                        toast("Esta fuente no se puede transmitir a Chromecast")
                        return@setItems
                    }
                    // Si se eligió el receptor que ya está seleccionado, puede no generarse
                    // un nuevo evento de sesión: recargarlo directamente evita dejar una carga pendiente.
                    if (router?.selectedRoute == route) {
                        val activeSession = castContext?.sessionManager?.currentCastSession
                        if (activeSession?.isConnected == true) {
                            castCurrentStream(activeSession)
                        } else {
                            pendingStreamOnSessionStart = true
                            toast("Esperando la conexión con el dispositivo…")
                        }
                        return@setItems
                    }
                    pendingStreamOnSessionStart = true
                    try {
                        router?.selectRoute(route)
                        // El envío se realiza al recibir onSessionStarted/onSessionResumed.
                        // No asumimos que el receptor esté listo después de un tiempo arbitrario.
                    } catch (e: Exception) {
                        pendingStreamOnSessionStart = false
                        android.util.Log.w(TAG, "No se pudo seleccionar la ruta Cast", e)
                        toast("No se pudo conectar con el dispositivo seleccionado")
                    }
                }
                .setNegativeButton("Cancelar", null)
                .show()
        } catch (e: Exception) {
            android.util.Log.w(TAG, "No se pudo mostrar el selector Cast", e)
            toast("No se pudo mostrar la lista de dispositivos")
        }
    }

    private fun loadAfterSessionStarts(session: CastSession) {
        if (!pendingStreamOnSessionStart) return
        pendingStreamOnSessionStart = false
        publishStatus("Conectado. Enviando transmisión…")
        castCurrentStream(session)
    }

    private fun isSupportedStream(stream: CastStream): Boolean = CastMediaPolicy.describe(stream) != null

    private fun castCurrentStream(session: CastSession) {
        val stream = currentStream()
        val descriptor = stream?.let(CastMediaPolicy::describe)
        if (descriptor == null) {
            toast("Esta fuente no se puede transmitir a Chromecast")
            return
        }

        val remoteClient = session.remoteMediaClient
        if (remoteClient == null) {
            toast("Chromecast conectó, pero no está disponible el control multimedia")
            return
        }

        try {
            val metadata = MediaMetadata(MediaMetadata.MEDIA_TYPE_MOVIE).apply {
                putString(MediaMetadata.KEY_TITLE, stream.title.ifBlank { "AngulismoTV" })
            }
            val mediaInfo = MediaInfo.Builder(descriptor.url)
                .setStreamType(if (descriptor.isLive) MediaInfo.STREAM_TYPE_LIVE else MediaInfo.STREAM_TYPE_BUFFERED)
                .setContentType(descriptor.contentType)
                .setMetadata(metadata)
                .build()

            remoteClient.load(
                MediaLoadRequestData.Builder()
                    .setMediaInfo(mediaInfo)
                    .setAutoplay(true)
                    .build()
            ).setResultCallback { result ->
                if (result.status.isSuccess) {
                    if (!activity.isFinishing && !activity.isDestroyed) {
                        publishStatus("Transmitiendo en el dispositivo")
                        runCatching(onCastStarted)
                        toast("Transmisión enviada a Chromecast")
                    }
                } else {
                    publishStatus("El dispositivo no pudo reproducir esta fuente. Probá otra señal.")
                    android.util.Log.w(TAG, "El receptor rechazó la transmisión. Código=${result.status.statusCode}")
                    toast("Chromecast conectó, pero no pudo reproducir esta fuente")
                }
            }
        } catch (e: Exception) {
            publishStatus("No se pudo enviar la transmisión. Probá otra fuente.")
            android.util.Log.w(TAG, "Error al enviar la transmisión a Cast", e)
            toast("No se pudo enviar la transmisión. Probá otra fuente.")
        }
    }

    private fun reportSessionFailure(message: String) {
        val wasConnectingForThisStream = pendingStreamOnSessionStart
        pendingStreamOnSessionStart = false
        if (wasConnectingForThisStream && !activity.isFinishing && !activity.isDestroyed) {
            publishStatus(message)
            toast(message, long = true)
        }
    }

    private fun publishStatus(message: String) {
        if (activity.isFinishing || activity.isDestroyed) return
        runCatching { onStatusChanged(message) }
    }

    private fun toast(message: String, long: Boolean = false) {
        if (activity.isFinishing || activity.isDestroyed) return
        Toast.makeText(activity, message, if (long) Toast.LENGTH_LONG else Toast.LENGTH_SHORT).show()
    }

    private companion object {
        const val TAG = "AngulismoTV-Cast"
        const val RECEIVER_APP_ID = "CC1AD845" // Default Media Receiver de Google Cast.
        const val DISCOVERY_TIMEOUT_MS = 8_000L
    }
}
