package com.angulismotv.player

/**
 * Acumula pulsaciones CH+/CH- mientras el reproductor termina de cambiar de canal.
 * No depende de Android para que el comportamiento sea fácil de probar.
 */
class ChannelZappingQueue {
    private var pendingDelta = 0

    fun add(delta: Int, channelCount: Int) {
        if (channelCount <= 0) {
            clear()
            return
        }
        pendingDelta = (pendingDelta + delta).mod(channelCount)
    }

    /** Devuelve y consume el desplazamiento pendiente, normalizado al catálogo actual. */
    fun consume(channelCount: Int): Int {
        if (channelCount <= 0) {
            clear()
            return 0
        }
        val result = pendingDelta.mod(channelCount)
        pendingDelta = 0
        return result
    }

    fun clear() {
        pendingDelta = 0
    }
}
