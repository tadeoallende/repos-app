package com.angulismotv.player

import android.os.Handler
import android.view.View
import android.widget.TextView

/**
 * Coordinates numeric channel entry from a TV remote, including its timeout and overlay.
 * Channel selection itself is injected so this controller does not own the Activity/catalog.
 */
class ChannelNumberEntryController(
    private val handler: Handler,
    private val overlay: TextView,
    private val channelCountProvider: () -> Int,
    private val canCommit: () -> Boolean,
    private val onNumberConfirmed: (Int) -> Unit,
    private val timeoutMs: Long = DEFAULT_TIMEOUT_MS
) {
    private var buffer = ChannelNumberInputBuffer()

    private val timeoutRunnable = Runnable { commit() }

    val hasPendingInput: Boolean
        get() = buffer.value.isNotEmpty()

    /** Resets the entry state when the channel catalog changes. */
    fun configureForChannelCount(channelCount: Int) {
        cancelTimeout()
        buffer = ChannelNumberInputBuffer.forChannelCount(channelCount)
        overlay.visibility = View.GONE
    }

    fun appendDigit(digit: Int) {
        val channelCount = channelCountProvider()
        if (channelCount <= 0 || !canCommit()) return

        val result = buffer.append(digit, channelCount) ?: return
        overlay.text = "CANAL  ${result.value}"
        overlay.visibility = View.VISIBLE
        cancelTimeout()
        handler.postDelayed(timeoutRunnable, timeoutMs)

        if (result.shouldCommitImmediately) commit()
    }

    fun commit() {
        cancelTimeout()
        val requestedNumber = buffer.takeNumber()
        overlay.visibility = View.GONE
        val channelCount = channelCountProvider()
        if (requestedNumber == null || requestedNumber !in 1..channelCount || !canCommit()) return
        onNumberConfirmed(requestedNumber)
    }

    fun clear() {
        cancelTimeout()
        buffer.clear()
        overlay.visibility = View.GONE
    }

    fun dispose() {
        clear()
    }

    private fun cancelTimeout() {
        handler.removeCallbacks(timeoutRunnable)
    }

    companion object {
        private const val DEFAULT_TIMEOUT_MS = 1_500L
    }
}
