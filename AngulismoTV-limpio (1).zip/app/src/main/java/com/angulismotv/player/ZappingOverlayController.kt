package com.angulismotv.player

import android.view.View
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import com.angulismotv.models.Channel
import com.angulismotv.utils.loadChannelLogo

/**
 * Muestra brevemente la identidad del canal durante el zapping, sin capturar el foco:
 * el logo arriba a la izquierda y el número del canal arriba a la derecha.
 */
internal class ZappingOverlayController(
    private val overlay: LinearLayout?,
    private val logo: ImageView?,
    private val numberView: TextView? = null
) {
    private val hideRunnable = Runnable {
        overlay?.visibility = View.GONE
        numberView?.visibility = View.GONE
    }

    /** @param number posición del canal en el catálogo (1 = primero); null si no se pudo determinar. */
    fun show(channel: Channel, number: Int? = null) {
        val view = overlay ?: return
        view.visibility = View.VISIBLE
        // Se mantiene por encima de los controles visibles.
        view.bringToFront()
        logo?.loadChannelLogo(channel.name, channel.logo)
        numberView?.let { label ->
            if (number != null && number > 0) {
                label.text = number.toString()
                label.contentDescription = "Canal $number"
                label.visibility = View.VISIBLE
                label.bringToFront()
            } else {
                label.visibility = View.GONE
            }
        }
        view.removeCallbacks(hideRunnable)
        view.postDelayed(hideRunnable, HIDE_DELAY_MS)
    }

    fun dispose() {
        overlay?.removeCallbacks(hideRunnable)
    }

    private companion object {
        const val HIDE_DELAY_MS = 2_000L
    }
}
