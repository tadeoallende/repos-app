package com.angulismotv.player

import com.angulismotv.models.Channel
import com.google.android.exoplayer2.ExoPlayer
import android.view.ViewGroup
import android.webkit.WebView

/**
 * Transfers the current preview engine between ChannelsFragment and UnifiedPlayerActivity.
 * Native ExoPlayer sessions keep their buffer/position; iframe sources reuse the same WebView
 * instance to avoid reloading the embed just because the player view became fullscreen.
 * All calls are made on the main thread; synchronized methods also guard against
 * lifecycle callbacks racing during Activity transitions.
 */
object InlinePlayerHandoff {
    data class Session(
        val player: ExoPlayer?,
        val channel: Channel,
        val streamUrl: String,
        val streamType: String,
        val sourceIndex: Int,
        val wasPlaying: Boolean,
        val webView: WebView? = null,
        val webViewParentIndex: Int = -1,
        val webViewLayoutParams: ViewGroup.LayoutParams? = null
    )

    private var pendingFullscreen: Session? = null
    private var pendingInline: Session? = null

    @Synchronized
    fun offerToFullscreen(session: Session) {
        // A handoff is a single-owner transition. Any unconsumed result from an older
        // transition is stale now; dispose its resources except those reused by this session.
        val oldFullscreen = pendingFullscreen
        val oldInline = pendingInline
        pendingFullscreen = session
        pendingInline = null
        disposeSupersededSessions(session, oldFullscreen, oldInline)
    }

    /** Returns the detached preview player only when the resolved source exactly matches. */
    @Synchronized
    fun takeForFullscreen(streamUrl: String, streamType: String): Session? {
        val session = pendingFullscreen ?: return null
        pendingFullscreen = null
        val matches = session.player != null &&
            session.streamUrl == streamUrl &&
            session.streamType.equals(streamType, ignoreCase = true)
        if (matches) return session

        // The fullscreen route did not consume the offered media. It is no longer safe
        // to reuse it for a different URL; release the detached engine rather than leak it.
        // If an older pending-inline record aliases the same object, clear it too so it cannot
        // later reattach an already-disposed resource.
        val oldInline = pendingInline
        if (oldInline != null && sharesResource(session, oldInline)) {
            pendingInline = null
            disposeSupersededSessions(null, session, oldInline)
        } else {
            disposeSupersededSessions(null, session)
        }
        return null
    }

    /** Takes an already-loaded iframe WebView so the fullscreen screen can reuse its page. */
    @Synchronized
    fun takePendingWebViewForFullscreen(): Session? {
        val session = pendingFullscreen ?: return null
        if (session.webView == null) return null
        pendingFullscreen = null
        return session
    }

    @Synchronized
    fun cancelPendingFullscreen(): Session? = pendingFullscreen.also { pendingFullscreen = null }

    /**
     * Atomically returns a session that was offered by the inline player but never claimed by
     * UnifiedPlayerActivity. This covers Activity startup failures before source resolution.
     */
    @Synchronized
    fun recoverUnclaimedFullscreenToInline(): Boolean {
        val session = pendingFullscreen ?: return false
        val oldInline = pendingInline
        pendingFullscreen = null
        pendingInline = session
        disposeSupersededSessions(session, oldInline)
        return true
    }

    @Synchronized
    fun returnToInline(session: Session) {
        val oldFullscreen = pendingFullscreen
        val oldInline = pendingInline
        // Clear old ownership records before disposal; a duplicated reference must never be
        // reachable from a pending slot after its underlying resource has been released.
        pendingFullscreen = null
        pendingInline = session
        disposeSupersededSessions(session, oldFullscreen, oldInline)
    }

    @Synchronized
    fun takeReturnedToInline(): Session? = pendingInline.also { pendingInline = null }

    private fun sharesResource(first: Session, second: Session): Boolean =
        (first.player != null && first.player === second.player) ||
            (first.webView != null && first.webView === second.webView)

    /** Releases obsolete resources once by identity, even if pending slots alias a session. */
    private fun disposeSupersededSessions(keep: Session?, vararg obsolete: Session?) {
        val guard = IdentityResourceDisposalGuard()
        obsolete.filterNotNull().forEach { old ->
            old.player?.let { player ->
                if (player !== keep?.player && guard.claim(player)) {
                    runCatching { player.release() }
                }
            }
            old.webView?.let { webView ->
                if (webView !== keep?.webView && guard.claim(webView)) disposeWebView(webView)
            }
        }
    }

    private fun disposeWebView(webView: WebView?) {
        if (webView == null) return
        runCatching {
            webView.stopLoading()
            (webView.parent as? ViewGroup)?.removeView(webView)
            webView.removeAllViews()
            webView.destroy()
        }
    }
}
