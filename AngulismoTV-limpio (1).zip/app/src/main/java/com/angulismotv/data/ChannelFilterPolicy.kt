package com.angulismotv.data

import com.angulismotv.models.Channel
import java.text.Normalizer
import java.util.Locale

/** Pure transformations for the channel catalogue's general-category and country filters. */
object ChannelFilterPolicy {
    private val combiningMarksRegex = "\\p{Mn}+".toRegex()

    val generalCategoryOrder: List<String> = listOf(
        "deportes", "noticias", "peliculas", "series", "infantiles", "musicales",
        "documentales", "educativos", "entretenimiento", "internacionales",
        "estilo-vida", "eventos", "otros"
    )

    fun filter(
        channels: List<Channel>,
        categoryKey: String,
        selectedCountryKey: String,
        query: String
    ): List<Channel> {
        val categoryFiltered = if (categoryKey == "todos") channels else channels.filter { channel ->
            generalCategoryFor(channel.category) == categoryKey
        }
        val countryFiltered = if (selectedCountryKey == "todos") categoryFiltered else categoryFiltered.filter { channel ->
            countryKey(channel.country) == selectedCountryKey
        }
        val normalizedQuery = normalizeSearchText(query)
        if (normalizedQuery.isEmpty()) return countryFiltered
        return countryFiltered.filter { normalizeSearchText(it.name).contains(normalizedQuery) }
    }

    fun categories(
        channels: List<Channel>,
        categoryNames: Map<String, String>,
        fallbackLabel: (String) -> String
    ): List<Pair<String, String>> {
        if (channels.isEmpty()) return emptyList()
        val presentCategories = channels.asSequence()
            .map { generalCategoryFor(it.category) }
            .toSet()
        val result = mutableListOf("todos" to "Todos")
        generalCategoryOrder.forEach { key ->
            if (key in presentCategories) {
                result += key to (categoryNames[key] ?: fallbackLabel(key))
            }
        }
        return result
    }

    fun availableCountryKeys(channels: List<Channel>): List<String> =
        channels.map { countryKey(it.country) }.distinct()

    fun normalizeSelectedCountry(channels: List<Channel>, selectedCountry: String): String {
        val available = availableCountryKeys(channels)
        return if (available.isEmpty() || (selectedCountry != "todos" && selectedCountry !in available)) {
            "todos"
        } else selectedCountry
    }

    fun generalCategoryFor(rawCategory: String): String {
        val rawValue = rawCategory.trim().lowercase(Locale.ROOT)
            .replace('_', ' ').replace('-', ' ')
        // Playlists can mix accented Spanish labels with unaccented English group-title values.
        val value = Normalizer.normalize(rawValue, Normalizer.Form.NFD)
            .replace(combiningMarksRegex, "")
        return when {
            value.contains("sport") || value.contains("deport") || value.contains("football") || value.contains("soccer") || value.contains("basket") || value.contains("racing") || value.contains("motorsport") -> "deportes"
            value.contains("news") || value.contains("noticia") || value.contains("current affairs") || value == "weather" -> "noticias"
            value.contains("movie") || value.contains("film") || value.contains("cinema") || value.contains("pelicula") -> "peliculas"
            value.contains("series") || value.contains("drama") -> "series"
            value.contains("kid") || value.contains("child") || value.contains("cartoon") || value.contains("animation") || value.contains("infantil") -> "infantiles"
            value.contains("music") || value.contains("musica") || value.contains("radio") -> "musicales"
            value.contains("documentary") || value.contains("documental") || value.contains("nature") -> "documentales"
            value.contains("education") || value.contains("educativo") || value.contains("learning") || value.contains("legislative") -> "educativos"
            value.contains("international") || value.contains("internacional") -> "internacionales"
            value.contains("lifestyle") || value.contains("estilo vida") || value.contains("estilo de vida") -> "estilo-vida"
            value.contains("event") || value.contains("evento") -> "eventos"
            value.contains("entertainment") || value.contains("comedy") || value.contains("cooking") || value.contains("travel") || value.contains("culture") || value.contains("general") || value.contains("family") -> "entretenimiento"
            else -> "otros"
        }
    }

    /** Accent-insensitive matching is more forgiving for Spanish names (e.g. "peliculas"). */
    private fun normalizeSearchText(value: String): String = Normalizer.normalize(
        value.trim().lowercase(Locale.ROOT),
        Normalizer.Form.NFD
    ).replace(combiningMarksRegex, "")

    fun countryKey(rawCountry: String): String {
        val value = rawCountry.trim().substringBefore(',')
        if (value.isBlank()) return "sin_pais"
        return value.lowercase(Locale.ROOT).replace(' ', '_')
    }

    fun countryLabel(key: String): String {
        if (key == "sin_pais") return "Sin país informado"
        val raw = key.replace('_', ' ')
        return if (raw.length == 2 && raw.all { it.isLetter() }) {
            Locale("", raw.uppercase(Locale.ROOT)).getDisplayCountry(Locale("es", "AR"))
                .ifBlank { raw.uppercase(Locale.ROOT) }
        } else {
            raw.split(' ').joinToString(" ") { it.replaceFirstChar { ch -> ch.uppercase(Locale("es", "AR")) } }
        }
    }
}
