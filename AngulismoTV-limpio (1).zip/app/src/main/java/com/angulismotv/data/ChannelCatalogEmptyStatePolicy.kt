package com.angulismotv.data

/** Presentation decision for an empty catalogue; it intentionally contains no Android Views. */
data class ChannelCatalogEmptyState(
    val message: String,
    val isError: Boolean,
    val showRetry: Boolean
)

object ChannelCatalogEmptyStatePolicy {
    /** Returns null when the result contains channels and therefore has no empty-state screen. */
    fun forResult(result: LoadResult): ChannelCatalogEmptyState? {
        if (result.channels.isNotEmpty()) return null
        return when {
            result.notConfigured -> ChannelCatalogEmptyState(
                message = "Todavía no hay una lista de canales configurada.",
                isError = false,
                showRetry = false
            )
            result.failed -> ChannelCatalogEmptyState(
                message = "No se pudo cargar la lista de canales.\nRevisá tu conexión e intentá de nuevo.",
                isError = true,
                showRetry = true
            )
            else -> ChannelCatalogEmptyState(
                message = "La lista de canales está vacía.",
                isError = false,
                showRetry = true
            )
        }
    }
}
