package com.angulismotv.data

import android.util.Log
import com.angulismotv.models.Channel
import com.angulismotv.network.HttpClient
import kotlinx.coroutines.suspendCancellableCoroutine
import okhttp3.Call
import okhttp3.Callback
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response as OkHttpResponse
import java.io.FilterInputStream
import java.io.IOException
import java.io.InputStream
import java.io.InputStreamReader
import java.net.URI
import kotlin.coroutines.resume

/** Downloads and parses a public IPTV-org M3U playlist. */
class IptvOrgDataSource(
    private val httpClient: OkHttpClient = HttpClient.shared,
    private val maxResponseBytes: Int = DEFAULT_MAX_RESPONSE_BYTES
) {
    suspend fun load(url: String): Result<List<Channel>> {
        if (url.isBlank()) return Result.success(emptyList())
        val uri = runCatching { URI(url.trim()) }.getOrNull()
        if (uri?.scheme?.equals("https", ignoreCase = true) != true || uri.host.isNullOrBlank()) {
            return Result.failure(IllegalArgumentException("La URL de IPTV-org debe usar HTTPS"))
        }
        val request = try {
            Request.Builder()
                .url(uri.toASCIIString())
                .header("Accept", "audio/x-mpegurl, application/vnd.apple.mpegurl, text/plain, */*")
                .build()
        } catch (error: Exception) {
            return Result.failure(error)
        }

        return suspendCancellableCoroutine { continuation ->
            val call = httpClient.newCall(request)
            continuation.invokeOnCancellation { call.cancel() }
            call.enqueue(object : Callback {
                override fun onFailure(call: Call, e: IOException) {
                    if (continuation.isActive) {
                        Log.w(TAG, "Falló la descarga de IPTV-org (${e.javaClass.simpleName})")
                        continuation.resume(Result.failure(e))
                    }
                }

                override fun onResponse(call: Call, response: OkHttpResponse) {
                    val result = parseResponse(response)
                    if (continuation.isActive) continuation.resume(result)
                }
            })
        }
    }

    private fun parseResponse(response: OkHttpResponse): Result<List<Channel>> = try {
        Result.success(response.use {
            if (!it.isSuccessful) throw IOException("IPTV-org respondió HTTP ${it.code}")
            if (!it.request.url.isHttps) throw IOException("Se rechazó una redirección de IPTV-org a HTTP")
            val body = it.body ?: throw IOException("Respuesta M3U vacía")
            if (body.contentLength() > maxResponseBytes) {
                throw IOException("La lista de IPTV-org supera el límite permitido")
            }
            body.byteStream().use { stream ->
                val limited = LimitedInputStream(stream, maxResponseBytes)
                InputStreamReader(limited, Charsets.UTF_8).buffered().use(M3uPlaylistParser::parse)
            }
        })
    } catch (error: Exception) {
        Log.w(TAG, "No se pudo interpretar IPTV-org (${error.javaClass.simpleName})")
        Result.failure(error)
    }

    private class LimitedInputStream(input: InputStream, private val limit: Int) : FilterInputStream(input) {
        private var bytesRead = 0

        override fun read(): Int {
            val value = super.read()
            if (value >= 0) countBytes(1)
            return value
        }

        override fun read(buffer: ByteArray, offset: Int, length: Int): Int {
            if (length == 0) return 0
            val remainingIncludingOverflowCheck = (limit - bytesRead + 1).coerceAtLeast(1)
            val read = super.read(buffer, offset, minOf(length, remainingIncludingOverflowCheck))
            if (read > 0) countBytes(read)
            return read
        }

        private fun countBytes(count: Int) {
            bytesRead += count
            if (bytesRead > limit) throw IOException("La lista de IPTV-org supera el límite de $limit bytes")
        }
    }

    companion object {
        const val DEFAULT_MAX_RESPONSE_BYTES = 32 * 1024 * 1024
        private const val TAG = "IptvOrgDataSource"
    }
}
