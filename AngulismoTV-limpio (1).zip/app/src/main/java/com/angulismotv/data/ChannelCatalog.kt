package com.angulismotv.data

import com.angulismotv.models.Channel
import java.util.Locale

/** Pure catalog operations shared by the mobile list and the TV side panel. */
object ChannelCatalog {

    /**
     * Filters by category while allowing callers to preserve the matching semantics of their UI.
     * The configured all-category key returns the original list instance.
     */
    fun filterByCategory(
        channels: List<Channel>,
        category: String,
        allCategoryKey: String = "todos",
        ignoreCase: Boolean = false
    ): List<Channel> {
        val isAllCategory = if (ignoreCase) {
            category.equals(allCategoryKey, ignoreCase = true)
        } else {
            category == allCategoryKey
        }
        if (isAllCategory) return channels

        return channels.filter { channel ->
            if (ignoreCase) channel.category.equals(category, ignoreCase = true)
            else channel.category == category
        }
    }

    /** Searches channel names without mutating or reordering the source collection. */
    fun searchByName(channels: List<Channel>, query: String): List<Channel> {
        val normalizedQuery = query.trim()
        if (normalizedQuery.isEmpty()) return channels
        return channels.filter { it.name.contains(normalizedQuery, ignoreCase = true) }
    }

    /**
     * Returns category keys using caller-selected normalization rules. These options intentionally
     * let each UI retain its historic sort/case behavior while sharing the collection mechanics.
     */
    fun uniqueCategories(
        channels: List<Channel>,
        allCategoryKey: String = "todos",
        trimValues: Boolean,
        ignoreCase: Boolean,
        sortIgnoreCase: Boolean
    ): List<String> {
        val categories = channels.map { channel ->
            if (trimValues) channel.category.trim() else channel.category
        }.filter { category ->
            category.isNotBlank() && if (ignoreCase) {
                !category.equals(allCategoryKey, ignoreCase = true)
            } else {
                category != allCategoryKey
            }
        }.distinctBy { category ->
            if (ignoreCase) normalizeCategoryKey(category) else category
        }

        return if (sortIgnoreCase) categories.sortedBy { it.lowercase(Locale.ROOT) }
        else categories.sorted()
    }

    /** Stable normalization for comparing category keys independent of the device locale. */
    fun normalizeCategoryKey(value: String): String = value.trim().lowercase(Locale.ROOT)
}
