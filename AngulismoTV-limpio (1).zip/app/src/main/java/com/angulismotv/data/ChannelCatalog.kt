package com.angulismotv.data

import com.angulismotv.models.Channel
import com.angulismotv.models.ChannelIdentity
import java.text.Normalizer
import java.util.Locale

/** Pure catalog operations shared by the mobile list and the TV side panel. */
object ChannelCatalog {

    /**
     * Filters by category while allowing callers to preserve the matching semantics of their UI.
     * The configured all-category key returns the original list instance.
     */
    fun filterByCategory(
        channels: List<Channel>,
        category: String,
        allCategoryKey: String = "todos",
        ignoreCase: Boolean = false
    ): List<Channel> {
        val isAllCategory = if (ignoreCase) {
            category.equals(allCategoryKey, ignoreCase = true)
        } else {
            category == allCategoryKey
        }
        if (isAllCategory) return channels

        return channels.filter { channel ->
            if (ignoreCase) channel.category.equals(category, ignoreCase = true)
            else channel.category == category
        }
    }

    /**
     * Searches the visible name and useful catalog metadata without mutating or reordering the
     * source collection. Accents and punctuation are normalized, and query words may be entered
     * in any order (for example, "publica tv" finds "TV Pública").
     */
    fun searchByName(channels: List<Channel>, query: String): List<Channel> {
        val normalizedQuery = normalizeSearchText(query)
        if (normalizedQuery.isEmpty()) return channels
        val terms = normalizedQuery.split(' ').filter(String::isNotBlank)
        val compactQuery = normalizedQuery.replace(" ", "")

        return channels.filter { channel ->
            val categoryKey = ChannelFilterEngine.categoryKey(channel.category)
            val searchableText = normalizeSearchText(
                listOf(
                    channel.name,
                    channel.category,
                    categoryKey,
                    categorySearchAliases(categoryKey),
                    channel.country
                ).joinToString(" ")
            )
            terms.all { it in searchableText } ||
                searchableText.replace(" ", "").contains(compactQuery)
        }
    }

    private fun categorySearchAliases(categoryKey: String): String = when (categoryKey) {
        "deportes" -> "deporte sport sports football soccer"
        "noticias" -> "noticia news current affairs"
        "peliculas" -> "pelicula cine cine peliculas movies films"
        "infantiles" -> "infantil niños kids children cartoons"
        "musicales" -> "musica music radio"
        "documentales" -> "documental documentary nature science history"
        "educativos" -> "educacion educativo education learning school"
        "internacionales" -> "internacional international internacionales mundo world global"
        "estilo-vida" -> "estilo de vida estilo vida lifestyle travel viajes cocina cooking moda fashion bienestar wellness"
        "eventos" -> "evento eventos event events especial special"
        "entretenimiento" -> "entretenimiento entertainment general comedy cultura culture"
        else -> ""
    }

    private fun normalizeSearchText(value: String): String =
        Normalizer.normalize(value.lowercase(Locale.ROOT), Normalizer.Form.NFD)
            .replace(COMBINING_MARKS_REGEX, "")
            .replace(NON_ALPHANUMERIC_REGEX, " ")
            .trim()

    /**
     * Maps logical channel identities to their first one-based position in the original catalog.
     * RecyclerView rows can then render channel numbers in O(1) instead of rescanning all channels
     * every time a row is bound. First occurrence matches the previous indexOfFirst behavior.
     */
    fun channelNumbersByIdentity(channels: List<Channel>): Map<String, Int> {
        val result = HashMap<String, Int>(channels.size)
        channels.forEachIndexed { index, channel ->
            val key = ChannelIdentity.key(channel)
            if (!result.containsKey(key)) result[key] = index + 1
        }
        return result
    }

    /**
     * Returns category keys using caller-selected normalization rules. These options intentionally
     * let each UI retain its historic sort/case behavior while sharing the collection mechanics.
     */
    fun uniqueCategories(
        channels: List<Channel>,
        allCategoryKey: String = "todos",
        trimValues: Boolean,
        ignoreCase: Boolean,
        sortIgnoreCase: Boolean
    ): List<String> {
        val categories = channels.map { channel ->
            if (trimValues) channel.category.trim() else channel.category
        }.filter { category ->
            category.isNotBlank() && if (ignoreCase) {
                !category.equals(allCategoryKey, ignoreCase = true)
            } else {
                category != allCategoryKey
            }
        }.distinctBy { category ->
            if (ignoreCase) normalizeCategoryKey(category) else category
        }

        return if (sortIgnoreCase) categories.sortedBy { it.lowercase(Locale.ROOT) }
        else categories.sorted()
    }

    /**
     * Stable key for deduplicating feed entries without discarding channels that have different
     * alternative sources. Unlike [com.angulismotv.models.ChannelIdentity], this keeps the display
     * name/logo as part of the feed identity so separately branded entries remain visible.
     */
    fun feedDeduplicationKey(channel: Channel): String {
        val optionsKey = channel.options.orEmpty().joinToString("\u001e") { option ->
            "${option.streamType.trim().lowercase(Locale.ROOT)}\u001f${option.iframe.trim()}"
        }
        return listOf(
            channel.name.trim().lowercase(Locale.ROOT),
            channel.logo.trim().lowercase(Locale.ROOT),
            channel.streamUrl.orEmpty().trim(),
            channel.streamType.orEmpty().trim().lowercase(Locale.ROOT),
            optionsKey
        ).joinToString("\u001d")
    }

    /** Stable normalization for comparing category keys independent of the device locale. */
    fun normalizeCategoryKey(value: String): String = value.trim().lowercase(Locale.ROOT)

    private val COMBINING_MARKS_REGEX = Regex("\\p{M}+")
    private val NON_ALPHANUMERIC_REGEX = Regex("[^\\p{L}\\p{N}]+")
}
