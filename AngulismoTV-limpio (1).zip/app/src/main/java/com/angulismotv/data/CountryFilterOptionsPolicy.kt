package com.angulismotv.data

import java.util.Locale

/** Stable presentation model for the country picker. Keeps sorting and selection fallback testable. */
data class CountryFilterOption(val key: String, val label: String)

object CountryFilterOptionsPolicy {
    const val ALL_COUNTRIES_KEY = "todos"

    fun build(
        countryKeys: Iterable<String>,
        labelFor: (String) -> String
    ): List<CountryFilterOption> {
        val countries = countryKeys.asSequence()
            .map { it.trim().lowercase(Locale.ROOT) }
            .filter { it.isNotEmpty() && it != ALL_COUNTRIES_KEY }
            .distinct()
            .sortedBy { labelFor(it).lowercase(Locale.ROOT) }
            .map { CountryFilterOption(it, labelFor(it)) }
            .toList()

        return listOf(CountryFilterOption(ALL_COUNTRIES_KEY, "Todos los países")) + countries
    }

    fun selectedIndex(options: List<CountryFilterOption>, selectedKey: String): Int =
        options.indexOfFirst { it.key.equals(selectedKey, ignoreCase = true) }.coerceAtLeast(0)

    fun keyAt(options: List<CountryFilterOption>, index: Int): String? =
        options.getOrNull(index)?.key
}
