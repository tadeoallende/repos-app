package com.angulismotv.data

import android.util.Log
import com.angulismotv.BuildConfig
import com.angulismotv.models.Channel
import kotlinx.coroutines.async
import kotlinx.coroutines.coroutineScope

/** Result of loading the configured feeds. */
data class LoadResult(
    val channels: List<Channel>,
    val failed: Boolean = false,
    val notConfigured: Boolean = false,
    /** True when usable data loaded, but at least one configured source failed. */
    val partialFailure: Boolean = false,
    /** Human-readable internal diagnostic label for the source selected by the repository. */
    val sourceName: String? = null
)

/** Loads IPTV-org first and falls back to the user's configured JSON feeds if necessary. */
object ChannelRepository {
    private val iptvOrgDataSource by lazy(LazyThreadSafetyMode.SYNCHRONIZED) { IptvOrgDataSource() }
    private val fallbackDataSource by lazy(LazyThreadSafetyMode.SYNCHRONIZED) { ChannelFeedDataSource() }

    private data class PrimarySourceLoad(
        val url: String,
        val result: Result<List<Channel>>,
        val channels: List<Channel>
    )

    suspend fun loadAll(): LoadResult = coroutineScope {
        val primary = loadPrimarySource()
        if (primary.channels.isNotEmpty()) {
            Log.i(TAG, "Canales cargados desde IPTV-org: ${primary.channels.size}")
            return@coroutineScope LoadResult(
                channels = primary.channels,
                sourceName = "IPTV-org"
            )
        }

        logPrimarySourceFailure(primary)
        loadFallbackSources(primary)
    }

    private suspend fun loadPrimarySource(): PrimarySourceLoad {
        // Resolve the official Argentina-only list even if an old secret still points worldwide.
        val url = IptvOrgPlaylistPolicy.resolve(BuildConfig.IPTV_ORG_URL)
        val result = if (url.isBlank()) Result.success(emptyList()) else iptvOrgDataSource.load(url)
        return PrimarySourceLoad(url, result, result.getOrDefault(emptyList()).distinctChannels())
    }

    private fun logPrimarySourceFailure(primary: PrimarySourceLoad) {
        if (primary.result.isFailure) {
            Log.w(TAG, "IPTV-org no disponible; se intentarán las fuentes de fallback")
        } else if (primary.url.isNotBlank()) {
            Log.w(TAG, "IPTV-org no devolvió canales utilizables; se intentarán las fuentes de fallback")
        }
    }

    private suspend fun loadFallbackSources(primary: PrimarySourceLoad): LoadResult = coroutineScope {
        val channelsUrl = BuildConfig.CHANNELS_URL.trim()
        val eventsUrl = BuildConfig.EVENTS_URL.trim()
        if (channelsUrl.isBlank() && eventsUrl.isBlank()) {
            return@coroutineScope LoadResult(
                channels = emptyList(),
                failed = primary.result.isFailure,
                notConfigured = primary.url.isBlank(),
                sourceName = null
            )
        }

        val direct = async { fallbackDataSource.load(channelsUrl, defaultCategory = "todos") }
        val events = async { fallbackDataSource.load(eventsUrl, defaultCategory = "deportes") }
        val results = listOf(direct.await(), events.await())
        val channels = results.flatMap { it.getOrDefault(emptyList()) }.distinctChannels()
        val fallbackFailure = (channelsUrl.isNotBlank() && results[0].isFailure) ||
            (eventsUrl.isNotBlank() && results[1].isFailure)
        val primaryFailed = primary.url.isNotBlank() && primary.result.isFailure

        LoadResult(
            channels = channels,
            failed = channels.isEmpty() && (primaryFailed || fallbackFailure),
            notConfigured = channels.isEmpty() && primary.url.isBlank() &&
                channelsUrl.isBlank() && eventsUrl.isBlank(),
            partialFailure = channels.isNotEmpty() && (primaryFailed || fallbackFailure),
            sourceName = channels.takeIf { it.isNotEmpty() }?.let { "Fuentes propias (fallback)" }
        )
    }

    private fun List<Channel>.distinctChannels(): List<Channel> =
        distinctBy(ChannelCatalog::feedDeduplicationKey)

    private const val TAG = "ChannelRepository"
}
