package com.angulismotv.data

import android.net.Uri
import android.util.Log
import com.angulismotv.BuildConfig
import com.angulismotv.models.Channel
import com.angulismotv.models.StreamOption
import com.angulismotv.models.StreamType
import com.angulismotv.network.HttpClient
import com.google.gson.Gson
import com.google.gson.JsonParseException
import com.google.gson.annotations.SerializedName
import kotlinx.coroutines.async
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.suspendCancellableCoroutine
import okhttp3.Call
import okhttp3.Callback
import okhttp3.Request
import okhttp3.Response as OkHttpResponse
import java.io.IOException
import kotlin.coroutines.resume
import java.io.InputStream

/** Resultado de cargar la lista: distingue configuración ausente de una carga fallida. */
data class LoadResult(
    val channels: List<Channel>,
    val failed: Boolean = false,
    val notConfigured: Boolean = false,
    /** Indica que se cargaron algunos datos, pero al menos una fuente falló. */
    val partialFailure: Boolean = false
)

/**
 * Repositorio de canales y eventos.
 *
 * - Las peticiones usan el dispatcher asíncrono de OkHttp y se cancelan con la coroutine.
 * - Las respuestas tienen un límite de tamaño para evitar consumo excesivo de memoria.
 * - La cancelación de coroutines se propaga en vez de convertirse en un error de red.
 * - Se descartan canales incompletos y fuentes de reproducción que no usen HTTP(S).
 */
object ChannelRepository {

    private const val TAG = "ChannelRepository"
    private const val MAX_RESPONSE_BYTES = 4 * 1024 * 1024
    private val gson = Gson()

    private data class Response(val channels: List<ChannelDto>?)

    private data class ChannelDto(
        val name: String?,
        val logo: String?,
        val streamUrl: String?,
        val streamType: String?,
        val show: Boolean?,
        val category: String?,
        val options: List<OptionDto>?
    )

    private data class OptionDto(
        val name: String?,
        @SerializedName("iframe") val url: String?,
        val streamType: String?
    )

    suspend fun loadAll(): LoadResult = coroutineScope {
        val channelsUrl = BuildConfig.CHANNELS_URL.trim()
        val eventsUrl = BuildConfig.EVENTS_URL.trim()
        if (channelsUrl.isBlank() && eventsUrl.isBlank()) {
            return@coroutineScope LoadResult(emptyList(), notConfigured = true)
        }

        val direct = async { load(channelsUrl, defaultCategory = "todos") }
        val events = async { load(eventsUrl, defaultCategory = "deportes") }
        val results = listOf(direct.await(), events.await())
        val channels = results.flatMap { it.getOrDefault(emptyList()) }
        val anyFailure = results.any { it.isFailure }

        // Evita duplicados accidentales si el mismo canal aparece en ambos feeds.
        val uniqueChannels = channels.distinctBy {
            "${it.name.trim().lowercase()}|${it.logo.trim().lowercase()}|${it.streamUrl.orEmpty().trim()}"
        }
        LoadResult(
            channels = uniqueChannels,
            failed = uniqueChannels.isEmpty() && anyFailure,
            partialFailure = uniqueChannels.isNotEmpty() && anyFailure
        )
    }

    private suspend fun load(url: String, defaultCategory: String): Result<List<Channel>> {
        if (url.isBlank()) return Result.success(emptyList())
        val uri = requireHttpUrl(url)
            ?: return Result.failure(IllegalArgumentException("La URL de datos debe usar HTTP o HTTPS"))
        val request = try {
            Request.Builder()
                .url(uri.toString())
                .header("Accept", "application/json")
                .build()
        } catch (error: Exception) {
            return Result.failure(error)
        }

        return suspendCancellableCoroutine { continuation ->
            val call = HttpClient.shared.newCall(request)
            // Si la pantalla desaparece o se inicia otra carga, cancelar también la petición real.
            continuation.invokeOnCancellation { call.cancel() }
            call.enqueue(object : Callback {
                override fun onFailure(call: Call, error: IOException) {
                    if (continuation.isActive) {
                        Log.w(TAG, "Falló la carga de una fuente (${error.javaClass.simpleName})")
                        continuation.resume(Result.failure(error))
                    }
                }

                override fun onResponse(call: Call, response: OkHttpResponse) {
                    val result = try {
                        response.use {
                            if (!it.isSuccessful) throw IOException("HTTP ${it.code}")
                            val body = it.body ?: throw IOException("Respuesta vacía")
                            if (body.contentLength() > MAX_RESPONSE_BYTES) {
                                throw IOException("La respuesta supera el límite permitido")
                            }
                            val json = body.byteStream().use { input -> input.readLimited(MAX_RESPONSE_BYTES) }
                            val parsed = gson.fromJson(json, Response::class.java)
                                ?: throw JsonParseException("El JSON no contiene un objeto válido")
                            Result.success(parsed.channels.orEmpty().mapNotNull { dto -> dto.toChannel(defaultCategory) })
                        }
                    } catch (error: Exception) {
                        Log.w(TAG, "Falló la carga de una fuente (${error.javaClass.simpleName})")
                        Result.failure(error)
                    }
                    if (continuation.isActive) continuation.resume(result)
                }
            })
        }
    }

    private fun ChannelDto.toChannel(defaultCategory: String): Channel? {
        if (show == false) return null
        val cleanName = name?.trim()?.takeIf { it.isNotEmpty() } ?: return null
        val cleanStreamUrl = streamUrl?.trim()?.takeIf { requireHttpUrl(it) != null }
        val cleanOptions = options.orEmpty().mapNotNull { option ->
            val optionUrl = option.url?.trim()?.takeIf { requireHttpUrl(it) != null } ?: return@mapNotNull null
            StreamOption(
                name = option.name?.trim()?.takeIf { it.isNotEmpty() } ?: "Opción",
                iframe = optionUrl,
                streamType = normalizeStreamType(option.streamType, StreamType.IFRAME)
            )
        }.distinctBy { it.iframe }

        if (cleanStreamUrl == null && cleanOptions.isEmpty()) return null
        return Channel(
            name = cleanName,
            logo = logo?.trim().orEmpty(),
            streamUrl = cleanStreamUrl,
            streamType = normalizeStreamType(streamType, StreamType.HLS),
            options = cleanOptions.ifEmpty { null },
            category = category?.trim()?.takeIf { it.isNotEmpty() } ?: defaultCategory
        )
    }

    private fun normalizeStreamType(value: String?, fallback: String): String {
        val normalized = value?.trim()?.lowercase()
        return when (normalized) {
            StreamType.HLS, StreamType.DASH, StreamType.MP4, StreamType.IFRAME, StreamType.AUTO -> normalized
            else -> fallback
        }
    }

    private fun requireHttpUrl(value: String): Uri? {
        val uri = runCatching { Uri.parse(value) }.getOrNull() ?: return null
        val scheme = uri.scheme?.lowercase()
        return uri.takeIf { !it.host.isNullOrBlank() && (scheme == "http" || scheme == "https") }
    }

    private fun InputStream.readLimited(limit: Int): String {
        val output = java.io.ByteArrayOutputStream(minOf(limit, 16 * 1024))
        val buffer = ByteArray(8 * 1024)
        var total = 0
        while (true) {
            val read = read(buffer)
            if (read < 0) break
            total += read
            if (total > limit) throw IOException("La respuesta supera el límite permitido")
            output.write(buffer, 0, read)
        }
        return output.toString(Charsets.UTF_8.name())
    }
}
