package com.angulismotv.data

import android.util.Log
import com.angulismotv.BuildConfig
import com.angulismotv.models.Channel
import kotlinx.coroutines.async
import kotlinx.coroutines.coroutineScope
import java.util.Locale

/** Result of loading the configured feeds. */
data class LoadResult(
    val channels: List<Channel>,
    val failed: Boolean = false,
    val notConfigured: Boolean = false,
    /** True when usable data loaded, but at least one configured source failed. */
    val partialFailure: Boolean = false,
    /** Human-readable internal diagnostic label for the source selected by the repository. */
    val sourceName: String? = null
)

/** Loads IPTV-org first and falls back to the user's configured JSON feeds if necessary. */
object ChannelRepository {
    private val iptvOrgDataSource by lazy(LazyThreadSafetyMode.SYNCHRONIZED) { IptvOrgDataSource() }
    private val fallbackDataSource by lazy(LazyThreadSafetyMode.SYNCHRONIZED) { ChannelFeedDataSource() }

    suspend fun loadAll(): LoadResult = coroutineScope {
        val configuredPrimaryUrl = BuildConfig.IPTV_ORG_URL.trim()
        // "disabled" is an explicit opt-out; an unset/empty build property keeps the default URL.
        val primaryUrl = configuredPrimaryUrl.takeUnless { it.equals("disabled", ignoreCase = true) }.orEmpty()
        val primaryResult = if (primaryUrl.isBlank()) {
            Result.success(emptyList())
        } else {
            iptvOrgDataSource.load(primaryUrl)
        }
        val primaryChannels = primaryResult.getOrDefault(emptyList()).distinctChannels()

        // A non-empty, valid playlist is considered a successful primary source.
        if (primaryChannels.isNotEmpty()) {
            Log.i(TAG, "Canales cargados desde IPTV-org: ${primaryChannels.size}")
            return@coroutineScope LoadResult(
                channels = primaryChannels,
                sourceName = "IPTV-org"
            )
        }
        if (primaryResult.isFailure) {
            Log.w(TAG, "IPTV-org no disponible; se intentarán las fuentes de fallback")
        } else if (primaryUrl.isNotBlank()) {
            Log.w(TAG, "IPTV-org no devolvió canales utilizables; se intentarán las fuentes de fallback")
        }

        val channelsUrl = BuildConfig.CHANNELS_URL.trim()
        val eventsUrl = BuildConfig.EVENTS_URL.trim()
        if (channelsUrl.isBlank() && eventsUrl.isBlank()) {
            return@coroutineScope LoadResult(
                channels = emptyList(),
                failed = primaryResult.isFailure,
                notConfigured = primaryUrl.isBlank(),
                sourceName = null
            )
        }

        val direct = async { fallbackDataSource.load(channelsUrl, defaultCategory = "todos") }
        val events = async { fallbackDataSource.load(eventsUrl, defaultCategory = "deportes") }
        val results = listOf(direct.await(), events.await())
        val fallbackChannels = results.flatMap { it.getOrDefault(emptyList()) }.distinctChannels()
        val fallbackFailure = (channelsUrl.isNotBlank() && results[0].isFailure) ||
            (eventsUrl.isNotBlank() && results[1].isFailure)
        val primaryFailed = primaryUrl.isNotBlank() && primaryResult.isFailure

        LoadResult(
            channels = fallbackChannels,
            failed = fallbackChannels.isEmpty() && (primaryFailed || fallbackFailure),
            notConfigured = fallbackChannels.isEmpty() && primaryUrl.isBlank() && channelsUrl.isBlank() && eventsUrl.isBlank(),
            partialFailure = fallbackChannels.isNotEmpty() && (primaryFailed || fallbackFailure),
            sourceName = fallbackChannels.takeIf { it.isNotEmpty() }?.let { "Fuentes propias (fallback)" }
        )
    }

    private fun List<Channel>.distinctChannels(): List<Channel> = distinctBy { channel ->
        "${channel.name.trim().lowercase(Locale.ROOT)}|${channel.logo.trim().lowercase(Locale.ROOT)}|${channel.streamUrl.orEmpty().trim()}"
    }

    private const val TAG = "ChannelRepository"
}
