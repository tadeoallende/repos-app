package com.angulismotv.data

import com.angulismotv.BuildConfig
import com.angulismotv.models.Channel
import kotlinx.coroutines.async
import kotlinx.coroutines.coroutineScope

/** Result of loading the configured feeds. */
data class LoadResult(
    val channels: List<Channel>,
    val failed: Boolean = false,
    val notConfigured: Boolean = false,
    /** True when some valid data loaded, but at least one source failed. */
    val partialFailure: Boolean = false
)

/** Coordinates configured feeds and merges their results into a de-duplicated catalog. */
object ChannelRepository {
    private val dataSource by lazy(LazyThreadSafetyMode.SYNCHRONIZED) { ChannelFeedDataSource() }

    suspend fun loadAll(): LoadResult = coroutineScope {
        val channelsUrl = BuildConfig.CHANNELS_URL.trim()
        val eventsUrl = BuildConfig.EVENTS_URL.trim()
        if (channelsUrl.isBlank() && eventsUrl.isBlank()) {
            return@coroutineScope LoadResult(emptyList(), notConfigured = true)
        }

        val direct = async { dataSource.load(channelsUrl, defaultCategory = "todos") }
        val events = async { dataSource.load(eventsUrl, defaultCategory = "deportes") }
        val results = listOf(direct.await(), events.await())
        val channels = results.flatMap { it.getOrDefault(emptyList()) }
        val anyFailure = results.any { it.isFailure }

        val uniqueChannels = channels.distinctBy {
            "${it.name.trim().lowercase()}|${it.logo.trim().lowercase()}|${it.streamUrl.orEmpty().trim()}"
        }
        LoadResult(
            channels = uniqueChannels,
            failed = uniqueChannels.isEmpty() && anyFailure,
            partialFailure = uniqueChannels.isNotEmpty() && anyFailure
        )
    }
}
