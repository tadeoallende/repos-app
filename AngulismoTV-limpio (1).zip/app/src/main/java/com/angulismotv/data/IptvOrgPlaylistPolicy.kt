package com.angulismotv.data

import java.net.URI

/**
 * Source policy for the current AngulismoTV catalog rollout.
 * Any playlist URL under the official iptv-org.github.io/iptv/ path is normalized to Argentina so a stale build secret
 * cannot silently restore the worldwide playlist and its hundreds of source categories.
 * Custom HTTPS M3U URLs on other hosts remain configurable; "disabled" opts out explicitly.
 */
internal object IptvOrgPlaylistPolicy {
    const val ARGENTINA_PLAYLIST_URL = "https://iptv-org.github.io/iptv/countries/ar.m3u"
    private const val OFFICIAL_HOST = "iptv-org.github.io"
    private const val ARGENTINA_PATH = "/iptv/countries/ar.m3u"

    fun resolve(configuredUrl: String?): String {
        val value = configuredUrl?.trim().orEmpty()
        if (value.equals("disabled", ignoreCase = true)) return ""
        if (value.isBlank()) return ARGENTINA_PLAYLIST_URL

        val uri = runCatching { URI(value) }.getOrNull()
        if (uri != null) {
            val isOfficialPlaylist = uri.host?.equals(OFFICIAL_HOST, ignoreCase = true) == true &&
                uri.path.orEmpty().startsWith("/iptv/", ignoreCase = true)
            if (isOfficialPlaylist && !uri.path.equals(ARGENTINA_PATH, ignoreCase = true)) {
                return ARGENTINA_PLAYLIST_URL
            }
        }
        return value
    }
}
