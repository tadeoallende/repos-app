package com.angulismotv.data

import com.angulismotv.models.Channel
import java.util.Locale

/**
 * Owns the mutable filtering state for the channels screen. Android views remain responsible for
 * rendering and focus, while this class keeps selection normalization and filtering consistent when
 * the catalog is replaced.
 */
class ChannelCatalogFilterController {
    companion object {
        const val ALL = "todos"
    }

    private var catalog: List<Channel> = emptyList()

    var selectedCategoryKey: String = ALL
        private set

    var selectedCountryKey: String = ALL
        private set

    var query: String = ""
        private set

    /** Replace the catalog and optionally reset only category/country selection, not the search. */
    fun replaceCatalog(channels: List<Channel>, resetSelection: Boolean = false) {
        catalog = channels
        if (resetSelection) {
            selectedCategoryKey = ALL
            selectedCountryKey = ALL
        }
        normalizeSelection()
    }

    fun selectCategory(key: String) {
        val normalized = key.trim().lowercase(Locale.ROOT).ifBlank { ALL }
        val available = catalog.asSequence()
            .map { ChannelFilterPolicy.generalCategoryFor(it.category) }
            .toSet()
        selectedCategoryKey = if (normalized == ALL || normalized in available) normalized else ALL
    }

    fun selectCountry(key: String) {
        val normalized = key.trim().lowercase(Locale.ROOT)
            .replace(' ', '_')
            .ifBlank { ALL }
        selectedCountryKey = if (normalized == ALL) ALL else normalized
        normalizeSelectedCountry()
    }

    fun setQuery(value: String) {
        query = value
    }

    fun filter(): List<Channel> = ChannelFilterPolicy.filter(
        channels = catalog,
        categoryKey = selectedCategoryKey,
        selectedCountryKey = selectedCountryKey,
        query = query
    )

    fun categoryOptions(
        categoryNames: Map<String, String>,
        fallbackLabel: (String) -> String
    ): List<Pair<String, String>> = ChannelFilterPolicy.categories(catalog, categoryNames, fallbackLabel)

    fun availableCountryKeys(): List<String> = ChannelFilterPolicy.availableCountryKeys(catalog)

    private fun normalizeSelection() {
        val availableCategories = catalog.asSequence()
            .map { ChannelFilterPolicy.generalCategoryFor(it.category) }
            .toSet()
        if (selectedCategoryKey != ALL && selectedCategoryKey !in availableCategories) {
            selectedCategoryKey = ALL
        }
        normalizeSelectedCountry()
    }

    private fun normalizeSelectedCountry() {
        selectedCountryKey = ChannelFilterPolicy.normalizeSelectedCountry(catalog, selectedCountryKey)
    }
}
