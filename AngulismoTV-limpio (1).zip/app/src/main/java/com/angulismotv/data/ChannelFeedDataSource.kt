package com.angulismotv.data

import android.util.Log
import com.angulismotv.models.Channel
import com.angulismotv.models.StreamOption
import com.angulismotv.models.StreamType
import com.angulismotv.network.HttpClient
import com.angulismotv.player.StreamUrlPolicy
import com.google.gson.Gson
import com.google.gson.JsonParseException
import com.google.gson.annotations.SerializedName
import kotlinx.coroutines.suspendCancellableCoroutine
import okhttp3.Call
import okhttp3.Callback
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response as OkHttpResponse
import java.io.IOException
import java.io.InputStream
import java.util.Locale
import kotlin.coroutines.resume

/** Fetches and maps one JSON channel feed. Aggregating multiple feeds is ChannelRepository's job. */
class ChannelFeedDataSource(
    private val httpClient: OkHttpClient = HttpClient.shared,
    private val gson: Gson = Gson(),
    private val maxResponseBytes: Int = DEFAULT_MAX_RESPONSE_BYTES
) {
    private data class FeedResponse(val channels: List<ChannelDto>?)

    private data class ChannelDto(
        val name: String?,
        val logo: String?,
        val streamUrl: String?,
        val streamType: String?,
        val show: Boolean?,
        val category: String?,
        val country: String?,
        val options: List<OptionDto>?
    )

    private data class OptionDto(
        val name: String?,
        @SerializedName("iframe") val url: String?,
        val streamType: String?
    )

    suspend fun load(url: String, defaultCategory: String): Result<List<Channel>> {
        if (url.isBlank()) return Result.success(emptyList())
        val uri = StreamUrlPolicy.parseHttpUrl(url)
            ?: return Result.failure(IllegalArgumentException("La URL de datos debe usar HTTP o HTTPS"))
        val request = try {
            Request.Builder()
                .url(uri.toString())
                .header("Accept", "application/json")
                .build()
        } catch (error: Exception) {
            return Result.failure(error)
        }

        return suspendCancellableCoroutine { continuation ->
            val call = httpClient.newCall(request)
            continuation.invokeOnCancellation { call.cancel() }
            call.enqueue(object : Callback {
                override fun onFailure(call: Call, error: IOException) {
                    if (continuation.isActive) {
                        Log.w(TAG, "Falló la carga de una fuente (${error.javaClass.simpleName})")
                        continuation.resume(Result.failure(error))
                    }
                }

                override fun onResponse(call: Call, response: OkHttpResponse) {
                    val result = parseResponse(response, defaultCategory)
                    if (continuation.isActive) continuation.resume(result)
                }
            })
        }
    }

    private fun parseResponse(
        response: OkHttpResponse,
        defaultCategory: String
    ): Result<List<Channel>> = try {
        response.use {
            if (!it.isSuccessful) throw IOException("HTTP ${it.code}")
            val body = it.body ?: throw IOException("Respuesta vacía")
            if (body.contentLength() > maxResponseBytes) {
                throw IOException("La respuesta supera el límite permitido")
            }
            val json = body.byteStream().use { input -> input.readLimited(maxResponseBytes) }
            val parsed = gson.fromJson(json, FeedResponse::class.java)
                ?: throw JsonParseException("El JSON no contiene un objeto válido")
            Result.success(parsed.channels.orEmpty().mapNotNull { dto -> dto.toChannel(defaultCategory) })
        }
    } catch (error: Exception) {
        Log.w(TAG, "Falló la carga de una fuente (${error.javaClass.simpleName})")
        Result.failure(error)
    }

    private fun ChannelDto.toChannel(defaultCategory: String): Channel? {
        if (show == false) return null
        val cleanName = name?.trim()?.takeIf { it.isNotEmpty() } ?: return null
        val cleanStreamUrl = streamUrl?.trim()?.takeIf { StreamUrlPolicy.isHttpUrl(it) }
        val cleanOptions = options.orEmpty().mapNotNull { option ->
            val optionUrl = option.url?.trim()?.takeIf { StreamUrlPolicy.isHttpUrl(it) } ?: return@mapNotNull null
            StreamOption(
                name = option.name?.trim()?.takeIf { it.isNotEmpty() } ?: "Opción",
                iframe = optionUrl,
                streamType = normalizeStreamType(option.streamType, StreamType.IFRAME)
            )
        }.distinctBy { it.iframe }

        if (cleanStreamUrl == null && cleanOptions.isEmpty()) return null
        return Channel(
            name = cleanName,
            logo = logo?.trim().orEmpty(),
            streamUrl = cleanStreamUrl,
            streamType = normalizeStreamType(streamType, StreamType.HLS),
            options = cleanOptions.ifEmpty { null },
            category = category?.trim()?.takeIf { it.isNotEmpty() } ?: defaultCategory,
            country = country?.trim().orEmpty()
        )
    }

    private fun normalizeStreamType(value: String?, fallback: String): String {
        val normalized = value?.trim()?.lowercase(Locale.ROOT)
        return when (normalized) {
            StreamType.HLS, StreamType.DASH, StreamType.MP4, StreamType.IFRAME, StreamType.AUTO -> normalized
            else -> fallback
        }
    }

    private fun InputStream.readLimited(limit: Int): String {
        val output = java.io.ByteArrayOutputStream(minOf(limit, 16 * 1024))
        val buffer = ByteArray(8 * 1024)
        var total = 0
        while (true) {
            val read = read(buffer)
            if (read < 0) break
            total += read
            if (total > limit) throw IOException("La respuesta supera el límite permitido")
            output.write(buffer, 0, read)
        }
        return output.toString(Charsets.UTF_8.name())
    }

    companion object {
        const val DEFAULT_MAX_RESPONSE_BYTES = 4 * 1024 * 1024
        private const val TAG = "ChannelFeedDataSource"
    }
}
