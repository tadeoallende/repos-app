package com.angulismotv.ui

import org.junit.Assert.assertEquals
import org.junit.Test

class ChannelCategoryRailPolicyTest {
    @Test
    fun `all category is always first and empty input gets a usable fallback`() {
        assertEquals(listOf("todos" to "Todos"), ChannelCategoryRailPolicy.normalize(emptyList()))
        assertEquals(
            listOf("todos" to "Todas", "deportes" to "Deportes"),
            ChannelCategoryRailPolicy.normalize(listOf("Deportes" to "Deportes", "TODOS" to "Todas"))
        )
    }

    @Test
    fun `normalizes keys and removes blank and duplicate categories`() {
        assertEquals(
            listOf("todos" to "Todos", "deportes" to "Deportes", "otros" to "Otros"),
            ChannelCategoryRailPolicy.normalize(
                listOf(
                    "deportes" to "Deportes",
                    " DEPORTES " to "Duplicada",
                    " " to "Sin clave",
                    "otros" to "",
                    "todos" to "Todos"
                )
            )
        )
    }
}
