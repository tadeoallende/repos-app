package com.angulismotv.ui

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class ViewLifecycleGateTest {
    @Test
    fun startsInactiveAndActivatesForCurrentView() {
        val gate = ViewLifecycleGate()
        assertFalse(gate.isActive())

        val token = gate.activate()
        assertTrue(gate.isActive())
        assertTrue(gate.isActive(token))
        assertFalse(gate.isActive(token + 1))
    }

    @Test
    fun invalidationRejectsCallbacksFromDestroyedView() {
        val gate = ViewLifecycleGate()
        val oldToken = gate.activate()

        gate.invalidate()

        assertFalse(gate.isActive())
        assertFalse(gate.isActive(oldToken))
    }

    @Test
    fun reactivationDoesNotAcceptPreviousViewToken() {
        val gate = ViewLifecycleGate()
        val oldToken = gate.activate()
        gate.invalidate()
        val newToken = gate.activate()

        assertTrue(gate.isActive(newToken))
        assertFalse(gate.isActive(oldToken))
    }

    @Test
    fun repeatedInvalidationIsSafe() {
        val gate = ViewLifecycleGate()
        val token = gate.activate()

        gate.invalidate()
        gate.invalidate()

        assertFalse(gate.isActive(token))
        assertFalse(gate.isActive())
    }
}
