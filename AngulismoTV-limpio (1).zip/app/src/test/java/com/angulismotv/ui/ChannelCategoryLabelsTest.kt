package com.angulismotv.ui

import org.junit.Assert.assertEquals
import org.junit.Test

class ChannelCategoryLabelsTest {
    @Test
    fun `known categories use the established Spanish labels`() {
        assertEquals("Películas", ChannelCategoryLabels.displayName("peliculas"))
        assertEquals("Estilo de vida", ChannelCategoryLabels.displayName("estilo-vida"))
        assertEquals("Internacionales", ChannelCategoryLabels.displayName("internacionales"))
    }

    @Test
    fun `unknown categories are cleaned and capitalized for display`() {
        assertEquals("Canales Premium", ChannelCategoryLabels.displayName(" canales_premium "))
        assertEquals("Eventos Especiales", ChannelCategoryLabels.displayName("EVENTOS-ESPECIALES"))
    }
}
