package com.angulismotv.ui

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class DebouncedActionControllerTest {
    private class FakeScheduler {
        val pending = mutableListOf<Runnable>()
        val history = mutableListOf<Runnable>()
        val delays = mutableListOf<Long>()
        fun controller(delay: Long = 300L) = DebouncedActionController(
            delayMillis = delay,
            postDelayed = { task, ms -> pending += task; history += task; delays += ms },
            removeCallbacks = { task -> pending.remove(task) }
        )
        fun runPending() {
            val task = pending.removeAt(0)
            task.run()
        }
    }

    @Test
    fun `only the latest scheduled action remains pending`() {
        val scheduler = FakeScheduler()
        val controller = scheduler.controller()
        val output = mutableListOf<String>()

        controller.schedule { output += "first" }
        controller.schedule { output += "latest" }
        assertEquals(1, scheduler.pending.size)
        assertEquals(listOf(300L, 300L), scheduler.delays)
        scheduler.runPending()
        assertEquals(listOf("latest"), output)
    }

    @Test
    fun `stale runnable cannot execute if scheduler races with cancellation`() {
        val scheduler = FakeScheduler()
        val controller = scheduler.controller()
        val output = mutableListOf<String>()

        controller.schedule { output += "stale" }
        val stale = scheduler.history.last()
        controller.schedule { output += "current" }
        stale.run()
        scheduler.runPending()

        assertEquals(listOf("current"), output)
    }

    @Test
    fun `cancel removes work and does not execute it`() {
        val scheduler = FakeScheduler()
        val controller = scheduler.controller()
        var called = false
        controller.schedule { called = true }
        controller.cancel()

        assertTrue(scheduler.pending.isEmpty())
        assertFalse(called)
    }

    @Test
    fun `dispose cancels work and rejects future scheduling`() {
        val scheduler = FakeScheduler()
        val controller = scheduler.controller()
        var calls = 0
        controller.schedule { calls++ }
        controller.dispose()
        controller.schedule { calls += 100 }

        assertTrue(scheduler.pending.isEmpty())
        assertEquals(0, calls)
    }

    @Test
    fun `completed action can be scheduled again`() {
        val scheduler = FakeScheduler()
        val controller = scheduler.controller()
        var calls = 0
        controller.schedule { calls++ }
        scheduler.runPending()
        controller.schedule { calls++ }
        scheduler.runPending()

        assertEquals(2, calls)
    }
}
