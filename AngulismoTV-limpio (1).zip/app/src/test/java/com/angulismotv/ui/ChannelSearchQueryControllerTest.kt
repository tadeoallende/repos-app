package com.angulismotv.ui

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class ChannelSearchQueryControllerTest {
    private class FakeScheduler {
        val pending = mutableListOf<Runnable>()
        val history = mutableListOf<Runnable>()
        fun controller(
            onQueryChanged: (String) -> Unit = {},
            onApply: () -> Unit
        ) = ChannelSearchQueryController(
            delayMillis = 300L,
            postDelayed = { task, delay ->
                require(delay == 300L)
                pending += task
                history += task
            },
            removeCallbacks = { task -> pending.remove(task) },
            onQueryChanged = onQueryChanged,
            onApply = onApply
        )
        fun runPending() {
            val task = pending.removeAt(0)
            task.run()
        }
    }

    @Test
    fun `query state updates immediately but application is debounced`() {
        val scheduler = FakeScheduler()
        val changed = mutableListOf<String>()
        var applies = 0
        val controller = scheduler.controller(changed::add) { applies++ }

        controller.onTextChanged("esp")

        assertEquals("esp", controller.query)
        assertEquals(listOf("esp"), changed)
        assertEquals(0, applies)
        scheduler.runPending()
        assertEquals(1, applies)
    }

    @Test
    fun `only latest query is applied after rapid typing`() {
        val scheduler = FakeScheduler()
        val appliedQueries = mutableListOf<String>()
        lateinit var controller: ChannelSearchQueryController
        controller = scheduler.controller(onApply = { appliedQueries += controller.query })

        controller.onTextChanged("e")
        val staleTask = scheduler.history.last()
        controller.onTextChanged("es")
        controller.onTextChanged("espn")
        staleTask.run() // Simulate a callback already dequeued by the scheduler.
        scheduler.runPending()

        assertEquals(listOf("espn"), appliedQueries)
        assertEquals(0, scheduler.pending.size)
    }

    @Test
    fun `immediate apply cancels debounce and applies exactly once`() {
        val scheduler = FakeScheduler()
        var applies = 0
        val controller = scheduler.controller(onApply = { applies++ })

        controller.onTextChanged("fox")
        controller.applyImmediately("fox sports")
        scheduler.history.forEach { it.run() }

        assertEquals("fox sports", controller.query)
        assertEquals(1, applies)
        assertTrue(scheduler.pending.isEmpty())
    }

    @Test
    fun `clear without apply updates query and cancels pending work`() {
        val scheduler = FakeScheduler()
        val changed = mutableListOf<String>()
        var applies = 0
        val controller = scheduler.controller(changed::add) { applies++ }

        controller.onTextChanged("tennis")
        controller.clear(applyImmediately = false)
        scheduler.history.forEach { it.run() }

        assertEquals("", controller.query)
        assertEquals(listOf("tennis", ""), changed)
        assertEquals(0, applies)
        assertTrue(scheduler.pending.isEmpty())
    }

    @Test
    fun `same query does not emit duplicate state changes`() {
        val scheduler = FakeScheduler()
        val changed = mutableListOf<String>()
        var applies = 0
        val controller = scheduler.controller(changed::add) { applies++ }

        controller.syncQuery("f1")
        controller.onTextChanged("f1")
        scheduler.runPending()

        assertEquals(listOf("f1"), changed)
        assertEquals(1, applies)
    }

    @Test
    fun `disposed controller ignores text changes and callbacks`() {
        val scheduler = FakeScheduler()
        val changed = mutableListOf<String>()
        var applies = 0
        val controller = scheduler.controller(changed::add) { applies++ }

        controller.onTextChanged("motogp")
        val staleTask = scheduler.history.last()
        controller.dispose()
        controller.onTextChanged("f1")
        staleTask.run()

        assertEquals(listOf("motogp"), changed)
        assertEquals(0, applies)
        assertTrue(scheduler.pending.isEmpty())
    }
}
