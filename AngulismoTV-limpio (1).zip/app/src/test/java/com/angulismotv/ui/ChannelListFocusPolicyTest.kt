package com.angulismotv.ui

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class ChannelListFocusPolicyTest {
    @Test
    fun `selected channel takes priority over remembered row`() {
        assertEquals(3, ChannelListFocusPolicy.targetPosition(5, 3, 1))
    }

    @Test
    fun `remembered row is used when selected channel is filtered out`() {
        assertEquals(2, ChannelListFocusPolicy.targetPosition(5, -1, 2))
    }

    @Test
    fun `invalid positions fall back to first row`() {
        assertEquals(0, ChannelListFocusPolicy.targetPosition(5, 9, -1))
    }

    @Test
    fun `empty list has no focus target`() {
        assertTrue(ChannelListFocusPolicy.targetPosition(0, -1, 0) == null)
        assertTrue(ChannelListFocusPolicy.targetPosition(-1, 0, 0) == null)
    }
}
