package com.angulismotv.data

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class CountryFilterOptionsPolicyTest {
    @Test
    fun `all countries is first and remaining options are unique and alphabetically ordered by label`() {
        val options = CountryFilterOptionsPolicy.build(
            listOf("cl", "ar", "CL", "todos", "", "br")
        ) { key -> mapOf("ar" to "Argentina", "br" to "Brasil", "cl" to "Chile")[key.lowercase()] ?: key }

        assertEquals(
            listOf("todos", "ar", "br", "cl"),
            options.map { it.key.lowercase() }
        )
        assertEquals("Todos los países", options.first().label)
    }

    @Test
    fun `missing selection safely points at all countries`() {
        val options = CountryFilterOptionsPolicy.build(listOf("ar")) { it }
        assertEquals(0, CountryFilterOptionsPolicy.selectedIndex(options, "cl"))
        assertEquals(1, CountryFilterOptionsPolicy.selectedIndex(options, "AR"))
    }

    @Test
    fun `invalid indices have no key`() {
        val options = CountryFilterOptionsPolicy.build(emptyList()) { it }
        assertNull(CountryFilterOptionsPolicy.keyAt(options, -1))
        assertNull(CountryFilterOptionsPolicy.keyAt(options, 20))
    }
}
