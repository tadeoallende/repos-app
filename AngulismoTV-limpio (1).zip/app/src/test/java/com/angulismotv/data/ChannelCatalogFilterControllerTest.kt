package com.angulismotv.data

import com.angulismotv.models.Channel
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class ChannelCatalogFilterControllerTest {
    private val controller = ChannelCatalogFilterController()

    @Test
    fun `combines category country and accent insensitive query`() {
        controller.replaceCatalog(
            listOf(
                Channel(name = "ESPN Argentina", category = "Sports", country = "AR"),
                Channel(name = "ESPN Chile", category = "Sports", country = "CL"),
                Channel(name = "Películas AR", category = "Movies", country = "AR")
            ),
            resetSelection = true
        )
        controller.selectCategory("peliculas")
        controller.selectCountry("ar")
        controller.setQuery("peliculas")

        assertEquals(listOf("Películas AR"), controller.filter().map { it.name })
    }

    @Test
    fun `invalid category falls back to all instead of empty results`() {
        controller.replaceCatalog(listOf(Channel(name = "ESPN", category = "Sports")), resetSelection = true)
        controller.selectCategory("peliculas")

        assertEquals(ChannelCatalogFilterController.ALL, controller.selectedCategoryKey)
        assertEquals(listOf("ESPN"), controller.filter().map { it.name })
    }

    @Test
    fun `catalog replacement normalizes disappeared country and category`() {
        controller.replaceCatalog(
            listOf(Channel(name = "Películas AR", category = "Movies", country = "AR")),
            resetSelection = true
        )
        controller.selectCategory("peliculas")
        controller.selectCountry("ar")
        controller.replaceCatalog(listOf(Channel(name = "ESPN CL", category = "Sports", country = "CL")))

        assertEquals("todos", controller.selectedCategoryKey)
        assertEquals("todos", controller.selectedCountryKey)
        assertEquals(listOf("ESPN CL"), controller.filter().map { it.name })
    }

    @Test
    fun `resetting catalog filters preserves the search query`() {
        controller.replaceCatalog(listOf(Channel(name = "ESPN", category = "Sports")), resetSelection = true)
        controller.setQuery("esp")
        controller.replaceCatalog(listOf(Channel(name = "ESPN 2", category = "Sports")), resetSelection = true)

        assertEquals("esp", controller.query)
        assertEquals(listOf("ESPN 2"), controller.filter().map { it.name })
    }

    @Test
    fun `category options only contain categories present in catalog`() {
        controller.replaceCatalog(
            listOf(Channel(name = "ESPN", category = "Sports"), Channel(name = "Radio", category = "Música")),
            resetSelection = true
        )

        val options = controller.categoryOptions(
            mapOf("todos" to "Todos", "deportes" to "Deportes", "musicales" to "Musicales"),
            { it }
        )
        assertEquals(listOf("todos", "deportes", "musicales"), options.map { it.first })
    }

    @Test
    fun `empty catalog clears selections but keeps query`() {
        controller.replaceCatalog(listOf(Channel(name = "ESPN", category = "Sports", country = "AR")), resetSelection = true)
        controller.selectCategory("deportes")
        controller.selectCountry("ar")
        controller.setQuery("esp")
        controller.replaceCatalog(emptyList())

        assertEquals("todos", controller.selectedCategoryKey)
        assertEquals("todos", controller.selectedCountryKey)
        assertEquals("esp", controller.query)
        assertTrue(controller.filter().isEmpty())
        assertFalse(controller.availableCountryKeys().isNotEmpty())
    }
}
