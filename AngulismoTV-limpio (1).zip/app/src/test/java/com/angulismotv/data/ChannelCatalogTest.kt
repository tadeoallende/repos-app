package com.angulismotv.data

import com.angulismotv.models.Channel
import com.angulismotv.models.StreamOption
import com.angulismotv.models.StreamType
import org.junit.Assert.assertEquals
import org.junit.Assert.assertSame
import org.junit.Test

class ChannelCatalogTest {
    private val channels = listOf(
        Channel(name = "ESPN 1", category = "Deportes"),
        Channel(name = "Noticias 24", category = "Noticias"),
        Channel(name = "ESPN 2", category = "Deportes")
    )

    @Test
    fun `all category returns original channel list`() {
        assertSame(channels, ChannelCatalog.filterByCategory(channels, "todos"))
    }

    @Test
    fun `category filtering preserves requested case semantics`() {
        assertEquals(2, ChannelCatalog.filterByCategory(channels, "Deportes").size)
        assertEquals(0, ChannelCatalog.filterByCategory(channels, "deportes").size)
        assertEquals(2, ChannelCatalog.filterByCategory(channels, "deportes", ignoreCase = true).size)
    }

    @Test
    fun `search ignores case and surrounding whitespace`() {
        assertEquals(listOf("ESPN 1", "ESPN 2"), ChannelCatalog.searchByName(channels, " espn ").map { it.name })
        assertSame(channels, ChannelCatalog.searchByName(channels, "   "))
    }

    @Test
    fun `feed deduplication preserves distinct alternative sources`() {
        val first = Channel(
            name = "Radio Uno", logo = "logo.png", streamUrl = null, streamType = StreamType.IFRAME,
            options = listOf(StreamOption(name = "Principal", iframe = "https://a.example/embed"))
        )
        val same = first.copy(options = listOf(StreamOption(name = "Principal", iframe = "https://a.example/embed")))
        val otherSource = first.copy(options = listOf(StreamOption(name = "Respaldo", iframe = "https://b.example/embed")))

        assertEquals(ChannelCatalog.feedDeduplicationKey(first), ChannelCatalog.feedDeduplicationKey(same))
        org.junit.Assert.assertNotEquals(
            ChannelCatalog.feedDeduplicationKey(first),
            ChannelCatalog.feedDeduplicationKey(otherSource)
        )
    }

    @Test
    fun `feed deduplication ignores device locale for technical identifiers`() {
        val channel = Channel(
            name = "Iris TV", streamType = "IFRAME",
            options = listOf(StreamOption(streamType = "IFRAME", iframe = "https://a.example/embed"))
        )
        val previous = java.util.Locale.getDefault()
        try {
            java.util.Locale.setDefault(java.util.Locale.forLanguageTag("tr-TR"))
            assertEquals("iframe", channel.streamType!!.trim().lowercase(java.util.Locale.ROOT))
            assertEquals(
                ChannelCatalog.feedDeduplicationKey(channel),
                ChannelCatalog.feedDeduplicationKey(channel.copy(streamType = "iframe"))
            )
        } finally {
            java.util.Locale.setDefault(previous)
        }
    }

    @Test
    fun `category collection can retain exact keys or merge case variants`() {
        val mixed = listOf(
            Channel(name = "A", category = "Deportes"),
            Channel(name = "B", category = "deportes"),
            Channel(name = "C", category = "todos")
        )
        assertEquals(
            listOf("Deportes", "deportes"),
            ChannelCatalog.uniqueCategories(
                mixed, trimValues = false, ignoreCase = false, sortIgnoreCase = false
            )
        )
        assertEquals(
            listOf("Deportes"),
            ChannelCatalog.uniqueCategories(
                mixed, trimValues = true, ignoreCase = true, sortIgnoreCase = true
            )
        )
    }
}
