package com.angulismotv.data

import com.angulismotv.models.Channel
import org.junit.Assert.assertEquals
import org.junit.Assert.assertSame
import org.junit.Test

class ChannelCatalogTest {
    private val channels = listOf(
        Channel(name = "ESPN 1", category = "Deportes"),
        Channel(name = "Noticias 24", category = "Noticias"),
        Channel(name = "ESPN 2", category = "Deportes")
    )

    @Test
    fun `all category returns original channel list`() {
        assertSame(channels, ChannelCatalog.filterByCategory(channels, "todos"))
    }

    @Test
    fun `category filtering preserves requested case semantics`() {
        assertEquals(2, ChannelCatalog.filterByCategory(channels, "Deportes").size)
        assertEquals(0, ChannelCatalog.filterByCategory(channels, "deportes").size)
        assertEquals(2, ChannelCatalog.filterByCategory(channels, "deportes", ignoreCase = true).size)
    }

    @Test
    fun `search ignores case and surrounding whitespace`() {
        assertEquals(listOf("ESPN 1", "ESPN 2"), ChannelCatalog.searchByName(channels, " espn ").map { it.name })
        assertSame(channels, ChannelCatalog.searchByName(channels, "   "))
    }

    @Test
    fun `category collection can retain exact keys or merge case variants`() {
        val mixed = listOf(
            Channel(name = "A", category = "Deportes"),
            Channel(name = "B", category = "deportes"),
            Channel(name = "C", category = "todos")
        )
        assertEquals(
            listOf("Deportes", "deportes"),
            ChannelCatalog.uniqueCategories(
                mixed, trimValues = false, ignoreCase = false, sortIgnoreCase = false
            )
        )
        assertEquals(
            listOf("Deportes"),
            ChannelCatalog.uniqueCategories(
                mixed, trimValues = true, ignoreCase = true, sortIgnoreCase = true
            )
        )
    }
}
