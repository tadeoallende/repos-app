package com.angulismotv.data

import com.angulismotv.models.StreamType
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class M3uPlaylistParserTest {
    @Test
    fun `parses name logo category and HLS stream`() {
        val playlist = """#EXTM3U
#EXTINF:-1 tvg-id="sports.one" tvg-logo="https://logos.example/sports.png" group-title="Sports",Sports One
https://stream.example/live/index.m3u8
""".trimIndent()

        val channels = M3uPlaylistParser.parse(playlist)

        assertEquals(1, channels.size)
        assertEquals("Sports One", channels[0].name)
        assertEquals("https://logos.example/sports.png", channels[0].logo)
        assertEquals("Sports", channels[0].category)
        assertEquals("https://stream.example/live/index.m3u8", channels[0].streamUrl)
        assertEquals(StreamType.HLS, channels[0].streamType)
    }

    @Test
    fun `uses tvg name when display name is blank and parses quoted commas`() {
        val playlist = """#EXTM3U
#EXTINF:-1 tvg-name="Channel, International" tvg-logo="https://logos.example/logo,2.png" group-title="World News",
https://stream.example/live/manifest.mpd
""".trimIndent()

        val channels = M3uPlaylistParser.parse(playlist)

        assertEquals(1, channels.size)
        assertEquals("Channel, International", channels[0].name)
        assertEquals("https://logos.example/logo,2.png", channels[0].logo)
        assertEquals("World News", channels[0].category)
        assertEquals(StreamType.DASH, channels[0].streamType)
    }

    @Test
    fun `ignores comments invalid URLs and entries without extinf metadata`() {
        val playlist = """#EXTM3U
https://not-associated.example/live.m3u8
#EXTINF:-1 group-title="Sports",Invalid URL
javascript:alert(1)
#EXTINF:-1 group-title="Sports",Valid Stream
https://stream.example/live.mp4
""".trimIndent()

        val channels = M3uPlaylistParser.parse(playlist)

        assertEquals(1, channels.size)
        assertEquals("Valid Stream", channels.single().name)
        assertEquals(StreamType.MP4, channels.single().streamType)
    }

    @Test
    fun `deduplicates identical channel and stream pairs`() {
        val playlist = """#EXTM3U
#EXTINF:-1 group-title="News",News Channel
https://stream.example/news.m3u8
#EXTINF:-1 group-title="Other",News Channel
https://stream.example/news.m3u8
""".trimIndent()

        assertEquals(1, M3uPlaylistParser.parse(playlist).size)
    }

    @Test
    fun `rejects content without valid m3u header`() {
        val error = runCatching { M3uPlaylistParser.parse("Not a playlist\nhttps://stream.example/live.m3u8") }.exceptionOrNull()
        assertTrue(error is IllegalArgumentException)
    }

    @Test
    fun `empty valid playlist returns no channels so repository can fallback`() {
        assertTrue(M3uPlaylistParser.parse("#EXTM3U\n").isEmpty())
    }
}
