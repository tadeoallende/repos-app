package com.angulismotv.data

import com.angulismotv.models.Channel
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class ChannelCatalogEmptyStatePolicyTest {
    @Test fun missingConfigurationShowsGuidanceWithoutRetry() {
        val state = ChannelCatalogEmptyStatePolicy.forResult(
            LoadResult(channels = emptyList(), notConfigured = true)
        )

        assertEquals("Todavía no hay una lista de canales configurada.", state?.message)
        assertFalse(state?.isError ?: true)
        assertFalse(state?.showRetry ?: true)
    }

    @Test fun failedLoadShowsErrorAndRetry() {
        val state = ChannelCatalogEmptyStatePolicy.forResult(
            LoadResult(channels = emptyList(), failed = true)
        )

        assertEquals("No se pudo cargar la lista de canales.\nRevisá tu conexión e intentá de nuevo.", state?.message)
        assertTrue(state?.isError == true)
        assertTrue(state?.showRetry == true)
    }

    @Test fun emptySuccessfulListShowsRetryWithoutErrorColor() {
        val state = ChannelCatalogEmptyStatePolicy.forResult(LoadResult(channels = emptyList()))

        assertEquals("La lista de canales está vacía.", state?.message)
        assertFalse(state?.isError ?: true)
        assertTrue(state?.showRetry == true)
    }

    @Test fun nonEmptyCatalogDoesNotRequestEmptyState() {
        val state = ChannelCatalogEmptyStatePolicy.forResult(
            LoadResult(channels = listOf(Channel(name = "Canal de prueba")))
        )
        assertNull(state)
    }

    @Test fun notConfiguredTakesPrecedenceOverGenericFailure() {
        val state = ChannelCatalogEmptyStatePolicy.forResult(
            LoadResult(channels = emptyList(), failed = true, notConfigured = true)
        )
        assertFalse(state?.isError ?: true)
        assertFalse(state?.showRetry ?: true)
    }
}
