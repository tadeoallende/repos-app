package com.angulismotv.data

import org.junit.Assert.assertEquals
import org.junit.Test

class IptvOrgPlaylistPolicyTest {
    @Test
    fun `blank source resolves to Argentina playlist`() {
        assertEquals(
            IptvOrgPlaylistPolicy.ARGENTINA_PLAYLIST_URL,
            IptvOrgPlaylistPolicy.resolve("")
        )
    }

    @Test
    fun `old worldwide playlist is normalized to Argentina`() {
        assertEquals(
            IptvOrgPlaylistPolicy.ARGENTINA_PLAYLIST_URL,
            IptvOrgPlaylistPolicy.resolve("https://iptv-org.github.io/iptv/index.m3u")
        )
    }

    @Test
    fun `official non Argentina playlist is normalized to Argentina`() {
        assertEquals(
            IptvOrgPlaylistPolicy.ARGENTINA_PLAYLIST_URL,
            IptvOrgPlaylistPolicy.resolve("https://iptv-org.github.io/iptv/countries/br.m3u")
        )
    }

    @Test
    fun `Argentina playlist and custom hosts are preserved`() {
        val argentina = IptvOrgPlaylistPolicy.ARGENTINA_PLAYLIST_URL
        val custom = "https://feeds.example/channels.m3u"
        assertEquals(argentina, IptvOrgPlaylistPolicy.resolve(argentina))
        assertEquals(custom, IptvOrgPlaylistPolicy.resolve(custom))
    }

    @Test
    fun `disabled source remains disabled`() {
        assertEquals("", IptvOrgPlaylistPolicy.resolve("disabled"))
    }
}
