package com.angulismotv.data

import com.angulismotv.models.Channel
import org.junit.Assert.assertEquals
import org.junit.Test

class ChannelFilterEngineTest {
    private val channels = listOf(
        Channel(name = "ESPN Argentina", category = "Sports", country = "AR"),
        Channel(name = "Noticias Uno", category = "News", country = "CO"),
        Channel(name = "Cine Familiar", category = "Movies", country = "AR"),
        Channel(name = "ESPN Internacional", category = "Deportes", country = "US")
    )

    @Test
    fun `normalizes source categories into stable user categories`() {
        assertEquals("deportes", ChannelFilterEngine.categoryKey("Motorsport"))
        assertEquals("noticias", ChannelFilterEngine.categoryKey("Current Affairs"))
        assertEquals("peliculas", ChannelFilterEngine.categoryKey("Movies"))
        assertEquals("otros", ChannelFilterEngine.categoryKey("Shopping"))
    }

    @Test
    fun `available categories only include categories present in catalog`() {
        assertEquals(
            listOf("todos", "deportes", "noticias", "peliculas"),
            ChannelFilterEngine.availableCategories(channels).map { it.first }
        )
        assertEquals(emptyList<Pair<String, String>>(), ChannelFilterEngine.availableCategories(emptyList()))
    }

    @Test
    fun `country keys and labels handle ISO codes and missing country`() {
        assertEquals("ar", ChannelFilterEngine.countryKey("AR, South America"))
        assertEquals("sin_pais", ChannelFilterEngine.countryKey("  "))
        assertEquals("Argentina", ChannelFilterEngine.countryLabel("ar"))
        assertEquals("Sin país informado", ChannelFilterEngine.countryLabel("sin_pais"))
    }

    @Test
    fun `combined filter applies category country and query`() {
        val result = ChannelFilterEngine.filter(
            channels = channels,
            category = "deportes",
            country = "ar",
            query = " espn "
        )
        assertEquals(listOf("ESPN Argentina"), result.map { it.name })
    }

    @Test
    fun `all filters and blank query preserve catalog ordering`() {
        assertEquals(channels, ChannelFilterEngine.filter(channels, "todos", "todos", "  "))
    }
}
