package com.angulismotv.data

import com.angulismotv.models.Channel
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class ChannelFilterPolicyTest {
    @Test
    fun `normalizes common playlist categories into general groups`() {
        assertEquals("deportes", ChannelFilterPolicy.generalCategoryFor("Sports; Football"))
        assertEquals("noticias", ChannelFilterPolicy.generalCategoryFor("News"))
        assertEquals("peliculas", ChannelFilterPolicy.generalCategoryFor("Movie Channels"))
        assertEquals("musicales", ChannelFilterPolicy.generalCategoryFor("Radio Música"))
        assertEquals("peliculas", ChannelFilterPolicy.generalCategoryFor("Películas"))
        assertEquals("otros", ChannelFilterPolicy.generalCategoryFor("Unclassified"))
    }

    @Test
    fun `combines category country and name filters without changing source order`() {
        val channels = listOf(
            Channel(name = "ESPN Argentina", category = "Sports", country = "AR"),
            Channel(name = "ESPN Chile", category = "Sports", country = "CL"),
            Channel(name = "Noticias Argentina", category = "News", country = "AR"),
            Channel(name = "Películas AR", category = "Movies", country = "AR")
        )

        val filtered = ChannelFilterPolicy.filter(
            channels = channels,
            categoryKey = "deportes",
            selectedCountryKey = "ar",
            query = "espn"
        )

        assertEquals(listOf("ESPN Argentina"), filtered.map { it.name })
    }

    @Test
    fun `search matches Spanish names regardless of accents`() {
        val channels = listOf(
            Channel(name = "Películas HD", category = "Movies"),
            Channel(name = "Música Argentina", category = "Music"),
            Channel(name = "ESPN", category = "Sports")
        )

        assertEquals(listOf("Películas HD"), ChannelFilterPolicy.filter(channels, "todos", "todos", "peliculas").map { it.name })
        assertEquals(listOf("Música Argentina"), ChannelFilterPolicy.filter(channels, "todos", "todos", "musica").map { it.name })
    }

    @Test
    fun `category generation only includes groups that exist`() {
        val channels = listOf(
            Channel(name = "ESPN", category = "Sports"),
            Channel(name = "News", category = "News")
        )
        val categories = ChannelFilterPolicy.categories(
            channels,
            mapOf("deportes" to "Deportes", "noticias" to "Noticias"),
            { it }
        )

        assertEquals(listOf("todos", "deportes", "noticias"), categories.map { it.first })
        assertEquals(listOf("Todos", "Deportes", "Noticias"), categories.map { it.second })
    }

    @Test
    fun `international lifestyle and event groups use their dedicated categories`() {
        assertEquals("internacionales", ChannelFilterPolicy.generalCategoryFor("International Channels"))
        assertEquals("estilo-vida", ChannelFilterPolicy.generalCategoryFor("Lifestyle"))
        assertEquals("estilo-vida", ChannelFilterPolicy.generalCategoryFor("Estilo de Vida"))
        assertEquals("eventos", ChannelFilterPolicy.generalCategoryFor("Live Events"))

        val options = ChannelFilterPolicy.categories(
            listOf(
                Channel(name = "World", category = "International"),
                Channel(name = "Life", category = "Lifestyle"),
                Channel(name = "Live", category = "Events")
            ),
            mapOf(
                "todos" to "Todos",
                "internacionales" to "Internacionales",
                "estilo-vida" to "Estilo de vida",
                "eventos" to "Eventos"
            ),
            { it }
        )
        assertEquals(
            listOf("todos", "internacionales", "estilo-vida", "eventos"),
            options.map { it.first }
        )
    }

    @Test
    fun `invalid country selection resets to all and blank countries are retained`() {
        val channels = listOf(Channel(name = "Unknown country", country = ""))
        assertEquals(listOf("sin_pais"), ChannelFilterPolicy.availableCountryKeys(channels))
        assertEquals("todos", ChannelFilterPolicy.normalizeSelectedCountry(channels, "ar"))
        assertEquals("sin_pais", ChannelFilterPolicy.countryKey(""))
        assertEquals("Sin país informado", ChannelFilterPolicy.countryLabel("sin_pais"))
        assertTrue(ChannelFilterPolicy.countryLabel("ar").isNotBlank())
    }
}
