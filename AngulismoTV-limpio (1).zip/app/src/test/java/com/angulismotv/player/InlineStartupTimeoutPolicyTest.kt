package com.angulismotv.player

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class InlineStartupTimeoutPolicyTest {
    @Test
    fun firesOnlyWhileCurrentPlayerIsStillStarting() {
        assertTrue(InlineStartupTimeoutPolicy.shouldFire(true, true, false))
    }

    @Test
    fun ignoresStaleGeneration() {
        assertFalse(InlineStartupTimeoutPolicy.shouldFire(false, true, false))
    }

    @Test
    fun ignoresReplacedPlayer() {
        assertFalse(InlineStartupTimeoutPolicy.shouldFire(true, false, false))
    }

    @Test
    fun ignoresReadyOrEndedPlayback() {
        assertFalse(InlineStartupTimeoutPolicy.shouldFire(true, true, true))
    }
}
