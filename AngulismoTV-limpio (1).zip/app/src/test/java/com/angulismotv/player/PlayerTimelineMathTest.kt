package com.angulismotv.player

import org.junit.Assert.assertEquals
import org.junit.Test

class PlayerTimelineMathTest {
    @Test fun progressConvertsToMediaPosition() {
        assertEquals(0L, PlayerTimelineMath.progressToPosition(0, 120_000L))
        assertEquals(60_000L, PlayerTimelineMath.progressToPosition(500, 120_000L))
        assertEquals(120_000L, PlayerTimelineMath.progressToPosition(1_000, 120_000L))
    }

    @Test fun progressIsClampedToSeekBarRange() {
        assertEquals(0L, PlayerTimelineMath.progressToPosition(-50, 120_000L))
        assertEquals(120_000L, PlayerTimelineMath.progressToPosition(5_000, 120_000L))
    }

    @Test fun mediaPositionConvertsToBoundedProgress() {
        assertEquals(0, PlayerTimelineMath.positionToProgress(-500L, 120_000L))
        assertEquals(250, PlayerTimelineMath.positionToProgress(30_000L, 120_000L))
        assertEquals(1_000, PlayerTimelineMath.positionToProgress(150_000L, 120_000L))
    }

    @Test fun invalidDurationsAndScalesReturnSafeZeroValues() {
        assertEquals(0L, PlayerTimelineMath.progressToPosition(500, -1L))
        assertEquals(0L, PlayerTimelineMath.progressToPosition(500, 10L, scale = 0))
        assertEquals(0, PlayerTimelineMath.positionToProgress(10L, 0L))
        assertEquals(0, PlayerTimelineMath.positionToProgress(10L, 100L, scale = -1))
    }

    @Test fun multiplicationDoesNotOverflowForVeryLongDurations() {
        assertEquals(Long.MAX_VALUE, PlayerTimelineMath.progressToPosition(1_000, Long.MAX_VALUE))
        assertEquals(500, PlayerTimelineMath.positionToProgress(Long.MAX_VALUE / 2, Long.MAX_VALUE))
    }
}
