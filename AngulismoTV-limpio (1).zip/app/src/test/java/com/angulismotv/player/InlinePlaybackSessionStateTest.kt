package com.angulismotv.player

import com.angulismotv.models.Channel
import com.angulismotv.models.StreamType
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class InlinePlaybackSessionStateTest {
    @Test
    fun startingANewChannelInvalidatesCallbacksAndClearsPreviousSource() {
        val state = InlinePlaybackSessionState()
        val oldGeneration = state.beginChannel(Channel(name = "Anterior"))
        state.setResolvedSource("https://old.example/live.m3u8", StreamType.HLS)

        val newGeneration = state.beginChannel(Channel(name = "Nuevo"))

        assertNotEquals(oldGeneration, newGeneration)
        assertFalse(state.isCurrent(oldGeneration))
        assertEquals("Nuevo", state.channel?.name)
        assertEquals(0, state.sourceIndex)
        assertEquals("", state.streamUrl)
        assertEquals(StreamType.AUTO, state.streamType)
    }

    @Test
    fun sourceSelectionKeepsChannelButClearsOldUrlBeforeResolution() {
        val state = InlinePlaybackSessionState()
        val channel = Channel(name = "Canal")
        state.beginChannel(channel)
        state.setResolvedSource("https://old.example/live.m3u8", StreamType.HLS)

        val generation = state.beginSourceSelection(2)

        assertTrue(state.isCurrent(generation))
        assertEquals(channel, state.channel)
        assertEquals(2, state.sourceIndex)
        assertEquals("", state.streamUrl)
        assertEquals(StreamType.AUTO, state.streamType)
    }

    @Test
    fun restorePreservesStreamAndNormalizesNegativeSourceIndex() {
        val state = InlinePlaybackSessionState()
        val generation = state.restore(
            channel = Channel(name = "Devuelto"),
            sourceIndex = -2,
            url = "https://cdn.example/live.m3u8",
            type = StreamType.HLS
        )

        assertTrue(state.isCurrent(generation))
        assertEquals("Devuelto", state.channel?.name)
        assertEquals(0, state.sourceIndex)
        assertEquals("https://cdn.example/live.m3u8", state.streamUrl)
        assertEquals(StreamType.HLS, state.streamType)
    }

    @Test
    fun refusesBlankUrlAndAllowsCastOnlyForNativeResolvedStreams() {
        val state = InlinePlaybackSessionState()
        state.beginChannel(Channel(name = "Canal"))
        assertFalse(state.setResolvedSource("  ", StreamType.HLS))
        assertFalse(state.canCast())

        state.setResolvedSource("https://cdn.example/live.m3u8", StreamType.HLS)
        assertTrue(state.canCast())
        val failedGeneration = state.generation
        assertTrue(state.failSource(failedGeneration))
        assertFalse(state.canCast())
        assertFalse(state.failSource(failedGeneration))
        state.beginSourceSelection(0)
        state.setResolvedSource("https://cdn.example/live.m3u8", StreamType.HLS)
        assertTrue(state.canCast())

        state.setResolvedSource("https://embed.example/player", StreamType.IFRAME)
        assertFalse(state.canCast())
    }

    @Test
    fun clearInvalidatesCallbacksAndRemovesChannel() {
        val state = InlinePlaybackSessionState()
        val generation = state.beginChannel(Channel(name = "Canal"))

        val clearedGeneration = state.clear()

        assertNotEquals(generation, clearedGeneration)
        assertFalse(state.isCurrent(generation))
        assertNull(state.channel)
        assertEquals("", state.streamUrl)
        assertEquals(StreamType.AUTO, state.streamType)
    }
}
