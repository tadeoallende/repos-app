package com.angulismotv.player

import com.angulismotv.models.StreamType
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class PlaybackRecoveryPolicyTest {
    @Test
    fun `retry delay follows configured progressive schedule`() {
        assertEquals(500L, PlaybackRecoveryPolicy.reconnectDelayMs(1))
        assertEquals(1_000L, PlaybackRecoveryPolicy.reconnectDelayMs(2))
        assertEquals(3_000L, PlaybackRecoveryPolicy.reconnectDelayMs(4))
        assertEquals(12_000L, PlaybackRecoveryPolicy.reconnectDelayMs(7))
    }

    @Test
    fun `retry delay remains capped for later attempts`() {
        assertEquals(12_000L, PlaybackRecoveryPolicy.reconnectDelayMs(8))
        assertEquals(12_000L, PlaybackRecoveryPolicy.reconnectDelayMs(100))
    }

    @Test(expected = IllegalArgumentException::class)
    fun `retry attempt must be positive`() {
        PlaybackRecoveryPolicy.reconnectDelayMs(0)
    }

    @Test
    fun `only HLS and DASH retry indefinitely after the configured limit`() {
        assertTrue(PlaybackRecoveryPolicy.retryBeyondLimit(StreamType.HLS))
        assertTrue(PlaybackRecoveryPolicy.retryBeyondLimit(StreamType.DASH))
        assertFalse(PlaybackRecoveryPolicy.retryBeyondLimit(StreamType.MP4))
        assertFalse(PlaybackRecoveryPolicy.retryBeyondLimit(StreamType.IFRAME))
    }
}
