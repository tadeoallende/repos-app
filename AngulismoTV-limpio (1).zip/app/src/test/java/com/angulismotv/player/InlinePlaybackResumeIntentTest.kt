package com.angulismotv.player

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class InlinePlaybackResumeIntentTest {
    @Test fun preservesPausedStateAcrossLifecycle() {
        val intent = InlinePlaybackResumeIntent()
        intent.capture(playWhenReady = false)
        assertEquals(false, intent.consume())
        assertNull(intent.consume())
    }

    @Test fun preservesPlayingStateAcrossLifecycle() {
        val intent = InlinePlaybackResumeIntent()
        intent.capture(playWhenReady = true)
        assertEquals(true, intent.consume())
    }

    @Test fun duplicateLifecycleCallbacksDoNotOverwriteFirstIntent() {
        val intent = InlinePlaybackResumeIntent()
        intent.capture(playWhenReady = true)
        intent.capture(playWhenReady = false)
        assertEquals(true, intent.consume())
    }

    @Test fun noCapturedIntentDoesNotForcePlayback() {
        val intent = InlinePlaybackResumeIntent()
        assertNull(intent.consume())
    }
}
