package com.angulismotv.player

import android.view.KeyEvent
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class TvRemoteKeyControllerTest {
    @Test
    fun `digit keys append only while side panel is closed`() {
        val fixture = Fixture()
        assertTrue(fixture.controller.handleKey(KeyEvent.KEYCODE_7))
        assertEquals(listOf(7), fixture.actions.digits)

        fixture.state = fixture.state.copy(panelOpen = true)
        assertFalse(fixture.controller.handleKey(KeyEvent.KEYCODE_4))
        assertEquals(listOf(7), fixture.actions.digits)
        assertEquals(0, fixture.actions.panelVerticalCalls)
    }

    @Test
    fun `up and down zapping depends on visibility of controls`() {
        val fixture = Fixture()
        assertTrue(fixture.controller.handleKey(KeyEvent.KEYCODE_DPAD_UP))
        assertEquals(listOf(-1), fixture.actions.channelDeltas)

        fixture.state = fixture.state.copy(controlsVisible = true)
        assertTrue(fixture.controller.handleKey(KeyEvent.KEYCODE_DPAD_DOWN))
        assertEquals(1, fixture.actions.navigateDownCalls)
        assertEquals(listOf(-1), fixture.actions.channelDeltas)
    }

    @Test
    fun `right key performs the appropriate panel action`() {
        val fixture = Fixture()
        fixture.state = fixture.state.copy(panelOpen = true, searchTriggerFocused = true)
        assertTrue(fixture.controller.handleKey(KeyEvent.KEYCODE_DPAD_RIGHT))
        assertEquals(1, fixture.actions.activateSearchCalls)

        fixture.state = fixture.state.copy(searchTriggerFocused = false, rightPanelFocused = true)
        assertTrue(fixture.controller.handleKey(KeyEvent.KEYCODE_DPAD_RIGHT))
        assertEquals(1, fixture.actions.closePanelCalls)
    }

    @Test
    fun `enter commits a pending number but remains available to panel focus`() {
        val fixture = Fixture()
        fixture.state = fixture.state.copy(hasPendingChannelNumber = true)
        assertTrue(fixture.controller.handleKey(KeyEvent.KEYCODE_ENTER))
        assertEquals(1, fixture.actions.commitCalls)

        fixture.state = fixture.state.copy(panelOpen = true)
        assertFalse(fixture.controller.handleKey(KeyEvent.KEYCODE_ENTER))
        assertEquals(1, fixture.actions.commitCalls)
    }

    @Test
    fun `media keys route iframe controls and native playback separately`() {
        val fixture = Fixture()
        fixture.state = fixture.state.copy(iframeActive = true)
        assertTrue(fixture.controller.handleKey(KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE))
        assertEquals(listOf("toggle"), fixture.actions.iframeCommands)

        fixture.state = fixture.state.copy(iframeActive = false)
        assertTrue(fixture.controller.handleKey(KeyEvent.KEYCODE_MEDIA_PLAY))
        assertEquals(1, fixture.actions.nativePlayCalls)
    }

    @Test
    fun `unknown key falls through`() {
        val fixture = Fixture()
        assertFalse(fixture.controller.handleKey(KeyEvent.KEYCODE_A))
    }

    private class Fixture {
        var state = TvRemoteKeyController.State(
            panelOpen = false,
            controlsVisible = false,
            hasPendingChannelNumber = false,
            rightPanelFocused = false,
            searchTriggerFocused = false,
            closePanelFocused = false,
            iframeActive = false
        )
        val actions = RecordingActions()
        val controller = TvRemoteKeyController(stateProvider = { state }, actions = actions)
    }

    private class RecordingActions : TvRemoteKeyController.Actions {
        val digits = mutableListOf<Int>()
        val channelDeltas = mutableListOf<Int>()
        val iframeCommands = mutableListOf<String>()
        var panelVerticalCalls = 0
        var navigateDownCalls = 0
        var activateSearchCalls = 0
        var closePanelCalls = 0
        var commitCalls = 0
        var nativePlayCalls = 0

        override fun appendChannelNumberDigit(digit: Int) { digits += digit }
        override fun commitChannelNumber() { commitCalls++ }
        override fun handlePanelVerticalFocus(keyCode: Int): Boolean { panelVerticalCalls++; return true }
        override fun navigateControlsDown() { navigateDownCalls++ }
        override fun changeChannel(delta: Int) { channelDeltas += delta }
        override fun activateSearchMode() { activateSearchCalls++ }
        override fun closeSidePanel() { closePanelCalls++ }
        override fun controlIframe(command: String) { iframeCommands += command }
        override fun playNative() { nativePlayCalls++ }
    }
}
