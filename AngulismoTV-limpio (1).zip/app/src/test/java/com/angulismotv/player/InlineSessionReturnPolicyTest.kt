package com.angulismotv.player

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class InlineSessionReturnPolicyTest {
    @Test
    fun doesNotAttemptRecoveryForStandaloneOrAlreadyReturnedActivity() {
        assertFalse(InlineSessionReturnPolicy.shouldAttemptUnclaimedRecovery(false, false))
        assertFalse(InlineSessionReturnPolicy.shouldAttemptUnclaimedRecovery(true, true))
        assertTrue(InlineSessionReturnPolicy.shouldAttemptUnclaimedRecovery(true, false))
    }

    @Test
    fun keepsCurrentFullscreenSourceWhenItHasBeenResolved() {
        val result = InlineSessionReturnPolicy.resolveStreamMetadata(
            currentUrl = "https://new.example/live.m3u8",
            currentType = "hls",
            currentSourceIndex = 2,
            originUrl = "https://old.example/embed",
            originType = "iframe",
            originSourceIndex = 1
        )
        assertEquals("https://new.example/live.m3u8", result.url)
        assertEquals("hls", result.type)
        assertEquals(2, result.sourceIndex)
    }

    @Test
    fun restoresOriginMetadataWhenFullscreenExitsBeforeResolvingSource() {
        val result = InlineSessionReturnPolicy.resolveStreamMetadata(
            currentUrl = "",
            currentType = "auto",
            currentSourceIndex = 0,
            originUrl = "https://origin.example/embed",
            originType = "iframe",
            originSourceIndex = 3
        )
        assertEquals("https://origin.example/embed", result.url)
        assertEquals("iframe", result.type)
        assertEquals(3, result.sourceIndex)
    }

    @Test
    fun metadataNeverReturnsNegativeSourceIndex() {
        val result = InlineSessionReturnPolicy.resolveStreamMetadata(
            currentUrl = "https://origin.example/live.m3u8",
            currentType = "hls",
            currentSourceIndex = -1,
            originUrl = null,
            originType = null,
            originSourceIndex = null
        )
        assertEquals(0, result.sourceIndex)
    }
}
