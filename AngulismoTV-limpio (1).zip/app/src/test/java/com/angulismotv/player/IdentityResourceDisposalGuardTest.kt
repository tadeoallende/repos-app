package com.angulismotv.player

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class IdentityResourceDisposalGuardTest {
    @Test fun claimsAnExactResourceOnlyOnce() {
        val guard = IdentityResourceDisposalGuard()
        val resource = Any()
        assertTrue(guard.claim(resource))
        assertFalse(guard.claim(resource))
    }

    @Test fun doesNotMergeDistinctResources() {
        val guard = IdentityResourceDisposalGuard()
        assertTrue(guard.claim(AlwaysEqualResource()))
        assertTrue(guard.claim(AlwaysEqualResource()))
    }

    private class AlwaysEqualResource {
        override fun equals(other: Any?): Boolean = other is AlwaysEqualResource
        override fun hashCode(): Int = 1
    }
}
