package com.angulismotv.player

import org.junit.Assert.assertEquals
import org.junit.Test

class ChannelZappingQueueTest {
    @Test
    fun `accumulates rapid next channel presses`() {
        val queue = ChannelZappingQueue()
        queue.add(1, 10)
        queue.add(1, 10)
        queue.add(1, 10)
        assertEquals(3, queue.consume(10))
    }

    @Test
    fun `opposite presses cancel each other`() {
        val queue = ChannelZappingQueue()
        queue.add(1, 8)
        queue.add(-1, 8)
        assertEquals(0, queue.consume(8))
    }

    @Test
    fun `normalizes positive and negative deltas for circular catalogs`() {
        val queue = ChannelZappingQueue()
        queue.add(-1, 5)
        assertEquals(4, queue.consume(5))
        queue.add(7, 5)
        assertEquals(2, queue.consume(5))
    }

    @Test
    fun `consume clears the pending delta`() {
        val queue = ChannelZappingQueue()
        queue.add(2, 12)
        assertEquals(2, queue.consume(12))
        assertEquals(0, queue.consume(12))
    }

    @Test
    fun `empty catalog clears queued presses`() {
        val queue = ChannelZappingQueue()
        queue.add(2, 12)
        queue.add(1, 0)
        assertEquals(0, queue.consume(12))
    }
}
