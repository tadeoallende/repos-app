package com.angulismotv.player

import com.angulismotv.models.Channel
import com.angulismotv.models.StreamOption
import com.angulismotv.models.StreamType
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class InlineSourceResolverTest {
    @Test
    fun resolvesSelectedOptionAndExplicitType() {
        val channel = Channel(
            streamUrl = "https://fallback.example/live.m3u8",
            options = listOf(
                StreamOption("Iframe", "https://embed.example/player", StreamType.IFRAME),
                StreamOption("DASH", "https://cdn.example/live.mpd", StreamType.DASH)
            )
        )

        val result = InlineSourceResolver.resolve(channel, 1)

        assertTrue(result is InlineSourceResolver.Result.Resolved)
        result as InlineSourceResolver.Result.Resolved
        assertEquals("https://cdn.example/live.mpd", result.url)
        assertEquals(StreamType.DASH, result.type)
    }

    @Test
    fun rejectsOutOfRangeOptionInsteadOfSilentlyUsingPrimaryUrl() {
        val channel = Channel(
            streamUrl = "https://fallback.example/live.m3u8",
            options = listOf(StreamOption("Only option", "https://embed.example/player", StreamType.IFRAME))
        )

        val result = InlineSourceResolver.resolve(channel, 4)

        assertEquals(
            InlineSourceResolver.Result.Unavailable(InlineSourceResolver.FailureReason.INVALID_SOURCE_INDEX),
            result
        )
    }

    @Test
    fun resolvesPrimaryUrlWhenNoOptionsExist() {
        val channel = Channel(streamUrl = "https://cdn.example/live.m3u8", streamType = StreamType.AUTO)

        val result = InlineSourceResolver.resolve(channel, 0)

        assertEquals(
            InlineSourceResolver.Result.Resolved("https://cdn.example/live.m3u8", StreamType.HLS),
            result
        )
    }

    @Test
    fun rejectsBlankSelectedUrl() {
        val channel = Channel(options = listOf(StreamOption("Vacía", "  ", StreamType.IFRAME)))

        val result = InlineSourceResolver.resolve(channel, 0)

        assertEquals(
            InlineSourceResolver.Result.Unavailable(InlineSourceResolver.FailureReason.EMPTY_URL),
            result
        )
    }

    @Test
    fun doesNotTreatQueryStringExtensionAsMediaType() {
        val channel = Channel(streamUrl = "https://cdn.example/live?redirect=.mpd", streamType = StreamType.AUTO)

        val result = InlineSourceResolver.resolve(channel, 0)

        assertEquals(StreamType.HLS, (result as InlineSourceResolver.Result.Resolved).type)
    }
}
