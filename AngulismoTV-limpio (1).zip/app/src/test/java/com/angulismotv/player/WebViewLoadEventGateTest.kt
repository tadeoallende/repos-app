package com.angulismotv.player

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class WebViewLoadEventGateTest {
    @Test fun acceptsOnlyTheFirstPageFinishForCurrentGeneration() {
        val gate = WebViewLoadEventGate()
        gate.begin(4)
        assertTrue(gate.shouldDeliverPageLoaded(4, isGenerationCurrent = true))
        assertFalse(gate.shouldDeliverPageLoaded(4, isGenerationCurrent = true))
    }

    @Test fun rejectsStalePageFinishAndFailure() {
        val gate = WebViewLoadEventGate()
        gate.begin(5)
        assertFalse(gate.shouldDeliverPageLoaded(5, isGenerationCurrent = false))
        assertFalse(gate.shouldDeliverFailure(5, isGenerationCurrent = false))
    }

    @Test fun reportsOnlyTheFirstFailureForOneGeneration() {
        val gate = WebViewLoadEventGate()
        gate.begin(6)
        assertTrue(gate.shouldDeliverFailure(6, isGenerationCurrent = true))
        assertFalse(gate.shouldDeliverFailure(6, isGenerationCurrent = true))
        assertFalse(gate.shouldDeliverPageLoaded(6, isGenerationCurrent = true))
    }

    @Test fun successAndFailureAreMutuallyExclusiveTerminalEvents() {
        val successFirst = WebViewLoadEventGate()
        successFirst.begin(7)
        assertTrue(successFirst.shouldDeliverPageLoaded(7, isGenerationCurrent = true))
        assertFalse(successFirst.shouldDeliverFailure(7, isGenerationCurrent = true))

        val failureFirst = WebViewLoadEventGate()
        failureFirst.begin(8)
        assertTrue(failureFirst.shouldDeliverFailure(8, isGenerationCurrent = true))
        assertFalse(failureFirst.shouldDeliverPageLoaded(8, isGenerationCurrent = true))
    }

    @Test fun startingANewGenerationResetsTerminalState() {
        val gate = WebViewLoadEventGate()
        gate.begin(9)
        assertTrue(gate.shouldDeliverFailure(9, isGenerationCurrent = true))
        gate.begin(10)
        assertTrue(gate.shouldDeliverPageLoaded(10, isGenerationCurrent = true))
    }
}
