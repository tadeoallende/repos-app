package com.angulismotv.player

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class SidePanelLayoutPolicyTest {
    @Test
    fun `compact screens use shorter labels and bounded columns`() {
        val dimensions = SidePanelLayoutPolicy.calculate(390f)
        assertEquals(120, dimensions.menuWidthDp)
        assertEquals("Buscar", dimensions.searchLabel)
        assertEquals("Canales", dimensions.allChannelsLabel)
        assertTrue(dimensions.listWidthDp >= 96f)
        assertTrue(dimensions.listWidthDp <= 220f)
    }

    @Test
    fun `wide TV screens use standard labels and cap the list width`() {
        val dimensions = SidePanelLayoutPolicy.calculate(1920f)
        assertEquals(208, dimensions.menuWidthDp)
        assertEquals("Buscar canales", dimensions.searchLabel)
        assertEquals("Lista de canales", dimensions.allChannelsLabel)
        assertEquals(420f, dimensions.listWidthDp, 0.01f)
    }
}
