package com.angulismotv.player

import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class WebViewBridgeContractTest {
    @Test
    fun nativeReceiverAndPageApiUseDifferentNames() {
        assertNotEquals(WebViewScripts.NATIVE_BRIDGE_NAME, WebViewScripts.PLAYER_API_NAME)
        assertTrue(WebViewScripts.BRIDGE.contains("window.${WebViewScripts.NATIVE_BRIDGE_NAME}"))
        assertTrue(WebViewScripts.BRIDGE.contains("window.${WebViewScripts.PLAYER_API_NAME}"))
    }

    @Test
    fun stateQueryUsesTheInjectedPageApiNotTheNativeReceiver() {
        assertTrue(WebViewScripts.GET_STATE.contains(WebViewScripts.PLAYER_API_NAME))
        assertFalse(WebViewScripts.GET_STATE.contains(WebViewScripts.NATIVE_BRIDGE_NAME))
    }

    @Test
    fun nativeCallbacksDoNotOverwriteThePageControlApi() {
        assertTrue(WebViewScripts.BRIDGE.contains("if (!window.${WebViewScripts.PLAYER_API_NAME})"))
        assertFalse(WebViewScripts.BRIDGE.contains("if (!window.${WebViewScripts.NATIVE_BRIDGE_NAME})"))
    }

    @Test
    fun html5VideoFallbackSupportsTheSharedOverlayTransport() {
        assertTrue(WebViewScripts.BRIDGE.contains("detectHtml5Video"))
        assertTrue(WebViewScripts.BRIDGE.contains("querySelectorAll('video')"))
        assertTrue(WebViewScripts.BRIDGE.contains("html5Video.currentTime = target"))
        assertTrue(WebViewScripts.BRIDGE.contains("video.addEventListener(eventName"))
        assertTrue(WebViewScripts.BRIDGE.contains("html5Video ? 'html5' : null"))
        assertTrue(WebViewScripts.BRIDGE.contains("suppressProviderControls(video)"))
        assertTrue(WebViewScripts.BRIDGE.contains(".shaka-seek-bar-container"))
        assertTrue(WebViewScripts.BRIDGE.contains(".media-control-button[data-media-control=\"play_pause\"]"))
    }

    @Test
    fun reinjectingTheBridgeReplacesStalePageApiClosures() {
        assertTrue(WebViewScripts.BRIDGE.contains("window.__angulismoTVPlayer = null"))
        assertTrue(WebViewScripts.BRIDGE.contains("window.__angulismoTVVideoMonitor"))
    }
}
