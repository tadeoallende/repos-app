package com.angulismotv.player

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class InlineControlsAutoHideControllerTest {
    @Test fun temporaryShowHidesAfterDeadline() {
        val fixture = Fixture()
        fixture.controller.showTemporarily()

        assertTrue(fixture.controller.isVisible)
        assertEquals(listOf(true), fixture.visibilityChanges)
        fixture.scheduler.advanceBy(3_999L)
        assertTrue(fixture.controller.isVisible)
        fixture.scheduler.advanceBy(1L)
        assertFalse(fixture.controller.isVisible)
        assertEquals(listOf(true, false), fixture.visibilityChanges)
    }

    @Test fun repeatedShowRestartsDeadlineAndStaleTasksCannotHideControls() {
        val fixture = Fixture()
        fixture.controller.showTemporarily()
        val oldTask = fixture.scheduler.pending.single().task
        fixture.scheduler.advanceBy(2_000L)
        fixture.controller.showTemporarily()

        // Simulate a task that was already dequeued before removeCallbacks took effect.
        oldTask.run()
        assertTrue(fixture.controller.isVisible)
        fixture.scheduler.advanceBy(3_999L)
        assertTrue(fixture.controller.isVisible)
        fixture.scheduler.advanceBy(1L)
        assertFalse(fixture.controller.isVisible)
    }

    @Test fun persistentShowCancelsAutoHideUntilExplicitHide() {
        val fixture = Fixture()
        fixture.controller.showTemporarily()
        fixture.scheduler.advanceBy(1_000L)
        fixture.controller.showPersistent()
        fixture.scheduler.advanceBy(20_000L)

        assertTrue(fixture.controller.isVisible)
        assertEquals(listOf(true, true), fixture.visibilityChanges)
        fixture.controller.hide()
        assertFalse(fixture.controller.isVisible)
    }

    @Test fun tvAndUnavailableContainerDoNotShowControls() {
        val tvFixture = Fixture(isTv = true)
        tvFixture.controller.showTemporarily()
        tvFixture.controller.showPersistent()
        assertFalse(tvFixture.controller.isVisible)
        assertTrue(tvFixture.visibilityChanges.isEmpty())

        val hiddenFixture = Fixture(canShow = false)
        hiddenFixture.controller.showTemporarily()
        assertFalse(hiddenFixture.controller.isVisible)
        assertTrue(hiddenFixture.visibilityChanges.isEmpty())
    }

    @Test fun hideAndDisposeCancelPendingWork() {
        val fixture = Fixture()
        fixture.controller.showTemporarily()
        fixture.controller.hide()
        fixture.scheduler.advanceBy(10_000L)
        assertEquals(listOf(true, false), fixture.visibilityChanges)

        fixture.controller.showTemporarily()
        fixture.controller.dispose()
        fixture.scheduler.advanceBy(10_000L)
        assertFalse(fixture.controller.isVisible)
        assertEquals(listOf(true, false, true), fixture.visibilityChanges)
    }

    private class Fixture(
        isTv: Boolean = false,
        canShow: Boolean = true
    ) {
        val scheduler = FakeScheduler()
        val visibilityChanges = mutableListOf<Boolean>()
        val controller = InlineControlsAutoHideController(
            postDelayed = scheduler::postDelayed,
            removeCallbacks = scheduler::remove,
            isTv = { isTv },
            canShow = { canShow },
            onVisibilityChanged = visibilityChanges::add,
            onShowRequested = {},
            autoHideDelayMs = 4_000L
        )
    }

    private class FakeScheduler {
        data class Scheduled(val task: Runnable, val dueAt: Long)
        private var now = 0L
        val pending = mutableListOf<Scheduled>()

        fun postDelayed(task: Runnable, delayMs: Long) {
            pending.removeAll { it.task === task }
            pending += Scheduled(task, now + delayMs)
        }

        fun remove(task: Runnable) {
            pending.removeAll { it.task === task }
        }

        fun advanceBy(deltaMs: Long) {
            val target = now + deltaMs
            while (true) {
                val next = pending.filter { it.dueAt <= target }.minByOrNull { it.dueAt } ?: break
                pending.remove(next)
                now = next.dueAt
                next.task.run()
            }
            now = target
        }
    }
}
