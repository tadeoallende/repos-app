package com.angulismotv.utils

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class ApkIntegrityTest {
    // SHA-256("abc")
    private val abc = "ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad"

    @Test fun hashesKnownVector() {
        assertEquals(abc, ApkIntegrity.sha256Hex("abc".byteInputStream()))
    }

    @Test fun hashesEmptyInput() {
        assertEquals(
            "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855",
            ApkIntegrity.sha256Hex(ByteArray(0).inputStream())
        )
    }

    @Test fun hashesInputLargerThanBuffer() {
        val data = ByteArray(200_000) { (it % 251).toByte() }
        val expected = java.security.MessageDigest.getInstance("SHA-256").digest(data)
            .joinToString("") { "%02x".format(it) }
        assertEquals(expected, ApkIntegrity.sha256Hex(data.inputStream()))
    }

    @Test fun normalizesCaseWhitespaceAndPrefix() {
        assertEquals(abc, ApkIntegrity.normalizeSha256("  ${abc.uppercase()}\n"))
        assertEquals(abc, ApkIntegrity.normalizeSha256("sha256:$abc"))
        assertEquals(abc, ApkIntegrity.normalizeSha256("SHA256: $abc"))
    }

    @Test fun rejectsMalformedDigests() {
        assertNull(ApkIntegrity.normalizeSha256(null))
        assertNull(ApkIntegrity.normalizeSha256(""))
        assertNull(ApkIntegrity.normalizeSha256(abc.dropLast(1)))
        assertNull(ApkIntegrity.normalizeSha256(abc + "0"))
        assertNull(ApkIntegrity.normalizeSha256("z".repeat(64)))
    }

    @Test fun matchesComparesExactly() {
        assertTrue(ApkIntegrity.matches(abc, abc))
        assertFalse(ApkIntegrity.matches(abc, abc.replaceRange(0, 1, "0")))
        assertFalse(ApkIntegrity.matches(abc, abc.dropLast(1)))
    }
}
