# AngulismoTV — Etapa 31: reducir aserciones no nulas

## Cambios
- Se eliminaron aserciones `!!` en la selección del canal actual y en el catálogo recibido por Intent; se usan variables locales y `getOrNull()` para conservar el control explícito de casos vacíos o índices fuera de rango.
- Los `Runnable` de zapping, fallback, reproducción estable y ocultación de controles ahora se programan mediante una referencia local no nula, sin forzar el desempaquetado de propiedades anulables.
- Se quitó el parámetro `position` no utilizado de `selectChannelFromSidePanel()` y se actualizaron sus llamadas.
- Se mantuvieron las diferencias intencionales entre `showControls()` y `showControlsTemporarily()`: el segundo inicia la actualización de la línea de tiempo en móvil, por lo que no son duplicados equivalentes.

## Validación
- Revisión estática de los flujos modificados y búsqueda de `!!` restante en `UnifiedPlayerActivity.kt`.
- ZIP verificado por integridad y XML revisados.
- La compilación de Gradle y las pruebas en dispositivos siguen pendientes; no se declara validación funcional.
