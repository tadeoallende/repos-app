# AngulismoTV — Etapa 28: audio nativo en Android TV

## Cambios
- Se configura el reproductor nativo con `USAGE_MEDIA` y contenido de tipo película, y se activa la gestión de foco de audio de ExoPlayer.
- Se habilita `setHandleAudioBecomingNoisy(true)` para gestionar la desconexión de una salida de audio externa.
- Se aplica la configuración tanto al reproductor integrado (`ChannelsFragment`) como al reproductor de pantalla completa (`UnifiedPlayerActivity`), ya que la sesión integrada puede transferirse a pantalla completa sin crear otro ExoPlayer.
- Se agregan logs `PlayerAudio` al cambiar las pistas: MIME, códecs declarados, canales, frecuencia de muestreo, pista seleccionada y nivel de soporte informado por ExoPlayer. También se registra si la fuente no expone ninguna pista de audio.

## Por qué no se declara resuelto definitivamente
El código anterior no registraba las pistas de audio ni configuraba explícitamente los atributos/foco de audio. Eso no demuestra por sí solo la causa de todos los casos sin sonido. Si la pista está marcada como no compatible por el dispositivo, una configuración de foco no puede añadir soporte para ese códec; se necesitaría una fuente con audio compatible o una conversión/transcodificación fuera del cliente.

## Diagnóstico en un dispositivo afectado
1. Instalar la compilación de prueba en el Android TV afectado.
2. Reproducir un canal con sonido y otro que se escuche sin audio.
3. Filtrar Logcat por `PlayerAudio` y comparar `mime`, `codecs`, `support` y `selected`.
4. Si el audio aparece seleccionado y compatible, revisar el error de `AudioTrack`/decodificador en Logcat y la salida de audio configurada en el TV.
5. Si no hay pistas de audio o el soporte no es compatible, conservar el host del canal y el log del formato para corregir la fuente o el tratamiento específico.

## Validación realizada
- Se comprobó que el ZIP original abre y que los archivos modificados existen.
- La ejecución de `./gradlew testDebugUnitTest` no pudo arrancar: el wrapper necesita descargar Gradle 8.13 desde `services.gradle.org`, pero el entorno no tiene acceso de red. No se afirma que la compilación o las pruebas hayan pasado.
- Falta probar en el Android TV que presenta el problema; los logs de ese dispositivo son necesarios para distinguir entre selección de pista, incompatibilidad de códec y fallo de salida de audio.
