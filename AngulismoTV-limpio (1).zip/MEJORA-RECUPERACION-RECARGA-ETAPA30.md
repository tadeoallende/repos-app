# AngulismoTV — Etapa 30: limpieza de recuperación y recarga

## Cambios
- Se unificó el reinicio del contador de reconexiones y la cancelación de la reconexión pendiente usando `PlaybackRecoveryController.reset(cancelPendingReconnect = true)` al iniciar el zapping y la recarga manual.
- Se eliminó la reasignación redundante de `currentStreamUrl` y `currentStreamType` dentro de `reloadCurrentTransmission()`: ambos valores se leen de la fuente ya seleccionada y se mantienen sin cambios mientras se recarga.
- Se conserva el tratamiento distinto por tipo de fuente: los iframes fuerzan una navegación nueva y las fuentes nativas pasan por `playStream()`.
- Se mantiene la limpieza de tareas de zapping, fallback y watchdog que ya existía, sin alterar la política de reintentos ni la selección de fuente.

## Validación
- Revisión estática de los puntos de entrada `reloadCurrentTransmission()`, `zapTo()` y `PlaybackRecoveryController.reset()`.
- Verificación de que las acciones manuales cancelan el reintento anterior y reinician el contador en una sola llamada.
- ZIP comprobado por integridad y XML revisados.
- No se afirma compilación ni prueba funcional: el entorno no pudo descargar Gradle 8.13 y no dispone de un Android TV para comprobar las transmisiones.

## Pruebas manuales recomendadas
1. Iniciar una fuente HLS/DASH y recargarla; comprobar que el reproductor vuelve a preparar la misma fuente.
2. Recargar una fuente iframe y confirmar que se realiza una navegación nueva.
3. Provocar un error y pulsar recargar antes de que venza el reintento automático; verificar que no se ejecutan dos recuperaciones en paralelo.
4. Cambiar de canal durante un reintento pendiente y confirmar que el canal anterior no vuelve a abrirse.
