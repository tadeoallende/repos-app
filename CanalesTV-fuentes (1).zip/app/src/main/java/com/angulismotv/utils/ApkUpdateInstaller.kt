package com.angulismotv.utils

import android.app.DownloadManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.os.Handler
import android.util.Log
import android.widget.Toast
import java.util.Locale
import java.util.concurrent.Executors

/** Owns DownloadManager operations and APK launch; dialogs remain in UpdateManager. */
class ApkUpdateInstaller(
    context: Context,
    private val mainHandler: Handler,
    private val listener: Listener
) {
    // DownloadManager may finish after the originating Activity has been destroyed.
    private val context = context.applicationContext
    private var activeDownloadId: Long? = null
    private var activeDownloadReceiver: BroadcastReceiver? = null
    private var statusCheckRunnable: Runnable? = null
    private var pausedToastShownForDownload: Long? = null

    interface Listener {
        fun onDownloadError()
        fun onInsufficientSpace()
        fun onInstallPermissionRequired()
    }

    fun downloadAndInstall(apkUrl: String, versionName: String, expectedSha256: String) {
        if (!ApkIntegrityVerifier.isValidSha256(expectedSha256)) {
            Log.e(TAG, "Se rechazó una actualización sin SHA-256 válido")
            listener.onDownloadError()
            return
        }
        val normalizedExpectedSha256 = expectedSha256.lowercase(Locale.ROOT)
        val apkUri = runCatching { Uri.parse(apkUrl) }.getOrNull()
        if (apkUri?.scheme?.equals("https", ignoreCase = true) != true || apkUri.host.isNullOrBlank()) {
            Log.w(TAG, "Se rechazó una URL de APK no segura")
            listener.onDownloadError()
            return
        }

        try {
            val safeVersionName = versionName.replace(Regex("[^A-Za-z0-9._-]"), "_").take(64)
            val fileName = "canalestv-$safeVersionName.apk"
            cleanOldApks()

            val request = DownloadManager.Request(apkUri).apply {
                setTitle("Descargando CanalesTV")
                setDescription("Versión $versionName")
                setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, fileName)
                } else {
                    setDestinationInExternalFilesDir(context, Environment.DIRECTORY_DOWNLOADS, fileName)
                }
                setMimeType("application/vnd.android.package-archive")
                setAllowedOverMetered(true)
                setAllowedOverRoaming(false)
            }

            val downloadManager = context.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
            val downloadId = downloadManager.enqueue(request)
            Log.d(TAG, "Descarga iniciada con ID: $downloadId")
            Toast.makeText(context, "Descargando actualización...", Toast.LENGTH_SHORT).show()
            registerDownloadReceiver(downloadId, downloadManager, normalizedExpectedSha256)
        } catch (error: Exception) {
            Log.e(TAG, "No se pudo iniciar la descarga (${error.javaClass.simpleName})")
            listener.onDownloadError()
        }
    }

    private fun registerDownloadReceiver(
        downloadId: Long,
        downloadManager: DownloadManager,
        expectedSha256: String
    ) {
        // Only one update download is tracked at a time. Stop an older in-flight transfer too;
        // merely untracking it would waste bandwidth and leave a second APK download orphaned.
        activeDownloadId?.let { previousId ->
            finishTracking(previousId)
            runCatching { downloadManager.remove(previousId) }
                .onFailure { Log.w(TAG, "No se pudo cancelar la descarga anterior", it) }
        }
        pausedToastShownForDownload = null
        val receiver = object : BroadcastReceiver() {
            override fun onReceive(ctx: Context, intent: Intent) {
                val receivedId = intent.getLongExtra(DownloadManager.EXTRA_DOWNLOAD_ID, -1)
                if (receivedId != downloadId || activeDownloadId != downloadId) return
                // The completion broadcast can race with DownloadManager's final status update.
                // Keep the receiver until a terminal state is confirmed.
                mainHandler.post { checkDownloadStatus(downloadId, downloadManager, expectedSha256) }
            }
        }
        activeDownloadId = downloadId
        activeDownloadReceiver = receiver

        try {
            val filter = IntentFilter(DownloadManager.ACTION_DOWNLOAD_COMPLETE)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                context.registerReceiver(receiver, filter, Context.RECEIVER_NOT_EXPORTED)
            } else {
                @Suppress("UnspecifiedRegisterReceiverFlag")
                context.registerReceiver(receiver, filter)
            }
            // Handles the case where the download completes before the receiver is registered.
            checkDownloadStatus(downloadId, downloadManager, expectedSha256)
        } catch (error: Exception) {
            Log.e(TAG, "Error registrando receiver o consultando la descarga: ${error.javaClass.simpleName}")
            finishTracking(downloadId)
            runCatching { downloadManager.remove(downloadId) }
            mainHandler.post { listener.onDownloadError() }
        }
    }

    private fun checkDownloadStatus(
        downloadId: Long,
        downloadManager: DownloadManager,
        expectedSha256: String
    ) {
        if (activeDownloadId != downloadId) return
        statusCheckRunnable?.let(mainHandler::removeCallbacks)
        statusCheckRunnable = null
        try {
            val cursor = downloadManager.query(DownloadManager.Query().setFilterById(downloadId))
            cursor.use {
                if (!it.moveToFirst()) {
                    Log.e(TAG, "No se encontró la descarga con ID: $downloadId")
                    finishTracking(downloadId)
                    mainHandler.post { listener.onDownloadError() }
                    return
                }

                val statusIndex = it.getColumnIndex(DownloadManager.COLUMN_STATUS)
                val reasonIndex = it.getColumnIndex(DownloadManager.COLUMN_REASON)
                val status = if (statusIndex >= 0) it.getInt(statusIndex) else -1
                val reason = if (reasonIndex >= 0) it.getInt(reasonIndex) else -1
                when (status) {
                    DownloadManager.STATUS_SUCCESSFUL -> {
                        finishTracking(downloadId)
                        Log.d(TAG, "Descarga completada exitosamente")
                        verifyAndInstallApk(downloadId, downloadManager, expectedSha256)
                    }
                    DownloadManager.STATUS_FAILED -> {
                        finishTracking(downloadId)
                        handleDownloadError(reason)
                    }
                    DownloadManager.STATUS_PAUSED -> {
                        Log.d(TAG, "Descarga pausada. Reason: $reason")
                        if (pausedToastShownForDownload != downloadId) {
                            pausedToastShownForDownload = downloadId
                            mainHandler.post {
                                Toast.makeText(context, "Descarga pausada. Verificá tu conexión.", Toast.LENGTH_LONG).show()
                            }
                        }
                        scheduleStatusCheck(downloadId, downloadManager, expectedSha256)
                    }
                    DownloadManager.STATUS_PENDING, DownloadManager.STATUS_RUNNING ->
                        scheduleStatusCheck(downloadId, downloadManager, expectedSha256)
                    else -> {
                        finishTracking(downloadId)
                        Log.w(TAG, "Estado de descarga desconocido: $status")
                        mainHandler.post { listener.onDownloadError() }
                    }
                }
            }
        } catch (error: Exception) {
            finishTracking(downloadId)
            Log.e(TAG, "No se pudo consultar el estado de la descarga (${error.javaClass.simpleName})")
            mainHandler.post { listener.onDownloadError() }
        }
    }

    private fun scheduleStatusCheck(
        downloadId: Long,
        downloadManager: DownloadManager,
        expectedSha256: String
    ) {
        if (activeDownloadId != downloadId) return
        statusCheckRunnable?.let(mainHandler::removeCallbacks)
        val runnable = Runnable {
            if (activeDownloadId == downloadId) {
                statusCheckRunnable = null
                checkDownloadStatus(downloadId, downloadManager, expectedSha256)
            }
        }
        statusCheckRunnable = runnable
        mainHandler.postDelayed(runnable, STATUS_RECHECK_DELAY_MS)
    }

    private fun finishTracking(downloadId: Long) {
        if (activeDownloadId != downloadId) return
        statusCheckRunnable?.let(mainHandler::removeCallbacks)
        statusCheckRunnable = null
        activeDownloadReceiver?.let { receiver ->
            runCatching { context.unregisterReceiver(receiver) }
        }
        activeDownloadReceiver = null
        activeDownloadId = null
        pausedToastShownForDownload = null
    }

    private fun handleDownloadError(reason: Int) {
        val message = when (reason) {
            DownloadManager.ERROR_CANNOT_RESUME -> "No se puede reanudar la descarga"
            DownloadManager.ERROR_DEVICE_NOT_FOUND -> "Dispositivo de almacenamiento no encontrado"
            DownloadManager.ERROR_FILE_ALREADY_EXISTS -> "El archivo ya existe"
            DownloadManager.ERROR_FILE_ERROR -> "Problema con el archivo"
            DownloadManager.ERROR_HTTP_DATA_ERROR -> "Datos HTTP incorrectos"
            DownloadManager.ERROR_INSUFFICIENT_SPACE -> "Espacio insuficiente en el dispositivo"
            DownloadManager.ERROR_TOO_MANY_REDIRECTS -> "Demasiadas redirecciones"
            DownloadManager.ERROR_UNHANDLED_HTTP_CODE -> "Código HTTP no manejado"
            DownloadManager.ERROR_UNKNOWN -> "Error desconocido"
            else -> "Error: $reason"
        }
        Log.e(TAG, "Error de descarga: $message")
        if (reason == DownloadManager.ERROR_INSUFFICIENT_SPACE) listener.onInsufficientSpace()
        else listener.onDownloadError()
    }

    /**
     * Hashing an APK can take seconds on low-end TVs. Do it away from the main thread,
     * then open the system installer only after verification succeeds.
     */
    private fun verifyAndInstallApk(
        downloadId: Long,
        downloadManager: DownloadManager,
        expectedSha256: String
    ) {
        val uri = try {
            downloadManager.getUriForDownloadedFile(downloadId)
        } catch (error: Exception) {
            Log.e(TAG, "No se pudo obtener el archivo descargado (${error.javaClass.simpleName})")
            null
        }
        if (uri == null) {
            Log.e(TAG, "URI de archivo descargado es null")
            mainHandler.post { listener.onDownloadError() }
            return
        }

        verificationExecutor.execute {
            val verified = try {
                context.contentResolver.openInputStream(uri)?.use { input ->
                    ApkIntegrityVerifier.matches(input, expectedSha256)
                } ?: false
            } catch (error: Exception) {
                Log.e(TAG, "No se pudo verificar el SHA-256 (${error.javaClass.simpleName})")
                false
            }

            mainHandler.post {
                if (!verified) {
                    Log.e(TAG, "La verificación SHA-256 del APK falló; se cancela la instalación")
                    runCatching { context.contentResolver.delete(uri, null, null) }
                    listener.onDownloadError()
                    return@post
                }
                launchInstaller(uri)
            }
        }
    }

    private fun launchInstaller(uri: Uri) {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O &&
                !context.packageManager.canRequestPackageInstalls()) {
                listener.onInstallPermissionRequired()
                return
            }

            val intent = Intent(Intent.ACTION_VIEW).apply {
                setDataAndType(uri, APK_MIME_TYPE)
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_GRANT_READ_URI_PERMISSION
            }
            if (intent.resolveActivity(context.packageManager) != null) {
                context.startActivity(intent)
            } else {
                Log.e(TAG, "No se encontró app para instalar APK")
                listener.onDownloadError()
            }
        } catch (error: Exception) {
            Log.e(TAG, "No se pudo abrir el instalador (${error.javaClass.simpleName})")
            if (error is SecurityException) listener.onInstallPermissionRequired()
            else listener.onDownloadError()
        }
    }

    private fun cleanOldApks() {
        try {
            // Never delete from the public Downloads folder: a matching filename there may
            // belong to the user. Only remove stale APKs in this app's private external area.
            val dirs = listOfNotNull(context.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS))
            dirs.forEach { dir ->
                dir.listFiles { file -> file.name.startsWith(APK_FILE_PREFIX) && file.name.endsWith(".apk") }
                    ?.forEach { file ->
                        try {
                            val deleted = file.delete()
                            Log.d(TAG, "APK viejo eliminado: ${file.name} - $deleted")
                        } catch (error: Exception) {
                            Log.w(TAG, "No se pudo eliminar ${file.name}: ${error.message}")
                        }
                    }
            }
        } catch (error: Exception) {
            Log.w(TAG, "Error limpiando APKs viejos: ${error.message}")
        }
    }

    companion object {
        private const val TAG = "ApkUpdateInstaller"
        private const val APK_MIME_TYPE = "application/vnd.android.package-archive"
        private const val APK_FILE_PREFIX = "canalestv-"
        private const val STATUS_RECHECK_DELAY_MS = 5_000L
        private val verificationExecutor = Executors.newSingleThreadExecutor { runnable ->
            Thread(runnable, "CanalesTV-apk-verification").apply { isDaemon = true }
        }
    }
}
