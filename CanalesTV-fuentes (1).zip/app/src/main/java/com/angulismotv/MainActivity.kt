package com.angulismotv

import android.os.Bundle
import android.util.Log
import android.view.KeyEvent
import android.view.Gravity
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.angulismotv.databinding.ActivityMainBinding
import com.angulismotv.fragments.ChannelsFragment
import com.angulismotv.data.ChannelRepository
import com.angulismotv.data.LoadResult
import com.angulismotv.models.Channel
import com.angulismotv.utils.DeviceHelper
import com.angulismotv.utils.UpdateManager
import com.bumptech.glide.Glide
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private var allChannels = listOf<Channel>()
    private var channelsLoading = true
    private var lastLoadResult: LoadResult? = null
    private var channelLoadGeneration = 0
    private var channelLoadJob: Job? = null
    private var isTV = false

    // Reutilizar el Fragment restaurado por FragmentManager tras una recreación.
    // Crear siempre una instancia nueva podía dejar dos ChannelsFragment en el mismo contenedor.
    private val fragmentChannels by lazy(LazyThreadSafetyMode.NONE) {
        supportFragmentManager.findFragmentByTag(TAG_CHANNELS) as? ChannelsFragment ?: ChannelsFragment()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        isTV = DeviceHelper.isTV(this)

        Glide.with(this)
            .load(R.drawable.logo2)
            .placeholder(android.R.drawable.ic_menu_gallery)
            .error(android.R.drawable.ic_menu_gallery)
            .into(binding.logoImage)

        setupContent()
        setupBackHandler()
        loadAllChannels()

        // Check de actualizaciones (silencioso — solo muestra diálogo si hay novedad)
        UpdateManager(this).checkForUpdates(silent = true)
    }

    // ==================== CONTENIDO ====================

    /** La app tiene una sola sección (Canales): se muestra el fragment y se ajusta la cabecera. */
    private fun setupContent() {
        supportFragmentManager.beginTransaction().apply {
            if (fragmentChannels.isAdded) show(fragmentChannels)
            else add(R.id.fragment_container, fragmentChannels, TAG_CHANNELS)
        }.commit()

        if (isTV) {
            setMainContentInset(0)
            setupTvHeader()
        } else {
            setMainContentInset(0)
            setupMobileHeader()
        }
    }

    // ==================== BACK HANDLER ====================

    /**
     * Lógica de back unificada para móvil y TV:
     * 1. Si el fragment visible tiene su propio manejo de back → delegar
     * 2. Si no → confirmar salida con diálogo
     *
     * Para TV también se intercepta KEYCODE_BACK en dispatchKeyEvent
     * antes de que cualquier vista lo consuma.
     */
    private fun setupBackHandler() {
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                handleBack()
            }
        })
    }

    private fun handleBack() {
        val activeFragment = supportFragmentManager.findFragmentByTag(TAG_CHANNELS)
        if (activeFragment is BackHandler && activeFragment.handleBack()) return
        showExitDialog()
    }

    private fun showExitDialog() {
        AlertDialog.Builder(this)
            .setTitle("Salir de CanalesTV")
            .setMessage("¿Querés cerrar la aplicación?")
            .setPositiveButton("Salir") { _, _ -> finish() }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    // ==================== TV KEY DISPATCH ====================

    /**
     * Para TV interceptamos el back a nivel de Activity antes de que
     * cualquier View o Fragment lo consuma — mismo patrón que UnifiedPlayerActivity.
     */
    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        if (!isTV) return super.dispatchKeyEvent(event)
        if (event.action != KeyEvent.ACTION_DOWN) return super.dispatchKeyEvent(event)

        if (event.keyCode == KeyEvent.KEYCODE_BACK) {
            handleBack()
            return true
        }
        return super.dispatchKeyEvent(event)
    }

    // ==================== CABECERA ====================

    private fun setMainContentInset(inset: Int) {
        val params = binding.mainContainer.layoutParams as android.widget.FrameLayout.LayoutParams
        if (params.marginStart != inset) {
            params.marginStart = inset
            binding.mainContainer.layoutParams = params
        }
    }

    private fun setupTvHeader() {
        binding.headerClock.visibility = android.view.View.VISIBLE
        val params = binding.logoImage.layoutParams as android.widget.FrameLayout.LayoutParams
        params.width = dimen(R.dimen.header_logo_width)
        params.height = dimen(R.dimen.header_logo_height_tv)
        params.gravity = Gravity.START or Gravity.CENTER_VERTICAL
        params.marginStart = dimen(R.dimen.header_logo_margin_start_tv)
        binding.logoImage.layoutParams = params

        // En Android TV la búsqueda se abre desde el acceso bajo el reproductor.
        binding.headerSearchButton.visibility = android.view.View.GONE
        binding.headerSearchButton.isFocusable = false
        binding.headerSearchButton.isFocusableInTouchMode = false
        binding.headerSearchButton.isFocusable = true
        binding.headerSearchButton.isFocusableInTouchMode = true
        binding.headerSearchButton.contentDescription = getString(R.string.open_channel_search)
        binding.headerSearchButton.setImageResource(R.drawable.ic_search)
        (binding.headerSearchButton.layoutParams as? android.widget.FrameLayout.LayoutParams)?.let { buttonParams ->
            buttonParams.width = dimen(R.dimen.header_search_button_size_tv)
            buttonParams.height = dimen(R.dimen.header_search_button_size_tv)
            buttonParams.marginEnd = dimen(R.dimen.header_search_button_margin_end_tv)
            binding.headerSearchButton.layoutParams = buttonParams
        }
        binding.headerSearchButton.nextFocusDownId = R.id.inline_player_container
        binding.headerSearchButton.nextFocusLeftId = R.id.inline_player_container
        binding.headerSearchButton.setOnClickListener { fragmentChannels.toggleSearchFromHeader() }
    }

    private fun setupMobileHeader() {
        binding.headerClock.visibility = android.view.View.GONE
        // Cabecera compacta: marca a la izquierda y búsqueda a la derecha, como en una app de TV comercial.
        binding.headerContainer.layoutParams = binding.headerContainer.layoutParams.apply {
            height = dimen(R.dimen.header_height_mobile)
        }
        val contentParams = binding.mainContainer.layoutParams as android.widget.FrameLayout.LayoutParams
        contentParams.marginStart = 0
        contentParams.topMargin = dimen(R.dimen.header_height_mobile)
        binding.mainContainer.layoutParams = contentParams

        val logoParams = binding.logoImage.layoutParams as android.widget.FrameLayout.LayoutParams
        logoParams.width = dimen(R.dimen.header_logo_width)
        logoParams.height = dimen(R.dimen.header_logo_height_mobile)
        logoParams.gravity = Gravity.START or Gravity.CENTER_VERTICAL
        logoParams.marginStart = dimen(R.dimen.header_logo_margin_start_mobile)
        binding.logoImage.layoutParams = logoParams
        binding.headerSearchButton.visibility = android.view.View.VISIBLE
        binding.headerSearchButton.setOnClickListener { fragmentChannels.toggleSearchFromHeader() }
    }

    private fun dimen(resourceId: Int): Int = resources.getDimensionPixelSize(resourceId)

    // ==================== DATA LOADING ====================

    private fun loadAllChannels() {
        if (channelLoadJob?.isActive == true) {
            Log.d(TAG, "Se omite una recarga duplicada: ya hay una carga en curso")
            return
        }
        val generation = ++channelLoadGeneration
        channelsLoading = true
        fragmentChannels.onLoadStarted()
        channelLoadJob = lifecycleScope.launch {
            try {
                if (lastLoadResult == null) {
                    val cached = ChannelRepository.loadCached(this@MainActivity)
                    if (cached != null && generation == channelLoadGeneration && !isFinishing && !isDestroyed) {
                        allChannels = cached.channels
                        lastLoadResult = cached
                        fragmentChannels.showResult(cached)
                        Log.d(TAG, "Catálogo local mostrado de inmediato: " + cached.channels.size + " canales")
                    }
                }
                val fresh = ChannelRepository.loadAll(this@MainActivity)
                // Una recarga más nueva siempre gana: no aplicar respuestas obsoletas.
                if (generation != channelLoadGeneration || isFinishing || isDestroyed) return@launch
                val result = if (fresh.channels.isEmpty() && allChannels.isNotEmpty() &&
                    (fresh.failed || fresh.partialFailure)) {
                    Log.w(TAG, "Falló la actualización; se conserva el último catálogo válido")
                    LoadResult(allChannels, partialFailure = true, sourceName = "Caché local")
                } else fresh
                allChannels = result.channels
                lastLoadResult = result
                fragmentChannels.showResult(result)
                val sourceLabel = result.sourceName ?: "ninguna"
                Log.d(TAG, "Canales cargados: ${allChannels.size} (fuente=$sourceLabel, fallo=${result.failed}, parcial=${result.partialFailure})")
            } catch (cancelled: CancellationException) {
                throw cancelled
            } catch (error: Exception) {
                if (generation != channelLoadGeneration || isFinishing || isDestroyed) return@launch
                Log.e(TAG, "No se pudieron cargar los canales (${error.javaClass.simpleName})", error)
                val result = if (allChannels.isNotEmpty()) {
                    LoadResult(allChannels, partialFailure = true, sourceName = "Caché local")
                } else LoadResult(emptyList(), failed = true)
                lastLoadResult = result
                fragmentChannels.showResult(result)
            } finally {
                if (generation == channelLoadGeneration) channelsLoading = false
            }
        }
    }

    override fun onDestroy() {
        // Cancel any in-flight catalogue request and drop the completed Job reference explicitly.
        channelLoadGeneration++
        channelLoadJob?.cancel()
        channelLoadJob = null
        super.onDestroy()
    }

    // ==================== PUBLIC API ====================

    fun getChannels(): List<Channel> = allChannels

    fun isLoadingChannels(): Boolean = channelsLoading

    fun getLoadResult(): LoadResult? = lastLoadResult

    /** Vuelve a pedir la lista de canales (botón Reintentar y deslizar para actualizar). */
    fun reloadChannels() = loadAllChannels()

    // ==================== COMPANION ====================

    companion object {
        private const val TAG          = "MainActivity"
        private const val TAG_CHANNELS = "fragment_channels"
    }
}

/**
 * Interface que pueden implementar los Fragments para manejar
 * el botón Back internamente (ej: cerrar la búsqueda o el reproductor en línea).
 *
 * Retornar true significa "yo lo manejé, no hagas nada más".
 * Retornar false delega el back a MainActivity.
 */
interface BackHandler {
    fun handleBack(): Boolean
}
