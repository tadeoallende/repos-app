# El SDK de Cast localiza este proveedor por nombre desde AndroidManifest.
-keep class com.angulismotv.utils.CastOptionsProvider { *; }

# Modelos que Gson (de)serializa por reflexión
-keepclassmembers class com.angulismotv.data.ChannelRepository$* { <fields>; }
-keep class com.angulismotv.data.ChannelFeedDataSource$* { <fields>; }
-keep class com.angulismotv.models.** { *; }
-keepattributes Signature, *Annotation*

# Métodos expuestos al JavaScript del WebView
-keepclassmembers class * {
    @android.webkit.JavascriptInterface <methods>;
}
