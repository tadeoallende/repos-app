package com.angulismotv

import androidx.activity.OnBackPressedCallback
import androidx.core.content.IntentCompat
import com.angulismotv.player.ChannelZapAccumulator

import com.angulismotv.player.PlayerControlsAnimator

import android.content.pm.ActivityInfo
import android.content.res.Configuration
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.webkit.WebView
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.SeekBar
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.exoplayer2.ExoPlayer
import com.google.android.exoplayer2.Player
import com.google.android.exoplayer2.ui.PlayerView
import com.angulismotv.player.CastController
import com.angulismotv.player.PlayerPhysicalOrientationController
import com.angulismotv.player.FullscreenPlayerEventController
import com.angulismotv.player.ChannelNumberInputBuffer
import com.angulismotv.player.PlayerChannelCatalog
import com.angulismotv.player.CastStream
import com.angulismotv.player.InlinePlayerHandoff
import com.angulismotv.player.PlaybackRecoveryController
import com.angulismotv.player.PlaybackReloadController
import com.angulismotv.player.PlaybackLifecycleController
import com.angulismotv.player.PlayerTimelineController
import com.angulismotv.player.PlayerSourceSelectionController
import com.angulismotv.player.PlayerRemoteKeyRouter
import com.angulismotv.player.PlayerControlFocusController
import com.angulismotv.player.StreamUtils
import com.angulismotv.player.FullscreenNativePlaybackController
import com.angulismotv.player.FullscreenPlaybackSurfaceController
import com.angulismotv.player.StreamUrlPolicy
import com.angulismotv.player.WebViewPlayerBridge
import com.angulismotv.player.WebViewPlaybackController
import com.angulismotv.player.applyPlayerSettings
import com.angulismotv.utils.NetworkUtils
import com.angulismotv.utils.loadChannelLogo
import com.angulismotv.models.Channel
import com.angulismotv.models.ChannelIdentity
import com.angulismotv.data.FavoritesStore
import com.angulismotv.data.LastPlayedChannelStore
import com.angulismotv.data.ChannelFilterEngine
import com.angulismotv.ui.PlayerControlsLayoutController
import com.angulismotv.ui.PlayerControlStateController
import com.angulismotv.ui.PlayerChannelPanelController
import com.angulismotv.ui.PlayerPanelLayoutPolicy
import com.angulismotv.models.StreamType
import com.angulismotv.utils.DeviceHelper

private const val ZAPPING_START_DELAY_MS = 300L
private const val ZAPPING_RESET_DELAY_MS = 200L

class UnifiedPlayerActivity : AppCompatActivity() {

    private val fullscreenNativePlaybackController by lazy(LazyThreadSafetyMode.NONE) {
        FullscreenNativePlaybackController(
            context = this,
            playerView = playerView,
            playerEvents = fullscreenPlayerEvents,
            setCurrentPlayer = { exoPlayer = it },
            onPlayStateChanged = ::updatePlayPauseButton
        )
    }

    private val fullscreenPlaybackSurfaceController by lazy(LazyThreadSafetyMode.NONE) {
        FullscreenPlaybackSurfaceController(
            playerTimelineContainer = playerTimelineContainer,
            playerView = playerView,
            webView = webView,
            webViewTouchBlocker = webViewTouchBlocker,
            progressBar = progressBar,
            errorText = errorText,
            isTV = { isTV },
            stopTimelineUpdates = ::stopTimelineUpdates,
            invalidatePendingWebLoad = { webViewPlaybackController.invalidatePendingLoad() },
            stopRecoveryWatchdog = { recovery.stopWatchdog() },
            releasePlayer = ::releasePlayer,
            stopWebBridgeMonitor = { webBridge.stopMonitor() },
            detachWebBridge = { webBridge.detach() },
            setCurrentIsLive = { currentIsLive = it },
            setStreamIsLive = { streamIsLive = it },
            setCurrentStreamType = { currentStreamType = it },
            currentGeneration = { playerGeneration },
            lockWebViewFocus = ::lockWebViewFocus
        )
    }

    private val playbackReloadController by lazy(LazyThreadSafetyMode.NONE) {
        PlaybackReloadController(
            selectedChannel = { currentChannel },
            currentUrl = { currentStreamUrl },
            currentType = { currentStreamType },
            isHttpUrl = { url -> StreamUrlPolicy.isHttpUrl(url) },
            isIframeType = { type -> type.equals(StreamType.IFRAME, ignoreCase = true) },
            prepareForReload = {
                playerGeneration++
                cancelPendingZappingReset()
                pendingZapAccumulator.clear()
                isZapping = false
                cancelOptionFallback()
                fullscreenPlayerEvents.clearStableStreamTimer()
                recovery.reset(cancelPendingReconnect = true)
                webViewPlaybackController.invalidatePendingLoad()
                errorText.visibility = View.GONE
                progressBar.visibility = View.VISIBLE
            },
            reloadIframe = { url ->
                // A manual iframe reload must start a fresh navigation, not reuse a stale page.
                reuseInlineWebViewOnLoad = false
                webViewPlaybackController.load(url, reuseLoadedPage = false)
            },
            reloadStream = ::playStream,
            fallbackToFirstOption = ::playFirstValidOption,
            controlsVisible = { controlsVisible },
            resetAutoHideTimer = ::resetAutoHideTimer,
            showMissingChannelError = { showError("No hay ningún canal seleccionado para recargar.") }
        )
    }

    private val playerControlsAnimator = PlayerControlsAnimator()

    // ==================== VIEWS ====================
    private lateinit var btnMenu: ImageButton
    private lateinit var playerView: PlayerView
    private lateinit var playerContainer: FrameLayout
    private lateinit var webView: WebView
    private lateinit var webViewTouchBlocker: View
    private lateinit var progressBar: ProgressBar
    private lateinit var errorText: TextView
    private lateinit var controlsOverlay: View
    private lateinit var bottomControls: View
    private lateinit var playerRemoteHelp: TextView
    private lateinit var btnRewind: ImageButton
    private lateinit var btnForward: ImageButton
    private lateinit var btnPlayPause: ImageButton
    private lateinit var btnClose: ImageButton
    private lateinit var btnOptions: ImageButton
    private lateinit var btnReloadStream: ImageButton
    private lateinit var btnFavoriteChannel: ImageButton
    private lateinit var favoritesStore: FavoritesStore
    private lateinit var mediaRouteButton: ImageButton
    private lateinit var channelLogo: ImageView
    private lateinit var channelNameText: TextView
    private lateinit var channelCategoryText: TextView
    private lateinit var playerControlsMainRow: LinearLayout
    private lateinit var playerActionGroupsRow: LinearLayout
    private lateinit var playerChannelIdentity: LinearLayout
    private lateinit var playerTransportControls: LinearLayout
    private lateinit var playerUtilityControls: LinearLayout
    private lateinit var playerControlsLayoutController: PlayerControlsLayoutController
    private lateinit var playerTimelineContainer: View
    private lateinit var playerSeekBar: SeekBar
    private lateinit var playerTimeCurrent: TextView
    private lateinit var playerTimeDuration: TextView
    private lateinit var timelineController: PlayerTimelineController
    private lateinit var playerControlStateController: PlayerControlStateController

    // Panel lateral
    private lateinit var channelsPanelContainer: LinearLayout
    private lateinit var panelMenuColumn: LinearLayout
    private lateinit var channelsList: RecyclerView
    private lateinit var btnClosePanel: ImageButton
    private lateinit var btnAllChannels: LinearLayout
    private lateinit var allChannelsText: TextView

    // Búsqueda
    private lateinit var btnSearchTrigger: LinearLayout
    private lateinit var searchTriggerText: TextView
    private lateinit var menuSearchInput: EditText
    private lateinit var menuSearchResults: RecyclerView
    private lateinit var searchEmptyText: TextView

    // Categorías
    private lateinit var menuCategoriesList: RecyclerView

    // Minimal channel identity shown briefly while zapping on TV and mobile.
    private var zappingOverlay: LinearLayout? = null
    private var zappingLogo: ImageView? = null

    // ==================== STATE ====================
    private var exoPlayer: ExoPlayer? = null
    private var inlineSessionReturned = false
    private var inlineWebViewOrigin: InlinePlayerHandoff.Session? = null
    private var reuseInlineWebViewOnLoad = false
    private var inlineWebViewReturnedToFragment = false
    private lateinit var webBridge: WebViewPlayerBridge
    private lateinit var cast: CastController
    private var isTV = false
    private var currentChannel: Channel? = null
    private var controlsVisible = false
    private lateinit var playerControlFocusController: PlayerControlFocusController
    // Conserva el último control enfocado para que el mando no vuelva siempre al inicio.
    private var lastFocusedControlId: Int = View.NO_ID
    private var isPanelOpen = false
    private var currentIsLive = false
    private var streamIsLive = false
    private var currentStreamUrl: String = ""
    private var currentStreamType: String = StreamType.AUTO
    private var isZapping = false
    private val pendingZapAccumulator = ChannelZapAccumulator()
    private var clearZappingRunnable: Runnable? = null

    // Entrada de número de canal desde el mando: se confirma con OK o al vencer el tiempo.
    private var channelNumberBuffer = ChannelNumberInputBuffer()
    private val channelNumberTimeoutMs = 1_500L
    private val clearChannelNumberRunnable = Runnable { commitChannelNumberInput() }
    private lateinit var channelNumberOverlay: TextView

    // RECONEXION
    private var playerGeneration = 0
    // Channels
    private var allChannels: List<Channel> = emptyList()
    private var currentChannelIndex: Int = 0
    private val lastPlayedChannelStore by lazy(LazyThreadSafetyMode.NONE) { LastPlayedChannelStore(this) }

    // Handlers
    private val mainHandler = Handler(Looper.getMainLooper())
    private val orientationControllerDelegate = lazy(LazyThreadSafetyMode.NONE) {
        PlayerPhysicalOrientationController(
            context = this,
            handler = mainHandler,
            isActivityUnavailable = { isFinishing || isDestroyed },
            onReturnToInline = {
                finish()
                overridePendingTransition(0, 0)
            }
        )
    }
    private val orientationController by orientationControllerDelegate
    private val recoveryDelegate = lazy(LazyThreadSafetyMode.NONE) {
        PlaybackRecoveryController(
            handler = mainHandler,
            isGenerationCurrent = { generation -> generation == playerGeneration },
            isZapping = { isZapping },
            playerProvider = { exoPlayer },
            streamProvider = { currentStreamUrl to currentStreamType },
            networkAvailable = { NetworkUtils.hasActiveConnection(this) },
            releasePlayer = ::releasePlayer,
            replayStream = { url, type, shouldResume -> showExoPlayer(url, type, shouldResume) },
            showError = ::showError,
            showLoading = {
                progressBar.visibility = View.VISIBLE
                errorText.visibility = View.GONE
            }
        )
    }
    private val recovery by recoveryDelegate
    private val sourceSelectionControllerDelegate = lazy(LazyThreadSafetyMode.NONE) {
        PlayerSourceSelectionController(
            handler = mainHandler,
            currentGeneration = { playerGeneration },
            isZapping = { isZapping },
            currentChannel = { currentChannel },
            selectedOptionIndex = { currentOptionIndex },
            setSelectedOptionIndex = { currentOptionIndex = it },
            currentPlayer = { exoPlayer },
            setCurrentStream = { url, type ->
                if (currentStreamUrl != url || currentStreamType != type) {
                    recovery.reset(cancelPendingReconnect = true)
                }
                currentStreamUrl = url
                currentStreamType = type
            },
            playStream = ::playStream,
            releasePlayer = ::releasePlayer,
            clearError = { errorText.visibility = View.GONE },
            showError = ::showError,
            updateControlsVisibility = ::updateControlsVisibility
        )
    }
    private val sourceSelectionController by sourceSelectionControllerDelegate

    private val fullscreenPlayerEvents by lazy(LazyThreadSafetyMode.NONE) {
        FullscreenPlayerEventController(
            currentGeneration = { playerGeneration },
            currentPlayer = { exoPlayer },
            isZapping = { isZapping },
            isTV = { isTV },
            progressBar = progressBar,
            errorText = errorText,
            recovery = recovery,
            onPlayStateChanged = ::updatePlayPauseButton,
            updateControlsVisibility = ::updateControlsVisibility,
            showControlsTemporarily = ::showControlsTemporarily,
            startTimelineUpdates = ::startTimelineUpdates,
            cancelOptionFallback = ::cancelOptionFallback,
            onLiveStatusChanged = { currentLive, streamLive ->
                currentIsLive = currentLive
                streamIsLive = streamLive
            },
            isStreamLive = { currentIsLive || streamIsLive }
        )
    }

    private var hideControlsRunnable: Runnable? = null
    private var zapRunnable: Runnable? = null
    private lateinit var webViewPlaybackController: WebViewPlaybackController

    private lateinit var channelPanelController: PlayerChannelPanelController

    private val remoteKeyRouter by lazy(LazyThreadSafetyMode.NONE) {
        PlayerRemoteKeyRouter(
            isPanelOpen = { isPanelOpen },
            areControlsVisible = { controlsVisible },
            isZapping = { isZapping },
            streamType = { currentStreamType },
            hasPendingChannelNumber = { channelNumberBuffer.value.isNotEmpty() },
            focusedViewId = { currentFocus?.id ?: View.NO_ID },
            isRightPanelFocused = { isRightPanelFocused() },
            actions = PlayerRemoteKeyRouter.Actions(
                appendChannelNumberDigit = ::appendChannelNumberDigit,
                commitChannelNumberInput = ::commitChannelNumberInput,
                handlePanelBack = { channelPanelController.handleBackInPanel() },
                hideControls = ::hideControls,
                finishActivity = ::finish,
                handlePanelVerticalFocus = ::handlePanelVerticalFocus,
                navigateControlsUp = ::navigateControlsUp,
                navigateControlsDown = ::navigateControlsDown,
                navigateControlsLeft = ::navigateControlsLeft,
                navigateControlsRight = ::navigateControlsRight,
                changeChannel = ::changeChannel,
                moveFocusToCategoriesPanel = ::moveFocusToCategoriesPanel,
                closeSidePanel = ::closeSidePanel,
                openSidePanel = ::openSidePanel,
                activateSearchMode = { channelPanelController.activateSearchMode() },
                moveFocusToChannelsList = ::moveFocusToChannelsList,
                showControls = ::showControls,
                activateFocusedControl = ::activateFocusedControl,
                controlWebPlayer = { action -> webBridge.control(action) },
                toggleNativePlayback = ::togglePlayPause,
                playNativePlayback = {
                    exoPlayer?.play()
                    updatePlayPauseButton(true)
                },
                pauseNativePlayback = {
                    exoPlayer?.pause()
                    updatePlayPauseButton(false)
                },
                clickForward = { btnForward.performClick() },
                clickRewind = { btnRewind.performClick() }
            )
        )
    }

    // ==================== LIFECYCLE ====================

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        isTV = DeviceHelper.isTV(this)
        if (!isTV) enableImmersiveFullscreen()
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        setContentView(R.layout.activity_unified_player)
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (!isTV) finish()
            }
        })

        bindViews()
        setupPlayerUiControllers()
        configureInitialOrientation()
        setupWebViewPlayback()
        setupCast()
        setupPlayerUi()
        loadChannelData()
    }

    private fun setupPlayerUiControllers() {
        playerControlsLayoutController = PlayerControlsLayoutController(
            context = this,
            isTV = isTV,
            playerControlsMainRow = playerControlsMainRow,
            playerChannelIdentity = playerChannelIdentity,
            playerActionGroupsRow = playerActionGroupsRow,
            playerTransportControls = playerTransportControls,
            playerUtilityControls = playerUtilityControls,
            bottomControls = bottomControls,
            centerTransportControlsContainer = findViewById(R.id.center_transport_controls_container)
        )
        timelineController = PlayerTimelineController(
            handler = mainHandler,
            container = playerTimelineContainer,
            seekBar = playerSeekBar,
            currentTime = playerTimeCurrent,
            durationTime = playerTimeDuration,
            playerProvider = { exoPlayer },
            isTimelineEnabled = { !isTV && currentStreamType != StreamType.IFRAME && controlsVisible },
            shouldContinueUpdates = { controlsVisible && exoPlayer != null }
        )
        playerControlStateController = PlayerControlStateController(
            isTv = { isTV },
            streamType = { currentStreamType },
            castConfigured = { cast.isConfigured },
            hasMultipleOptions = ::hasMultipleOptions,
            currentIsLive = { currentIsLive },
            streamIsLive = { streamIsLive },
            iframeIsControllable = { webBridge.isControllable },
            iframeIsPlaying = { webBridge.isPlaying },
            iframeDurationMs = { webBridge.duration },
            menuButton = btnMenu,
            playPauseButton = btnPlayPause,
            rewindButton = btnRewind,
            forwardButton = btnForward,
            optionsButton = btnOptions,
            reloadButton = btnReloadStream,
            closeButton = btnClose,
            castButton = mediaRouteButton,
            onPlayStateChanged = ::updatePlayPauseButton,
            updateControlFocusOrder = ::updateControlFocusOrder
        )
        playerControlsLayoutController.apply(resources.configuration.orientation)
        playerControlFocusController = PlayerControlFocusController(
            isTv = { isTV },
            controlsVisible = { controlsVisible },
            isPanelOpen = { isPanelOpen },
            lastFocusedControlId = { lastFocusedControlId },
            playerContainer = playerContainer,
            controlsProvider = {
                listOf(
                    btnRewind,
                    btnPlayPause,
                    btnForward,
                    btnMenu,
                    mediaRouteButton,
                    btnOptions,
                    btnReloadStream,
                    btnClose
                )
            },
            resetAutoHideTimer = ::resetAutoHideTimer
        )
    }

    private fun configureInitialOrientation() {
        // El fullscreen forzado en móvil permanece en horizontal. El retorno al mini-player
        // se decide por orientación física, no solo por la configuración visible de la Activity.
        val inlineMobileFullscreen = !isTV &&
            intent.getBooleanExtra("from_inline_player", false) &&
            intent.getBooleanExtra("force_landscape_fullscreen", false)
        requestedOrientation = when {
            isTV -> ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
            inlineMobileFullscreen -> ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
            else -> ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
        }
        orientationController.configure(inlineMobileFullscreen)
    }

    private fun setupWebViewPlayback() {
        webBridge = WebViewPlayerBridge(
            webView = webView,
            handler = mainHandler,
            isIframeActive = { currentStreamType == StreamType.IFRAME },
            onStateChanged = ::updateWebViewControls
        )
        webViewPlaybackController = WebViewPlaybackController(
            webView = webView,
            touchBlocker = webViewTouchBlocker,
            playerView = playerView,
            playerContainer = playerContainer,
            progressBar = progressBar,
            controlsOverlay = controlsOverlay,
            bottomControls = bottomControls,
            bridge = webBridge,
            isTV = { isTV },
            currentStreamType = { currentStreamType },
            updateControlsVisibility = ::updateControlsVisibility,
            lockWebViewFocus = ::lockWebViewFocus,
            showControlsTemporarily = ::showControlsTemporarily,
            onMainFrameError = ::handleWebViewMainFrameError
        )
    }

    private fun setupCast() {
        cast = CastController(
            activity = this,
            button = mediaRouteButton,
            handler = mainHandler,
            currentStream = {
                if (currentStreamUrl.isEmpty()) null
                else {
                    // Antes de STATE_READY no afirmamos que el stream sea VOD: las listas HLS/DASH
                    // pueden ser en vivo y Cast debe conservar el comportamiento predeterminado.
                    val liveStatus: Boolean? = when {
                        currentIsLive || streamIsLive -> true
                        exoPlayer?.playbackState == Player.STATE_READY -> false
                        else -> null
                    }
                    CastStream(currentStreamUrl, currentStreamType, currentChannel?.name ?: "Canal", liveStatus)
                }
            },
            onCastStarted = { exoPlayer?.pause() },
            onStatusChanged = { message ->
                mediaRouteButton.contentDescription = message
                if (isTV) playerRemoteHelp.text = message
                else android.widget.Toast.makeText(this, message, android.widget.Toast.LENGTH_SHORT).show()
            }
        )
        cast.setup(isTV)
    }

    private fun setupPlayerUi() {
        setupWebViewForTV()
        setupWebViewTouchBlocker()
        setupSidePanel()
        setupControls()
    }

    private var resumePlaybackAfterPause = false

    private val playbackLifecycleController by lazy(LazyThreadSafetyMode.NONE) {
        PlaybackLifecycleController(
            isTV = { isTV },
            isZapping = { isZapping },
            isFinishing = { isFinishing },
            isFromInlinePlayer = { intent.getBooleanExtra("from_inline_player", false) },
            resumeAfterPause = { resumePlaybackAfterPause },
            setResumeAfterPause = { resumePlaybackAfterPause = it },
            nativePlayerWantsPlay = { exoPlayer?.playWhenReady == true },
            playNativePlayer = { exoPlayer?.play() },
            pauseNativePlayer = { exoPlayer?.pause() },
            returnSessionToInline = ::returnSessionToInline,
            orientationOnResume = { orientationController.onResume() },
            orientationOnPause = { orientationController.onPause() },
            enableImmersiveFullscreen = ::enableImmersiveFullscreen,
            startCastDiscovery = { cast.startDiscovery() },
            stopCastDiscovery = { cast.stopDiscovery() },
            resumeWebView = { webView.onResume() },
            pauseWebView = { webView.onPause() },
            stopRecoveryWatchdog = { recovery.stopWatchdog() }
        )
    }

    override fun onResume() {
        super.onResume()
        playbackLifecycleController.onResume()
    }

    override fun onPause() {
        playbackLifecycleController.onPauseBeforeSuper()
        super.onPause()
        playbackLifecycleController.onPauseAfterSuper()
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus && !isTV) enableImmersiveFullscreen()
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        playerControlsLayoutController.apply(newConfig.orientation)
        // No desbloquear a FULL_SENSOR aquí: la configuración visible puede cambiar a landscape
        // mientras el dispositivo sigue físicamente en portrait. El sensor dedicado distingue
        // ese giro impuesto del posterior regreso físico a vertical.
        if (!isTV) enableImmersiveFullscreen()
    }

    override fun onStop() {
        playbackLifecycleController.onStopBeforeSuper()
        super.onStop()
        playbackLifecycleController.onStopAfterSuper()
    }

    override fun onDestroy() {
        if (orientationControllerDelegate.isInitialized()) orientationController.dispose()
        playerGeneration++
        if (::webViewPlaybackController.isInitialized) webViewPlaybackController.invalidatePendingLoad()
        clearZappingRunnable?.let(mainHandler::removeCallbacks)
        clearZappingRunnable = null
        zappingOverlay?.removeCallbacks(hideZappingRunnable)
        if (sourceSelectionControllerDelegate.isInitialized()) sourceSelectionController.dispose()
        if (recoveryDelegate.isInitialized()) recovery.dispose()
        pendingZapAccumulator.clear()
        zapRunnable = null
        mainHandler.removeCallbacksAndMessages(null)
        stopTimelineUpdates()
        if (isFinishing && intent.getBooleanExtra("from_inline_player", false) && !inlineSessionReturned) {
            returnSessionToInline()
        }
        if (::cast.isInitialized) cast.dispose()
        releasePlayer()
        if (::webBridge.isInitialized) {
            webBridge.stopMonitor()
            webBridge.detach()
        }
        if (::webViewPlaybackController.isInitialized) {
            webViewPlaybackController.dispose(destroyWebView = !inlineWebViewReturnedToFragment)
        }
        super.onDestroy()
    }



    // ==================== BIND VIEWS ====================

    private fun bindViews() {
        bindPlaybackSurfaceViews()
        bindPlayerControlViews()
        bindChannelPanelViews()
        bindZappingViews()
    }

    private fun bindPlaybackSurfaceViews() {
        btnMenu = findViewById(R.id.btn_menu)
        playerView = findViewById(R.id.player_view)
        playerContainer = findViewById(R.id.player_container)
        if (isTV) {
            // Superficie de foco de respaldo cuando el stream se reproduce dentro de WebView.
            playerContainer.isFocusable = true
            playerContainer.isFocusableInTouchMode = true
        }

        val webViewPlaceholder = findViewById<WebView>(R.id.web_view)
        val handedOffSession = if (intent.getBooleanExtra("reuse_inline_webview_session", false)) {
            InlinePlayerHandoff.takePendingWebViewForFullscreen()
        } else null
        if (handedOffSession?.webView != null) {
            val parent = webViewPlaceholder.parent as? ViewGroup
            val childIndex = parent?.indexOfChild(webViewPlaceholder) ?: -1
            val layoutParams = webViewPlaceholder.layoutParams
            parent?.removeView(webViewPlaceholder)
            val transferred = handedOffSession.webView
            (transferred.parent as? ViewGroup)?.removeView(transferred)
            if (parent != null) parent.addView(transferred, childIndex.coerceAtLeast(0), layoutParams)
            runCatching {
                webViewPlaceholder.stopLoading()
                webViewPlaceholder.removeAllViews()
                webViewPlaceholder.destroy()
            }
            webView = transferred
            inlineWebViewOrigin = handedOffSession
            reuseInlineWebViewOnLoad = true
        } else {
            webView = webViewPlaceholder
        }

        webViewTouchBlocker = findViewById(R.id.web_view_touch_blocker)
        progressBar = findViewById(R.id.progress_bar)
        errorText = findViewById(R.id.error_text)
        controlsOverlay = findViewById(R.id.controls_overlay)
        bottomControls = findViewById(R.id.bottom_controls)
        playerRemoteHelp = findViewById(R.id.player_remote_help)
        playerRemoteHelp.visibility = if (isTV) View.VISIBLE else View.GONE
    }

    private fun bindPlayerControlViews() {
        btnRewind = findViewById(R.id.btn_rewind)
        btnForward = findViewById(R.id.btn_forward)
        btnPlayPause = findViewById(R.id.btn_play_pause)
        btnClose = findViewById(R.id.btn_close_player)
        btnOptions = findViewById(R.id.btn_options)
        btnReloadStream = findViewById(R.id.btn_reload_stream)
        btnFavoriteChannel = findViewById(R.id.btn_favorite_channel)
        favoritesStore = FavoritesStore(this)
        mediaRouteButton = findViewById(R.id.media_route_button)
        channelLogo = findViewById(R.id.channel_logo)
        channelNameText = findViewById(R.id.channel_name)
        channelCategoryText = findViewById(R.id.channel_category)
        playerControlsMainRow = findViewById(R.id.player_controls_main_row)
        playerActionGroupsRow = findViewById(R.id.player_action_groups_row)
        playerChannelIdentity = findViewById(R.id.player_channel_identity)
        playerTransportControls = findViewById(R.id.player_transport_controls)
        playerUtilityControls = findViewById(R.id.player_utility_controls)
        playerTimelineContainer = findViewById(R.id.player_timeline_container)
        playerSeekBar = findViewById(R.id.player_seek_bar)
        playerTimeCurrent = findViewById(R.id.player_time_current)
        playerTimeDuration = findViewById(R.id.player_time_duration)
    }

    private fun bindChannelPanelViews() {
        channelsPanelContainer = findViewById(R.id.channels_panel_container)
        channelsList = findViewById(R.id.channels_list)
        panelMenuColumn = findViewById(R.id.panel_menu_column)
        btnClosePanel = findViewById(R.id.btn_close_panel)
        btnAllChannels = findViewById(R.id.btn_all_channels)
        allChannelsText = findViewById(R.id.all_channels_text)
        btnSearchTrigger = findViewById(R.id.btn_search_trigger)
        searchTriggerText = findViewById(R.id.search_trigger_text)
        menuSearchInput = findViewById(R.id.menu_search_input)
        menuSearchResults = findViewById(R.id.menu_search_results)
        searchEmptyText = findViewById(R.id.search_empty_text)
        menuCategoriesList = findViewById(R.id.menu_categories_list)
    }

    private fun bindZappingViews() {
        zappingOverlay = findViewById(R.id.zapping_overlay)
        zappingLogo = findViewById(R.id.zapping_logo)
        channelNumberOverlay = findViewById(R.id.channel_number_overlay)
    }

    // ==================== FULLSCREEN ====================

    private fun enableImmersiveFullscreen() {
        WindowCompat.setDecorFitsSystemWindows(window, false)
        WindowInsetsControllerCompat(window, window.decorView).apply {
            hide(WindowInsetsCompat.Type.systemBars())
            systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        }
        @Suppress("DEPRECATION")
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.R) {
            window.decorView.systemUiVisibility = (
                    View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                            or View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                            or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                            or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                            or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                            or View.SYSTEM_UI_FLAG_FULLSCREEN
                    )
        }
    }

    // ==================== WEBVIEW ====================

    private fun setupWebViewForTV() {
        if (!isTV) return
        webView.apply {
            isFocusable = false
            isFocusableInTouchMode = false
            isClickable = false
            isLongClickable = false
            applyPlayerSettings()
        }
    }

    private fun setupWebViewTouchBlocker() {
        webViewTouchBlocker.apply {
            setOnTouchListener { _, event ->
                if (!isTV && event.action == MotionEvent.ACTION_UP) {
                    if (controlsVisible) hideControls() else showControlsTemporarily()
                }
                true
            }
            visibility = View.GONE
        }
    }

    /**
     * Actualiza los controles según el estado del WebView
     */
    private fun updateWebViewControls() {
        runOnUiThread {
            if (currentStreamType != StreamType.IFRAME) return@runOnUiThread
            // Reutiliza la política común de transporte para TV y móvil.
            updateIframeTransportControls()
            btnOptions.visibility = if (hasMultipleOptions()) View.VISIBLE else View.GONE
            if (isTV) {
                btnMenu.visibility = View.VISIBLE
                btnMenu.isFocusable = true
                btnClose.isFocusable = true
            }
            if (controlsVisible) {
                bottomControls.visibility = View.VISIBLE
                bottomControls.bringToFront()
            }
            updateControlFocusOrder()
        }
    }

    // ==================== SIDE PANEL ====================

    private fun setupSidePanel() {
        channelPanelController = PlayerChannelPanelController(
            activity = this,
            channelsList = channelsList,
            menuCategoriesList = menuCategoriesList,
            menuSearchResults = menuSearchResults,
            menuSearchInput = menuSearchInput,
            searchInputContainer = findViewById(R.id.search_input_container),
            searchEmptyText = searchEmptyText,
            contentTitle = findViewById(R.id.content_title),
            channelsCountText = findViewById(R.id.channels_count),
            btnAllChannels = btnAllChannels,
            allChannelsMarker = findViewById(R.id.all_channels_marker),
            allChannelsIcon = findViewById(R.id.all_channels_icon),
            allChannelsText = allChannelsText,
            btnSearchTrigger = btnSearchTrigger,
            btnClosePanel = btnClosePanel,
            getChannels = { allChannels },
            getCurrentChannel = { currentChannel },
            onChannelSelected = { channel, _ -> selectChannelFromSidePanel(channel) },
            onFocusChannels = ::moveFocusToChannelsList,
            onClosePanel = ::closeSidePanel
        )
        channelPanelController.initialize(isTV)
    }

    // ==================== CONTROLS ====================

    private fun setupControls() {
        btnClose.setOnClickListener { finish() }
        setupTimelineSeekBar()
        setupPlaybackButtons()
        setupChannelActionButtons()
        configureControlsForDevice()
    }

    private fun setupTimelineSeekBar() {
        playerSeekBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onStartTrackingTouch(seekBar: SeekBar?) {
                timelineController.onStartTracking()
                resetAutoHideTimer()
            }

            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                timelineController.onProgressChanged(progress, fromUser)
            }

            override fun onStopTrackingTouch(seekBar: SeekBar?) {
                timelineController.onStopTracking()
                resetAutoHideTimer()
            }
        })
    }

    private fun setupPlaybackButtons() {
        btnPlayPause.setOnClickListener {
            if (currentStreamType == StreamType.IFRAME && isTV) {
                webBridge.control("toggle")
                resetAutoHideTimer()
            } else if (currentStreamType != StreamType.IFRAME) {
                togglePlayPause()
                resetAutoHideTimer()
            }
        }
        btnRewind.setOnClickListener { seekBySeconds(-10L) }
        btnForward.setOnClickListener { seekBySeconds(10L) }
    }

    /** Applies the same seek rules to both transport buttons and native/web streams. */
    private fun seekBySeconds(offsetSeconds: Long) {
        if (currentStreamType == StreamType.IFRAME && isTV && webBridge.isControllable) {
            val requestedTime = webBridge.currentTime + offsetSeconds
            val targetTime = if (offsetSeconds < 0) {
                requestedTime.coerceAtLeast(0L)
            } else {
                requestedTime.coerceAtMost(webBridge.duration)
            }
            webBridge.control("seek", targetTime.toDouble())
            resetAutoHideTimer()
            return
        }

        if (currentStreamType == StreamType.IFRAME || currentIsLive || streamIsLive) return

        val currentPosition = exoPlayer?.currentPosition ?: 0L
        if (offsetSeconds < 0) {
            exoPlayer?.seekTo((currentPosition + offsetSeconds * 1_000L).coerceAtLeast(0L))
        } else {
            val duration = exoPlayer?.duration ?: 0L
            if (duration > 0L) {
                exoPlayer?.seekTo((currentPosition + offsetSeconds * 1_000L).coerceAtMost(duration))
            }
        }
        resetAutoHideTimer()
    }

    private fun setupChannelActionButtons() {
        btnMenu.setOnClickListener {
            if (isTV) {
                if (isPanelOpen) closeSidePanel() else openSidePanel()
            }
        }
        btnMenu.visibility = View.GONE
        btnOptions.setOnClickListener {
            showOptionsDialog(currentChannel ?: return@setOnClickListener)
            resetAutoHideTimer()
        }
        btnReloadStream.setOnClickListener { reloadCurrentTransmission() }
        btnFavoriteChannel.setOnClickListener {
            val channel = currentChannel ?: return@setOnClickListener
            val added = favoritesStore.toggle(channel)
            updateFavoriteButton(channel)
            android.widget.Toast.makeText(
                this,
                if (added) "Agregado a favoritos" else "Quitado de favoritos",
                android.widget.Toast.LENGTH_SHORT
            ).show()
            resetAutoHideTimer()
        }
    }

    private fun configureControlsForDevice() {
        if (isTV) {
            listOf(
                btnMenu, btnPlayPause, btnRewind, btnForward, btnOptions,
                btnFavoriteChannel, btnReloadStream, btnClose, mediaRouteButton
            ).forEach { control ->
                control.isFocusable = true
                control.isFocusableInTouchMode = true
                control.isClickable = true
                val size = resources.getDimensionPixelSize(R.dimen.player_control_size_tv)
                control.layoutParams = control.layoutParams.apply { width = size; height = size }
                control.setOnFocusChangeListener { view, hasFocus ->
                    if (hasFocus) {
                        lastFocusedControlId = view.id
                        view.animate().scaleX(1.06f).scaleY(1.06f).setDuration(120L).start()
                        if (controlsVisible && !isPanelOpen) resetAutoHideTimer()
                    } else {
                        view.animate().scaleX(1f).scaleY(1f).setDuration(120L).start()
                    }
                }
            }
            controlsOverlay.visibility = View.GONE
            bottomControls.visibility = View.GONE
            controlsVisible = false
        } else {
            playerView.setOnClickListener {
                if (controlsVisible) hideControls() else showControlsTemporarily()
            }
        }
    }

    private fun togglePlayPause() {
        val player = exoPlayer ?: return
        if (player.isPlaying) {
            player.pause()
            updatePlayPauseButton(false)
        } else {
            player.play()
            updatePlayPauseButton(true)
        }
    }

    /** Mantiene icono y etiqueta accesible sincronizados con la acción disponible. */
    private fun updatePlayPauseButton(isPlaying: Boolean) {
        btnPlayPause.setImageResource(if (isPlaying) R.drawable.ic_pause else R.drawable.ic_play)
        btnPlayPause.contentDescription = if (isPlaying) "Pausar" else "Reproducir"
    }

    // ==================== TV KEY HANDLING ====================

    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        if (!isTV || event.action != KeyEvent.ACTION_DOWN) return super.dispatchKeyEvent(event)
        if (event.repeatCount > 0 && remoteKeyRouter.digitForKey(event.keyCode) >= 0) return true
        return if (remoteKeyRouter.handleKey(event.keyCode)) true else super.dispatchKeyEvent(event)
    }

    private fun appendChannelNumberDigit(digit: Int) {
        if (allChannels.isEmpty() || isZapping) return
        val result = channelNumberBuffer.append(digit, allChannels.size) ?: return
        channelNumberOverlay.text = "CANAL  ${result.value}"
        channelNumberOverlay.visibility = View.VISIBLE
        mainHandler.removeCallbacks(clearChannelNumberRunnable)
        mainHandler.postDelayed(clearChannelNumberRunnable, channelNumberTimeoutMs)

        // Para catálogos grandes se permiten 4 o 5 cifras; la entrada completa se aplica
        // al alcanzar el máximo o al vencer el timeout/confirmar con OK.
        if (result.shouldCommitImmediately) commitChannelNumberInput()
    }

    private fun commitChannelNumberInput() {
        mainHandler.removeCallbacks(clearChannelNumberRunnable)
        val requestedNumber = channelNumberBuffer.takeNumber()
        if (::channelNumberOverlay.isInitialized) channelNumberOverlay.visibility = View.GONE
        if (requestedNumber == null || requestedNumber !in 1..allChannels.size || isZapping) return
        val index = requestedNumber - 1
        val channel = allChannels.getOrNull(index) ?: return
        if (index != currentChannelIndex) zapTo(index, channel)
    }

    private fun isDescendantFocused(view: View): Boolean {
        val focused = currentFocus ?: return false
        var parent = focused.parent
        while (parent != null) {
            if (parent === view) return true
            parent = (parent as? View)?.parent
        }
        return false
    }

    private fun isRightPanelFocused(): Boolean =
        channelsList.hasFocus() || isDescendantFocused(channelsList) ||
            menuSearchResults.hasFocus() || isDescendantFocused(menuSearchResults)

    private fun moveFocusToCategoriesPanel() {
        // Al volver desde canales, retomamos la categoría activa (o el campo de búsqueda).
        if (channelPanelController.isSearchActive) {
            menuSearchInput.requestFocus()
            return
        }
        if (channelPanelController.currentCategory.equals("todos", ignoreCase = true)) {
            btnAllChannels.requestFocus()
            return
        }
        val position = channelPanelController.categoriesAdapter.getPositionForKey(channelPanelController.currentCategory)
        if (position < 0) {
            btnAllChannels.requestFocus()
            return
        }
        menuCategoriesList.post {
            (menuCategoriesList.layoutManager as? LinearLayoutManager)?.scrollToPositionWithOffset(position, 0)
            menuCategoriesList.post {
                val item = menuCategoriesList.findViewHolderForAdapterPosition(position)?.itemView
                if (item?.requestFocus() != true) menuCategoriesList.requestFocus()
            }
        }
    }

    private fun moveFocusToChannelsList() {
        // Si la búsqueda no tuvo coincidencias, el destino accionable sigue siendo el campo.
        if (channelPanelController.isSearchActive && searchEmptyText.visibility == View.VISIBLE) {
            menuSearchInput.requestFocus()
            return
        }
        // En modo búsqueda, derecha lleva a los resultados; en navegación normal, a los canales.
        if (channelPanelController.isSearchActive && menuSearchResults.visibility == View.VISIBLE) {
            // La búsqueda usa AsyncListDiffer; esperar a que el primer resultado esté adjunto.
            menuSearchResults.post {
                menuSearchResults.post {
                    val item = if (channelPanelController.searchAdapter.itemCount > 0) {
                        menuSearchResults.findViewHolderForAdapterPosition(0)?.itemView
                    } else null
                    if (item?.requestFocus() != true) menuSearchResults.requestFocus()
                }
            }
            return
        }

        val selectedCurrentChannel = currentChannel
        val selectedInFiltered = channelPanelController.filteredChannels.indexOfFirst {
            selectedCurrentChannel != null && ChannelIdentity.same(it, selectedCurrentChannel)
        }
        val targetPosition = if (selectedInFiltered >= 0) selectedInFiltered else 0
        channelsList.post {
            val lm = channelsList.layoutManager as? LinearLayoutManager
            lm?.scrollToPositionWithOffset(targetPosition, 0)
            channelsList.post {
                val item = channelsList.findViewHolderForAdapterPosition(targetPosition)?.itemView
                if (item?.requestFocus() != true) channelsList.requestFocus()
            }
        }
    }

    /** Foco vertical explícito para que las acciones fijas formen parte del mismo rail. */
    private fun handlePanelVerticalFocus(keyCode: Int): Boolean {
        val focused = currentFocus ?: return false
        return when {
            focused.id == R.id.btn_search_trigger && keyCode == KeyEvent.KEYCODE_DPAD_DOWN -> {
                btnAllChannels.requestFocus()
                true
            }
            focused.id == R.id.btn_all_channels && keyCode == KeyEvent.KEYCODE_DPAD_UP -> {
                btnSearchTrigger.requestFocus()
                true
            }
            focused.id == R.id.btn_all_channels && keyCode == KeyEvent.KEYCODE_DPAD_DOWN -> {
                focusFirstCategory()
                true
            }
            focused.id == R.id.btn_close_panel && keyCode == KeyEvent.KEYCODE_DPAD_DOWN -> {
                btnSearchTrigger.requestFocus()
                true
            }
            focused.id == R.id.btn_search_trigger && keyCode == KeyEvent.KEYCODE_DPAD_UP -> {
                btnClosePanel.requestFocus()
                true
            }
            else -> false
        }
    }

    private fun focusFirstCategory() {
        if (channelPanelController.categoriesAdapter.itemCount == 0) {
            moveFocusToChannelsList()
            return
        }
        menuCategoriesList.post {
            (menuCategoriesList.layoutManager as? LinearLayoutManager)?.scrollToPositionWithOffset(0, 0)
            menuCategoriesList.post {
                val first = menuCategoriesList.findViewHolderForAdapterPosition(0)?.itemView
                if (first?.requestFocus() != true) menuCategoriesList.requestFocus()
            }
        }
    }

    private fun activateFocusedControl() {
        when (currentFocus?.id) {
            R.id.btn_menu -> btnMenu.performClick()
            R.id.btn_play_pause -> btnPlayPause.performClick()
            R.id.btn_rewind -> btnRewind.performClick()
            R.id.btn_forward -> btnForward.performClick()
            R.id.btn_options -> btnOptions.performClick()
            R.id.btn_reload_stream -> btnReloadStream.performClick()
            R.id.btn_close_player -> btnClose.performClick()
            else -> requestPreferredControlFocus()
        }
    }


    private fun updateControlFocusOrder() = playerControlFocusController.updateControlFocusOrder()

    private fun requestPreferredControlFocus() = playerControlFocusController.requestPreferredControlFocus()

    private fun navigateControlsRight() = playerControlFocusController.navigateRight()

    private fun navigateControlsLeft() = playerControlFocusController.navigateLeft()

    private fun navigateControlsUp() = navigateControlsLeft()
    private fun navigateControlsDown() = navigateControlsRight()

    // ==================== CHANNEL SELECTION ====================

    private fun selectChannelFromSidePanel(channel: Channel) {
        val globalIndex = allChannels.indexOfFirst { ChannelIdentity.same(it, channel) }
        closeSidePanel()
        // No iniciar zapping con índice -1: puede ocurrir si una búsqueda antigua queda
        // visible mientras el catálogo se actualiza.
        if (globalIndex < 0 || globalIndex == currentChannelIndex) return
        if (!isZapping) zapTo(globalIndex, allChannels[globalIndex])
    }

    private fun changeChannel(delta: Int) {
        if (allChannels.isEmpty()) {
            pendingZapAccumulator.clear()
            return
        }
        if (isZapping) {
            pendingZapAccumulator.accumulate(delta)
            return
        }
        val targetIndex = (currentChannelIndex + delta).mod(allChannels.size)
        zapTo(targetIndex, allChannels[targetIndex])
    }

    /** Applies accumulated CH+/CH- presses after the active channel transition is complete. */
    private fun dispatchPendingZap() {
        if (isZapping) return
        val delta = pendingZapAccumulator.consume()
        if (delta == 0 || allChannels.isEmpty()) return
        changeChannel(delta)
    }

    private fun zapTo(index: Int, channel: Channel) {
        cancelPendingZappingReset()
        pendingZapAccumulator.clear()
        isZapping = true
        invalidateCurrentPlaybackForZapping()
        prepareWebViewForZapping()
        progressBar.visibility = View.VISIBLE
        errorText.visibility = View.GONE
        showZappingOverlay(channel)
        scheduleChannelZap(index, channel)
    }

    private fun cancelPendingZappingReset() {
        clearZappingRunnable?.let(mainHandler::removeCallbacks)
        clearZappingRunnable = null
        zapRunnable?.let(mainHandler::removeCallbacks)
        zapRunnable = null
    }

    private fun invalidateCurrentPlaybackForZapping() {
        playerGeneration++
        webViewPlaybackController.invalidatePendingLoad()
        recovery.reset(cancelPendingReconnect = true)
        releasePlayer()
    }

    private fun prepareWebViewForZapping() {
        webView.apply {
            stopLoading()
            loadUrl("about:blank")
            clearHistory()
            webBridge.detach()
            visibility = View.GONE
        }
        webBridge.reset()
        webBridge.stopMonitor()

        // Keep iframe controls touchable on phones, but prevent WebView focus theft on TV.
        if (isTV) {
            webViewTouchBlocker.visibility = View.VISIBLE
            lockWebViewFocus()
        } else {
            webViewTouchBlocker.visibility = View.GONE
            webView.isClickable = true
            webView.isFocusable = true
            webView.isFocusableInTouchMode = true
        }
    }

    private fun scheduleChannelZap(index: Int, channel: Channel) {
        zapRunnable = Runnable {
            currentChannelIndex = index
            currentChannel = channel
            lastPlayedChannelStore.remember(channel)
            currentChannel?.let(::loadChannelInfo)
            updateFavoriteButton(channel)
            playFirstValidOption(channel)
            clearZappingRunnable?.let(mainHandler::removeCallbacks)
            clearZappingRunnable = Runnable {
                isZapping = false
                clearZappingRunnable = null
                dispatchPendingZap()
            }.also { mainHandler.postDelayed(it, ZAPPING_RESET_DELAY_MS) }
            zapRunnable = null
        }
        zapRunnable?.let { mainHandler.postDelayed(it, ZAPPING_START_DELAY_MS) }
    }

    // ==================== ZAPPING OVERLAY ====================

    private fun showZappingOverlay(channel: Channel) {
        val overlay = zappingOverlay ?: return
        overlay.visibility = View.VISIBLE
        // Keep the transient identity above any visible player controls without capturing focus.
        overlay.bringToFront()
        zappingLogo?.loadChannelLogo(channel.name, channel.logo)
        overlay.removeCallbacks(hideZappingRunnable)
        overlay.postDelayed(hideZappingRunnable, 2_000)
    }

    private val hideZappingRunnable = Runnable { zappingOverlay?.visibility = View.GONE }

    // ==================== CHANNEL INFO ====================

    private fun loadChannelInfo(channel: Channel) {
        channelNameText.text = channel.name
        channelLogo.loadChannelLogo(channel.name, channel.logo)
        val categoryLabel = channel.category.trim().takeIf {
            it.isNotBlank() && !it.equals("todos", ignoreCase = true)
        }?.let(::formatCategoryLabel).orEmpty()
        channelCategoryText.text = categoryLabel
        channelCategoryText.visibility = if (categoryLabel.isBlank()) View.GONE else View.VISIBLE
    }

    /** Mantiene el rótulo del canal consistente con las categorías del catálogo. */
    private fun formatCategoryLabel(raw: String): String =
        ChannelFilterEngine.displayCategoryName(ChannelFilterEngine.categoryKey(raw))

    // ==================== PLAYBACK ====================

    private var currentOptionIndex: Int = 0

    /** Reintenta la fuente actual sin cambiar de canal ni reiniciar la selección del usuario. */
    private fun reloadCurrentTransmission() =
        playbackReloadController.reloadCurrentTransmission()

    private fun playFirstValidOption(channel: Channel) {
        sourceSelectionController.playFirstValidOption(channel)
    }

    private fun tryOption(channel: Channel, optionIndex: Int) {
        sourceSelectionController.tryOption(channel, optionIndex)
    }

    private fun cancelOptionFallback() {
        sourceSelectionController.cancelPendingFallback()
    }

    private fun playStream(url: String, type: String) {
        if (!StreamUrlPolicy.isHttpUrl(url)) {
            showError("La dirección de reproducción no es válida o no está admitida.")
            return
        }
        when (type) {
            StreamType.IFRAME -> showWebView(url)
            StreamType.HLS, StreamType.DASH, StreamType.MP4 -> showExoPlayer(url, type)
            else -> showExoPlayer(url, StreamType.HLS)
        }
    }

    // ==================== EXO PLAYER ====================

    private fun showExoPlayer(url: String, type: String, playWhenReady: Boolean = true) {
        val generation = prepareNativePlaybackSurface(type)
        if (fullscreenNativePlaybackController.reuseInlinePlayerIfAvailable(
                enabled = intent.getBooleanExtra("reuse_inline_player_session", false),
                url = url,
                type = type,
                generation = generation
            )) return
        try {
            fullscreenNativePlaybackController.createAndStart(url, type, generation, playWhenReady)
        } catch (error: Exception) {
            android.util.Log.w(
                "FullscreenPlayer",
                "No se pudo preparar la fuente (${StreamUtils.hostForLog(url)})",
                error
            )
            recovery.scheduleReconnect(url, type, generation, error)
        }
    }

    /** Clears the previous renderer and prepares a clean surface for native playback. */
    private fun prepareNativePlaybackSurface(type: String): Int =
        fullscreenPlaybackSurfaceController.prepareNativePlaybackSurface(type)


    /** Returns the active playback session and latest channel selection before fullscreen exits. */
    private fun returnSessionToInline() {
        if (inlineSessionReturned) return
        val channel = currentChannel ?: return
        val player = exoPlayer
        val wasPlaying = resumePlaybackAfterPause || (player?.playWhenReady == true)
        recovery.stopWatchdog()
        cancelOptionFallback()
        recovery.cancelPendingReconnect()
        zapRunnable?.let { mainHandler.removeCallbacks(it) }
        zapRunnable = null
        fullscreenPlayerEvents.clearStableStreamTimer()
        if (player != null) {
            fullscreenPlayerEvents.detachListener()
            if (::playerView.isInitialized) playerView.player = null
            exoPlayer = null // hand the engine back; releasePlayer() must not release it.
        }
        val returnWebView = inlineWebViewOrigin?.takeIf { webViewReturnedFromInlineOrigin() }
        if (returnWebView != null) {
            webBridge.stopMonitor()
            webBridge.detach()
            webViewPlaybackController.resetNavigationHandlers()
            if (currentStreamType != StreamType.IFRAME) {
                webView.stopLoading()
                webView.loadUrl("about:blank")
            }
            (webView.parent as? ViewGroup)?.removeView(webView)
            inlineWebViewReturnedToFragment = true
        }
        InlinePlayerHandoff.returnToInline(
            InlinePlayerHandoff.Session(
                player = player,
                channel = channel,
                streamUrl = currentStreamUrl,
                streamType = currentStreamType,
                sourceIndex = currentOptionIndex,
                wasPlaying = wasPlaying,
                webView = returnWebView?.webView,
                webViewParentIndex = returnWebView?.webViewParentIndex ?: -1,
                webViewLayoutParams = returnWebView?.webViewLayoutParams
            )
        )
        inlineSessionReturned = true
    }

    private fun webViewReturnedFromInlineOrigin(): Boolean =
        inlineWebViewOrigin?.webView === webView && intent.getBooleanExtra("reuse_inline_webview_session", false)

    // ==================== WEBVIEW (IFRAME) ====================

    /**
     * Muestra el WebView con soporte para control híbrido:
     * - TV: Controles nativos traducidos al iframe
     * - Móvil: Sin bloqueo táctil, controles nativos del iframe
     */
    private fun showWebView(url: String) {
        val reuseLoadedPage = reuseInlineWebViewOnLoad && inlineWebViewOrigin?.streamUrl == url
        releasePlayer()
        playerView.visibility = View.GONE
        playerTimelineContainer.visibility = View.GONE
        stopTimelineUpdates()

        // El estado del stream pertenece a la Activity; la configuración y navegación web
        // viven en WebViewPlaybackController.
        currentIsLive = false
        streamIsLive = false
        currentStreamType = StreamType.IFRAME
        if (reuseLoadedPage) reuseInlineWebViewOnLoad = false
        webViewPlaybackController.load(url, reuseLoadedPage)
    }

    /** Un error de la página principal sí permite probar la siguiente fuente del canal. */
    private fun handleWebViewMainFrameError(loadGeneration: Int, failedUrl: String?, description: String?) {
        if (!webViewPlaybackController.isCurrentLoad(loadGeneration) || currentStreamType != StreamType.IFRAME) return
        if (failedUrl == "about:blank") return

        android.util.Log.w("WebView", "Falló la carga de una fuente (${StreamUtils.hostForLog(failedUrl.orEmpty())}); detalle=${description?.take(120).orEmpty()}")
        progressBar.visibility = View.GONE
        // Invalida eventos duplicados/tardíos de esta misma navegación.
        webViewPlaybackController.invalidatePendingLoad()

        val channel = currentChannel
        val nextIndex = currentOptionIndex + 1
        if (channel != null && nextIndex < (channel.options?.size ?: 0)) {
            android.util.Log.w("OPTION_FALLBACK", "Falló la carga del iframe; probando opción ${nextIndex + 1}")
            tryOption(channel, nextIndex)
        } else {
            showError("No se pudo cargar esta fuente. Revisá tu conexión o probá otra opción.")
        }
    }

    // ==================== PLAYER RELEASE ====================

    private fun releasePlayer() {
        recovery.stopWatchdog()
        cancelOptionFallback()
        webBridge.stopMonitor()
        fullscreenPlayerEvents.dispose()
        if (::playerView.isInitialized) playerView.player = null
        exoPlayer?.run { stop(); clearMediaItems(); release() }
        exoPlayer = null
    }

    // ==================== SIDE PANEL ====================

    private fun openSidePanel() {
        if (!isTV || isPanelOpen) return
        if (!channelPanelController.isReady) return
        isPanelOpen = true
        val screenWidthPx = window.decorView.width.takeIf { it > 0 }
            ?: resources.displayMetrics.widthPixels
        val density = resources.displayMetrics.density
        val screenWidthDp = screenWidthPx / density

        // Mantiene un ancho mínimo para el vídeo en resoluciones bajas sin desbordar la pantalla.
        val panelDimensions = PlayerPanelLayoutPolicy.calculate(screenWidthDp)
        searchTriggerText.text = if (screenWidthDp < 600f) "Buscar" else "Buscar canales"
        allChannelsText.text = if (screenWidthDp < 600f) "Canales" else "Lista de canales"
        val menuWidthDp = panelDimensions.menuWidthDp
        val listWidthDp = panelDimensions.channelListWidthDp
        val menuWidthPx = (menuWidthDp * density + 0.5f).toInt()
        val listWidthPx = (listWidthDp * density + 0.5f).toInt()

        panelMenuColumn.layoutParams = panelMenuColumn.layoutParams.apply {
            width = menuWidthPx
        }
        channelsPanelContainer.layoutParams = channelsPanelContainer.layoutParams.apply {
            width = menuWidthPx + listWidthPx
        }
        channelsPanelContainer.visibility = View.VISIBLE
        if (allChannels.isNotEmpty()) {
            // El controlador refresca la lista y delega la selección de foco a la Activity.
            channelPanelController.refreshForOpening()
        } else {
            // Si los datos aún no llegaron, el buscador es un destino enfocable estable.
            btnSearchTrigger.post { btnSearchTrigger.requestFocus() }
        }
    }

    private fun closeSidePanel() {
        if (!isTV || !isPanelOpen) return
        channelPanelController.deactivateSearchMode()
        channelsPanelContainer.layoutParams = channelsPanelContainer.layoutParams.apply { width = 0 }
        channelsPanelContainer.visibility = View.GONE
        isPanelOpen = false
        restorePlayerFocus()
        // Si el panel quedó abierto más de cinco segundos, el temporizador anterior pudo vencer.
        // Al volver al vídeo lo reiniciamos para que los controles sigan ocultándose correctamente.
        if (controlsVisible) resetAutoHideTimer()
    }

    private fun restorePlayerFocus() {
        if (!isTV) return
        playerContainer.post {
            when {
                controlsVisible && bottomControls.visibility == View.VISIBLE -> {
                    requestPreferredControlFocus()
                }
                playerView.visibility == View.VISIBLE -> {
                    playerView.isFocusable = true
                    playerView.requestFocus()
                }
                else -> playerContainer.requestFocus()
            }
        }
    }

    // ==================== CONTROLS VISIBILITY ====================

    private fun resetAutoHideTimer() {
        hideControlsRunnable?.let { mainHandler.removeCallbacks(it) }
        hideControlsRunnable = Runnable { if (controlsVisible && !isPanelOpen) hideControls() }
        hideControlsRunnable?.let { mainHandler.postDelayed(it, 5_000) }
    }

    private fun showControls() = revealControls(temporarily = false)

    private fun showControlsTemporarily() = revealControls(temporarily = true)

    private fun revealControls(temporarily: Boolean) {
        updateControlsVisibility()
        // Los controles son independientes del motor; también aparecen sobre WebView/iframe.
        playerControlsAnimator.show(controlsOverlay, slide = false)
        playerControlsAnimator.show(bottomControls, slide = true)
        if (!isTV) playerControlsAnimator.show(findViewById(R.id.center_transport_controls_container), slide = false)
        bottomControls.bringToFront()
        controlsVisible = true
        updatePlayerTimeline()
        if (isTV && !temporarily) requestPreferredControlFocus()
        if (!isTV && temporarily) startTimelineUpdates()
        resetAutoHideTimer()
    }

    private fun hideControls() {
        playerControlsAnimator.hide(controlsOverlay, slide = false)
        playerControlsAnimator.hide(bottomControls, slide = true)
        if (!isTV) playerControlsAnimator.hide(findViewById(R.id.center_transport_controls_container), slide = false)
        controlsVisible = false
        playerTimelineContainer.visibility = View.GONE
        stopTimelineUpdates()
        hideControlsRunnable?.let { mainHandler.removeCallbacks(it) }
        if (isTV) restorePlayerFocus()
    }

    private fun updatePlayerTimeline() {
        if (::timelineController.isInitialized) timelineController.update()
    }

    private fun startTimelineUpdates() {
        if (isTV || !::timelineController.isInitialized) return
        timelineController.startUpdates()
    }

    private fun stopTimelineUpdates() {
        if (::timelineController.isInitialized) timelineController.stopUpdates()
    }

    private fun updateControlsVisibility() = playerControlStateController.updateControlsVisibility()



    private fun updateIframeTransportControls() = playerControlStateController.updateIframeTransportControls()



    private fun updateFavoriteButton(channel: Channel) {
        if (!::btnFavoriteChannel.isInitialized || !::favoritesStore.isInitialized) return
        val favorite = favoritesStore.contains(channel)
        btnFavoriteChannel.setImageResource(if (favorite) R.drawable.ic_favorite_filled else R.drawable.ic_favorite_outline)
        val tintColor = if (favorite) R.color.accent else R.color.text_primary
        btnFavoriteChannel.imageTintList = android.content.res.ColorStateList.valueOf(
            androidx.core.content.ContextCompat.getColor(this, tintColor)
        )
        btnFavoriteChannel.contentDescription = if (favorite) "Quitar canal de favoritos" else "Agregar canal a favoritos"
        btnFavoriteChannel.isSelected = favorite
    }

    private fun hasMultipleOptions() = (currentChannel?.options?.size ?: 0) > 1

    // ==================== DATA LOADING ====================

    private fun loadChannelData() {
        val catalogToken = intent.getLongExtra("channel_catalog_token", -1L)
        val sharedCatalog = PlayerChannelCatalog.get(catalogToken)
        @Suppress("DEPRECATION")
        val legacyCatalog = intent.getParcelableArrayListExtra<Channel>("channels")
        val singleChannel = IntentCompat.getParcelableExtra(intent, "current_channel", Channel::class.java)
        val hasInMemoryCatalog = sharedCatalog.isNotEmpty()
        val hasLegacyCatalog = !legacyCatalog.isNullOrEmpty()
        allChannels = when {
            hasInMemoryCatalog -> sharedCatalog
            hasLegacyCatalog -> legacyCatalog.orEmpty()
            singleChannel != null -> listOf(singleChannel)
            else -> emptyList()
        }
        mainHandler.removeCallbacks(clearChannelNumberRunnable)
        channelNumberBuffer = ChannelNumberInputBuffer.forChannelCount(allChannels.size)
        currentChannelIndex = if (hasInMemoryCatalog || hasLegacyCatalog) {
            intent.getIntExtra("channel_index", 0)
        } else {
            // Si el proceso se recreó y ya no existe el catálogo en memoria, se preserva al
            // menos el canal solicitado por el Intent en lugar de romper la apertura del player.
            0
        }
        channelPanelController.setChannelCatalog(allChannels)
        if (isTV && intent.getBooleanExtra("open_channel_panel", false)) {
            val openSearchOnStart = intent.getBooleanExtra("open_channel_search", false)
            playerContainer.post {
                if (isFinishing || isDestroyed || !isTV) return@post
                openSidePanel()
                if (openSearchOnStart) channelPanelController.activateSearchMode()
            }
        }
        if (allChannels.isNotEmpty() && currentChannelIndex in allChannels.indices) {
            val selectedChannel = allChannels.getOrNull(currentChannelIndex) ?: return
            currentChannel = selectedChannel
            loadChannelInfo(selectedChannel)
            updateFavoriteButton(selectedChannel)
            val selectedOptions = selectedChannel.options.orEmpty()
            val requestedSourceIndex = intent.getIntExtra("source_index", 0)
            if (selectedOptions.isNotEmpty() && requestedSourceIndex in selectedOptions.indices) {
                tryOption(selectedChannel, requestedSourceIndex)
            } else {
                playFirstValidOption(selectedChannel)
            }
        } else {
            showError("No hay canales disponibles")
        }
    }

    // ==================== OPTIONS DIALOG ====================

    private fun showOptionsDialog(channel: Channel) {
        val options = channel.options ?: run { showError("No hay opciones disponibles"); return }
        if (options.isEmpty()) { showError("No hay opciones disponibles"); return }
        AlertDialog.Builder(this)
            .setTitle("Seleccionar fuente — ${channel.name}")
            .setItems(options.map { it.name }.toTypedArray()) { _, which ->
                playerGeneration++
                recovery.reset(cancelPendingReconnect = true)
                val url = options[which].iframe
                val type = StreamUtils.resolveType(url, options[which].streamType)
                currentStreamUrl = url
                currentStreamType = type
                currentOptionIndex = which
                currentChannel = channel
                loadChannelInfo(channel)
                updateFavoriteButton(channel)
                playStream(url, type)
                updateControlsVisibility()
                hideControls()
            }
            .setNegativeButton("Cancelar") { _, _ -> if (currentStreamUrl.isEmpty()) finish() }
            .setCancelable(true)
            .show()
    }

    // ==================== HELPERS ====================

    private fun lockWebViewFocus() {
        if (!isTV) return
        webView.apply { isFocusable = false; isFocusableInTouchMode = false; isClickable = false; clearFocus() }
    }

    private fun showError(message: String) {
        progressBar.visibility = View.GONE
        errorText.text = if (isTV) "$message\n\nUsá ↻ Recargar en los controles para volver a intentar." else "$message\n\nPodés tocar Recargar en los controles para volver a intentar."
        errorText.visibility = View.VISIBLE
        updateControlsVisibility()
        // Ante un error dejamos la barra visible para que Recargar siga accesible
        // con el tacto o el mando, sin obligar a salir del reproductor.
        showControlsTemporarily()
        hideControlsRunnable?.let { mainHandler.removeCallbacks(it) }
        hideControlsRunnable = null
    }
}
