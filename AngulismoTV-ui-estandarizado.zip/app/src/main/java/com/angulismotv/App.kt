package com.angulismotv

import android.app.Application
import com.angulismotv.utils.CrashReporter

class App : Application() {
    override fun onCreate() {
        super.onCreate()
        // La pantalla de errores corre en otro proceso: no hay que inicializar nada allí
        if (CrashReporter.isCrashProcess()) return
        CrashReporter.install(this)

        // Cast se inicializa bajo demanda al pulsar el botón de transmitir.
        // No inicializar CastContext aquí: un fallo del SDK no debe impedir llegar al menú.
    }
}