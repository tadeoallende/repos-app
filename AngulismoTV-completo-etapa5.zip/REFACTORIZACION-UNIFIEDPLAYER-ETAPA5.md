# UnifiedPlayerActivity — Etapa 5: lectura del Intent y diálogos

Refactor sin cambio de comportamiento: la decisión de qué reproducir al abrir y los diálogos salen de la Activity.

## Qué se movió

| Antes (en la Activity) | Ahora |
|---|---|
| Elección de catálogo, índice y fuente dentro de `loadChannelData()` | `PlayerLaunchPlanner.plan()` (lógica pura y genérica, probada en JVM) |
| Claves de extras escritas a mano en la fábrica, el fragmento y la Activity | `PlayerLaunchExtras` (una sola definición para quien lanza y quien lee) |
| `showManagedDialog`, `activeDialog`, construcción de los diálogos de fuentes e Info de audio | `PlayerDialogController` |

`loadChannelData()` queda en: leer extras → `plan()` → aplicar el resultado (catálogo, panel, canal y fuente).

## Reglas que conserva el planificador

- Catálogo: en memoria primero, luego el formato antiguo (`channels`) y, si no hay ninguno, el canal único del Intent.
- Índice: solo se respeta con catálogo; con canal único vale 0. Fuera de rango se ajusta al rango válido (corrección de la etapa 1).
- Fuente: solo si el canal elegido la tiene; si no, se usa la primera válida.
- Sin ningún dato: "No hay canales disponibles".
- Abrir el panel solo se aplica en TV (esa comprobación sigue en la Activity).

## Notas

- `channel_name`, `channel_logo`, `stream_url` y `stream_type` se siguen enviando en el Intent pero la Activity no los lee. Quedaron definidos en `PlayerLaunchExtras` sin cambios; conviene revisar si se pueden eliminar.
- `ChannelsFragment.kt` solo cambia en tres líneas (el import y dos `putExtra`); si tu copia difiere, aplicá esas líneas a mano.

## Pruebas nuevas

`PlayerLaunchPlannerTest` (10 casos): prioridad entre catálogos, canal único con índice viejo, sin datos, índice fuera de rango por arriba y por abajo, índice válido, fuente válida/inválida, canal sin fuentes, fuente validada contra el canal realmente elegido y banderas del panel.

## Validación

Revisión manual del diff y de cada prueba contra el código. **No se compiló ni se ejecutaron pruebas** (sin Kotlin/Gradle en el entorno). Probar: abrir un canal desde la lista (con fuente elegida y sin ella), abrir el panel de canales/búsqueda desde el inicio en TV, y elegir otra fuente desde el botón Opciones.
