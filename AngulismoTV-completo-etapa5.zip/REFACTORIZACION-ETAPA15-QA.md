# QA estático — Etapa 15

Fecha de trabajo: 20 de octubre de 2026.

## Resultado de controles

| Control | Resultado | Observación |
|---|---|---|
| Catálogo `gradle/libs.versions.toml` | Correcto | TOML parseable; 20 bibliotecas y 6 bundles; todas las referencias de los bundles existen. |
| XML de `app/src/main` | Correcto | 71 archivos parseados sin errores. |
| Smoke check de Kotlin puro | Correcto | Pasaron comprobaciones de formato de tiempo, política de reintento, catálogo y política de navegación. Se compilaron clases puras con stubs mínimos para modelos Android ausentes; esto no sustituye el build de la app. |
| Referencias de métodos/campos extraídos | Correcto en búsqueda estática | No quedan referencias a `showStoragePermissionDialog`, `webLoadGeneration`, `webCustomView`, `formatPlayerTime`, `formatInlineTime` ni al temporizador de timeline anterior de ninguna de las dos pantallas. |
| Uso del factory de streams | Correcto en búsqueda estática | `ChannelsFragment` y `UnifiedPlayerActivity` llaman a `StreamMediaSourceFactory`. |
| Política WebView compartida | Correcto en búsqueda estática | Ambas pantallas usan `WebViewNavigationPolicy`; mini reproductor y fullscreen usan `PlayerTimelineController`. |
| Dependencias retiradas | Correcto en búsqueda estática | No hay referencias de código/recursos a ConstraintLayout, AndroidX WebKit, Lifecycle ViewModel KTX o ExoPlayer Cast extension. |
| `./gradlew --offline testDebugUnitTest` | Bloqueado por entorno | El wrapper intentó descargar `gradle-8.13-bin.zip` y falló con `UnknownHostException: services.gradle.org`. No se pudieron compilar Android ni ejecutar JUnit con Gradle. |
| Instalación/ejecución en dispositivo | No realizada | No hay validación en emulador ni hardware disponible desde este entorno. |

## Revisiones manuales de riesgo

- La pantalla fullscreen todavía transfiere el mismo reproductor/WebView en el flujo de vuelta al inline; la extracción del controlador no cambia la decisión de reutilizar la sesión.
- `WebViewPlaybackController` invalida las cargas antiguas antes de procesar errores de página principal para evitar que callbacks tardíos cambien el canal actual.
- La política de reintentos conserva el calendario progresivo y los reintentos continuados para HLS/DASH después del máximo configurado.
- `ChannelCatalog` conserva los modos exactos/case-insensitive que utilizaban las dos UIs.
- `ApkUpdateInstaller` mantiene la descarga y la instalación fuera del coordinador de diálogos.

## Limitación importante

El análisis estático no puede garantizar que el proyecto compile ni que el traspaso de sesión funcione en todos los dispositivos. Antes de publicar una APK, ejecutar `testDebugUnitTest`, `assembleDebug` y pruebas manuales del mini reproductor → pantalla completa → vuelta, reproducción iframe, HLS/DASH, selección de fuente y actualización en un entorno con Gradle 8.13 y Android SDK instalados.
