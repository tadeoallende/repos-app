# AngulismoTV — rediseño de navegación para Android TV (v10)

## Objetivo

Adaptar la pantalla de TV a una estructura tipo guía televisiva comercial, inspirada en la organización de la referencia aportada, sin añadir funciones de series/películas ni categorías que no existan en AngulismoTV.

## Estructura de pantalla

- **Rail global izquierdo:** accesos Canales y Agenda. Se conserva el comportamiento existente de expansión por foco.
- **Columna central:** vista previa de TV con relación 16:9, estado vacío cuando todavía no se eligió una señal, banda degradada con logo/nombre/categoría cuando hay vista previa y texto de ayuda dependiente del estado del foco.
- **Columna derecha:** título y conteo de canales, búsqueda compacta que se abre desde el icono de la cabecera, chips de categorías dinámicas, lista vertical de canales y una leyenda de navegación.
- **Móvil:** conserva el layout móvil separado; las modificaciones visuales para TV no reemplazan la interfaz compacta del teléfono.

## Navegación con mando

- Rail global: arriba/abajo alterna Canales/Agenda; derecha entra en el contenido de la sección seleccionada.
- Reproductor de vista previa: derecha enfoca el canal de vista previa actual o el primer canal; izquierda vuelve al rail global; OK/Enter abre el reproductor a pantalla completa cuando ya existe un canal. Si aún no hay canal, el foco pasa a la lista.
- Categorías: izquierda entre categorías; la primera devuelve el foco al reproductor. Abajo entra a la lista.
- Lista de canales: arriba/abajo recorre la lista; OK elige/inicia la vista previa sin abandonar la guía; izquierda vuelve al reproductor. Derecha se consume al ser la última columna, para evitar saltos impredecibles.
- Cabecera: búsqueda a demanda; se abre el campo, al cerrarlo se devuelve el foco al icono. Back cierra la búsqueda antes de activar la salida de la app.

## Guía contextual

El texto de ayuda cambia según el reproductor tenga foco o haya una vista previa activa. Las instrucciones explican que OK abre pantalla completa desde el reproductor, OK sobre una fila previsualiza el canal, izquierda regresa al video/rail y las flechas recorren categorías/lista.

## Archivos principales

- `app/src/main/res/layout/fragment_channels_tv.xml`: composición de las dos columnas en TV.
- `app/src/main/java/com/angulismotv/fragments/ChannelsFragment.kt`: selección de canal, preview inline, búsqueda y navegación por D-pad.
- `app/src/main/java/com/angulismotv/MainActivity.kt`: rail global Canales/Agenda, cabecera y entrada al contenido.
- `app/src/main/java/com/angulismotv/adapters/ChannelsAdapter.kt`: lista de canales, selección de preview y foco por fila.
- `app/src/main/res/drawable/item_channel_bg.xml`: estados visuales diferenciados para foco y canal en vista previa.
- `app/src/main/res/values/strings.xml`: instrucciones visibles y descripciones accesibles.

## Límites de verificación

Los recursos XML y referencias locales se comprobaron estáticamente. La compilación y las pruebas interactivas en TV quedan pendientes porque el entorno no puede resolver `services.gradle.org` para descargar Gradle 8.13 y no tiene un Android SDK configurado. Este documento no debe interpretarse como una certificación de ejecución real.
