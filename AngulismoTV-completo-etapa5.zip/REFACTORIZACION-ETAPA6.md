# AngulismoTV — Etapa 6: fiabilidad de fuentes alternativas

## Base y alcance

Parte de `AngulismoTV-TV-Player-Etapa5.zip`, que el usuario probó y reportó funcionando bien. Se conservan la interfaz visual, las animaciones de foco, la navegación con mando, la búsqueda, los controles, el motor ExoPlayer/WebView, Cast y el comportamiento móvil.

## Cambios

- Se corrigió el fallback de fuentes: antes, el temporizador podía tomar `exoPlayer == null` como señal de fallo incluso cuando la fuente era un iframe. Como los iframe no usan ExoPlayer, eso podía cambiar de fuente tras 12 segundos aunque la página siguiera funcionando.
- Las fuentes iframe ya no se reemplazan por el mero vencimiento de ese temporizador. En ellas, el fallback pasa a la siguiente opción cuando se detecta un error de carga de la página principal o una respuesta HTTP de error (código 400 o superior).
- Los errores de subrecursos no provocan un cambio de fuente: solo se procesan errores de la página principal para reducir falsos positivos por anuncios, imágenes u otros recursos secundarios.
- Se muestra un mensaje claro si la página principal no carga y no quedan fuentes alternativas.
- Se agrega un identificador de carga para ignorar callbacks atrasados de una fuente iframe anterior cuando el usuario cambia de canal/fuente o se cierra el reproductor.
- Al elegir manualmente una fuente desde el diálogo de opciones, se guarda correctamente su índice para que la recuperación apunte a la siguiente opción real.

## Validación realizada

- Revisión estática de las ramas de fallback y de los filtros de error de WebView.
- Pendiente de ejecutar compilación Android completa y prueba manual en TV/celular. Estas comprobaciones estáticas no sustituyen esas pruebas.

## Pruebas recomendadas

1. Abrir un canal con fuente iframe y dejarlo funcionando más de 12 segundos: no debería saltar a otra fuente solamente por el temporizador.
2. Probar un canal con varias fuentes, donde una página iframe falle al cargar: debería intentarse la siguiente fuente.
3. Probar una fuente iframe funcional mientras recursos secundarios fallan: no debería cambiar de fuente por un error de recurso que no sea la página principal.
4. Cambiar de canal rápidamente durante la carga y comprobar que un error atrasado del canal anterior no altere la reproducción actual.
5. Probar la selección manual de una fuente desde el diálogo de opciones, además de navegación y controles habituales con mando y en móvil.
