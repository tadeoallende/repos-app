# Modelos que Gson (de)serializa por reflexión
-keepclassmembers class com.angulismotv.data.ChannelRepository$* { <fields>; }
-keep class com.angulismotv.data.ChannelFeedDataSource$* { <fields>; }
-keep class com.angulismotv.models.** { *; }
-keepattributes Signature, *Annotation*

# Métodos expuestos al JavaScript del WebView
-keepclassmembers class * {
    @android.webkit.JavascriptInterface <methods>;
}

# Gson usa firmas genéricas en TypeToken; R8 debe conservarlas.
-keep class com.google.gson.reflect.TypeToken { *; }
-keep class * extends com.google.gson.reflect.TypeToken { *; }
