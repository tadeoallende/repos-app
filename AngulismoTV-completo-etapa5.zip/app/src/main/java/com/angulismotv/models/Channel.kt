package com.angulismotv.models

import android.os.Parcelable
import kotlinx.parcelize.Parcelize
import com.google.gson.annotations.SerializedName

/** Tipos de reproducción soportados. */
object StreamType {
    const val HLS = "hls"
    const val DASH = "dash"
    const val MP4 = "mp4"
    const val IFRAME = "iframe"
    const val AUTO = "auto"
}

/** Canal listo para usar en la UI. Se construye desde [com.angulismotv.data.ChannelRepository]. */
@Parcelize
data class Channel(
    @field:SerializedName("name") val name: String = "",
    @field:SerializedName("logo") val logo: String = "",
    @field:SerializedName("streamUrl") val streamUrl: String? = null,
    @field:SerializedName("streamType") val streamType: String? = StreamType.HLS,
    @field:SerializedName("options") val options: List<StreamOption>? = null,
    @field:SerializedName("show") val show: Boolean = true,
    @field:SerializedName("category") val category: String = "todos",
    /** Country ISO code or display name supplied by the playlist, when available. */
    @field:SerializedName("country") val country: String = ""
) : Parcelable

/** Fuente alternativa de un canal (se prueban en orden hasta que una funcione). */
@Parcelize
data class StreamOption(
    @field:SerializedName("name") val name: String = "",
    @field:SerializedName("iframe") val iframe: String = "",
    @field:SerializedName("streamType") val streamType: String = StreamType.IFRAME
) : Parcelable
