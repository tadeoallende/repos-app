package com.angulismotv.models

import java.util.Locale

/**
 * Identidad lógica de una señal. La URL/tipo de reproducción tienen prioridad sobre
 * el logo, que puede repetirse o cambiar entre actualizaciones del catálogo.
 */
object ChannelIdentity {
    fun key(channel: Channel): String {
        val streamUrl = channel.streamUrl?.trim().orEmpty()
        val streamType = channel.streamType?.trim()?.lowercase(Locale.ROOT).orEmpty()
        if (streamUrl.isNotEmpty()) return "stream|$streamType|$streamUrl"

        val options = channel.options.orEmpty()
            .joinToString("\u001e") { option ->
                "${option.streamType.trim().lowercase(Locale.ROOT)}\u001f${option.iframe.trim()}"
            }
        if (options.isNotEmpty()) return "options|${channel.name.trim().lowercase(Locale.ROOT)}|$options"

        // Canales sin URL ni opciones: último recurso para datos incompletos.
        return "fallback|${channel.name.trim().lowercase(Locale.ROOT)}|${channel.logo.trim()}|${channel.category.trim().lowercase(Locale.ROOT)}"
    }

    fun same(first: Channel, second: Channel): Boolean = key(first) == key(second)
}
