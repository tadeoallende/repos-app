package com.angulismotv

import android.app.Application
import android.util.Log
import com.angulismotv.utils.CrashReporter
import com.google.android.gms.cast.framework.CastContext

class App : Application() {
    override fun onCreate() {
        super.onCreate()
        // La pantalla de errores corre en otro proceso: no hay que inicializar nada allí
        if (CrashReporter.isCrashProcess()) return
        CrashReporter.install(this)

        try {
            val castContext = CastContext.getSharedInstance(this)
            Log.d("CAST", "CastContext inicializado OK: $castContext")
        } catch (e: Exception) {
            Log.e("CAST", "Error inicializando CastContext: ${e.message}", e)
        }
    }
}