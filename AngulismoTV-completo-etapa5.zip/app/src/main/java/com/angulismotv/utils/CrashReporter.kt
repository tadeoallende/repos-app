package com.angulismotv.utils

import android.app.Application
import android.content.Intent
import android.os.Build
import com.angulismotv.BuildConfig
import java.io.File
import java.io.PrintWriter
import java.io.StringWriter

/**
 * Cuando la app se cierra por una excepción no controlada, abre [CrashActivity] con la traza
 * completa para poder copiarla. Solo está activo en builds de debug.
 */
object CrashReporter {

    private const val MAX_REPORT_CHARS = 30_000

    fun install(app: Application) {
        if (!BuildConfig.DEBUG) return
        val previous = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { thread, error ->
            try {
                val intent = Intent(app, CrashActivity::class.java)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK)
                    .putExtra(CrashActivity.EXTRA_REPORT, buildReport(thread, error))
                app.startActivity(intent)
                Thread.sleep(500) // margen para que el sistema lance la pantalla antes de matar el proceso
            } catch (_: Throwable) {
                // Si falla el reporte, no se hace nada más: se deja seguir al handler original
            }
            previous?.uncaughtException(thread, error)
        }
    }

    /** CrashActivity corre en su propio proceso (":crash"); ahí no hay que iniciar nada de la app. */
    fun isCrashProcess(): Boolean {
        val name = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            Application.getProcessName()
        } else {
            runCatching { File("/proc/self/cmdline").readText().trim('\u0000') }.getOrNull()
        }
        return name?.endsWith(":crash") == true
    }

    private fun buildReport(thread: Thread, error: Throwable): String {
        val trace = StringWriter().also { error.printStackTrace(PrintWriter(it)) }.toString()
        return buildString {
            appendLine("AngulismoTV ${BuildConfig.VERSION_NAME} (${BuildConfig.VERSION_CODE})")
            appendLine("Android ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT}) - ${Build.MANUFACTURER} ${Build.MODEL}")
            appendLine("Hilo: ${thread.name}")
            appendLine()
            append(trace)
        }.take(MAX_REPORT_CHARS)
    }
}
