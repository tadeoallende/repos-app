package com.angulismotv.utils

import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.graphics.Typeface
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

/**
 * Pantalla de error (solo debug). Se arma por código, sin layouts ni temas de la app,
 * para que funcione aunque el crash haya sido justamente por un recurso o un tema.
 */
class CrashActivity : Activity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val report = intent.getStringExtra(EXTRA_REPORT).orEmpty().ifEmpty { "Sin detalles del error." }
        setContentView(createCrashReportView(report))
    }

    private fun createCrashReportView(report: String): View {
        val density = resources.displayMetrics.density
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(0xFF070B1C.toInt())
            setPadding(dp(16, density), dp(32, density), dp(16, density), dp(16, density))
            addView(createTitleView())
            addView(createHintView(density))
            addView(
                ScrollView(this@CrashActivity).apply { addView(createReportView(report)) },
                LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f)
            )
            addView(createActionButtons(report))
        }
        return root
    }

    private fun createTitleView() = TextView(this).apply {
        text = "La app se cerró por un error"
        setTextColor(0xFFE8ECF8.toInt())
        textSize = 18f
        setTypeface(typeface, Typeface.BOLD)
    }

    private fun createHintView(density: Float) = TextView(this).apply {
        text = "Tocá «Copiar» y pegale el texto a Claude."
        setTextColor(0xFF9AA3C0.toInt())
        textSize = 13f
        setPadding(0, dp(4, density), 0, dp(12, density))
    }

    private fun createReportView(report: String) = TextView(this).apply {
        text = report
        typeface = Typeface.MONOSPACE
        textSize = 11f
        setTextColor(0xFFB8C0E0.toInt())
        setTextIsSelectable(true)
    }

    private fun createActionButtons(report: String) = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        gravity = Gravity.CENTER
        addView(createActionButton("Copiar") { copyReport(report) }, actionButtonLayoutParams())
        addView(createActionButton("Compartir") { shareReport(report) }, actionButtonLayoutParams())
        addView(createActionButton("Cerrar") { finishAndRemoveTask() }, actionButtonLayoutParams())
    }

    private fun createActionButton(label: String, onClick: () -> Unit) = Button(this).apply {
        text = label
        setOnClickListener { onClick() }
    }

    private fun actionButtonLayoutParams() =
        LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)

    private fun copyReport(report: String) {
        val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        clipboard.setPrimaryClip(ClipData.newPlainText("Error AngulismoTV", report))
        Toast.makeText(this, "Copiado", Toast.LENGTH_SHORT).show()
    }

    private fun shareReport(report: String) {
        val send = Intent(Intent.ACTION_SEND)
            .setType("text/plain")
            .putExtra(Intent.EXTRA_TEXT, report)
        startActivity(Intent.createChooser(send, "Compartir error"))
    }

    private fun dp(value: Int, density: Float): Int = (value * density).toInt()

    companion object {
        const val EXTRA_REPORT = "report"
    }
}
