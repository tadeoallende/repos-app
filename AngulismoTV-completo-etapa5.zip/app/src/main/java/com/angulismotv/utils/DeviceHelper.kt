package com.angulismotv.utils

import android.app.UiModeManager
import android.content.Context
import android.content.pm.PackageManager
import android.content.res.Configuration

/** Detección del tipo de dispositivo (TV vs móvil/tablet). */
object DeviceHelper {

    @Volatile
    private var tvCache: Boolean? = null

    /**
     * Es TV si el sistema lo declara (modo televisión, Leanback o feature TV) o si no tiene pantalla
     * táctil. Esto cubre Android TV, Google TV, Fire TV y los TV boxes genéricos que no reportan
     * UI_MODE_TYPE_TELEVISION.
     */
    fun isTV(context: Context): Boolean = tvCache ?: detectTV(context.applicationContext).also { tvCache = it }

    private fun detectTV(context: Context): Boolean {
        val uiMode = context.getSystemService(Context.UI_MODE_SERVICE) as UiModeManager
        if (uiMode.currentModeType == Configuration.UI_MODE_TYPE_TELEVISION) return true

        val pm = context.packageManager
        return pm.hasSystemFeature(PackageManager.FEATURE_LEANBACK) ||
            pm.hasSystemFeature(PackageManager.FEATURE_TELEVISION) ||
            !pm.hasSystemFeature(PackageManager.FEATURE_TOUCHSCREEN)
    }

    fun isTablet(context: Context): Boolean {
        val size = context.resources.configuration.screenLayout and Configuration.SCREENLAYOUT_SIZE_MASK
        return size >= Configuration.SCREENLAYOUT_SIZE_LARGE
    }
}
