package com.angulismotv.utils

import android.content.Context
import android.util.Base64
import android.util.Log
import com.angulismotv.R
import java.security.PublicKey
import java.security.Signature
import java.security.KeyFactory
import java.security.spec.X509EncodedKeySpec

/** Verifies the detached SHA256withRSA signature of the exact manifest bytes. */
internal object UpdateManifestSignatureVerifier {
    private const val TAG = "UpdateManifestSignature"

    fun verify(context: Context, manifestBytes: ByteArray, signatureBase64: String): Boolean {
        val signatureText = signatureBase64.trim()
        if (signatureText.isEmpty() || !BASE64_SIGNATURE_PATTERN.matches(signatureText)) {
            Log.w(TAG, "La firma del manifiesto no tiene un formato válido")
            return false
        }

        return try {
            val publicKeyPem = context.applicationContext.resources
                .openRawResource(R.raw.update_public_key)
                .bufferedReader(Charsets.UTF_8)
                .use { it.readText() }
            val publicKey = parsePublicKey(publicKeyPem) ?: return false
            val signatureBytes = Base64.decode(signatureText, Base64.DEFAULT)
            verifyWithPublicKey(manifestBytes, signatureBytes, publicKey)
        } catch (error: Exception) {
            Log.w(TAG, "No se pudo verificar la firma del manifiesto (${error.javaClass.simpleName})")
            false
        }
    }

    internal fun verifyWithPublicKey(
        manifestBytes: ByteArray,
        signatureBytes: ByteArray,
        publicKey: PublicKey
    ): Boolean = try {
        val verifier = Signature.getInstance("SHA256withRSA")
        verifier.initVerify(publicKey)
        verifier.update(manifestBytes)
        verifier.verify(signatureBytes)
    } catch (_: Exception) {
        false
    }

    private fun parsePublicKey(pem: String): PublicKey? {
        return try {
            val body = pem
                .replace("-----BEGIN PUBLIC KEY-----", "")
                .replace("-----END PUBLIC KEY-----", "")
                .filterNot(Char::isWhitespace)
            if (body.isEmpty()) null else {
                val der = Base64.decode(body, Base64.DEFAULT)
                KeyFactory.getInstance("RSA").generatePublic(X509EncodedKeySpec(der))
            }
        } catch (error: Exception) {
            Log.e(TAG, "La clave pública integrada no se pudo leer (${error.javaClass.simpleName})")
            null
        }
    }

    private val BASE64_SIGNATURE_PATTERN = Regex("[A-Za-z0-9+/=\r\n]+")
}
