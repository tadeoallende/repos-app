package com.angulismotv.utils

import java.io.InputStream
import java.security.MessageDigest
import java.util.Locale

/**
 * Small, testable SHA-256 utility for update payloads.
 * It deliberately does not own networking, DownloadManager, or installer UI.
 */
internal object ApkIntegrityVerifier {
    private const val SHA256_HEX_LENGTH = 64
    private const val BUFFER_SIZE = 64 * 1024
    private const val HEX_CHARS = "0123456789abcdef"

    fun isValidSha256(value: String): Boolean =
        value.length == SHA256_HEX_LENGTH && value.all { it in '0'..'9' || it in 'a'..'f' || it in 'A'..'F' }

    /** Consumes [input] and returns a lowercase 64-character hexadecimal SHA-256 digest. */
    fun calculateSha256(input: InputStream): String {
        val digest = MessageDigest.getInstance("SHA-256")
        val buffer = ByteArray(BUFFER_SIZE)
        while (true) {
            val count = input.read(buffer)
            if (count < 0) break
            if (count > 0) digest.update(buffer, 0, count)
        }
        return digest.digest().toHexString()
    }

    /**
     * Compares the file digest with a manifest value without an early-exit string comparison.
     * A malformed expected value is rejected before consuming the stream.
     */
    fun matches(input: InputStream, expectedSha256: String): Boolean {
        if (!isValidSha256(expectedSha256)) return false
        val actual = calculateSha256(input)
        val expected = expectedSha256.lowercase(Locale.ROOT)
        return MessageDigest.isEqual(
            actual.toByteArray(Charsets.US_ASCII),
            expected.toByteArray(Charsets.US_ASCII)
        )
    }

    private fun ByteArray.toHexString(): String = buildString(size * 2) {
        for (byte in this@toHexString) {
            val value = byte.toInt() and 0xff
            append(HEX_CHARS[value ushr 4])
            append(HEX_CHARS[value and 0x0f])
        }
    }
}
