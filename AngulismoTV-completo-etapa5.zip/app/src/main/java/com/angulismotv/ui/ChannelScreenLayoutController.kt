package com.angulismotv.ui

import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import android.util.TypedValue
import com.angulismotv.R
import androidx.recyclerview.widget.RecyclerView

/** Applies device-specific sizing and spacing without coupling layout details to playback logic. */
class ChannelScreenLayoutController(
    private val root: View,
    private val isTV: Boolean,
    private val channelsSectionHeader: View,
    private val channelsSearchContainer: View,
    private val btnSearch: ImageView,
    private val searchInput: EditText,
    private val categoriesScroll: HorizontalScrollView,
    private val channelsRecycler: RecyclerView,
    private val inlinePlayerContainer: FrameLayout,
    private val inlineControlsBar: LinearLayout,
    private val inlineChannelLogo: ImageView,
    private val inlineChannelName: TextView,
    private val inlineTimelineContainer: View,
    private val inlineTimeCurrent: TextView,
    private val inlineTimeDuration: TextView,
    private val inlineSeekBar: SeekBar,
    private val onSearchVisibilityChanged: (Boolean) -> Unit
) {
    fun applyDeviceSpecificLayout() {
        val searchRow = channelsSearchContainer as? ViewGroup
        val searchField = searchRow?.getChildAt(0) as? ViewGroup
        if (isTV) applyTvLayout(searchField) else applyMobileLayout(searchField)
    }

    private fun applyTvLayout(searchField: ViewGroup?) {
        channelsSectionHeader.visibility = View.GONE
        channelsSearchContainer.visibility = View.GONE
        categoriesScroll.visibility = View.GONE
        searchInput.nextFocusUpId = com.angulismotv.R.id.tv_inline_search_button
        searchInput.nextFocusLeftId = com.angulismotv.R.id.tv_inline_search_button
        searchInput.nextFocusDownId = com.angulismotv.R.id.channels_recycler
        channelsRecycler.nextFocusUpId = com.angulismotv.R.id.tv_inline_search_button
        channelsRecycler.descendantFocusability = ViewGroup.FOCUS_AFTER_DESCENDANTS
        onSearchVisibilityChanged(false)
        btnSearch.isFocusable = false
        btnSearch.isClickable = false
        btnSearch.setOnClickListener(null)
        channelsSearchContainer.setPadding(dimen(R.dimen.channels_search_padding_tv), dimen(R.dimen.channels_search_padding_tv), dimen(R.dimen.channels_search_padding_tv), dimen(R.dimen.channels_search_padding_tv))
        resizeSearchField(searchField, heightRes = R.dimen.search_field_height_tv, textSizeRes = R.dimen.search_field_text_size_tv, marginStartRes = R.dimen.search_field_margin_start)
        categoriesScroll.setPadding(dimen(R.dimen.channels_categories_padding_tv), dimen(R.dimen.channels_categories_padding_tv), dimen(R.dimen.channels_categories_padding_tv), dimen(R.dimen.channels_categories_padding_tv))
        findChannelsListContainer()?.setPadding(0, 0, 0, 0)
        channelsRecycler.setPadding(dimen(R.dimen.channels_recycler_padding_horizontal_tv), dimen(R.dimen.channels_recycler_padding_top_tv), dimen(R.dimen.channels_recycler_padding_horizontal_tv), dimen(R.dimen.channels_recycler_padding_bottom_tv))
        categoriesScroll.isFillViewport = false
    }

    private fun applyMobileLayout(searchField: ViewGroup?) {
        // En móvil la cabecera global identifica la sección; evitamos repetir un título grande.
        channelsSectionHeader.visibility = View.GONE
        channelsSectionHeader.layoutParams = channelsSectionHeader.layoutParams.apply { height = 0 }
        channelsSearchContainer.visibility = View.GONE
        channelsSearchContainer.setPadding(dimen(R.dimen.channels_search_padding_mobile), dimen(R.dimen.channels_search_padding_top_mobile), dimen(R.dimen.channels_search_padding_mobile), dimen(R.dimen.channels_search_padding_bottom_mobile))
        resizeSearchField(searchField, heightRes = R.dimen.search_field_height_mobile, textSizeRes = R.dimen.search_field_text_size_mobile, marginStartRes = R.dimen.search_field_margin_start)
        categoriesScroll.setPadding(dimen(R.dimen.channels_categories_padding_horizontal_mobile), dimen(R.dimen.channels_categories_padding_vertical_mobile), dimen(R.dimen.channels_categories_padding_horizontal_mobile), dimen(R.dimen.channels_categories_padding_vertical_mobile))
        findChannelsListContainer()?.setPadding(0, 0, 0, 0)
        channelsRecycler.setPadding(dimen(R.dimen.channels_recycler_padding_horizontal_mobile), dimen(R.dimen.channels_recycler_padding_top_mobile), dimen(R.dimen.channels_recycler_padding_horizontal_mobile), dimen(R.dimen.channels_recycler_padding_bottom_mobile))
        channelsRecycler.clipToPadding = false

        val playerParams = inlinePlayerContainer.layoutParams as? ViewGroup.MarginLayoutParams
        playerParams?.setMargins(dimen(R.dimen.inline_player_container_margin_mobile), dimen(R.dimen.inline_player_container_margin_mobile), dimen(R.dimen.inline_player_container_margin_mobile), 0)
        if (playerParams != null) inlinePlayerContainer.layoutParams = playerParams
        inlinePlayerContainer.elevation = 0f
        inlineControlsBar.apply {
            minimumHeight = dimen(R.dimen.inline_controls_min_height)
            setPadding(dimen(R.dimen.inline_controls_padding_horizontal), dimen(R.dimen.inline_controls_padding_vertical), dimen(R.dimen.inline_controls_padding_horizontal), dimen(R.dimen.inline_controls_padding_vertical))
        }
        inlineChannelLogo.layoutParams = inlineChannelLogo.layoutParams.apply {
            width = dimen(R.dimen.inline_channel_logo_size_mobile)
            height = dimen(R.dimen.inline_channel_logo_size_mobile)
        }
        inlineChannelName.apply {
            setTextSize(TypedValue.COMPLEX_UNIT_PX, root.resources.getDimension(R.dimen.inline_channel_name_text_size_mobile))
            (layoutParams as? ViewGroup.MarginLayoutParams)?.let { params ->
                params.marginStart = dimen(R.dimen.inline_channel_name_margin_start_mobile)
                layoutParams = params
            }
        }
        (inlineTimelineContainer.layoutParams as? FrameLayout.LayoutParams)?.let { params ->
            params.height = dimen(R.dimen.inline_timeline_height_mobile)
            params.leftMargin = dimen(R.dimen.inline_timeline_margin_horizontal_mobile)
            params.rightMargin = dimen(R.dimen.inline_timeline_margin_horizontal_mobile)
            params.bottomMargin = dimen(R.dimen.inline_timeline_margin_bottom_mobile)
            inlineTimelineContainer.layoutParams = params
        }
        inlineTimeCurrent.layoutParams = inlineTimeCurrent.layoutParams.apply { width = dimen(R.dimen.inline_timeline_time_width_mobile) }
        inlineTimeDuration.layoutParams = inlineTimeDuration.layoutParams.apply { width = dimen(R.dimen.inline_timeline_time_width_mobile) }
        inlineTimeCurrent.setTextSize(TypedValue.COMPLEX_UNIT_PX, root.resources.getDimension(R.dimen.text_size_player_time))
        inlineTimeDuration.setTextSize(TypedValue.COMPLEX_UNIT_PX, root.resources.getDimension(R.dimen.text_size_player_time))
        inlineSeekBar.layoutParams = inlineSeekBar.layoutParams.apply { height = dimen(R.dimen.inline_seekbar_height_mobile) }
        findChannelsListContainer()?.clipToPadding = false
    }

    private fun resizeSearchField(
        searchField: ViewGroup?,
        heightRes: Int,
        textSizeRes: Int,
        marginStartRes: Int
    ) {
        searchField?.layoutParams?.let { params ->
            params.height = dimen(heightRes)
            searchField.layoutParams = params
        }
        searchField?.setPadding(dimen(R.dimen.search_field_padding_horizontal), 0, dimen(R.dimen.search_field_padding_horizontal), 0)
        searchInput.setTextSize(TypedValue.COMPLEX_UNIT_PX, root.resources.getDimension(textSizeRes))
        (searchInput.layoutParams as? ViewGroup.MarginLayoutParams)?.let { params ->
            params.marginStart = dimen(marginStartRes)
            searchInput.layoutParams = params
        }
    }

    private fun findChannelsListContainer(): FrameLayout? =
        root.findViewById(com.angulismotv.R.id.channels_list_container)

    private fun dimen(resourceId: Int): Int = root.resources.getDimensionPixelSize(resourceId)

}
