package com.angulismotv.ui

/** Tamaños en dp para mantener visible el vídeo y el panel en resoluciones TV distintas. */
data class PlayerPanelDimensions(
    val menuWidthDp: Int,
    val channelListWidthDp: Float
)

/** Reglas de dimensionado del panel lateral, independientes del ciclo de vida de la Activity. */
object PlayerPanelLayoutPolicy {

    fun calculate(screenWidthDp: Float): PlayerPanelDimensions {
        val safeWidth = screenWidthDp.coerceAtLeast(0f)
        val menuWidth = when {
            safeWidth < 420f -> 120
            safeWidth < 600f -> 144
            safeWidth < 900f -> 168
            else -> 208
        }
        val minListWidth = when {
            safeWidth < 420f -> 96
            safeWidth < 600f -> 140
            safeWidth < 900f -> 160
            else -> 240
        }
        val maxListWidth = when {
            safeWidth < 600f -> 220
            safeWidth < 900f -> 300
            else -> 420
        }
        val minPlayerWidth = when {
            safeWidth < 420f -> 104
            safeWidth < 600f -> 150
            safeWidth < 760f -> 180
            safeWidth < 1_000f -> 260
            else -> 360
        }
        val maxListWidthForScreen = (safeWidth - menuWidth - minPlayerWidth)
            .coerceAtLeast(minListWidth.toFloat())
            .coerceAtMost((safeWidth - menuWidth).coerceAtLeast(0f))
        val desiredListWidth = (safeWidth * 0.27f)
            .coerceIn(minListWidth.toFloat(), maxListWidth.toFloat())

        return PlayerPanelDimensions(
            menuWidthDp = menuWidth,
            channelListWidthDp = desiredListWidth.coerceAtMost(maxListWidthForScreen)
        )
    }
}
