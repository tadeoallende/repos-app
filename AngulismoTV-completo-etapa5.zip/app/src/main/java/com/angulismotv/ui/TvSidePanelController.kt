package com.angulismotv.ui

import android.view.KeyEvent
import android.view.View
import android.widget.EditText
import android.widget.ImageButton
import android.widget.LinearLayout
import android.widget.TextView
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.angulismotv.R
import com.angulismotv.models.Channel
import com.angulismotv.models.ChannelIdentity

/**
 * Panel lateral de canales en TV: apertura/cierre con ancho adaptado a la pantalla y
 * movimiento del foco entre el rail fijo, las categorías y la lista de canales.
 *
 * La Activity aporta solo lo que le pertenece: el tamaño de pantalla, el canal actual y qué hacer
 * al cerrar (devolver el foco al reproductor y reiniciar el auto-ocultado de controles).
 */
internal class TvSidePanelController(
    private val isTv: () -> Boolean,
    private val views: Views,
    private val channelPanel: () -> PlayerChannelPanelController,
    private val screenWidthPx: () -> Int,
    private val density: () -> Float,
    private val channelCount: () -> Int,
    private val currentChannel: () -> Channel?,
    private val focusedView: () -> View?,
    private val onClosed: () -> Unit
) {
    class Views(
        val channelsPanelContainer: LinearLayout,
        val panelMenuColumn: LinearLayout,
        val channelsList: RecyclerView,
        val menuCategoriesList: RecyclerView,
        val menuSearchResults: RecyclerView,
        val menuSearchInput: EditText,
        val searchEmptyText: TextView,
        val btnClosePanel: ImageButton,
        val btnAllChannels: LinearLayout,
        val btnSearchTrigger: LinearLayout,
        val searchTriggerText: TextView,
        val allChannelsText: TextView
    )

    var isOpen: Boolean = false
        private set

    fun toggle() {
        if (isOpen) close() else open()
    }

    fun open() {
        if (!isTv() || isOpen) return
        val panel = channelPanel()
        if (!panel.isReady) return
        isOpen = true
        val scale = density()
        val screenWidthDp = screenWidthPx() / scale

        // Mantiene un ancho mínimo para el vídeo en resoluciones bajas sin desbordar la pantalla.
        val panelDimensions = PlayerPanelLayoutPolicy.calculate(screenWidthDp)
        views.searchTriggerText.text = if (screenWidthDp < 600f) "Buscar" else "Buscar canales"
        views.allChannelsText.text = if (screenWidthDp < 600f) "Canales" else "Lista de canales"
        val menuWidthPx = (panelDimensions.menuWidthDp * scale + 0.5f).toInt()
        val listWidthPx = (panelDimensions.channelListWidthDp * scale + 0.5f).toInt()

        views.panelMenuColumn.layoutParams = views.panelMenuColumn.layoutParams.apply {
            width = menuWidthPx
        }
        views.channelsPanelContainer.layoutParams = views.channelsPanelContainer.layoutParams.apply {
            width = menuWidthPx + listWidthPx
        }
        views.channelsPanelContainer.visibility = View.VISIBLE
        if (channelCount() > 0) {
            // El controlador refresca la lista y pide mover el foco a través de onFocusChannels.
            panel.refreshForOpening()
        } else {
            // Si los datos aún no llegaron, el buscador es un destino enfocable estable.
            views.btnSearchTrigger.post { views.btnSearchTrigger.requestFocus() }
        }
    }

    fun close() {
        if (!isTv() || !isOpen) return
        channelPanel().deactivateSearchMode()
        views.channelsPanelContainer.layoutParams =
            views.channelsPanelContainer.layoutParams.apply { width = 0 }
        views.channelsPanelContainer.visibility = View.GONE
        isOpen = false
        onClosed()
    }

    fun isRightPanelFocused(): Boolean =
        views.channelsList.hasFocus() || isDescendantFocused(views.channelsList) ||
            views.menuSearchResults.hasFocus() || isDescendantFocused(views.menuSearchResults)

    fun moveFocusToCategoriesPanel() {
        val panel = channelPanel()
        // Al volver desde canales, retomamos la categoría activa (o el campo de búsqueda).
        if (panel.isSearchActive) {
            views.menuSearchInput.requestFocus()
            return
        }
        if (panel.currentCategory.equals("todos", ignoreCase = true)) {
            views.btnAllChannels.requestFocus()
            return
        }
        val position = panel.categoriesAdapter.getPositionForKey(panel.currentCategory)
        if (position < 0) {
            views.btnAllChannels.requestFocus()
            return
        }
        focusCategoryAt(position)
    }

    fun moveFocusToChannelsList() {
        val panel = channelPanel()
        // Si la búsqueda no tuvo coincidencias, el destino accionable sigue siendo el campo.
        if (panel.isSearchActive && views.searchEmptyText.visibility == View.VISIBLE) {
            views.menuSearchInput.requestFocus()
            return
        }
        // En modo búsqueda, derecha lleva a los resultados; en navegación normal, a los canales.
        if (panel.isSearchActive && views.menuSearchResults.visibility == View.VISIBLE) {
            // La búsqueda usa AsyncListDiffer; esperar a que el primer resultado esté adjunto.
            views.menuSearchResults.post {
                views.menuSearchResults.post {
                    val item = if (panel.searchAdapter.itemCount > 0) {
                        views.menuSearchResults.findViewHolderForAdapterPosition(0)?.itemView
                    } else null
                    if (item?.requestFocus() != true) views.menuSearchResults.requestFocus()
                }
            }
            return
        }

        val selectedCurrentChannel = currentChannel()
        val selectedInFiltered = panel.filteredChannels.indexOfFirst {
            selectedCurrentChannel != null && ChannelIdentity.same(it, selectedCurrentChannel)
        }
        val targetPosition = if (selectedInFiltered >= 0) selectedInFiltered else 0
        views.channelsList.post {
            val lm = views.channelsList.layoutManager as? LinearLayoutManager
            lm?.scrollToPositionWithOffset(targetPosition, 0)
            views.channelsList.post {
                val item = views.channelsList.findViewHolderForAdapterPosition(targetPosition)?.itemView
                if (item?.requestFocus() != true) views.channelsList.requestFocus()
            }
        }
    }

    /** Foco vertical explícito para que las acciones fijas formen parte del mismo rail. */
    fun handleVerticalFocus(keyCode: Int): Boolean {
        val focused = focusedView() ?: return false
        val direction = when (keyCode) {
            KeyEvent.KEYCODE_DPAD_DOWN -> PanelRailFocusPolicy.Direction.DOWN
            KeyEvent.KEYCODE_DPAD_UP -> PanelRailFocusPolicy.Direction.UP
            else -> return false
        }
        val item = when (focused.id) {
            R.id.btn_close_panel -> PanelRailFocusPolicy.Item.CLOSE
            R.id.btn_search_trigger -> PanelRailFocusPolicy.Item.SEARCH
            R.id.btn_all_channels -> PanelRailFocusPolicy.Item.ALL_CHANNELS
            else -> return false
        }
        when (PanelRailFocusPolicy.next(item, direction) ?: return false) {
            PanelRailFocusPolicy.Target.CLOSE -> views.btnClosePanel.requestFocus()
            PanelRailFocusPolicy.Target.SEARCH -> views.btnSearchTrigger.requestFocus()
            PanelRailFocusPolicy.Target.ALL_CHANNELS -> views.btnAllChannels.requestFocus()
            PanelRailFocusPolicy.Target.FIRST_CATEGORY -> focusFirstCategory()
        }
        return true
    }

    private fun focusFirstCategory() {
        if (channelPanel().categoriesAdapter.itemCount == 0) {
            moveFocusToChannelsList()
            return
        }
        focusCategoryAt(0)
    }

    private fun focusCategoryAt(position: Int) {
        views.menuCategoriesList.post {
            (views.menuCategoriesList.layoutManager as? LinearLayoutManager)
                ?.scrollToPositionWithOffset(position, 0)
            views.menuCategoriesList.post {
                val item = views.menuCategoriesList.findViewHolderForAdapterPosition(position)?.itemView
                if (item?.requestFocus() != true) views.menuCategoriesList.requestFocus()
            }
        }
    }

    private fun isDescendantFocused(view: View): Boolean {
        val focused = focusedView() ?: return false
        var parent = focused.parent
        while (parent != null) {
            if (parent === view) return true
            parent = (parent as? View)?.parent
        }
        return false
    }
}
