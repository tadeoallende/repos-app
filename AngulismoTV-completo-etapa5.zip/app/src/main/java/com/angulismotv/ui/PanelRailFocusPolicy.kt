package com.angulismotv.ui

/**
 * Reglas de foco vertical del "rail" fijo del panel lateral (cerrar, buscar y lista de canales).
 * Sin dependencias de Android para poder verificarlas en JVM.
 */
object PanelRailFocusPolicy {
    enum class Item { CLOSE, SEARCH, ALL_CHANNELS }
    enum class Direction { UP, DOWN }
    enum class Target { CLOSE, SEARCH, ALL_CHANNELS, FIRST_CATEGORY }

    /** Destino del foco al pulsar [direction] desde [from], o null si el sistema debe resolverlo. */
    fun next(from: Item, direction: Direction): Target? = when (from to direction) {
        Item.CLOSE to Direction.DOWN -> Target.SEARCH
        Item.SEARCH to Direction.UP -> Target.CLOSE
        Item.SEARCH to Direction.DOWN -> Target.ALL_CHANNELS
        Item.ALL_CHANNELS to Direction.UP -> Target.SEARCH
        Item.ALL_CHANNELS to Direction.DOWN -> Target.FIRST_CATEGORY
        else -> null
    }
}
