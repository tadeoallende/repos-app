package com.angulismotv.data

import com.angulismotv.models.Channel
import com.angulismotv.player.StreamUtils
import java.io.BufferedReader
import java.io.Reader
import java.io.StringReader
import java.net.URI
import java.util.Locale

/** Converts a standard EXTINF M3U playlist into the app's channel model. */
object M3uPlaylistParser {
    private const val MAX_CHANNELS = 30_000
    private const val MAX_NAME_LENGTH = 240
    private const val MAX_LOGO_LENGTH = 2_048
    private const val MAX_CATEGORY_LENGTH = 120

    private data class EntryMetadata(
        val displayName: String,
        val attributes: Map<String, String>
    )

    fun parse(content: String): List<Channel> = parse(StringReader(content))

    /** Reads incrementally so large playlists do not need an extra list of all source lines. */
    fun parse(reader: Reader): List<Channel> {
        val input = if (reader is BufferedReader) reader else reader.buffered()
        val channels = ArrayList<Channel>()
        var headerSeen = false
        var pendingEntry: EntryMetadata? = null

        while (true) {
            val value = input.readLine()?.removePrefix("\uFEFF")?.trim() ?: break
            if (value.isEmpty()) continue
            if (!headerSeen) {
                headerSeen = requireM3uHeader(value)
                continue
            }
            pendingEntry = consumePlaylistLine(value, pendingEntry, channels)
        }

        if (!headerSeen) throw IllegalArgumentException("La fuente M3U está vacía")
        return removeDuplicateChannels(channels)
    }

    private fun requireM3uHeader(value: String): Boolean {
        if (!value.startsWith("#EXTM3U", ignoreCase = true)) {
            throw IllegalArgumentException("La fuente no contiene una cabecera M3U válida")
        }
        return true
    }

    private fun consumePlaylistLine(
        line: String,
        pendingEntry: EntryMetadata?,
        channels: MutableList<Channel>
    ): EntryMetadata? = when {
        line.startsWith("#EXTINF:", ignoreCase = true) -> parseMetadata(line)
        line.startsWith("#") -> pendingEntry // EXTGRP, EXT VLC options and other metadata.
        else -> {
            pendingEntry?.let { metadata ->
                parseChannel(line, metadata)?.let { channel ->
                    channels += channel
                    if (channels.size > MAX_CHANNELS) {
                        throw IllegalArgumentException("La lista supera el límite de $MAX_CHANNELS canales")
                    }
                }
            }
            null
        }
    }

    private fun parseChannel(streamUrl: String, metadata: EntryMetadata): Channel? {
        if (!isHttpStreamUrl(streamUrl)) return null
        val attributes = metadata.attributes
        val name = metadata.displayName.ifBlank { attributes["tvg-name"].orEmpty() }
            .trim().take(MAX_NAME_LENGTH)
        if (name.isBlank()) return null

        val category = attributes["group-title"]
            ?.trim()?.take(MAX_CATEGORY_LENGTH)?.takeIf { it.isNotBlank() } ?: "Otros"
        val logo = attributes["tvg-logo"]?.trim()?.take(MAX_LOGO_LENGTH).orEmpty()
        val country = attributes["tvg-country"]
            ?.substringBefore(",")?.trim()?.take(80)?.takeIf { it.isNotBlank() }
            ?: countryFromTvgId(attributes["tvg-id"])

        return Channel(
            name = name,
            logo = logo,
            streamUrl = streamUrl,
            streamType = StreamUtils.resolveType(streamUrl, null),
            category = category,
            country = country
        )
    }

    private fun removeDuplicateChannels(channels: List<Channel>): List<Channel> =
        channels.distinctBy { channel ->
            "${channel.name.trim().lowercase(Locale.ROOT)}|${channel.streamUrl.orEmpty().trim()}"
        }

    private fun parseMetadata(line: String): EntryMetadata? {
        val body = line.substringAfter(':', missingDelimiterValue = "")
        if (body.isBlank()) return null
        val comma = findCommaOutsideQuotes(body)
        if (comma < 0) return null

        val attributeText = body.substring(0, comma)
        val displayName = body.substring(comma + 1).trim()
        val attributes = LinkedHashMap<String, String>()
        ATTRIBUTE_REGEX.findAll(attributeText).forEach { match ->
            val key = match.groupValues[1].lowercase(Locale.ROOT)
            val value = sequenceOf(match.groupValues[2], match.groupValues[3], match.groupValues[4])
                .firstOrNull { it.isNotEmpty() }.orEmpty()
            if (key.isNotBlank()) attributes[key] = value
        }
        return EntryMetadata(displayName, attributes)
    }

    private fun findCommaOutsideQuotes(value: String): Int {
        var inDoubleQuotes = false
        var inSingleQuotes = false
        value.forEachIndexed { index, char ->
            when (char) {
                '"' -> if (!inSingleQuotes) inDoubleQuotes = !inDoubleQuotes
                '\'' -> if (!inDoubleQuotes) inSingleQuotes = !inSingleQuotes
                ',' -> if (!inDoubleQuotes && !inSingleQuotes) return index
            }
        }
        return -1
    }

    /** IPTV-org IDs often end in an ISO country suffix (for example, channel.us). */
    private fun countryFromTvgId(tvgId: String?): String {
        val suffix = tvgId?.substringAfterLast('.', missingDelimiterValue = "")
            ?.trim()?.lowercase(java.util.Locale.ROOT).orEmpty()
        return if (suffix.length == 2 && suffix in ISO_COUNTRY_CODES) suffix else ""
    }

    private fun isHttpStreamUrl(value: String): Boolean {
        val uri = runCatching { URI(value.trim()) }.getOrNull() ?: return false
        val scheme = uri.scheme?.lowercase(Locale.ROOT) ?: return false
        return uri.host?.isNotBlank() == true && (scheme == "http" || scheme == "https")
    }

    private val ISO_COUNTRY_CODES = java.util.Locale.getISOCountries()
        .map { it.lowercase(java.util.Locale.ROOT) }.toSet()
    private val ATTRIBUTE_REGEX = Regex("""([A-Za-z0-9_-]+)\s*=\s*(?:"([^"]*)"|'([^']*)'|([^\s,]+))""")
}
