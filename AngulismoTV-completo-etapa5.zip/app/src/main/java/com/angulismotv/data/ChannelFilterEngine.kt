package com.angulismotv.data

import com.angulismotv.models.Channel
import java.text.Normalizer
import java.util.Locale

/**
 * Reglas puras para clasificar y filtrar el catálogo de canales.
 *
 * Mantiene las reglas de categorías y países fuera de los Fragment y de las vistas para que
 * puedan probarse de forma aislada.
 */
object ChannelFilterEngine {

    private val spanishLocale = Locale.forLanguageTag("es-AR")
    private val combiningMarksRegex = Regex("\\p{M}+")
    private val whitespaceRegex = Regex("\\s+")

    private val categoryLabels = linkedMapOf(
        "todos" to "Todos",
        "deportes" to "Deportes",
        "noticias" to "Noticias",
        "peliculas" to "Películas",
        "series" to "Series",
        "infantiles" to "Infantiles",
        "educativos" to "Educativos",
        "internacionales" to "Internacionales",
        "estilo-vida" to "Estilo de vida",
        "musicales" to "Musicales",
        "documentales" to "Documentales",
        "entretenimiento" to "Entretenimiento",
        "otros" to "Otros",
        "eventos" to "Eventos"
    )

    // Orden fijo: la playlist argentina suele traer pocos canales, pero con muchos group-title.
    // Cada grupo debe terminar en una de estas categorías acotadas y visibles.
    private val generalCategoryOrder = listOf(
        "deportes", "noticias", "peliculas", "series", "infantiles", "musicales",
        "documentales", "educativos", "internacionales", "estilo-vida",
        "entretenimiento", "eventos", "otros"
    )

    fun categoryKey(rawCategory: String): String {
        val value = normalizeCategory(rawCategory)
        return when {
            containsAny(value, "sport", "deport", "football", "soccer", "basket", "racing", "motorsport", "tennis", "combat") -> "deportes"
            containsAny(value, "news", "noticia", "current affairs", "weather", "meteorolog") -> "noticias"
            containsAny(value, "movie", "film", "cinema", "pelicula") -> "peliculas"
            containsAny(value, "series", "drama", "soap opera") -> "series"
            containsAny(value, "kid", "child", "cartoon", "animation", "infantil", "youth") -> "infantiles"
            containsAny(value, "music", "musica", "radio", "concert") -> "musicales"
            containsAny(value, "documentary", "documental", "nature", "science", "history") -> "documentales"
            containsAny(value, "education", "educacion", "educativo", "learning", "legislative") -> "educativos"
            containsAny(value, "international", "internacional", "worldwide", "foreign", "world tv", "world", "global") -> "internacionales"
            containsAny(value, "lifestyle", "style of life", "cooking", "travel", "home and garden", "wellness", "fashion") -> "estilo-vida"
            containsAny(value, "event", "special event", "events") -> "eventos"
            containsAny(value, "entertainment", "comedy", "culture", "general", "family", "variety", "show") -> "entretenimiento"
            else -> "otros"
        }
    }

    private fun normalizeCategory(raw: String): String = Normalizer
        .normalize(raw.trim().lowercase(Locale.ROOT), Normalizer.Form.NFD)
        .replace(combiningMarksRegex, "")
        .replace('_', ' ')
        .replace('-', ' ')
        .replace(whitespaceRegex, " ")
        .trim()

    private fun containsAny(value: String, vararg tokens: String): Boolean =
        tokens.any { token -> value.contains(token) }

    fun countryKey(rawCountry: String): String {
        val value = rawCountry.trim().substringBefore(',')
        if (value.isBlank()) return UNKNOWN_COUNTRY
        return value.lowercase(Locale.ROOT).replace(' ', '_')
    }

    fun countryLabel(key: String): String {
        if (key == UNKNOWN_COUNTRY) return "Sin país informado"
        val raw = key.replace('_', ' ')
        // IPTV-org suele usar códigos ISO de dos letras; los nombres legibles se mantienen.
        return if (raw.length == 2 && raw.all { it.isLetter() }) {
            Locale.Builder().setRegion(raw.uppercase(Locale.ROOT)).build()
                .getDisplayCountry(spanishLocale)
                .ifBlank { raw.uppercase(Locale.ROOT) }
        } else {
            raw.split(' ').joinToString(" ") { word ->
                word.lowercase(spanishLocale).replaceFirstChar { first ->
                    if (first.isLowerCase()) first.titlecase(spanishLocale) else first.toString()
                }
            }
        }
    }

    fun displayCategoryName(categoryKey: String): String {
        categoryLabels[categoryKey]?.let { return it }
        return categoryKey
            .replace('-', ' ')
            .replace('_', ' ')
            .trim()
            .split(whitespaceRegex)
            .filter(String::isNotBlank)
            .joinToString(" ") { word ->
                word.lowercase(spanishLocale).replaceFirstChar { first ->
                    if (first.isLowerCase()) first.titlecase(spanishLocale) else first.toString()
                }
            }
    }

    /** Categorías disponibles en el catálogo, en el orden estable de la interfaz. */
    fun availableCategories(channels: List<Channel>): List<Pair<String, String>> {
        if (channels.isEmpty()) return emptyList()
        val availableKeys = channels.asSequence().map { categoryKey(it.category) }.toSet()
        return buildList {
            add("todos" to categoryLabels.getValue("todos"))
            generalCategoryOrder.forEach { key ->
                if (key in availableKeys) add(key to categoryLabels.getValue(key))
            }
        }
    }

    /** Países únicos en orden legible, sin incluir la opción especial «Todos». */
    fun availableCountries(channels: List<Channel>): List<String> = channels
        .asSequence()
        .map { countryKey(it.country) }
        .distinct()
        .sortedBy { countryLabel(it).lowercase(Locale.ROOT) }
        .toList()

    fun filter(
        channels: List<Channel>,
        category: String,
        country: String,
        query: String
    ): List<Channel> {
        // Una búsqueda explícita es global por categorías: no debe quedar escondida por
        // el chip elegido previamente. El filtro de país sí se conserva deliberadamente.
        val categoryFiltered = if (query.isNotBlank() || category.equals("todos", ignoreCase = true)) {
            channels
        } else {
            channels.filter { categoryKey(it.category) == category }
        }
        val countryFiltered = if (country.equals("todos", ignoreCase = true)) {
            categoryFiltered
        } else {
            categoryFiltered.filter { countryKey(it.country) == country }
        }
        return ChannelCatalog.searchByName(countryFiltered, query)
    }

    const val ALL_COUNTRIES = "todos"
    const val UNKNOWN_COUNTRY = "sin_pais"
}
