package com.angulismotv.data

import android.content.Context
import com.angulismotv.models.Channel
import com.angulismotv.models.ChannelIdentity

/** Persistencia simple de favoritos usando la identidad estable del canal. */
class FavoritesStore(context: Context) {
    private val prefs = context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun contains(channel: Channel): Boolean = keys().contains(ChannelIdentity.key(channel))

    fun toggle(channel: Channel): Boolean {
        val values = keys().toMutableSet()
        val key = ChannelIdentity.key(channel)
        val added = if (values.contains(key)) { values.remove(key); false } else { values.add(key); true }
        prefs.edit().putStringSet(KEY_FAVORITES, values).apply()
        return added
    }

    fun keys(): Set<String> = prefs.getStringSet(KEY_FAVORITES, emptySet())?.toSet() ?: emptySet()

    companion object {
        private const val PREFS = "channel_favorites"
        private const val KEY_FAVORITES = "favorite_channel_keys"
    }
}
