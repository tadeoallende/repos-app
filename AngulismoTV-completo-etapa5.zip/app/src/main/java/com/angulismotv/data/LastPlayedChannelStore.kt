package com.angulismotv.data

import android.content.Context
import com.angulismotv.models.Channel
import com.angulismotv.models.ChannelIdentity

/** Owns the persistent snapshot used to restore the last active channel on Android TV. */
class LastPlayedChannelStore(context: Context) {
    private val preferences = context.applicationContext.getSharedPreferences(
        PREFERENCES_NAME,
        Context.MODE_PRIVATE
    )

    fun remember(channel: Channel) {
        preferences.edit()
            .putString(KEY_CHANNEL_ID, ChannelIdentity.key(channel))
            .putString(KEY_CHANNEL_NAME, channel.name)
            .putString(KEY_CHANNEL_LOGO, channel.logo)
            .apply()
    }

    fun resolve(channels: List<Channel>): Channel? = LastPlayedChannelResolver.resolve(
        channels = channels,
        savedKey = preferences.getString(KEY_CHANNEL_ID, null),
        savedName = preferences.getString(KEY_CHANNEL_NAME, null).orEmpty(),
        savedLogo = preferences.getString(KEY_CHANNEL_LOGO, null)
    )

    /** Remove only this feature's keys, leaving unrelated preferences intact. */
    fun clear() {
        preferences.edit()
            .remove(KEY_CHANNEL_ID)
            .remove(KEY_CHANNEL_NAME)
            .remove(KEY_CHANNEL_LOGO)
            .apply()
    }

    private companion object {
        const val PREFERENCES_NAME = "angulismotv_playback"
        const val KEY_CHANNEL_ID = "last_channel_key"
        const val KEY_CHANNEL_NAME = "last_channel_name"
        const val KEY_CHANNEL_LOGO = "last_channel_logo"
    }
}

/** Pure matching policy, separated so last-channel restoration can be unit-tested. */
internal object LastPlayedChannelResolver {
    fun resolve(channels: List<Channel>, savedKey: String?, savedName: String, savedLogo: String?): Channel? {
        if (channels.isEmpty()) return null
        return channels.firstOrNull {
            !savedKey.isNullOrBlank() && ChannelIdentity.key(it) == savedKey
        } ?: channels.firstOrNull {
            savedName.isNotBlank() && it.name.equals(savedName, ignoreCase = true) &&
                (savedLogo.isNullOrBlank() || it.logo == savedLogo)
        } ?: channels.firstOrNull {
            savedName.isNotBlank() && it.name.equals(savedName, ignoreCase = true)
        }
    }
}
