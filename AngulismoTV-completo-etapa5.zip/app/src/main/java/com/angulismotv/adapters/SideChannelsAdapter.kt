package com.angulismotv.adapters

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.AsyncListDiffer
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.RecyclerView
import com.angulismotv.R
import com.angulismotv.models.Channel
import com.angulismotv.models.ChannelIdentity
import com.angulismotv.utils.loadChannelLogo

/** Lista de canales del panel lateral del reproductor. */
class SideChannelsAdapter(
    private val onItemClick: (Channel, Int) -> Unit,
    private val channelNumber: (Channel) -> Int = { 0 }
) : RecyclerView.Adapter<SideChannelsAdapter.ViewHolder>() {

    private val differ = AsyncListDiffer(this, object : DiffUtil.ItemCallback<Channel>() {
        override fun areItemsTheSame(oldItem: Channel, newItem: Channel): Boolean =
            oldItem.name == newItem.name && oldItem.logo == newItem.logo

        override fun areContentsTheSame(oldItem: Channel, newItem: Channel): Boolean =
            oldItem == newItem
    })
    private var selectedChannelKey: String? = null

    fun submitList(
        newChannels: List<Channel>,
        selectedIdx: Int,
        onCommitted: (() -> Unit)? = null
    ) {
        val snapshot = newChannels.toList()
        selectedChannelKey = snapshot.getOrNull(selectedIdx)?.let(ChannelIdentity::key)
        differ.submitList(snapshot) {
            // Selection is presentation state; update visible row payloads after the background diff.
            if (itemCount > 0) notifyItemRangeChanged(0, itemCount, PAYLOAD_SELECTION_STATE)
            onCommitted?.invoke()
        }
    }

    override fun getItemCount() = differ.currentList.size

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_channel_side, parent, false)
        view.isFocusable = true
        view.isFocusableInTouchMode = true
        view.isClickable = true
        // El drawable de estado enfocado ofrece una señal estable, sin animación ni solapamientos.
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val channel = differ.currentList[position]
        holder.bind(channel, ChannelIdentity.key(channel) == selectedChannelKey, channelNumber(channel))
        holder.itemView.setOnClickListener {
            val currentPosition = holder.bindingAdapterPosition
            if (currentPosition != RecyclerView.NO_POSITION) {
                // Lee el dato vigente de la lista tras un DiffUtil, no una referencia obsoleta.
                differ.currentList.getOrNull(currentPosition)?.let { currentChannel ->
                    onItemClick(currentChannel, currentPosition)
                }
            }
        }
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int, payloads: MutableList<Any>) {
        if (payloads.isNotEmpty() && payloads.all { it == PAYLOAD_SELECTION_STATE }) {
            differ.currentList.getOrNull(position)?.let { channel ->
                holder.updateSelection(
                    channel,
                    ChannelIdentity.key(channel) == selectedChannelKey,
                    channelNumber(channel)
                )
            }
            return
        }
        onBindViewHolder(holder, position)
    }

    companion object {
        private const val PAYLOAD_SELECTION_STATE = "selection_state"
    }

    class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val marker: View = itemView.findViewById(R.id.channel_selected_marker)
        private val logo: ImageView = itemView.findViewById(R.id.channel_logo)
        private val name: TextView = itemView.findViewById(R.id.channel_name)
        private val number: TextView = itemView.findViewById(R.id.channel_number)
        private val optionsIndicator: ImageView = itemView.findViewById(R.id.options_indicator)

        fun bind(channel: Channel, isSelected: Boolean, channelNumber: Int) {
            itemView.alpha = 1f
            number.text = if (channelNumber > 0) channelNumber.toString() else "—"
            name.text = channel.name
            optionsIndicator.visibility = if (!channel.options.isNullOrEmpty()) View.VISIBLE else View.GONE
            updateSelection(channel, isSelected, channelNumber)
            // Mantiene la forma original de cada logo; el elemento no agrega una tarjeta detrás.
            logo.loadChannelLogo(channel.name, channel.logo)
        }

        fun updateSelection(channel: Channel, isSelected: Boolean, channelNumber: Int) {
            number.text = if (channelNumber > 0) channelNumber.toString() else "—"
            itemView.isSelected = isSelected
            marker.visibility = if (isSelected) View.VISIBLE else View.INVISIBLE
            itemView.setBackgroundResource(
                if (isSelected) R.drawable.side_channel_item_selected
                else R.drawable.side_channel_item_bg
            )
            itemView.contentDescription = buildString {
                if (channelNumber > 0) append("Canal $channelNumber: ")
                append(channel.name)
                if (!channel.options.isNullOrEmpty()) append(", con opciones")
                if (isSelected) append(", en reproducción")
            }
        }
    }
}
