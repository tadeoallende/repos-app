package com.angulismotv.adapters

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.AsyncListDiffer
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.RecyclerView
import com.angulismotv.R
import com.angulismotv.models.Channel
import com.angulismotv.models.ChannelIdentity
import com.angulismotv.utils.DeviceHelper
import com.angulismotv.utils.loadChannelLogo
import com.bumptech.glide.Glide

class ChannelsAdapter(
    private val onItemClick: (Channel, Int) -> Unit,
    private val channelNumber: (Channel) -> Int = { 0 }
) : RecyclerView.Adapter<ChannelsAdapter.ChannelViewHolder>() {

    // ✅ AsyncListDiffer para actualizaciones eficientes
    private val differ = AsyncListDiffer(this, object : DiffUtil.ItemCallback<Channel>() {
        override fun areItemsTheSame(oldItem: Channel, newItem: Channel): Boolean {
            return ChannelIdentity.same(oldItem, newItem)
        }

        override fun areContentsTheSame(oldItem: Channel, newItem: Channel): Boolean {
            return oldItem == newItem
        }
    })

    private var isTV = false
    private var lastFocusedPosition = -1
    private var lastFocusedChannelKey: String? = null
    private var categoryFocusTargetId = View.NO_ID
    private var previewChannelKey: String? = null

    fun submitList(newChannels: List<Channel>, onCommitted: (() -> Unit)? = null) {
        differ.submitList(newChannels, Runnable { onCommitted?.invoke() })
    }

    /** Safe snapshot accessors used by focus restoration around AsyncListDiffer updates. */
    fun getChannelAt(position: Int): Channel? = differ.currentList.getOrNull(position)

    fun getPositionForKey(key: String): Int = differ.currentList.indexOfFirst {
        ChannelIdentity.key(it) == key
    }

    fun getLastFocusedChannelKey(): String? = lastFocusedChannelKey

    /** The first channel row returns UP to the currently selected category chip on Android TV. */
    fun setCategoryFocusTarget(viewId: Int) {
        categoryFocusTargetId = viewId
        if (isTV && itemCount > 0) notifyItemRangeChanged(0, itemCount)
    }

    /** Current inline preview remains subtly marked even when D-pad focus moves to another row. */
    fun setPreviewChannel(channel: Channel?) {
        val nextKey = channel?.let(ChannelIdentity::key)
        if (previewChannelKey == nextKey) return
        previewChannelKey = nextKey
        if (itemCount > 0) notifyItemRangeChanged(0, itemCount, PAYLOAD_PREVIEW_STATE)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ChannelViewHolder {
        isTV = DeviceHelper.isTV(parent.context)
        val layout = if (isTV) R.layout.item_channel_tv else R.layout.item_channel
        val view = LayoutInflater.from(parent.context).inflate(layout, parent, false)
        return ChannelViewHolder(view, isTV)
    }

    override fun onBindViewHolder(holder: ChannelViewHolder, position: Int) {
        val channel = differ.currentList[position]
        holder.bind(channel, position, channelNumber(channel))
        holder.itemView.isSelected = previewChannelKey == ChannelIdentity.key(channel)

        holder.itemView.setOnClickListener {
            // Long presses/releases can arrive while AsyncListDiffer is dispatching updates.
            // Resolve both the position and item from the current list at click time.
            val currentPosition = holder.bindingAdapterPosition
            if (currentPosition != RecyclerView.NO_POSITION) {
                differ.currentList.getOrNull(currentPosition)?.let { currentChannel ->
                    onItemClick(currentChannel, currentPosition)
                }
            }
        }
        holder.itemView.nextFocusLeftId = if (isTV) R.id.inline_player_container else View.NO_ID
        holder.itemView.nextFocusUpId = if (isTV && position == 0) categoryFocusTargetId else View.NO_ID
        if (isTV) {
            holder.itemView.setOnKeyListener { focusedRow, keyCode, event ->
                if (event.action != android.view.KeyEvent.ACTION_DOWN) {
                    false
                } else when (keyCode) {
                    android.view.KeyEvent.KEYCODE_DPAD_RIGHT -> true
                    android.view.KeyEvent.KEYCODE_DPAD_UP,
                    android.view.KeyEvent.KEYCODE_DPAD_DOWN -> {
                        val currentPosition = holder.bindingAdapterPosition
                        val count = differ.currentList.size
                        if (currentPosition == RecyclerView.NO_POSITION || count == 0) {
                            true
                        } else {
                            val delta = if (keyCode == android.view.KeyEvent.KEYCODE_DPAD_DOWN) 1 else -1
                            val targetPosition = currentPosition + delta
                            if (targetPosition < 0) {
                                false
                            } else if (targetPosition >= count) {
                                true
                            } else {
                                val recycler = focusedRow.parent as? RecyclerView
                                if (recycler != null) {
                                    val target = recycler.findViewHolderForAdapterPosition(targetPosition)?.itemView
                                    val fullyVisible = target != null &&
                                        target.top >= recycler.paddingTop &&
                                        target.bottom <= recycler.height - recycler.paddingBottom
                                    if (fullyVisible) {
                                        target?.requestFocus()
                                    } else {
                                        val layoutManager = recycler.layoutManager as?
                                            androidx.recyclerview.widget.LinearLayoutManager
                                        val rowHeight = focusedRow.height.takeIf { it > 0 } ?: 1
                                        val offset = if (delta > 0) {
                                            (recycler.height - recycler.paddingBottom - rowHeight)
                                                .coerceAtLeast(recycler.paddingTop)
                                        } else recycler.paddingTop
                                        layoutManager?.scrollToPositionWithOffset(targetPosition, offset)
                                        recycler.post {
                                            recycler.post {
                                                recycler.findViewHolderForAdapterPosition(targetPosition)
                                                    ?.itemView?.requestFocus()
                                            }
                                        }
                                    }
                                }
                                true
                            }
                        }
                    }
                    else -> false
                }
            }
        } else {
            holder.itemView.setOnKeyListener(null)
        }

        // Mejor manejo de foco para TV.
        if (isTV) {
            setupTVFocus(holder)
        }
    }

    override fun onBindViewHolder(holder: ChannelViewHolder, position: Int, payloads: MutableList<Any>) {
        if (payloads.contains(PAYLOAD_PREVIEW_STATE)) {
            val channel = differ.currentList.getOrNull(position)
            holder.itemView.isSelected = channel != null && previewChannelKey == ChannelIdentity.key(channel)
            return
        }
        onBindViewHolder(holder, position)
    }

    private fun setupTVFocus(holder: ChannelViewHolder) {
        holder.itemView.apply {
            isFocusable = true
            isFocusableInTouchMode = true

            nextFocusLeftId = R.id.inline_player_container
            nextFocusUpId = if (holder.bindingAdapterPosition == 0) categoryFocusTargetId else View.NO_ID
            setOnFocusChangeListener { _, hasFocus ->
                // El selector dibuja el foco sin escalar ni desplazar filas vecinas.
                if (hasFocus) {
                    val position = holder.bindingAdapterPosition
                    lastFocusedPosition = position
                    differ.currentList.getOrNull(position)?.let { channel ->
                        lastFocusedChannelKey = ChannelIdentity.key(channel)
                    }
                    nextFocusLeftId = R.id.inline_player_container
                    nextFocusUpId = if (position == 0) categoryFocusTargetId else View.NO_ID
                }
            }
        }
    }

    override fun getItemCount() = differ.currentList.size

    companion object {
        private const val PAYLOAD_PREVIEW_STATE = "preview_state"
    }

    // ✅ Método útil para recuperar el último foco
    fun getLastFocusedPosition(): Int = lastFocusedPosition

    inner class ChannelViewHolder(
        itemView: View,
        private val isTV: Boolean
    ) : RecyclerView.ViewHolder(itemView) {

        private val logo: ImageView = itemView.findViewById(R.id.channel_logo)
        private val channelName: TextView = itemView.findViewById(R.id.channel_name)
        private val channelNumberView: TextView = itemView.findViewById(R.id.channel_number)
        private val optionsIndicator: ImageView = itemView.findViewById(R.id.options_indicator)

        private var currentChannel: Channel? = null

        fun bind(channel: Channel, position: Int, channelNumber: Int) {
            currentChannel = channel
            channelNumberView.text = if (channelNumber > 0) channelNumber.toString() else "—"

            // Nombre del canal
            channelName.text = channel.name
            channelName.isSelected = isTV  // Para marquee en TV

            // Indicador de opciones múltiples
            val optionCount = channel.options.orEmpty().size
            val hasOptions = optionCount > 0
            optionsIndicator.visibility = if (hasOptions) View.VISIBLE else View.GONE

            val logoRadiusRes = if (isTV) R.dimen.channel_logo_corner_radius_tv else R.dimen.channel_logo_corner_radius_mobile
            val logoRadius = itemView.resources.getDimensionPixelSize(logoRadiusRes)
            logo.loadChannelLogo(channel.name, channel.logo, cornerRadiusPx = logoRadius)

            val numberDescription = if (channelNumber > 0) "Canal $channelNumber, " else ""
            val hasDirectSource = !channel.streamUrl.isNullOrBlank()
            val sourceCount = optionCount + if (hasDirectSource) 1 else 0
            val sourceDescription = when {
                sourceCount > 1 -> "con $sourceCount fuentes disponibles"
                sourceCount == 1 && optionCount > 0 -> "con una fuente alternativa"
                sourceCount == 1 -> "con reproducción directa"
                else -> "sin fuentes configuradas"
            }
            itemView.contentDescription = "$numberDescription${channel.name}, $sourceDescription"
        }

        fun recycle() {
            Glide.with(itemView.context).clear(logo)
            itemView.isSelected = false
            currentChannel = null
        }
    }

    // ✅ Limpiar recursos cuando el adapter se destruye
    override fun onViewRecycled(holder: ChannelViewHolder) {
        super.onViewRecycled(holder)
        holder.recycle()
    }
}