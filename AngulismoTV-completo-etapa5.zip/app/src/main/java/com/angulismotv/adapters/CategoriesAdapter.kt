package com.angulismotv.adapters

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import android.widget.ImageView
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.RecyclerView
import com.angulismotv.R

/** Categorías del panel lateral del reproductor. Conserva la selección sin recrear toda la lista. */
class CategoriesAdapter(
    private val onCategoryClick: (String) -> Unit
) : RecyclerView.Adapter<CategoriesAdapter.CategoryViewHolder>() {

    data class CategoryItem(val key: String, val name: String, val count: Int)

    private var categories: List<CategoryItem> = emptyList()
    private var selectedCategory = "todos"

    fun submitList(newCategories: List<CategoryItem>, selected: String) {
        val oldCategories = categories
        val oldSelected = selectedCategory
        val nextCategories = newCategories.toList()
        val nextSelected = selected

        val diff = DiffUtil.calculateDiff(object : DiffUtil.Callback() {
            override fun getOldListSize() = oldCategories.size
            override fun getNewListSize() = nextCategories.size

            override fun areItemsTheSame(oldPosition: Int, newPosition: Int): Boolean =
                oldCategories[oldPosition].key == nextCategories[newPosition].key

            override fun areContentsTheSame(oldPosition: Int, newPosition: Int): Boolean {
                val oldItem = oldCategories[oldPosition]
                val newItem = nextCategories[newPosition]
                val oldWasSelected = oldItem.key == oldSelected
                val newIsSelected = newItem.key == nextSelected
                return oldItem == newItem && oldWasSelected == newIsSelected
            }
        })

        categories = nextCategories
        selectedCategory = nextSelected
        diff.dispatchUpdatesTo(this)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): CategoryViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_category_side, parent, false)
        view.isFocusable = true
        view.isFocusableInTouchMode = true
        view.isClickable = true
        // El selector de fondo dibuja el foco sin escalar filas ni provocar solapamientos.
        return CategoryViewHolder(view)
    }

    override fun onBindViewHolder(holder: CategoryViewHolder, position: Int) {
        val category = categories[position]
        holder.bind(category, category.key == selectedCategory)
        // El primer elemento dinámico queda conectado de forma explícita con la acción
        // «Lista de canales» situada justo encima del RecyclerView.
        holder.itemView.nextFocusUpId = if (position == 0) R.id.btn_all_channels else View.NO_ID
        holder.itemView.setOnClickListener { onCategoryClick(category.key) }
    }

    override fun getItemCount() = categories.size

    fun getPositionForKey(categoryKey: String): Int =
        categories.indexOfFirst { it.key == categoryKey }

    inner class CategoryViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val markerView: View = itemView.findViewById(R.id.category_selected_marker)
        private val iconView: ImageView = itemView.findViewById(R.id.category_icon)
        private val nameView: TextView = itemView.findViewById(R.id.category_name)
        private val countView: TextView = itemView.findViewById(R.id.category_count)

        fun bind(category: CategoryItem, isSelected: Boolean) {
            itemView.alpha = 1f
            itemView.isSelected = isSelected
            nameView.text = category.name
            countView.text = category.count.toString()
            val context = itemView.context
            val accentColor = ContextCompat.getColor(context, R.color.accent)
            val secondaryColor = ContextCompat.getColor(context, R.color.text_secondary)
            markerView.visibility = if (isSelected) View.VISIBLE else View.INVISIBLE
            iconView.setColorFilter(if (isSelected) accentColor else ContextCompat.getColor(context, R.color.text_hint))
            countView.setTextColor(if (isSelected) accentColor else secondaryColor)
            itemView.setBackgroundResource(
                if (isSelected) R.drawable.side_category_item_selected
                else R.drawable.side_category_item_bg
            )
            itemView.contentDescription = buildString {
                append(category.name)
                append(", ${category.count} canales")
                if (isSelected) append(", seleccionada")
            }
        }
    }

    fun clearSelection() = submitList(categories, "")

    fun setSelectedCategory(categoryKey: String) = submitList(categories, categoryKey)
}
