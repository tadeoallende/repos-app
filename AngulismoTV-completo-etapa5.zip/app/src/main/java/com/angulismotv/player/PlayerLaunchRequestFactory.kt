package com.angulismotv.player

import android.content.Context
import android.content.Intent
import com.angulismotv.UnifiedPlayerActivity
import com.angulismotv.models.Channel
import com.angulismotv.models.ChannelIdentity
import com.angulismotv.models.StreamType

/**
 * Prepara el catálogo e Intent de pantalla completa sin mezclar esas tareas con la UI de canales.
 * La identidad se basa en ChannelIdentity y los canales obsoletos se conservan al final del catálogo.
 */
internal data class PlayerLaunchCatalog(
    val channels: List<Channel>,
    val channelIndex: Int
)

internal object PlayerLaunchRequestFactory {

    fun resolveCatalog(originalChannels: List<Channel>, channel: Channel): PlayerLaunchCatalog {
        val matchingIndex = originalChannels.indexOfFirst { ChannelIdentity.same(it, channel) }
        // Un canal desactualizado se agrega al final; nunca se reemplaza por el primer canal.
        val channels = if (matchingIndex >= 0) originalChannels else originalChannels + channel
        val index = if (matchingIndex >= 0) matchingIndex else channels.lastIndex
        return PlayerLaunchCatalog(channels, index)
    }

    fun createIntent(
        context: Context,
        channel: Channel,
        catalog: PlayerLaunchCatalog,
        catalogToken: Long,
        fromInline: Boolean,
        isTV: Boolean,
        sourceIndex: Int,
        handoff: InlinePlayerTransferPlan,
        openChannelPanel: Boolean = false,
        openChannelSearch: Boolean = false
    ): Intent = Intent(context, UnifiedPlayerActivity::class.java).apply {
        // Evitar incluir el catálogo entero en el Intent: los bundles tienen límite de tamaño.
        putExtra(PlayerLaunchExtras.CATALOG_TOKEN, catalogToken)
        putExtra(PlayerLaunchExtras.CURRENT_CHANNEL, channel)
        putExtra(PlayerLaunchExtras.CHANNEL_INDEX, catalog.channelIndex)
        putExtra(PlayerLaunchExtras.CHANNEL_NAME, channel.name)
        putExtra(PlayerLaunchExtras.CHANNEL_LOGO, channel.logo)
        putExtra(PlayerLaunchExtras.STREAM_URL, channel.streamUrl)
        putExtra(PlayerLaunchExtras.STREAM_TYPE, channel.streamType ?: StreamType.AUTO)
        putExtra(PlayerLaunchExtras.FROM_INLINE_PLAYER, fromInline)
        putExtra(PlayerLaunchExtras.FORCE_LANDSCAPE_FULLSCREEN, fromInline && !isTV)
        putExtra(PlayerLaunchExtras.SOURCE_INDEX, sourceIndex)
        putExtra(PlayerLaunchExtras.REUSE_INLINE_PLAYER_SESSION, handoff.transferNativePlayer)
        putExtra(PlayerLaunchExtras.REUSE_INLINE_WEBVIEW_SESSION, handoff.transferWebView)
        putExtra(PlayerLaunchExtras.OPEN_CHANNEL_PANEL, openChannelPanel)
        putExtra(PlayerLaunchExtras.OPEN_CHANNEL_SEARCH, openChannelSearch)
    }
}
