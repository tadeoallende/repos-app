package com.angulismotv.player

/** Shared top-level navigation rule for embedded streams in mobile and fullscreen players. */
object WebViewNavigationPolicy {
    /**
     * Returns true when a main-frame navigation should be blocked.
     * Server redirects remain allowed to preserve existing embed-provider behavior; other
     * top-level navigations must stay on the original host or one of its subdomains.
     */
    fun shouldBlockTopLevelNavigation(
        initialHost: String,
        requestedHost: String?,
        isMainFrame: Boolean,
        isRedirect: Boolean
    ): Boolean {
        if (!isMainFrame || isRedirect) return false

        val host = requestedHost.orEmpty()
        val sameSite = host == initialHost || host.endsWith(".$initialHost")
        return !sameSite
    }
}
