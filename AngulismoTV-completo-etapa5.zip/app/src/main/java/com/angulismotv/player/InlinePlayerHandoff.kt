package com.angulismotv.player

import com.angulismotv.models.Channel
import com.google.android.exoplayer2.ExoPlayer
import android.view.ViewGroup
import android.webkit.WebView

/**
 * Transfers the current preview engine between ChannelsFragment and UnifiedPlayerActivity.
 * Native ExoPlayer sessions keep their buffer/position; iframe sources reuse the same WebView
 * instance to avoid reloading the embed just because the player view became fullscreen.
 * All calls are made on the main thread; synchronized methods also guard against
 * lifecycle callbacks racing during Activity transitions.
 */
object InlinePlayerHandoff {
    data class Session(
        val player: ExoPlayer?,
        val channel: Channel,
        val streamUrl: String,
        val streamType: String,
        val sourceIndex: Int,
        val wasPlaying: Boolean,
        val webView: WebView? = null,
        val webViewParentIndex: Int = -1,
        val webViewLayoutParams: ViewGroup.LayoutParams? = null
    )

    private var pendingFullscreen: Session? = null
    private var pendingInline: Session? = null

    @Synchronized
    fun offerToFullscreen(session: Session) {
        pendingFullscreen?.let { old ->
            if (old.player !== session.player) old.player?.let { player -> runCatching { player.release() } }
            if (old.webView !== session.webView) disposeWebView(old.webView)
        }
        pendingFullscreen = session
    }

    /** Returns the detached preview player only when the resolved source exactly matches. */
    @Synchronized
    fun takeForFullscreen(streamUrl: String, streamType: String): Session? {
        val session = pendingFullscreen ?: return null
        pendingFullscreen = null
        val matches = session.player != null &&
            session.streamUrl == streamUrl &&
            session.streamType.equals(streamType, ignoreCase = true)
        if (matches) return session

        // The fullscreen route did not consume the offered media. It is no longer safe
        // to reuse it for a different URL; release the detached engine rather than leak it.
        session.player?.let { player -> runCatching { player.release() } }
        disposeWebView(session.webView)
        return null
    }

    /** Takes an already-loaded iframe WebView so the fullscreen screen can reuse its page. */
    @Synchronized
    fun takePendingWebViewForFullscreen(): Session? {
        val session = pendingFullscreen ?: return null
        if (session.webView == null) return null
        pendingFullscreen = null
        return session
    }

    @Synchronized
    fun cancelPendingFullscreen(): Session? = pendingFullscreen.also { pendingFullscreen = null }

    @Synchronized
    fun returnToInline(session: Session) {
        pendingFullscreen?.let { old ->
            if (old.player !== session.player) old.player?.let { player -> runCatching { player.release() } }
            if (old.webView !== session.webView) disposeWebView(old.webView)
        }
        pendingFullscreen = null
        pendingInline?.let { old ->
            if (old.player !== session.player) old.player?.let { player -> runCatching { player.release() } }
            if (old.webView !== session.webView) disposeWebView(old.webView)
        }
        pendingInline = session
    }

    @Synchronized
    fun takeReturnedToInline(): Session? = pendingInline.also { pendingInline = null }

    private fun disposeWebView(webView: WebView?) {
        if (webView == null) return
        runCatching {
            webView.stopLoading()
            (webView.parent as? ViewGroup)?.removeView(webView)
            webView.removeAllViews()
            webView.destroy()
        }
    }
}
