package com.angulismotv.player

/**
 * Distinguishes the initial portrait posture from a real return to portrait after the device
 * has physically reached landscape. Orientation degrees come from OrientationEventListener.
 */
class FullscreenOrientationPolicy {
    enum class Position {
        UNKNOWN,
        TRANSITION,
        PORTRAIT_BEFORE_LANDSCAPE,
        LANDSCAPE,
        PORTRAIT_AFTER_LANDSCAPE
    }

    private var observedPhysicalLandscape = false

    fun classify(degrees: Int): Position {
        if (degrees !in 0..359) return Position.UNKNOWN

        if (degrees in 60..120 || degrees in 240..300) {
            observedPhysicalLandscape = true
            return Position.LANDSCAPE
        }

        if (degrees in 0..30 || degrees in 150..210 || degrees in 330..359) {
            return if (observedPhysicalLandscape) {
                Position.PORTRAIT_AFTER_LANDSCAPE
            } else {
                Position.PORTRAIT_BEFORE_LANDSCAPE
            }
        }

        return Position.TRANSITION
    }

    fun shouldExitToInline(degrees: Int): Boolean = classify(degrees) == Position.PORTRAIT_AFTER_LANDSCAPE
}
