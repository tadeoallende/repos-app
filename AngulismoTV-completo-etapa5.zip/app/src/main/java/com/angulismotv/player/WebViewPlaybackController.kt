package com.angulismotv.player

import android.os.Build
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.ProgressBar
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import com.angulismotv.BuildConfig
import com.angulismotv.models.StreamType
import com.google.android.exoplayer2.ui.PlayerView

/** Owns the embed WebView navigation, security filters, custom-view lifecycle, and bridge hookup. */
class WebViewPlaybackController(
    private val webView: WebView,
    private val touchBlocker: View,
    private val playerView: PlayerView,
    private val playerContainer: FrameLayout,
    private val progressBar: ProgressBar,
    private val controlsOverlay: View,
    private val bottomControls: View,
    private val bridge: WebViewPlayerBridge,
    private val isTV: () -> Boolean,
    private val currentStreamType: () -> String,
    private val updateControlsVisibility: () -> Unit,
    private val lockWebViewFocus: () -> Unit,
    private val showControlsTemporarily: () -> Unit,
    private val onMainFrameError: (Int, String?, String?) -> Unit
) {
    private var loadGeneration = 0
    private var customView: View? = null
    private var customViewCallback: WebChromeClient.CustomViewCallback? = null

    fun invalidatePendingLoad() {
        loadGeneration++
    }

    fun isCurrentLoad(generation: Int): Boolean = generation == loadGeneration

    /** Configures and loads an embed, or rebinds the existing page without reloading it. */
    fun load(url: String, reuseLoadedPage: Boolean) {
        val initialHost = StreamUrlPolicy.parseHttpUrl(url)?.host.orEmpty()
        val generation = ++loadGeneration
        resetBridgeForLoad(reuseLoadedPage)
        prepareEmbedSurface()
        webView.webViewClient = createEmbedWebViewClient(initialHost, generation)
        webView.webChromeClient = createEmbedWebChromeClient()

        if (reuseLoadedPage) rebindLoadedPage(generation) else webView.loadUrl(url)
    }

    private fun resetBridgeForLoad(reuseLoadedPage: Boolean) {
        bridge.stopMonitor()
        bridge.reset()
        webView.applyPlayerSettings()
        if (reuseLoadedPage) return

        webView.stopLoading()
        webView.clearHistory()
        webView.loadUrl("about:blank")
        bridge.detach()
    }

    private fun prepareEmbedSurface() {
        webView.visibility = View.VISIBLE
        if (isTV()) {
            touchBlocker.visibility = View.VISIBLE
            lockWebViewFocus()
            playerView.visibility = View.INVISIBLE
            playerView.isFocusable = true
            playerView.isFocusableInTouchMode = true
            playerView.requestFocus()
        } else {
            touchBlocker.visibility = View.GONE
            webView.isClickable = true
            webView.isFocusable = true
            webView.isFocusableInTouchMode = true
        }
        progressBar.visibility = View.VISIBLE
        updateControlsVisibility()
        if (!isTV()) showControlsTemporarily()
    }

    private fun createEmbedWebViewClient(initialHost: String, generation: Int): WebViewClient =
        object : WebViewClient() {
            override fun onPageFinished(view: WebView?, url: String?) {
                handleEmbedPageFinished(view, url, generation)
            }

            @android.annotation.TargetApi(Build.VERSION_CODES.M)
            override fun onReceivedError(
                view: WebView?,
                request: android.webkit.WebResourceRequest?,
                error: android.webkit.WebResourceError?
            ) {
                handleEmbedResourceError(generation, request, error)
            }

            @Suppress("DEPRECATION")
            override fun onReceivedError(view: WebView?, code: Int, desc: String?, url: String?) {
                handleLegacyEmbedResourceError(generation, url, desc)
            }

            @android.annotation.TargetApi(Build.VERSION_CODES.M)
            override fun onReceivedHttpError(
                view: WebView?,
                request: android.webkit.WebResourceRequest?,
                errorResponse: android.webkit.WebResourceResponse?
            ) {
                handleEmbedHttpError(generation, request, errorResponse)
            }

            override fun onReceivedSslError(
                view: WebView?,
                handler: android.webkit.SslErrorHandler?,
                error: android.net.http.SslError?
            ) {
                // Never bypass a TLS certificate failure.
                handler?.cancel()
            }

            override fun shouldOverrideUrlLoading(
                view: WebView?,
                request: android.webkit.WebResourceRequest?
            ): Boolean {
                request ?: return false
                if (!request.isForMainFrame) return false
                return shouldBlockNavigation(initialHost, request)
            }
        }

    private fun handleEmbedPageFinished(view: WebView?, url: String?, generation: Int) {
        if (!isCurrentLoad(generation) || url.isNullOrBlank() || url == "about:blank") return
        view?.loadUrl("javascript:${WebViewScripts.FULLSCREEN}")
        progressBar.visibility = View.GONE
        bridge.attach()
        bridge.injectScript()
        if (isTV()) prepareTvFocusAfterPageLoad()
        showControlsTemporarily()
    }

    @android.annotation.TargetApi(Build.VERSION_CODES.M)
    private fun handleEmbedResourceError(
        generation: Int,
        request: android.webkit.WebResourceRequest?,
        error: android.webkit.WebResourceError?
    ) {
        val failedRequest = request ?: return
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M || !failedRequest.isForMainFrame) return
        val failedUrl = failedRequest.url.toString()
        if (failedUrl != "about:blank") {
            onMainFrameError(generation, failedUrl, error?.description?.toString())
        }
    }

    private fun handleLegacyEmbedResourceError(generation: Int, url: String?, description: String?) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M || url.isNullOrBlank() || url == "about:blank") return
        onMainFrameError(generation, url, description)
    }

    @android.annotation.TargetApi(Build.VERSION_CODES.M)
    private fun handleEmbedHttpError(
        generation: Int,
        request: android.webkit.WebResourceRequest?,
        errorResponse: android.webkit.WebResourceResponse?
    ) {
        val failedRequest = request ?: return
        val statusCode = errorResponse?.statusCode ?: 0
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && failedRequest.isForMainFrame && statusCode >= 400) {
            onMainFrameError(generation, failedRequest.url.toString(), "HTTP $statusCode")
        }
    }

    private fun shouldBlockNavigation(
        initialHost: String,
        request: android.webkit.WebResourceRequest
    ): Boolean {
        val host = request.url.host.orEmpty()
        val blocked = WebViewNavigationPolicy.shouldBlockTopLevelNavigation(
            initialHost = initialHost,
            requestedHost = host,
            isMainFrame = request.isForMainFrame,
            isRedirect = Build.VERSION.SDK_INT >= Build.VERSION_CODES.N && request.isRedirect
        )
        if (blocked) android.util.Log.d("WebView", "Navegación bloqueada para host $host")
        return blocked
    }

    private fun prepareTvFocusAfterPageLoad() {
        bridge.detectAfterLoad()
        lockWebViewFocus()
        playerView.isFocusable = true
        playerView.requestFocus()
    }

    private fun createEmbedWebChromeClient(): WebChromeClient = object : WebChromeClient() {
        override fun onPermissionRequest(request: android.webkit.PermissionRequest?) {
            request?.deny()
        }

        override fun onShowCustomView(view: View?, callback: WebChromeClient.CustomViewCallback?) {
            val custom = view ?: return
            customView?.let { old -> (old.parent as? ViewGroup)?.removeView(old) }
            customView = custom
            customViewCallback = callback
            (custom.parent as? ViewGroup)?.removeView(custom)
            playerContainer.addView(
                custom,
                FrameLayout.LayoutParams(
                    FrameLayout.LayoutParams.MATCH_PARENT,
                    FrameLayout.LayoutParams.MATCH_PARENT
                )
            )
            custom.bringToFront()
            controlsOverlay.bringToFront()
            bottomControls.bringToFront()
            showControlsTemporarily()
        }

        override fun onHideCustomView() {
            removeCustomView(notifyWebView = true)
            if (!isTV()) showControlsTemporarily()
        }

        override fun onCreateWindow(
            view: WebView?,
            isDialog: Boolean,
            isUserGesture: Boolean,
            resultMsg: android.os.Message?
        ): Boolean {
            android.util.Log.d("WebView", "POPUP BLOQUEADO (isDialog=$isDialog, isUserGesture=$isUserGesture)")
            return false
        }

        override fun onConsoleMessage(consoleMessage: android.webkit.ConsoleMessage?): Boolean {
            if (BuildConfig.DEBUG) {
                android.util.Log.d(
                    "WebView",
                    "Console ${consoleMessage?.sourceId()?.let { StreamUtils.hostForLog(it) } ?: "embed"}:${consoleMessage?.lineNumber()}"
                )
            }
            return true
        }
    }

    private fun rebindLoadedPage(generation: Int) {
        webView.post {
            if (!isCurrentLoad(generation) || currentStreamType() != StreamType.IFRAME) return@post
            webView.evaluateJavascript("javascript:${WebViewScripts.FULLSCREEN}", null)
            progressBar.visibility = View.GONE
            bridge.attach()
            bridge.injectScript()
            if (isTV()) prepareTvFocusAfterPageLoad()
            showControlsTemporarily()
        }
    }

    /** Restores neutral clients before the same WebView is handed back to the inline player. */
    fun resetNavigationHandlers() {
        webView.webViewClient = WebViewClient()
        webView.webChromeClient = WebChromeClient()
    }

    /** Cleans custom fullscreen content and, unless transferred, destroys the WebView. */
    fun dispose(destroyWebView: Boolean) {
        invalidatePendingLoad()
        removeCustomView(notifyWebView = true)
        if (!destroyWebView) return
        webView.apply {
            stopLoading()
            webViewClient = WebViewClient()
            webChromeClient = WebChromeClient()
            loadUrl("about:blank")
            clearHistory()
            onPause()
            removeAllViews()
            destroy()
        }
    }

    private fun removeCustomView(notifyWebView: Boolean) {
        customView?.let { custom -> (custom.parent as? ViewGroup)?.removeView(custom) }
        customView = null
        val callback = customViewCallback
        customViewCallback = null
        if (notifyWebView) callback?.onCustomViewHidden()
    }
}
