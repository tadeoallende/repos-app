package com.angulismotv.player

/** Pure classification for audio-track diagnostics; it does not change playback policy. */
object PlayerAudioDiagnosticPolicy {
    const val UNSUPPORTED_AUDIO_NOTICE =
        "Este canal usa un formato de audio que tu dispositivo no puede reproducir."

    enum class TrackState {
        NO_TRACKS,
        NO_SUPPORTED_TRACKS,
        NO_SELECTED_TRACK,
        READY
    }

    fun classifyTracks(
        audioTrackCount: Int,
        supportedTrackCount: Int,
        selectedTrackCount: Int
    ): TrackState {
        if (audioTrackCount <= 0) return TrackState.NO_TRACKS
        if (supportedTrackCount <= 0) return TrackState.NO_SUPPORTED_TRACKS
        if (selectedTrackCount <= 0) return TrackState.NO_SELECTED_TRACK
        return TrackState.READY
    }

    /**
     * Solo avisamos al usuario cuando hay audio pero ningún decodificador compatible.
     * "Sin pistas" puede ser transitorio en HLS (el audio aparece al leer el primer segmento),
     * así que no justifica un aviso por sí solo.
     */
    fun shouldNotifyUser(state: TrackState): Boolean = state == TrackState.NO_SUPPORTED_TRACKS

    /** Texto corto en español para mostrar al usuario y para capturas de soporte. */
    fun describeState(state: TrackState): String = when (state) {
        TrackState.NO_TRACKS -> "La fuente no expone pistas de audio (o todavía no se detectaron)."
        TrackState.NO_SUPPORTED_TRACKS -> "El canal tiene audio, pero tu dispositivo no puede decodificar ese formato."
        TrackState.NO_SELECTED_TRACK -> "Hay audio compatible, pero no quedó ninguna pista seleccionada."
        TrackState.READY -> "Pista de audio seleccionada. Si no se oye, revisá el volumen y la salida de audio del dispositivo."
    }

    /** Keep logs useful while avoiding exception messages that may contain signed stream URLs. */
    fun causeChain(error: Throwable?, maxDepth: Int = 5): List<String> {
        if (maxDepth <= 0) return emptyList()
        val result = mutableListOf<String>()
        val seen = java.util.Collections.newSetFromMap(java.util.IdentityHashMap<Throwable, Boolean>())
        var current = error
        while (current != null && result.size < maxDepth && seen.add(current)) {
            val item = current
            result += item.javaClass.simpleName.ifBlank { item.javaClass.name }
            current = item.cause
        }
        return result
    }
}
