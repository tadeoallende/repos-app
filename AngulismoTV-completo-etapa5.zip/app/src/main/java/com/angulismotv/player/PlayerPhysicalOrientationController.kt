package com.angulismotv.player

import android.content.Context
import android.os.Handler
import android.view.OrientationEventListener

/**
 * Owns the physical-orientation sensor and debounce used by fullscreen playback on mobile.
 * The Activity decides its requested orientation; this controller only detects a real return
 * to portrait after landscape has been physically observed.
 */
internal class PlayerPhysicalOrientationController(
    private val context: Context,
    private val handler: Handler,
    private val isActivityUnavailable: () -> Boolean,
    private val onReturnToInline: () -> Unit,
    private val debounceMs: Long = DEFAULT_DEBOUNCE_MS
) {
    private val orientationPolicy = FullscreenOrientationPolicy()
    private var listener: OrientationEventListener? = null
    private var exitPending = false
    private var lastOrientationDegrees = OrientationEventListener.ORIENTATION_UNKNOWN

    private val exitAfterPortraitRunnable = Runnable {
        exitPending = false
        if (isActivityUnavailable()) return@Runnable
        if (orientationPolicy.shouldExitToInline(lastOrientationDegrees)) {
            onReturnToInline()
        }
    }

    fun configure(enabledForActivity: Boolean) {
        if (!enabledForActivity || listener != null) return

        val candidate = object : OrientationEventListener(context) {
            override fun onOrientationChanged(orientation: Int) {
                if (isActivityUnavailable()) return
                lastOrientationDegrees = orientation
                when (orientationPolicy.classify(orientation)) {
                    FullscreenOrientationPolicy.Position.PORTRAIT_AFTER_LANDSCAPE -> schedulePortraitExit()
                    // Lecturas intermedias cancelan el cierre hasta que la postura se estabilice.
                    FullscreenOrientationPolicy.Position.LANDSCAPE,
                    FullscreenOrientationPolicy.Position.PORTRAIT_BEFORE_LANDSCAPE,
                    FullscreenOrientationPolicy.Position.TRANSITION,
                    FullscreenOrientationPolicy.Position.UNKNOWN -> cancelPortraitExit()
                }
            }
        }

        if (candidate.canDetectOrientation()) {
            listener = candidate
        } else {
            candidate.disable()
        }
    }

    fun onResume() {
        listener?.enable()
        // No dependemos de un nuevo evento del sensor si ya volvió a vertical durante una pausa.
        if (orientationPolicy.shouldExitToInline(lastOrientationDegrees)) schedulePortraitExit()
    }

    fun onPause() {
        listener?.disable()
        cancelPortraitExit()
    }

    fun dispose() {
        listener?.disable()
        listener = null
        cancelPortraitExit()
    }

    private fun schedulePortraitExit() {
        if (exitPending || isActivityUnavailable()) return
        exitPending = true
        handler.postDelayed(exitAfterPortraitRunnable, debounceMs)
    }

    private fun cancelPortraitExit() {
        handler.removeCallbacks(exitAfterPortraitRunnable)
        exitPending = false
    }

    private companion object {
        const val DEFAULT_DEBOUNCE_MS = 550L
    }
}
