package com.angulismotv.player

import android.os.Handler
import android.view.View
import android.widget.SeekBar
import android.widget.TextView
import com.google.android.exoplayer2.Player

/** Coordinates the native player's seek bar and periodic timeline refresh. */
class PlayerTimelineController(
    private val handler: Handler,
    private val container: View,
    private val seekBar: SeekBar,
    private val currentTime: TextView,
    private val durationTime: TextView,
    private val playerProvider: () -> Player?,
    private val isTimelineEnabled: () -> Boolean,
    private val shouldContinueUpdates: () -> Boolean,
    private val canSeekOnStopTracking: (Player) -> Boolean = { it.isCurrentWindowSeekable && it.duration > 0L }
) {
    private var isUserSeeking = false
    private var updateRunnable: Runnable? = null

    fun onStartTracking() {
        isUserSeeking = true
    }

    fun onProgressChanged(progress: Int, fromUser: Boolean) {
        if (!fromUser) return
        val duration = playerProvider()?.duration ?: return
        currentTime.text = PlayerTimeFormatter.format(duration * progress.toLong() / SEEK_SCALE)
    }

    fun onStopTracking() {
        val player = playerProvider()
        if (player != null && canSeekOnStopTracking(player)) {
            player.seekTo(player.duration * seekBar.progress.toLong() / SEEK_SCALE)
        }
        isUserSeeking = false
        update()
    }

    fun update() {
        if (!isTimelineEnabled()) {
            container.visibility = View.GONE
            return
        }
        val player = playerProvider()
        if (player == null) {
            container.visibility = View.GONE
            return
        }
        val duration = player.duration
        val canSeek = player.playbackState == Player.STATE_READY && player.isCurrentWindowSeekable && duration > 0L
        if (!canSeek) {
            container.visibility = View.GONE
            return
        }

        container.visibility = View.VISIBLE
        seekBar.max = SEEK_SCALE.toInt()
        if (!isUserSeeking) {
            seekBar.progress = ((player.currentPosition.coerceAtLeast(0L) * SEEK_SCALE) / duration)
                .toInt().coerceIn(0, SEEK_SCALE.toInt())
            currentTime.text = PlayerTimeFormatter.format(player.currentPosition)
        }
        durationTime.text = PlayerTimeFormatter.format(duration)
    }

    fun startUpdates() {
        stopUpdates()
        updateRunnable = object : Runnable {
            override fun run() {
                update()
                if (shouldContinueUpdates()) handler.postDelayed(this, UPDATE_INTERVAL_MS)
            }
        }
        handler.post(updateRunnable!!)
    }

    fun stopUpdates() {
        updateRunnable?.let { runnable -> handler.removeCallbacks(runnable) }
        updateRunnable = null
        isUserSeeking = false
    }

    companion object {
        private const val SEEK_SCALE = 1_000L
        private const val UPDATE_INTERVAL_MS = 500L
    }
}
