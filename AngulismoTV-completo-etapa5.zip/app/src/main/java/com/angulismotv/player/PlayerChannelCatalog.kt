package com.angulismotv.player

import com.angulismotv.models.Channel

/**
 * Shares the current channel catalog between Activities in the same app process without putting
 * thousands of Parcelable objects in an Intent (which can exceed Android's Binder transaction limit).
 */
object PlayerChannelCatalog {
    private var generation: Long = 0L
    private var currentChannels: List<Channel> = emptyList()

    @Synchronized
    fun publish(channels: List<Channel>): Long {
        generation += 1L
        currentChannels = channels
        return generation
    }

    @Synchronized
    fun get(token: Long): List<Channel> =
        if (token == generation) currentChannels else emptyList()
}
