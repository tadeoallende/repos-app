package com.angulismotv.player

/**
 * Máquina de estados del zapping: CH+/CH-, selección desde el panel y entrada numérica.
 *
 * No conoce vistas ni el motor de reproducción: la Activity inyecta el temporizador y las dos
 * acciones de cada cambio, lo que permite probarlo en JVM con un temporizador falso.
 *
 * Un cambio de canal tiene dos pasos separados por [START_DELAY_MS]:
 * 1. [onTransitionStarted]: detener lo actual y mostrar el overlay.
 * 2. [onChannelApplied]: fijar el canal nuevo e iniciar su reproducción.
 * Hasta [RESET_DELAY_MS] después del paso 2 se sigue "zapeando": las pulsaciones nuevas se
 * acumulan y se aplican juntas al terminar, en lugar de solapar recargas del player.
 *
 * @param T tipo de canal; se captura al iniciar el cambio para no depender de que el catálogo no varíe.
 */
internal class PlayerZappingController<T : Any>(
    private val schedule: (Runnable, Long) -> Unit,
    private val cancel: (Runnable) -> Unit,
    private val channelCount: () -> Int,
    private val channelAt: (Int) -> T?,
    private val currentIndex: () -> Int,
    private val onTransitionStarted: (T) -> Unit,
    private val onChannelApplied: (index: Int, channel: T) -> Unit
) {
    var isZapping: Boolean = false
        private set

    private val pending = ChannelZapAccumulator()
    private var applyRunnable: Runnable? = null
    private var releaseRunnable: Runnable? = null

    /** Avanza o retrocede [delta] canales con vuelta al inicio/final del catálogo. */
    fun changeChannel(delta: Int) {
        val count = channelCount()
        if (count <= 0) {
            pending.clear()
            return
        }
        if (isZapping) {
            pending.accumulate(delta)
            return
        }
        val target = (currentIndex() + delta).mod(count)
        val channel = channelAt(target) ?: return
        zapTo(target, channel)
    }

    fun zapTo(index: Int, channel: T) {
        cancelPendingTimers()
        pending.clear()
        isZapping = true
        onTransitionStarted(channel)
        scheduleApply(index, channel)
    }

    /** Recarga manual: cancela la transición en curso y descarta pulsaciones acumuladas. */
    fun reset() {
        cancelPendingTimers()
        pending.clear()
        isZapping = false
    }

    /** Cancela solo el paso 2 pendiente (la Activity está devolviendo la sesión al mini-player). */
    fun cancelScheduledApply() {
        applyRunnable?.let(cancel)
        applyRunnable = null
    }

    fun dispose() {
        cancelPendingTimers()
        pending.clear()
    }

    private fun cancelPendingTimers() {
        releaseRunnable?.let(cancel)
        releaseRunnable = null
        applyRunnable?.let(cancel)
        applyRunnable = null
    }

    private fun scheduleApply(index: Int, channel: T) {
        val apply = Runnable {
            applyRunnable = null
            onChannelApplied(index, channel)
            releaseRunnable?.let(cancel)
            val release = Runnable {
                releaseRunnable = null
                isZapping = false
                dispatchPending()
            }
            releaseRunnable = release
            schedule(release, RESET_DELAY_MS)
        }
        applyRunnable = apply
        schedule(apply, START_DELAY_MS)
    }

    private fun dispatchPending() {
        if (isZapping) return
        val delta = pending.consume()
        if (delta == 0 || channelCount() <= 0) return
        changeChannel(delta)
    }

    companion object {
        const val START_DELAY_MS = 300L
        const val RESET_DELAY_MS = 200L
    }
}
