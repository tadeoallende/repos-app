package com.angulismotv.player

import android.view.KeyEvent
import com.angulismotv.R
import com.angulismotv.models.StreamType

/** Routes Android TV remote/media keys without owning Activity state or views. */
internal class PlayerRemoteKeyRouter(
    private val isPanelOpen: () -> Boolean,
    private val areControlsVisible: () -> Boolean,
    private val isZapping: () -> Boolean,
    private val streamType: () -> String,
    private val hasPendingChannelNumber: () -> Boolean,
    private val focusedViewId: () -> Int,
    private val isRightPanelFocused: () -> Boolean,
    private val actions: Actions
) {
    data class Actions(
        val appendChannelNumberDigit: (Int) -> Unit,
        val commitChannelNumberInput: () -> Unit,
        val handlePanelBack: () -> Boolean,
        val hideControls: () -> Unit,
        val finishActivity: () -> Unit,
        val handlePanelVerticalFocus: (Int) -> Boolean,
        val navigateControlsUp: () -> Unit,
        val navigateControlsDown: () -> Unit,
        val navigateControlsLeft: () -> Unit,
        val navigateControlsRight: () -> Unit,
        val changeChannel: (Int) -> Unit,
        val moveFocusToCategoriesPanel: () -> Unit,
        val closeSidePanel: () -> Unit,
        val openSidePanel: () -> Unit,
        val activateSearchMode: () -> Unit,
        val moveFocusToChannelsList: () -> Unit,
        val showControls: () -> Unit,
        val activateFocusedControl: () -> Unit,
        val controlWebPlayer: (String) -> Unit,
        val toggleNativePlayback: () -> Unit,
        val playNativePlayback: () -> Unit,
        val pauseNativePlayback: () -> Unit,
        val clickForward: () -> Unit,
        val clickRewind: () -> Unit
    )

    fun digitForKey(keyCode: Int): Int = when {
        keyCode in KeyEvent.KEYCODE_0..KeyEvent.KEYCODE_9 -> keyCode - KeyEvent.KEYCODE_0
        keyCode in KeyEvent.KEYCODE_NUMPAD_0..KeyEvent.KEYCODE_NUMPAD_9 -> keyCode - KeyEvent.KEYCODE_NUMPAD_0
        else -> -1
    }

    fun handleKey(keyCode: Int): Boolean {
        if (!isPanelOpen()) {
            val digit = digitForKey(keyCode)
            if (digit >= 0) {
                actions.appendChannelNumberDigit(digit)
                return true
            }
        }

        return when (keyCode) {
            KeyEvent.KEYCODE_BACK -> handleBack()
            KeyEvent.KEYCODE_DPAD_UP -> handleVerticalKey(up = true, keyCode = keyCode)
            KeyEvent.KEYCODE_DPAD_DOWN -> handleVerticalKey(up = false, keyCode = keyCode)
            KeyEvent.KEYCODE_DPAD_LEFT -> handleLeft()
            KeyEvent.KEYCODE_DPAD_RIGHT -> handleRight()
            KeyEvent.KEYCODE_DPAD_CENTER,
            KeyEvent.KEYCODE_ENTER,
            KeyEvent.KEYCODE_NUMPAD_ENTER -> handleConfirm()
            KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE -> {
                if (streamType() == StreamType.IFRAME) actions.controlWebPlayer("toggle")
                else actions.toggleNativePlayback()
                true
            }
            KeyEvent.KEYCODE_MEDIA_PLAY -> {
                if (streamType() == StreamType.IFRAME) actions.controlWebPlayer("play")
                else actions.playNativePlayback()
                true
            }
            KeyEvent.KEYCODE_MEDIA_PAUSE -> {
                if (streamType() == StreamType.IFRAME) actions.controlWebPlayer("pause")
                else actions.pauseNativePlayback()
                true
            }
            KeyEvent.KEYCODE_MEDIA_FAST_FORWARD -> {
                actions.clickForward()
                true
            }
            KeyEvent.KEYCODE_MEDIA_REWIND -> {
                actions.clickRewind()
                true
            }
            else -> false
        }
    }

    private fun handleBack(): Boolean = when {
        isPanelOpen() -> actions.handlePanelBack()
        areControlsVisible() -> {
            actions.hideControls()
            true
        }
        else -> {
            actions.finishActivity()
            true
        }
    }

    private fun handleVerticalKey(up: Boolean, keyCode: Int): Boolean = when {
        isPanelOpen() -> actions.handlePanelVerticalFocus(keyCode)
        areControlsVisible() -> {
            if (up) actions.navigateControlsUp() else actions.navigateControlsDown()
            true
        }
        !isZapping() -> {
            actions.changeChannel(if (up) -1 else 1)
            true
        }
        else -> true
    }

    private fun handleLeft(): Boolean = when {
        isPanelOpen() -> {
            if (isRightPanelFocused()) actions.moveFocusToCategoriesPanel()
            else actions.closeSidePanel()
            true
        }
        areControlsVisible() -> {
            actions.navigateControlsLeft()
            true
        }
        else -> {
            // The Activity decides whether the panel can be opened on the current device.
            actions.openSidePanel()
            true
        }
    }

    private fun handleRight(): Boolean = when {
        isPanelOpen() -> when {
            focusedViewId() == R.id.btn_search_trigger -> {
                actions.activateSearchMode()
                true
            }
            focusedViewId() == R.id.btn_close_panel -> {
                actions.closeSidePanel()
                true
            }
            !isRightPanelFocused() -> {
                actions.moveFocusToChannelsList()
                true
            }
            else -> {
                actions.closeSidePanel()
                true
            }
        }
        areControlsVisible() -> {
            actions.navigateControlsRight()
            true
        }
        else -> {
            actions.showControls()
            true
        }
    }

    private fun handleConfirm(): Boolean = when {
        hasPendingChannelNumber() && !isPanelOpen() -> {
            actions.commitChannelNumberInput()
            true
        }
        isPanelOpen() -> false
        !areControlsVisible() -> {
            actions.showControls()
            true
        }
        else -> {
            actions.activateFocusedControl()
            true
        }
    }
}
