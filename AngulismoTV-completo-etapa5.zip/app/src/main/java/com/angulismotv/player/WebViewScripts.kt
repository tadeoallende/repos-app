package com.angulismotv.player

/**
 * Scripts JavaScript que se inyectan en el WebView de los embeds (iframes).
 * Se mantienen acá, separados de la lógica de la pantalla del reproductor.
 */
object WebViewScripts {

    /** Nombre del objeto JS expuesto por la app (también usado por [BRIDGE]). */
    const val BRIDGE_NAME = "AndroidWebViewBridge"

    /** Consulta el estado actual del reproductor detectado dentro del embed. */
    const val GET_STATE = "AndroidWebViewBridge.getState();"

    /** Detecta y controla reproductores Bitmovin dentro del iframe. */
    const val BRIDGE = """
        (function() {
            console.log('Android WebView Bridge: Iniciando para Bitmovin...');
            
            // Variable para guardar la instancia de Bitmovin
            var bitmovinPlayer = null;
            var isBitmovinPlayer = false;
            
            // Función para detectar Bitmovin Player
            function detectBitmovinPlayer() {
                try {
                    // Buscar el contenedor del player
                    var playerContainer = document.getElementById('player');
                    if (!playerContainer) {
                        // Buscar cualquier elemento que pueda contener Bitmovin
                        var containers = document.querySelectorAll('[class*="bmpui"]');
                        if (containers.length > 0) {
                            playerContainer = containers[0];
                        }
                    }
                    
                    if (!playerContainer) return null;
                    
                    // Buscar la instancia de Bitmovin en el objeto window
                    // Bitmovin normalmente se guarda en window.player o window.bitmovin
                    if (window.player && typeof window.player.play === 'function') {
                        bitmovinPlayer = window.player;
                        isBitmovinPlayer = true;
                        console.log('Bitmovin Player detectado en window.player');
                        return bitmovinPlayer;
                    }
                    
                    // Buscar en otras ubicaciones comunes
                    if (window.bitmovin && typeof window.bitmovin.play === 'function') {
                        bitmovinPlayer = window.bitmovin;
                        isBitmovinPlayer = true;
                        console.log('Bitmovin Player detectado en window.bitmovin');
                        return bitmovinPlayer;
                    }
                    
                    // Intentar obtener la instancia desde el contenedor
                    if (playerContainer.bitmovin && typeof playerContainer.bitmovin.play === 'function') {
                        bitmovinPlayer = playerContainer.bitmovin;
                        isBitmovinPlayer = true;
                        console.log('Bitmovin Player detectado en contenedor');
                        return bitmovinPlayer;
                    }
                    
                    return null;
                } catch(e) {
                    console.log('Error detectando Bitmovin:', e);
                    return null;
                }
            }
            
            // Función para esperar a que Bitmovin esté listo
            function waitForBitmovin(callback, attempts) {
                attempts = attempts || 0;
                if (attempts > 30) {
                    console.log('Bitmovin no detectado después de 30 intentos');
                    window.AndroidWebViewBridge?.onPlayerDetected(false);
                    return;
                }
                
                var player = detectBitmovinPlayer();
                if (player) {
                    console.log('Bitmovin Player encontrado!');
                    callback(player);
                    return;
                }
                
                console.log('Esperando Bitmovin... intento ' + (attempts + 1));
                setTimeout(function() {
                    waitForBitmovin(callback, attempts + 1);
                }, 500);
            }
            
            // Crear el bridge
            if (!window.AndroidWebViewBridge) {
                window.AndroidWebViewBridge = {
                    // Control de reproducción para Bitmovin
                    play: function() {
                        if (bitmovinPlayer && bitmovinPlayer.play) {
                            bitmovinPlayer.play();
                            return true;
                        }
                        return false;
                    },
                    pause: function() {
                        if (bitmovinPlayer && bitmovinPlayer.pause) {
                            bitmovinPlayer.pause();
                            return true;
                        }
                        return false;
                    },
                    togglePlayPause: function() {
                        if (bitmovinPlayer) {
                            if (bitmovinPlayer.isPlaying && bitmovinPlayer.isPlaying()) {
                                bitmovinPlayer.pause();
                            } else {
                                bitmovinPlayer.play();
                            }
                            return true;
                        }
                        return false;
                    },
                    seekTo: function(seconds) {
                        if (bitmovinPlayer && bitmovinPlayer.seek) {
                            bitmovinPlayer.seek(seconds);
                            return true;
                        }
                        return false;
                    },
                    getCurrentTime: function() {
                        if (bitmovinPlayer && bitmovinPlayer.getCurrentTime) {
                            return bitmovinPlayer.getCurrentTime();
                        }
                        return 0;
                    },
                    getDuration: function() {
                        if (bitmovinPlayer && bitmovinPlayer.getDuration) {
                            return bitmovinPlayer.getDuration();
                        }
                        return 0;
                    },
                    isPlaying: function() {
                        if (bitmovinPlayer && bitmovinPlayer.isPlaying) {
                            return bitmovinPlayer.isPlaying();
                        }
                        return false;
                    },
                    getState: function() {
                        try {
                            var playing = false;
                            var currentTime = 0;
                            var duration = 0;
                            var detected = false;
                            
                            if (bitmovinPlayer) {
                                detected = true;
                                if (bitmovinPlayer.isPlaying) {
                                    playing = bitmovinPlayer.isPlaying();
                                }
                                if (bitmovinPlayer.getCurrentTime) {
                                    currentTime = bitmovinPlayer.getCurrentTime();
                                }
                                if (bitmovinPlayer.getDuration) {
                                    duration = bitmovinPlayer.getDuration();
                                }
                            }
                            
                            return JSON.stringify({
                                playing: playing,
                                currentTime: currentTime,
                                duration: duration,
                                detected: detected,
                                isBitmovin: isBitmovinPlayer
                            });
                        } catch(e) {
                            return JSON.stringify({
                                playing: false,
                                currentTime: 0,
                                duration: 0,
                                detected: false,
                                isBitmovin: false
                            });
                        }
                    }
                };
                console.log('Android WebView Bridge: Bridge creado para Bitmovin');
            }
            
            // Configurar monitoreo de eventos para Bitmovin
            function setupBitmovinMonitoring(player) {
                console.log('Configurando monitoreo de eventos Bitmovin');
                
                // Evento cuando el player está listo
                player.on('ready', function() {
                    console.log('Bitmovin: Evento READY');
                    window.AndroidWebViewBridge?.onPlayerDetected(true);
                    // Enviar estado inicial
                    window.AndroidWebViewBridge?.onPlayStateChanged(player.isPlaying());
                    window.AndroidWebViewBridge?.onDurationChanged(player.getDuration());
                });
                
                // Evento de reproducción
                player.on('playing', function() {
                    console.log('Bitmovin: Evento PLAYING');
                    window.AndroidWebViewBridge?.onPlayStateChanged(true);
                });
                
                // Evento de pausa
                player.on('paused', function() {
                    console.log('Bitmovin: Evento PAUSED');
                    window.AndroidWebViewBridge?.onPlayStateChanged(false);
                });
                
                // Evento de fin
                player.on('finished', function() {
                    console.log('Bitmovin: Evento FINISHED');
                    window.AndroidWebViewBridge?.onPlayStateChanged(false);
                });
                
                // Evento de error
                player.on('error', function(error) {
                    console.log('Bitmovin: Evento ERROR', error);
                });
                
                // Monitoreo de tiempo (cada segundo)
                setInterval(function() {
                    if (player && player.getCurrentTime) {
                        window.AndroidWebViewBridge?.onTimeUpdate(
                            player.getCurrentTime(),
                            player.getDuration() || 0
                        );
                    }
                }, 1000);
            }
            
            // Inicializar
            function initialize() {
                console.log('Android WebView Bridge: Inicializando para Bitmovin...');
                
                waitForBitmovin(function(player) {
                    bitmovinPlayer = player;
                    isBitmovinPlayer = true;
                    setupBitmovinMonitoring(player);
                    
                    // Notificar que se detectó el reproductor
                    window.AndroidWebViewBridge?.onPlayerDetected(true);
                    
                    // Enviar estado inicial
                    setTimeout(function() {
                        window.AndroidWebViewBridge?.onPlayStateChanged(player.isPlaying());
                        window.AndroidWebViewBridge?.onDurationChanged(player.getDuration());
                    }, 500);
                });
            }
            
            // Ejecutar cuando la página esté lista
            if (document.readyState === 'complete') {
                initialize();
            } else {
                window.addEventListener('load', function() {
                    setTimeout(initialize, 1000);
                });
            }
            
            console.log('Android WebView Bridge: Script de inicialización completado para Bitmovin');
        })();
"""

    /** CSS/JS para forzar el video a pantalla completa dentro del WebView. */
    const val FULLSCREEN = """(function(){
            var s=document.createElement('style');
            s.innerHTML='*{margin:0!important;padding:0!important;box-sizing:border-box!important}'
            +'html,body{width:100%!important;height:100%!important;background:#000!important;overflow:hidden!important}'
            +'body{display:flex!important;align-items:center!important;justify-content:center!important}'
            +'iframe,video,embed,object{position:fixed!important;top:0!important;left:0!important;'
            +'width:100vw!important;height:100vh!important;object-fit:contain!important}';
            document.head.appendChild(s);
            function fix(){document.querySelectorAll('iframe,video,embed').forEach(function(e){
            e.style.cssText+='position:fixed!important;top:0!important;left:0!important;'
            +'width:100%!important;height:100%!important;object-fit:contain!important'});}
            fix();new MutationObserver(fix).observe(document.body,{childList:true,subtree:true});
        })();"""
}
