package com.angulismotv.player

import android.app.Activity
import androidx.appcompat.app.AlertDialog

/**
 * Diálogos del reproductor a pantalla completa. Mantiene la referencia al diálogo abierto para
 * evitar duplicados y poder cerrarlo si la Activity se destruye (evita WindowLeaked).
 */
internal class PlayerDialogController(private val activity: Activity) {
    private var active: AlertDialog? = null

    fun showSourceOptions(
        channelName: String,
        optionNames: List<String>,
        onSelected: (index: Int) -> Unit,
        onCancelled: () -> Unit
    ) {
        show(
            AlertDialog.Builder(activity)
                .setTitle("Seleccionar fuente — $channelName")
                .setItems(optionNames.toTypedArray()) { _, which -> onSelected(which) }
                .setNegativeButton("Cancelar") { _, _ -> onCancelled() }
                .setCancelable(true)
        )
    }

    /** Muestra el informe de audio para compartirlo con una captura de pantalla. */
    fun showAudioInfo(report: String) {
        show(
            AlertDialog.Builder(activity)
                .setTitle("Info de audio")
                .setMessage(report)
                .setPositiveButton("Cerrar", null)
        )
    }

    fun dismiss() {
        active?.dismiss()
        active = null
    }

    private fun show(builder: AlertDialog.Builder) {
        if (activity.isFinishing || activity.isDestroyed) return
        active?.dismiss()
        val dialog = builder.create()
        dialog.setOnDismissListener { if (active === dialog) active = null }
        active = dialog
        dialog.show()
    }
}
