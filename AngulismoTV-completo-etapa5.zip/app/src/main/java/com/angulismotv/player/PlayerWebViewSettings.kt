package com.angulismotv.player

import android.annotation.SuppressLint
import android.view.View
import android.webkit.WebSettings
import android.webkit.WebView
import com.angulismotv.BuildConfig

/** Configuración del WebView que aloja los embeds (iframes) del reproductor. */
@SuppressLint("SetJavaScriptEnabled")
fun WebView.applyPlayerSettings() {
    settings.apply {
        javaScriptEnabled = true // necesario: los embeds son reproductores web
        domStorageEnabled = true
        mediaPlaybackRequiresUserGesture = false
        setSupportZoom(false)
        builtInZoomControls = false
        displayZoomControls = false
        loadWithOverviewMode = true
        useWideViewPort = true
        // Los embeds no necesitan acceder al almacenamiento local de la app
        allowFileAccess = false
        allowContentAccess = false
        databaseEnabled = true
        mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
        javaScriptCanOpenWindowsAutomatically = false
        setSupportMultipleWindows(false)
    }
    // Inspección remota (chrome://inspect) solo en builds de debug
    WebView.setWebContentsDebuggingEnabled(BuildConfig.DEBUG)
    setLayerType(View.LAYER_TYPE_HARDWARE, null)
}
