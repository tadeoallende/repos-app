package com.angulismotv.player

import java.net.URI
import java.util.Locale

/** Restricts Agenda's top-level WebView navigations to the app's owned HTTPS origins. */
object AgendaNavigationPolicy {
    private val builtInAllowedHosts = setOf(
        "angulismotv.pages.dev",
        "angulismotv-dnh.pages.dev",
        "angulismotv.workers.dev"
    )

    fun isAllowedMainFrameUrl(value: String?, configuredBaseUrl: String? = null): Boolean {
        if (value.isNullOrBlank()) return false
        val uri = runCatching { URI(value.trim()) }.getOrNull() ?: return false
        if (!uri.scheme.equals("https", ignoreCase = true)) return false
        val host = uri.host?.lowercase(Locale.ROOT)?.removeSuffix(".") ?: return false

        val allowedHosts = builtInAllowedHosts + parseHttpsHost(configuredBaseUrl).orEmpty()
        return allowedHosts.any { host == it || host.endsWith(".$it") }
    }

    private fun parseHttpsHost(value: String?): String? {
        if (value.isNullOrBlank()) return null
        val uri = runCatching { URI(value.trim()) }.getOrNull() ?: return null
        if (!uri.scheme.equals("https", ignoreCase = true)) return null
        return uri.host?.lowercase(Locale.ROOT)?.removeSuffix(".")
    }
}
