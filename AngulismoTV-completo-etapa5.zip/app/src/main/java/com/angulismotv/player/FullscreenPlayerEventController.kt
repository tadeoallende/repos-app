package com.angulismotv.player

import android.view.View
import android.widget.ProgressBar
import android.widget.TextView
import com.google.android.exoplayer2.C
import com.google.android.exoplayer2.ExoPlayer
import com.google.android.exoplayer2.PlaybackException
import com.google.android.exoplayer2.Player
import com.google.android.exoplayer2.Tracks

/**
 * Owns fullscreen ExoPlayer event wiring and state/error reactions.
 * Creating/releasing the player, choosing the stream, and navigating UI remain outside this class.
 */
internal class FullscreenPlayerEventController(
    private val currentGeneration: () -> Int,
    private val currentPlayer: () -> ExoPlayer?,
    private val isZapping: () -> Boolean,
    private val isTV: () -> Boolean,
    private val progressBar: ProgressBar,
    private val errorText: TextView,
    private val recovery: PlaybackRecoveryController,
    private val onPlayStateChanged: (Boolean) -> Unit,
    private val updateControlsVisibility: () -> Unit,
    private val showControlsTemporarily: () -> Unit,
    private val startTimelineUpdates: () -> Unit,
    private val cancelOptionFallback: () -> Unit,
    private val onLiveStatusChanged: (currentWindowLive: Boolean, streamLive: Boolean) -> Unit,
    private val isStreamLive: () -> Boolean,
    private val onAudioSummary: (PlayerAudioDiagnostics.AudioSummary) -> Unit = {},
    private val onPlaybackErrorDiagnostic: (description: String, url: String) -> Unit = { _, _ -> }
) {
    private var listener: Player.Listener? = null
    private var listenerOwner: ExoPlayer? = null

    fun attach(player: ExoPlayer, url: String, type: String, generation: Int) {
        detachListener()
        val newListener = object : Player.Listener {
            override fun onPlaybackStateChanged(state: Int) {
                handleStateIfCurrent(player, url, type, generation, state)
            }

            override fun onIsPlayingChanged(isPlaying: Boolean) {
                if (!isCurrent(player, generation)) return
                if (isPlaying) recovery.scheduleStablePlaybackReset(generation)
                else recovery.cancelStablePlaybackTimer()
                onPlayStateChanged(isPlaying)
            }

            override fun onPlayWhenReadyChanged(playWhenReady: Boolean, reason: Int) {
                if (!isCurrent(player, generation)) return
                if (playWhenReady && player.playbackState != Player.STATE_IDLE &&
                    player.playbackState != Player.STATE_ENDED
                ) {
                    recovery.startWatchdog(generation)
                } else {
                    recovery.stopWatchdog()
                    recovery.cancelStablePlaybackTimer()
                }
            }

            override fun onTracksChanged(tracks: Tracks) {
                if (!isCurrent(player, generation)) return
                onAudioSummary(PlayerAudioDiagnostics.logTracks("fullscreen", tracks, type, url))
            }

            override fun onPlayerError(error: PlaybackException) {
                if (!isCurrent(player, generation) || isZapping()) return
                onPlaybackErrorDiagnostic(
                    PlayerAudioDiagnostics.logPlaybackError("fullscreen", type, url, error),
                    url
                )
                handlePlayerError(url, type, generation, error)
            }
        }
        listener = newListener
        listenerOwner = player
        player.addListener(newListener)
    }

    /** Applies the already-current state after a transferred player is attached. */
    fun handleCurrentState(player: ExoPlayer, url: String, type: String, generation: Int, state: Int) {
        handleStateIfCurrent(player, url, type, generation, state)
    }

    fun clearStableStreamTimer() {
        recovery.cancelStablePlaybackTimer()
    }

    /** Detaches callbacks without releasing the player, which may be transferred to the inline view. */
    fun detachListener() {
        val oldListener = listener
        val oldOwner = listenerOwner
        if (oldListener != null && oldOwner != null) {
            runCatching { oldOwner.removeListener(oldListener) }
        }
        listener = null
        listenerOwner = null
    }

    fun dispose() {
        clearStableStreamTimer()
        detachListener()
    }

    private fun isCurrent(player: ExoPlayer, generation: Int): Boolean =
        currentGeneration() == generation && currentPlayer() === player

    private fun handleStateIfCurrent(
        player: ExoPlayer,
        url: String,
        type: String,
        generation: Int,
        state: Int
    ) {
        if (!isCurrent(player, generation)) return
        when (state) {
            Player.STATE_BUFFERING -> {
                recovery.cancelStablePlaybackTimer()
                progressBar.visibility = View.VISIBLE
                errorText.visibility = View.GONE
            }

            Player.STATE_READY -> {
                progressBar.visibility = View.GONE
                errorText.visibility = View.GONE
                if (player.isPlaying) recovery.cancelPendingReconnect()
                val currentWindowLive = player.isCurrentWindowLive
                onLiveStatusChanged(currentWindowLive, currentWindowLive || player.duration == -1L)
                if (player.isPlaying) recovery.scheduleStablePlaybackReset(generation)
                updateControlsVisibility()
                if (!isTV()) {
                    showControlsTemporarily()
                    startTimelineUpdates()
                }
                cancelOptionFallback()
                if (player.playWhenReady) recovery.startWatchdog(generation)
                else recovery.stopWatchdog()
            }

            Player.STATE_ENDED -> {
                clearStableStreamTimer()
                recovery.stopWatchdog()
                // Do not restart finite HLS/DASH VOD automatically when it reaches its end.
                if (player.isCurrentWindowLive || player.duration == C.TIME_UNSET || isStreamLive()) {
                    progressBar.visibility = View.VISIBLE
                    errorText.visibility = View.GONE
                    recovery.scheduleReconnect(url, type, generation)
                }
            }

            else -> Unit
        }
    }

    private fun handlePlayerError(url: String, type: String, generation: Int, error: PlaybackException) {
        clearStableStreamTimer()
        recovery.stopWatchdog()
        progressBar.visibility = View.VISIBLE
        errorText.visibility = View.GONE
        recovery.scheduleReconnect(url, type, generation, error)
    }

}
