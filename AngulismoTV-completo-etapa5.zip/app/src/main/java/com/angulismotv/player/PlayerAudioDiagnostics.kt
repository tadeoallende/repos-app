package com.angulismotv.player

import android.os.Build
import android.util.Log
import com.google.android.exoplayer2.C
import com.google.android.exoplayer2.PlaybackException
import com.google.android.exoplayer2.Tracks

/** Shared, privacy-conscious diagnostics for native playback on inline and fullscreen surfaces. */
object PlayerAudioDiagnostics {
    private const val TAG = "PlayerAudio"

    /** Una pista de audio tal como la reporta ExoPlayer. */
    data class AudioTrackInfo(
        val selected: Boolean,
        val support: String,
        val mime: String?,
        val codecs: String?,
        val channels: Int,
        val sampleRate: Int
    )

    /** Resultado del análisis de pistas: estado clasificado + detalle por pista. */
    data class AudioSummary(
        val state: PlayerAudioDiagnosticPolicy.TrackState,
        val tracks: List<AudioTrackInfo>
    )

    fun summarize(tracks: Tracks): AudioSummary {
        val infos = mutableListOf<AudioTrackInfo>()
        var supportedCount = 0
        var selectedCount = 0
        tracks.groups.forEach { group ->
            if (group.type != C.TRACK_TYPE_AUDIO) return@forEach
            for (trackIndex in 0 until group.length) {
                val selected = group.isTrackSelected(trackIndex)
                val support = group.getTrackSupport(trackIndex)
                if (support == C.FORMAT_HANDLED || support == C.FORMAT_EXCEEDS_CAPABILITIES) supportedCount++
                if (selected) selectedCount++
                val format = group.getTrackFormat(trackIndex)
                infos += AudioTrackInfo(
                    selected = selected,
                    support = supportLabel(support),
                    mime = format.sampleMimeType,
                    codecs = format.codecs,
                    channels = format.channelCount,
                    sampleRate = format.sampleRate
                )
            }
        }
        return AudioSummary(
            PlayerAudioDiagnosticPolicy.classifyTracks(infos.size, supportedCount, selectedCount),
            infos
        )
    }

    fun logTracks(surface: String, tracks: Tracks, type: String, url: String): AudioSummary {
        val summary = summarize(tracks)
        summary.tracks.forEachIndexed { index, info ->
            Log.i(
                TAG,
                "surface=$surface, type=$type, track=$index, selected=${info.selected}, " +
                    "support=${info.support}, mime=${info.mime}, codecs=${info.codecs}, " +
                    "channels=${info.channels}, sampleRate=${info.sampleRate}"
            )
        }

        val host = StreamUtils.hostForLog(url)
        when (summary.state) {
            PlayerAudioDiagnosticPolicy.TrackState.NO_TRACKS ->
                Log.w(TAG, "surface=$surface, state=no_audio_tracks, type=$type, host=$host")
            PlayerAudioDiagnosticPolicy.TrackState.NO_SUPPORTED_TRACKS ->
                Log.w(TAG, "surface=$surface, state=no_supported_audio_track, type=$type, host=$host")
            PlayerAudioDiagnosticPolicy.TrackState.NO_SELECTED_TRACK ->
                Log.w(TAG, "surface=$surface, state=no_selected_audio_track, type=$type, host=$host")
            PlayerAudioDiagnosticPolicy.TrackState.READY ->
                Log.d(TAG, "surface=$surface, state=audio_track_selected, type=$type, host=$host")
        }
        return summary
    }

    /** Registra el error y devuelve un resumen corto (sin mensajes ni URLs) para mostrarlo en pantalla. */
    fun logPlaybackError(surface: String, type: String, url: String, error: PlaybackException): String {
        val causes = PlayerAudioDiagnosticPolicy.causeChain(error.cause).joinToString(" -> ")
            .ifBlank { "none" }
        Log.e(
            TAG,
            "surface=$surface, playback_error=${error.errorCodeName}, errorCode=${error.errorCode}, " +
                "type=$type, host=${StreamUtils.hostForLog(url)}, causeChain=$causes"
        )
        if (causes.contains("DecoderInitializationException") ||
            causes.contains("AudioSink") || causes.contains("AudioTrack")) {
            Log.w(TAG, "surface=$surface, audio_path_failure_suspected=true, type=$type")
        }
        return "${error.errorCodeName} ($causes)"
    }

    /**
     * Texto para el panel "Info de audio". Pensado para que el usuario lo copie con una captura:
     * incluye modelo y versión de Android, pero nunca la URL completa del stream.
     */
    fun formatReport(
        channelName: String?,
        type: String,
        url: String,
        summary: AudioSummary?,
        lastError: String?
    ): String = buildString {
        appendLine("Dispositivo: ${Build.MANUFACTURER} ${Build.MODEL} · Android ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})")
        if (!channelName.isNullOrBlank()) appendLine("Canal: $channelName")
        appendLine("Fuente: $type · ${StreamUtils.hostForLog(url)}")
        appendLine()
        if (summary == null) {
            appendLine("Todavía no hay información de pistas para esta fuente.")
        } else {
            appendLine(PlayerAudioDiagnosticPolicy.describeState(summary.state))
            summary.tracks.forEachIndexed { index, info ->
                appendLine()
                appendLine("Pista ${index + 1}: ${info.codecs ?: info.mime ?: "formato desconocido"}")
                appendLine("  MIME: ${info.mime ?: "—"}")
                appendLine("  Canales: ${info.channels.takeIf { it > 0 } ?: "—"} · Frecuencia: ${info.sampleRate.takeIf { it > 0 }?.let { "$it Hz" } ?: "—"}")
                appendLine("  Soporte: ${info.support} · Seleccionada: ${if (info.selected) "sí" else "no"}")
            }
        }
        if (!lastError.isNullOrBlank()) {
            appendLine()
            appendLine("Último error: $lastError")
        }
    }.trimEnd()

    private fun supportLabel(support: Int): String = when (support) {
        C.FORMAT_HANDLED -> "handled"
        C.FORMAT_EXCEEDS_CAPABILITIES -> "exceeds_capabilities"
        C.FORMAT_UNSUPPORTED_SUBTYPE -> "unsupported_subtype"
        C.FORMAT_UNSUPPORTED_TYPE -> "unsupported_type"
        else -> "unknown_$support"
    }
}
