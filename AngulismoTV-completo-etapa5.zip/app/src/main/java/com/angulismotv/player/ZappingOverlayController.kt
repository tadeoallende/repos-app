package com.angulismotv.player

import android.view.View
import android.widget.ImageView
import android.widget.LinearLayout
import com.angulismotv.models.Channel
import com.angulismotv.utils.loadChannelLogo

/** Muestra brevemente la identidad del canal durante el zapping, sin capturar el foco. */
internal class ZappingOverlayController(
    private val overlay: LinearLayout?,
    private val logo: ImageView?
) {
    private val hideRunnable = Runnable { overlay?.visibility = View.GONE }

    fun show(channel: Channel) {
        val view = overlay ?: return
        view.visibility = View.VISIBLE
        // Se mantiene por encima de los controles visibles.
        view.bringToFront()
        logo?.loadChannelLogo(channel.name, channel.logo)
        view.removeCallbacks(hideRunnable)
        view.postDelayed(hideRunnable, HIDE_DELAY_MS)
    }

    fun dispose() {
        overlay?.removeCallbacks(hideRunnable)
    }

    private companion object {
        const val HIDE_DELAY_MS = 2_000L
    }
}
