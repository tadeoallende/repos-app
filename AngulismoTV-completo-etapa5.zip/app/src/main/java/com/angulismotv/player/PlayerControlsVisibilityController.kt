package com.angulismotv.player

/**
 * Estado de visibilidad de los controles del reproductor y su temporizador de auto-ocultado.
 *
 * Los efectos sobre vistas (animaciones, foco, línea de tiempo) los aporta la Activity en
 * [onReveal] y [onHide]. El estado [isVisible] se actualiza antes de invocarlos porque el foco
 * y la línea de tiempo lo consultan. El temporizador se inyecta para poder probarlo en JVM.
 */
internal class PlayerControlsVisibilityController(
    private val schedule: (Runnable, Long) -> Unit,
    private val cancel: (Runnable) -> Unit,
    private val isSidePanelOpen: () -> Boolean,
    private val onReveal: (temporarily: Boolean) -> Unit,
    private val onHide: () -> Unit,
    private val autoHideDelayMs: Long = DEFAULT_AUTO_HIDE_MS
) {
    var isVisible: Boolean = false
        private set

    private var hideRunnable: Runnable? = null

    /** Muestra los controles y lleva el foco a ellos (mando de TV). */
    fun show() = reveal(temporarily = false)

    /** Muestra los controles sin robar el foco (toque en móvil o error de reproducción). */
    fun showTemporarily() = reveal(temporarily = true)

    fun toggleTemporarily() {
        if (isVisible) hide() else showTemporarily()
    }

    fun hide() {
        isVisible = false
        cancelAutoHide()
        onHide()
    }

    /** Reinicia la cuenta atrás; con el panel lateral abierto el vencimiento no oculta nada. */
    fun resetAutoHide() {
        cancelAutoHide()
        val task = Runnable { if (isVisible && !isSidePanelOpen()) hide() }
        hideRunnable = task
        schedule(task, autoHideDelayMs)
    }

    fun cancelAutoHide() {
        hideRunnable?.let(cancel)
        hideRunnable = null
    }

    /** Sincroniza el estado cuando la Activity oculta los controles por su cuenta (configuración de TV). */
    fun forceHiddenState() {
        isVisible = false
    }

    private fun reveal(temporarily: Boolean) {
        isVisible = true
        onReveal(temporarily)
        resetAutoHide()
    }

    companion object {
        const val DEFAULT_AUTO_HIDE_MS = 5_000L
    }
}
