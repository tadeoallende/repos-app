package com.angulismotv.player

import com.angulismotv.models.StreamType

/** Deterministic playback recovery limits, kept free of Android and player dependencies. */
object PlaybackRecoveryPolicy {
    const val MAX_FINITE_RECONNECT_ATTEMPTS = 4
    const val WATCHDOG_INTERVAL_MS = 5_000L
    const val FROZEN_TICKS_BEFORE_RECONNECT = 2
    const val BUFFERING_TICKS_BEFORE_RECONNECT = 3
    const val STABLE_PLAYBACK_RESET_MS = 15_000L
    const val NETWORK_RECHECK_INTERVAL_MS = 5_000L

    // Exponential-ish backoff with a 30 s cap: enough time for a server/network to recover.
    private val reconnectDelaysMs = longArrayOf(1_000, 2_000, 4_000, 8_000, 12_000, 20_000, 30_000)

    fun reconnectDelayMs(attempt: Int): Long {
        require(attempt >= 1) { "El intento de reconexión debe ser mayor que cero" }
        return reconnectDelaysMs[(attempt - 1).coerceAtMost(reconnectDelaysMs.lastIndex)]
    }

    /** Live HLS/DASH is allowed to recover indefinitely, always with capped backoff. */
    fun retryBeyondLimit(type: String): Boolean = type == StreamType.HLS || type == StreamType.DASH

    /** Auth/configuration responses are not fixed by repeatedly re-opening the same URL. */
    fun isPermanentHttpStatus(statusCode: Int): Boolean =
        statusCode == 400 || statusCode == 401 || statusCode == 403 ||
            statusCode == 405 || statusCode == 410
}
