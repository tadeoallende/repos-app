package com.angulismotv.player

import android.os.Handler
import com.angulismotv.models.Channel
import com.angulismotv.models.StreamType
import com.google.android.exoplayer2.ExoPlayer
import com.google.android.exoplayer2.Player

/**
 * Owns channel source selection and the delayed fallback between native-player sources.
 * UI changes remain callbacks so this controller can be reviewed independently of the Activity.
 */
internal class PlayerSourceSelectionController(
    private val handler: Handler,
    private val currentGeneration: () -> Int,
    private val isZapping: () -> Boolean,
    private val currentChannel: () -> Channel?,
    private val selectedOptionIndex: () -> Int,
    private val setSelectedOptionIndex: (Int) -> Unit,
    private val currentPlayer: () -> ExoPlayer?,
    private val setCurrentStream: (url: String, type: String) -> Unit,
    private val playStream: (url: String, type: String) -> Unit,
    private val releasePlayer: () -> Unit,
    private val clearError: () -> Unit,
    private val showError: (String) -> Unit,
    private val updateControlsVisibility: () -> Unit
) {
    private var fallbackRunnable: Runnable? = null

    fun playFirstValidOption(channel: Channel) {
        clearError()
        setSelectedOptionIndex(0)

        if (!channel.options.isNullOrEmpty()) {
            tryOption(channel, 0)
            return
        }

        val url = channel.streamUrl.orEmpty()
        if (url.isEmpty()) {
            showError("No hay fuentes disponibles")
            return
        }

        val type = StreamUtils.resolveType(url, channel.streamType ?: StreamType.AUTO)
        setCurrentStream(url, type)
        playStream(url, type)
    }

    fun tryOption(channel: Channel, optionIndex: Int) {
        val options = channel.options ?: return
        if (optionIndex !in options.indices) {
            showError("No se pudo reproducir con ninguna fuente disponible")
            return
        }

        val option = options[optionIndex]
        val url = option.iframe
        if (url.isEmpty()) {
            tryOption(channel, optionIndex + 1)
            return
        }

        val type = StreamUtils.resolveType(url, option.streamType)
        setCurrentStream(url, type)
        setSelectedOptionIndex(optionIndex)
        android.util.Log.d(
            "OPTION_TRY",
            "Intentando opción ${optionIndex + 1}/${options.size}: ${option.name} (${StreamUtils.hostForLog(url)})"
        )

        playStream(url, type)
        updateControlsVisibility()
        scheduleFallback(channel, optionIndex)
    }

    fun cancelPendingFallback() {
        fallbackRunnable?.let(handler::removeCallbacks)
        fallbackRunnable = null
    }

    fun dispose() = cancelPendingFallback()

    private fun scheduleFallback(channel: Channel, optionIndex: Int) {
        cancelPendingFallback()
        val option = channel.options?.getOrNull(optionIndex) ?: return
        val optionType = StreamUtils.resolveType(option.iframe, option.streamType)

        // An iframe may load slowly and does not expose a reliable ExoPlayer state.
        // It is advanced only when its own WebView load reports a real error.
        if (optionType == StreamType.IFRAME) return

        val expectedGeneration = currentGeneration()
        lateinit var task: Runnable
        task = Runnable {
            if (fallbackRunnable === task) fallbackRunnable = null
            val activePlayer = currentPlayer()
            val shouldAdvance = StreamOptionFallbackPolicy.shouldAdvance(
                generationMatches = currentGeneration() == expectedGeneration,
                isZapping = isZapping(),
                channelMatches = currentChannel() == channel,
                optionMatches = selectedOptionIndex() == optionIndex,
                playbackState = activePlayer?.playbackState
            )
            if (!shouldAdvance) return@Runnable

            android.util.Log.w(
                "OPTION_FALLBACK",
                "Opción ${optionIndex + 1} tardó demasiado, probando la siguiente"
            )
            val nextIndex = optionIndex + 1
            if (nextIndex < (channel.options?.size ?: 0)) {
                releasePlayer()
                tryOption(channel, nextIndex)
            }
        }
        fallbackRunnable = task
        handler.postDelayed(task, FALLBACK_TIMEOUT_MS)
    }

    private companion object {
        const val FALLBACK_TIMEOUT_MS = 12_000L
    }
}

/** Pure decision rule for delayed option fallback, kept separate for regression tests. */
internal object StreamOptionFallbackPolicy {
    fun shouldAdvance(
        generationMatches: Boolean,
        isZapping: Boolean,
        channelMatches: Boolean,
        optionMatches: Boolean,
        playbackState: Int?
    ): Boolean {
        if (!generationMatches || isZapping || !channelMatches || !optionMatches) return false
        return playbackState == null ||
            playbackState == Player.STATE_IDLE ||
            playbackState == Player.STATE_BUFFERING
    }
}
