package com.angulismotv.player

/**
 * Entrada de número de canal con el mando: acumula dígitos, muestra lo tecleado y confirma
 * al completar el número, al pulsar OK o al vencer [timeoutMs].
 *
 * No depende de vistas ni de Handler (todo se inyecta), así que es verificable en JVM.
 */
internal class ChannelNumberEntryController(
    private val schedule: (Runnable, Long) -> Unit,
    private val cancel: (Runnable) -> Unit,
    private val showEntry: (String) -> Unit,
    private val hideEntry: () -> Unit,
    private val channelCount: () -> Int,
    private val isZapping: () -> Boolean,
    private val currentIndex: () -> Int,
    private val requestChannel: (Int) -> Unit,
    private val timeoutMs: Long = DEFAULT_TIMEOUT_MS
) {
    private var buffer = ChannelNumberInputBuffer()
    private val commitRunnable = Runnable { commit() }

    val hasPending: Boolean
        get() = buffer.value.isNotEmpty()

    /** Ajusta la cantidad máxima de cifras al tamaño del catálogo y descarta lo tecleado. */
    fun configureForCatalog(size: Int) {
        cancel(commitRunnable)
        buffer = ChannelNumberInputBuffer.forChannelCount(size)
    }

    fun appendDigit(digit: Int) {
        val count = channelCount()
        if (count <= 0 || isZapping()) return
        val result = buffer.append(digit, count) ?: return
        showEntry(result.value)
        cancel(commitRunnable)
        schedule(commitRunnable, timeoutMs)
        // Para catálogos grandes se permiten 4 o 5 cifras; con un número completo y válido
        // se aplica de inmediato, si no se espera a OK o al vencimiento del tiempo.
        if (result.shouldCommitImmediately) commit()
    }

    fun commit() {
        cancel(commitRunnable)
        val requested = buffer.takeNumber()
        hideEntry()
        if (requested == null || requested !in 1..channelCount() || isZapping()) return
        val index = requested - 1
        if (index != currentIndex()) requestChannel(index)
    }

    companion object {
        const val DEFAULT_TIMEOUT_MS = 1_500L
    }
}
