package com.angulismotv.player

/**
 * State for classic TV remote channel-number entry. It deliberately has no Android dependency
 * so the boundary conditions can be unit-tested without an emulator.
 */
class ChannelNumberInputBuffer(private val maxDigits: Int = 3) {
    init {
        require(maxDigits > 0) { "maxDigits debe ser mayor que cero" }
    }

    var value: String = ""
        private set

    data class AppendResult(
        val value: String,
        val shouldCommitImmediately: Boolean
    )

    fun append(digit: Int, channelCount: Int): AppendResult? {
        if (digit !in 0..9 || channelCount <= 0) return null
        if (value.length >= maxDigits) value = ""
        value += digit.toString()
        val number = value.toIntOrNull()
        return AppendResult(
            value = value,
            shouldCommitImmediately = value.length >= maxDigits && number != null && number in 1..channelCount
        )
    }

    /** Returns the entered number and clears the buffer; validation against the catalog is the caller's job. */
    fun takeNumber(): Int? {
        val number = value.toIntOrNull()
        value = ""
        return number
    }

    fun clear() {
        value = ""
    }

    companion object {
        /** Supports 3, 4 or 5 digit channel numbers according to the loaded catalog size. */
        fun forChannelCount(channelCount: Int): ChannelNumberInputBuffer {
            val digits = when {
                channelCount < 1_000 -> 3
                channelCount < 10_000 -> 4
                else -> 5
            }
            return ChannelNumberInputBuffer(maxDigits = digits)
        }
    }
}
