package com.angulismotv.player

import com.angulismotv.models.StreamType
import java.net.URI
import java.util.Locale

/** Fuente que el emisor solicita reproducir en un receptor Cast. */
data class CastStream(
    val url: String,
    val type: String,
    val title: String,
    /** Permite distinguir un HLS/DASH en vivo de uno bajo demanda. */
    val isLive: Boolean? = null
)

/** Datos validados y normalizados antes de crear el MediaInfo del SDK. */
data class CastMediaDescriptor(
    val url: String,
    val resolvedType: String,
    val contentType: String,
    val isLive: Boolean
)

/** Reglas puras para impedir que Cast intente enviar páginas iframe o URLs no reproducibles. */
object CastMediaPolicy {

    fun describe(stream: CastStream): CastMediaDescriptor? {
        val url = stream.url.trim()
        if (url.isEmpty()) return null

        val uri = runCatching { URI(url) }.getOrNull() ?: return null
        val scheme = uri.scheme?.lowercase(Locale.ROOT)
        if (uri.host.isNullOrBlank() || (scheme != "http" && scheme != "https")) return null

        val type = StreamUtils.resolveType(url, stream.type)
        val path = uri.path?.lowercase(Locale.ROOT).orEmpty()
        // StreamUtils agrupa MKV/AVI bajo el tipo nativo genérico MP4; ese MIME sería
        // incorrecto para Cast y el receptor normalmente no puede decodificar esos contenedores.
        if (type == StreamType.MP4 && (path.endsWith(".mkv") || path.endsWith(".avi"))) return null

        val contentType = when (type) {
            StreamType.HLS -> "application/x-mpegURL"
            StreamType.DASH -> "application/dash+xml"
            StreamType.MP4 -> "video/mp4"
            else -> return null
        }
        val live = stream.isLive ?: (type == StreamType.HLS || type == StreamType.DASH)
        return CastMediaDescriptor(url, type, contentType, live)
    }
}
