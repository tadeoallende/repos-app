package com.angulismotv.player

import com.angulismotv.models.StreamType
import java.net.URI
import java.util.Locale

object StreamUtils {

    /**
     * Resuelve el formato usando un tipo explícito válido o la ruta de la URL.
     * Inspeccionar solo el path evita falsos positivos por parámetros como `?redirect=.m3u8`.
     */
    fun resolveType(url: String, providedType: String?): String {
        val explicit = providedType?.trim()?.lowercase(Locale.ROOT)
        if (explicit != null && explicit in SUPPORTED_TYPES && explicit != StreamType.AUTO) return explicit
        if (url.isBlank()) return StreamType.AUTO

        val uri = runCatching { URI(url.trim()) }.getOrNull()
        val host = uri?.host?.lowercase(Locale.ROOT).orEmpty()
        val path = uri?.path?.lowercase(Locale.ROOT).orEmpty()

        return when {
            host == "youtu.be" || host == "youtube.com" || host.endsWith(".youtube.com") ||
                host == "youtube-nocookie.com" || host.endsWith(".youtube-nocookie.com") -> StreamType.IFRAME
            path.endsWith(".mpd") -> StreamType.DASH
            path.endsWith(".m3u8") || path.endsWith(".m3u") -> StreamType.HLS
            path.endsWith(".mp4") || path.endsWith(".mkv") || path.endsWith(".avi") -> StreamType.MP4
            else -> StreamType.HLS // Compatibilidad con streams sin extensión visible.
        }
    }

    /** Host-only diagnostic helper: never emit query strings that may contain stream tokens. */
    fun hostForLog(url: String): String =
        runCatching { URI(url.trim()).host?.takeIf { it.isNotBlank() } ?: "host desconocido" }
            .getOrDefault("URL inválida")

    private val SUPPORTED_TYPES = setOf(
        StreamType.HLS,
        StreamType.DASH,
        StreamType.MP4,
        StreamType.IFRAME,
        StreamType.AUTO
    )
}
