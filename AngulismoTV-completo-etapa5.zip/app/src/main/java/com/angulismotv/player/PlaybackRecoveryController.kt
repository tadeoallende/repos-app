package com.angulismotv.player

import android.os.Handler
import android.util.Log
import com.google.android.exoplayer2.Player
import com.google.android.exoplayer2.upstream.HttpDataSource

/**
 * Owns retries and the playback watchdog independently from either player screen.
 * Callbacks keep Activity/Fragment, views and ExoPlayer ownership outside this class.
 */
class PlaybackRecoveryController(
    private val handler: Handler,
    private val isGenerationCurrent: (Int) -> Boolean,
    private val isZapping: () -> Boolean,
    private val playerProvider: () -> Player?,
    private val streamProvider: () -> Pair<String, String>,
    private val networkAvailable: () -> Boolean,
    private val releasePlayer: () -> Unit,
    private val replayStream: (String, String, Boolean) -> Unit,
    private val showError: (String) -> Unit,
    private val showLoading: () -> Unit
) {
    private var reconnectAttempts = 0
    private var resumeAfterRecovery = true
    private var watchdogRunnable: Runnable? = null
    private var reconnectRunnable: Runnable? = null
    private var stablePlaybackRunnable: Runnable? = null
    private var lastKnownPosition = -1L
    private var frozenPositionCount = 0

    /** Reset retry state and optionally cancel a retry belonging to a previous selection. */
    fun reset(cancelPendingReconnect: Boolean = false) {
        reconnectAttempts = 0
        resumeAfterRecovery = true
        cancelStablePlaybackTimer()
        if (cancelPendingReconnect) cancelPendingReconnect()
    }

    fun cancelPendingReconnect() {
        reconnectRunnable?.let(handler::removeCallbacks)
        reconnectRunnable = null
    }

    /** A retry budget is cleared only after uninterrupted, actual playback has remained stable. */
    fun scheduleStablePlaybackReset(generation: Int) {
        cancelStablePlaybackTimer()
        lateinit var task: Runnable
        task = Runnable {
            if (stablePlaybackRunnable === task) stablePlaybackRunnable = null
            if (!isGenerationCurrent(generation) || isZapping()) return@Runnable
            val player = playerProvider() ?: return@Runnable
            if (player.playWhenReady &&
                player.playbackState == Player.STATE_READY &&
                player.isPlaying &&
                player.playbackSuppressionReason == Player.PLAYBACK_SUPPRESSION_REASON_NONE
            ) {
                reconnectAttempts = 0
            }
        }
        stablePlaybackRunnable = task
        handler.postDelayed(task, PlaybackRecoveryPolicy.STABLE_PLAYBACK_RESET_MS)
    }

    fun cancelStablePlaybackTimer() {
        stablePlaybackRunnable?.let(handler::removeCallbacks)
        stablePlaybackRunnable = null
    }

    fun startWatchdog(generation: Int) {
        stopWatchdog()
        watchdogRunnable = createWatchdogRunnable(generation)
        handler.postDelayed(watchdogRunnable!!, PlaybackRecoveryPolicy.WATCHDOG_INTERVAL_MS)
    }

    private fun createWatchdogRunnable(generation: Int): Runnable = object : Runnable {
        override fun run() {
            if (shouldContinueWatchdog(generation)) {
                handler.postDelayed(this, PlaybackRecoveryPolicy.WATCHDOG_INTERVAL_MS)
            }
        }
    }

    /** Returns true while polling remains useful. */
    private fun shouldContinueWatchdog(generation: Int): Boolean {
        if (!isGenerationCurrent(generation) || isZapping()) {
            stopWatchdog()
            return false
        }
        val player = playerProvider() ?: run {
            stopWatchdog()
            return false
        }
        // A deliberate pause or system playback suppression must never trigger a reconnect.
        if (!player.playWhenReady) {
            stopWatchdog()
            return false
        }
        if (player.playbackSuppressionReason != Player.PLAYBACK_SUPPRESSION_REASON_NONE) {
            frozenPositionCount = 0
            lastKnownPosition = -1L
            return true
        }

        when (player.playbackState) {
            Player.STATE_BUFFERING -> return handleBufferingTick(generation)
            Player.STATE_READY -> return handlePlaybackPosition(player.currentPosition, generation)
            Player.STATE_ENDED -> {
                stopWatchdog()
                return false
            }
            else -> {
                // IDLE is normally transient during preparation. Do not treat it as a frozen frame.
                frozenPositionCount = 0
                lastKnownPosition = -1L
                return true
            }
        }
    }

    private fun handleBufferingTick(generation: Int): Boolean {
        lastKnownPosition = -1L
        frozenPositionCount++
        if (frozenPositionCount < PlaybackRecoveryPolicy.BUFFERING_TICKS_BEFORE_RECONNECT) return true
        frozenPositionCount = 0
        scheduleReconnectForCurrentStream(generation)
        return true
    }

    private fun handlePlaybackPosition(position: Long, generation: Int): Boolean {
        if (position != lastKnownPosition || lastKnownPosition < 0L) {
            // A stream that resumes while a retry is pending does not need to be restarted.
            if (lastKnownPosition >= 0L && position != lastKnownPosition && reconnectRunnable != null) {
                cancelPendingReconnect()
            }
            frozenPositionCount = 0
            lastKnownPosition = position
            return true
        }

        frozenPositionCount++
        if (frozenPositionCount < PlaybackRecoveryPolicy.FROZEN_TICKS_BEFORE_RECONNECT) return true
        frozenPositionCount = 0
        scheduleReconnectForCurrentStream(generation)
        // Keep sampling briefly; if the stream resumes before the backoff elapses, cancel retry.
        return true
    }

    private fun scheduleReconnectForCurrentStream(generation: Int) {
        val (url, type) = streamProvider()
        scheduleReconnect(url, type, generation)
    }

    fun stopWatchdog() {
        watchdogRunnable?.let { runnable -> handler.removeCallbacks(runnable) }
        watchdogRunnable = null
        lastKnownPosition = -1L
        frozenPositionCount = 0
    }

    /**
     * Schedules at most one pending retry. A second error/watchdog tick cannot consume extra
     * attempts while the first retry is already waiting.
     */
    fun scheduleReconnect(url: String, type: String, generation: Int, cause: Throwable? = null) {
        if (!isGenerationCurrent(generation) || isZapping()) return

        val responseCode = findHttpResponseCode(cause)
        if (responseCode != null && PlaybackRecoveryPolicy.isPermanentHttpStatus(responseCode)) {
            cancelPendingReconnect()
            stopWatchdog()
            cancelStablePlaybackTimer()
            reconnectAttempts = 0
            showError("El servidor rechazó esta fuente (HTTP $responseCode). Probá otra fuente o recargá manualmente.")
            return
        }
        if (reconnectRunnable != null) return
        // Preserve the user's play/pause intent when rebuilding the native player.
        resumeAfterRecovery = playerProvider()?.playWhenReady ?: resumeAfterRecovery
        cancelStablePlaybackTimer()

        val nextAttempt = if (reconnectAttempts < Int.MAX_VALUE) reconnectAttempts + 1 else Int.MAX_VALUE
        if (nextAttempt > PlaybackRecoveryPolicy.MAX_FINITE_RECONNECT_ATTEMPTS &&
            !PlaybackRecoveryPolicy.retryBeyondLimit(type)
        ) {
            reconnectAttempts = 0
            stopWatchdog()
            cancelStablePlaybackTimer()
            showError("No se pudo reconectar después de varios intentos. Revisá tu conexión o probá otra fuente.")
            return
        }
        reconnectAttempts = nextAttempt

        showLoading()
        lateinit var task: Runnable
        task = Runnable {
            if (reconnectRunnable === task) reconnectRunnable = null
            if (!isGenerationCurrent(generation) || isZapping()) return@Runnable

            if (!networkAvailable()) {
                // Offline time should not consume a finite stream's retry budget. Start fresh
                // when connectivity returns, then use the normal delay for the next request.
                reconnectAttempts = 0
                scheduleOfflineCheck(url, type, generation)
                return@Runnable
            }

            runCatching {
                // Read the latest intent immediately before release: the user may have paused
                // (or resumed) while the retry timer was waiting.
                resumeAfterRecovery = playerProvider()?.playWhenReady ?: resumeAfterRecovery
                val shouldResume = resumeAfterRecovery
                releasePlayer()
                replayStream(url, type, shouldResume)
            }.onFailure { error ->
                Log.w(TAG, "No se pudo reiniciar la transmisión (${StreamUtils.hostForLog(url)})", error)
                if (isGenerationCurrent(generation) && !isZapping()) {
                    scheduleReconnect(url, type, generation)
                }
            }
        }
        reconnectRunnable = task
        handler.postDelayed(task, PlaybackRecoveryPolicy.reconnectDelayMs(reconnectAttempts))
    }

    private fun scheduleOfflineCheck(url: String, type: String, generation: Int) {
        if (!isGenerationCurrent(generation) || isZapping() || reconnectRunnable != null) return
        showLoading()
        lateinit var task: Runnable
        task = Runnable {
            if (reconnectRunnable === task) reconnectRunnable = null
            if (!isGenerationCurrent(generation) || isZapping()) return@Runnable
            if (networkAvailable()) {
                scheduleReconnect(url, type, generation)
            } else {
                scheduleOfflineCheck(url, type, generation)
            }
        }
        reconnectRunnable = task
        handler.postDelayed(task, PlaybackRecoveryPolicy.NETWORK_RECHECK_INTERVAL_MS)
    }

    private fun findHttpResponseCode(cause: Throwable?): Int? {
        var current = cause
        val visited = HashSet<Throwable>()
        while (current != null && visited.add(current)) {
            if (current is HttpDataSource.InvalidResponseCodeException) return current.responseCode
            current = current.cause
        }
        return null
    }

    fun dispose() {
        stopWatchdog()
        cancelPendingReconnect()
        cancelStablePlaybackTimer()
    }

    private companion object {
        const val TAG = "PlaybackRecovery"
    }
}
