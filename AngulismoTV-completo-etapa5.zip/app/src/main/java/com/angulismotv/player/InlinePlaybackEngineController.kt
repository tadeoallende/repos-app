package com.angulismotv.player

import android.content.Context
import android.os.Build
import android.view.View
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceError
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.ImageButton
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import com.angulismotv.models.StreamType
import com.google.android.exoplayer2.C
import com.google.android.exoplayer2.ExoPlayer
import com.google.android.exoplayer2.PlaybackException
import com.google.android.exoplayer2.Player
import com.google.android.exoplayer2.Tracks
import com.google.android.exoplayer2.ui.PlayerView

/**
 * Owns the low-level inline playback wiring (ExoPlayer/WebView listeners and release).
 * Channel selection, UI state and fullscreen handoff remain owned by ChannelsFragment.
 */
internal class InlinePlaybackEngineController(
    private val contextProvider: () -> Context,
    private val playerView: PlayerView,
    private val webViewProvider: () -> WebView,
    private val progressBar: ProgressBar,
    private val errorText: TextView,
    private val playPauseButton: ImageButton,
    private val timelineContainer: View,
    private val isTV: () -> Boolean,
    private val currentGeneration: () -> Int,
    private val currentStream: () -> Pair<String, String>,
    private val currentPlayer: () -> ExoPlayer?,
    private val setCurrentPlayer: (ExoPlayer?) -> Unit,
    private val recovery: () -> PlaybackRecoveryController?,
    private val isWebViewTransferred: () -> Boolean,
    private val onSourceFailure: (Int) -> Unit,
    private val onPlaybackReady: () -> Unit,
    private val onPlayStateChanged: () -> Unit,
    private val onWebPageLoaded: () -> Unit,
    private val stopTimelineUpdates: () -> Unit
) {
    private var playerListener: Player.Listener? = null
    private var listenerOwner: ExoPlayer? = null
    private var audioNoticeShown = false

    fun startExoPlayer(url: String, type: String, generation: Int, playWhenReady: Boolean = true) {
        val webView = webViewProvider()
        webView.stopLoading()
        webView.visibility = View.GONE
        playerView.visibility = View.VISIBLE
        playPauseButton.visibility = View.VISIBLE
        timelineContainer.visibility = View.GONE
        audioNoticeShown = false

        try {
            val mediaSource = StreamMediaSourceFactory.create(url, type)
            val context = contextProvider()
            val player = ExoPlayer.Builder(context, StreamMediaSourceFactory.createRenderersFactory(context))
                .setLoadControl(
                    StreamMediaSourceFactory.createLoadControl(
                        StreamMediaSourceFactory.BufferProfile.INLINE
                    )
                )
                .build()
            setCurrentPlayer(player)
            playerView.player = player
            playerView.useController = false
            installPlayerListener(player, url, type, generation)
            player.setMediaSource(mediaSource)
            player.playWhenReady = playWhenReady
            player.prepare()
        } catch (error: Exception) {
            android.util.Log.e("InlinePlayer", "No se pudo iniciar la fuente", error)
            val recoveryController = recovery()
            if (recoveryController != null) {
                recoveryController.scheduleReconnect(url, type, generation, error)
            } else {
                onSourceFailure(generation)
            }
        }
    }

    /** Attaches listeners to a player returned from fullscreen without replacing its media item. */
    fun attachExistingPlayer(player: ExoPlayer, generation: Int) {
        setCurrentPlayer(player)
        playerView.player = player
        playerView.useController = false
        val (url, type) = currentStream()
        installPlayerListener(player, url, type, generation)
        if (player.playWhenReady && player.playbackState != Player.STATE_IDLE &&
            player.playbackState != Player.STATE_ENDED
        ) recovery()?.startWatchdog(generation)
        if (player.isPlaying) recovery()?.scheduleStablePlaybackReset(generation)
    }

    /** Detaches listeners and the PlayerView before ownership moves to fullscreen; never releases it. */
    fun detachForHandoff(player: ExoPlayer) {
        playerListener?.let { listener ->
            (listenerOwner ?: player).let { owner -> runCatching { owner.removeListener(listener) } }
        }
        playerListener = null
        listenerOwner = null
        stopTimelineUpdates()
        playerView.player = null
        if (currentPlayer() === player) setCurrentPlayer(null)
    }

    fun startWebView(url: String, generation: Int, loadUrl: Boolean = true) {
        val webView = webViewProvider()
        prepareInlineWebSurface(webView)
        val initialHost = StreamUrlPolicy.parseHttpUrl(url)?.host.orEmpty()
        webView.webChromeClient = createInlineWebChromeClient()
        webView.webViewClient = createInlineWebViewClient(initialHost, generation)
        if (loadUrl) webView.loadUrl(url)
    }

    private fun prepareInlineWebSurface(webView: WebView) {
        playerView.player = null
        playerView.visibility = View.GONE
        webView.visibility = View.VISIBLE
        playPauseButton.visibility = View.GONE
        timelineContainer.visibility = View.GONE
        stopTimelineUpdates()
        webView.applyPlayerSettings()
        val interactive = !isTV()
        webView.isFocusable = interactive
        webView.isFocusableInTouchMode = interactive
        webView.isClickable = interactive
    }

    private fun createInlineWebChromeClient(): WebChromeClient = object : WebChromeClient() {
        override fun onPermissionRequest(request: android.webkit.PermissionRequest?) {
            request?.deny()
        }

        override fun onCreateWindow(
            view: WebView?,
            isDialog: Boolean,
            isUserGesture: Boolean,
            resultMsg: android.os.Message?
        ): Boolean = false
    }

    private fun createInlineWebViewClient(initialHost: String, generation: Int): WebViewClient =
        object : WebViewClient() {
            override fun onPageFinished(view: WebView?, finishedUrl: String?) {
                if (generation != currentGeneration() || finishedUrl.isNullOrBlank() || finishedUrl == "about:blank") return
                progressBar.visibility = View.GONE
                errorText.visibility = View.GONE
                onWebPageLoaded()
            }

            @android.annotation.TargetApi(Build.VERSION_CODES.M)
            override fun onReceivedError(
                view: WebView?, request: WebResourceRequest?, error: WebResourceError?
            ) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && request?.isForMainFrame == true &&
                    request.url.toString() != "about:blank"
                ) {
                    onSourceFailure(generation)
                }
            }

            @Suppress("DEPRECATION")
            override fun onReceivedError(view: WebView?, code: Int, description: String?, failedUrl: String?) {
                if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M &&
                    !failedUrl.isNullOrBlank() && failedUrl != "about:blank"
                ) {
                    onSourceFailure(generation)
                }
            }

            @android.annotation.TargetApi(Build.VERSION_CODES.M)
            override fun onReceivedHttpError(
                view: WebView?, request: WebResourceRequest?, errorResponse: WebResourceResponse?
            ) {
                if (request?.isForMainFrame == true && (errorResponse?.statusCode ?: 0) >= 400) {
                    onSourceFailure(generation)
                }
            }

            override fun shouldOverrideUrlLoading(
                view: WebView?, request: WebResourceRequest?
            ): Boolean {
                request ?: return false
                return WebViewNavigationPolicy.shouldBlockTopLevelNavigation(
                    initialHost = initialHost,
                    requestedHost = request.url.host.orEmpty(),
                    isMainFrame = request.isForMainFrame,
                    isRedirect = Build.VERSION.SDK_INT >= Build.VERSION_CODES.N && request.isRedirect
                )
            }
        }

    /** Releases an owned player and resets the inline surfaces, except a WebView transferred to fullscreen. */
    fun release() {
        stopTimelineUpdates()
        timelineContainer.visibility = View.GONE
        playerListener?.let { listener ->
            (listenerOwner ?: currentPlayer())?.let { player -> runCatching { player.removeListener(listener) } }
        }
        playerListener = null
        listenerOwner = null
        currentPlayer()?.run {
            stop()
            clearMediaItems()
            release()
        }
        setCurrentPlayer(null)
        playerView.player = null

        val webView = webViewProvider()
        if (!isWebViewTransferred()) {
            webView.stopLoading()
            webView.visibility = View.GONE
            webView.loadUrl("about:blank")
        }
    }

    /** Avisa una sola vez por sesión cuando el canal tiene audio que el dispositivo no puede decodificar. */
    private fun notifyUnsupportedAudio(summary: PlayerAudioDiagnostics.AudioSummary) {
        if (audioNoticeShown || !PlayerAudioDiagnosticPolicy.shouldNotifyUser(summary.state)) return
        audioNoticeShown = true
        Toast.makeText(
            playerView.context.applicationContext,
            PlayerAudioDiagnosticPolicy.UNSUPPORTED_AUDIO_NOTICE,
            Toast.LENGTH_LONG
        ).show()
    }

    private fun installPlayerListener(player: ExoPlayer, url: String, type: String, generation: Int) {
        playerListener?.let { previous ->
            (listenerOwner ?: currentPlayer())?.let { active -> runCatching { active.removeListener(previous) } }
        }
        val listener = object : Player.Listener {
            override fun onPlaybackStateChanged(state: Int) {
                if (generation != currentGeneration() || currentPlayer() !== player) return
                when (state) {
                    Player.STATE_BUFFERING -> {
                        recovery()?.cancelStablePlaybackTimer()
                        progressBar.visibility = View.VISIBLE
                        errorText.visibility = View.GONE
                        if (player.playWhenReady) recovery()?.startWatchdog(generation)
                        else recovery()?.stopWatchdog()
                    }
                    Player.STATE_READY -> {
                        progressBar.visibility = View.GONE
                        errorText.visibility = View.GONE
                        if (player.isPlaying) recovery()?.cancelPendingReconnect()
                        if (player.playWhenReady) recovery()?.startWatchdog(generation)
                        else recovery()?.stopWatchdog()
                        if (player.isPlaying) recovery()?.scheduleStablePlaybackReset(generation)
                        onPlaybackReady()
                    }
                    Player.STATE_ENDED -> {
                        progressBar.visibility = View.GONE
                        recovery()?.stopWatchdog()
                        recovery()?.cancelStablePlaybackTimer()
                        // HLS/DASH may also be finite VOD. Reconnect on end only when ExoPlayer
                        // identifies a live window or the timeline duration is unknown.
                        if (player.isCurrentWindowLive || player.duration == C.TIME_UNSET) {
                            progressBar.visibility = View.VISIBLE
                            errorText.visibility = View.GONE
                            recovery()?.scheduleReconnect(url, type, generation)
                        }
                    }
                }
            }

            override fun onIsPlayingChanged(isPlaying: Boolean) {
                if (generation != currentGeneration() || currentPlayer() !== player) return
                if (isPlaying) recovery()?.scheduleStablePlaybackReset(generation)
                else recovery()?.cancelStablePlaybackTimer()
                onPlayStateChanged()
            }

            override fun onPlayWhenReadyChanged(playWhenReady: Boolean, reason: Int) {
                if (generation != currentGeneration() || currentPlayer() !== player) return
                if (playWhenReady && player.playbackState != Player.STATE_IDLE &&
                    player.playbackState != Player.STATE_ENDED
                ) recovery()?.startWatchdog(generation)
                else recovery()?.stopWatchdog()
                if (!playWhenReady) recovery()?.cancelStablePlaybackTimer()
            }

            override fun onTracksChanged(tracks: Tracks) {
                if (generation != currentGeneration() || currentPlayer() !== player) return
                notifyUnsupportedAudio(PlayerAudioDiagnostics.logTracks("inline", tracks, type, url))
            }

            override fun onPlayerError(error: PlaybackException) {
                if (generation != currentGeneration() || currentPlayer() !== player) return
                PlayerAudioDiagnostics.logPlaybackError("inline", type, url, error)
                recovery()?.cancelStablePlaybackTimer()
                recovery()?.stopWatchdog()
                if (recovery() != null) {
                    recovery()?.scheduleReconnect(url, type, generation, error)
                } else {
                    onSourceFailure(generation)
                }
            }
        }
        playerListener = listener
        listenerOwner = player
        player.addListener(listener)
    }
}
