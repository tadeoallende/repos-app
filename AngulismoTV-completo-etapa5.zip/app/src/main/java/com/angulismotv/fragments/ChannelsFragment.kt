package com.angulismotv.fragments
import com.angulismotv.player.InlinePlayerTransferController
import com.angulismotv.player.InlinePlayerTransferPlan
import com.angulismotv.player.PlayerLaunchExtras
import com.angulismotv.player.PlayerLaunchRequestFactory

import android.content.res.Configuration
import android.os.Handler
import android.os.Looper
import android.os.Bundle
import android.view.LayoutInflater
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.view.MotionEvent
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.view.animation.AnimationUtils
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.SeekBar
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.view.isVisible
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.angulismotv.MainActivity
import com.angulismotv.BackHandler
import com.angulismotv.R
import com.angulismotv.data.LoadResult
import com.angulismotv.data.ChannelCatalog
import com.angulismotv.data.ChannelFilterEngine
import com.angulismotv.data.LastPlayedChannelStore
import android.widget.Toast
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout
import com.angulismotv.adapters.ChannelsAdapter
import com.angulismotv.models.Channel
import com.angulismotv.models.ChannelIdentity
import com.angulismotv.models.StreamType
import com.angulismotv.player.CastController
import com.angulismotv.player.CastStream
import com.angulismotv.player.InlinePlayerHandoff
import com.angulismotv.player.PlayerChannelCatalog
import com.angulismotv.player.PlayerTimelineController
import com.angulismotv.player.InlinePlaybackEngineController
import com.angulismotv.player.PlaybackRecoveryController
import com.angulismotv.player.InlinePlaybackSourceResolver
import com.angulismotv.player.StreamUrlPolicy
import com.angulismotv.player.applyPlayerSettings
import com.google.android.exoplayer2.ExoPlayer
import com.google.android.exoplayer2.Player
import com.google.android.exoplayer2.ui.PlayerView
import com.angulismotv.utils.DeviceHelper
import com.angulismotv.utils.NetworkUtils
import com.angulismotv.utils.loadChannelLogo
import com.angulismotv.ui.ChannelScreenLayoutController
import com.angulismotv.ui.ChannelCategoryBarController
import com.angulismotv.ui.InlinePlayerPresentationController
import com.angulismotv.ui.DebouncedChannelSearchController
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class ChannelsFragment : Fragment(), BackHandler {

    // View references are cleared together in onDestroyView() to avoid retaining the old hierarchy.
    private val viewReferences = mutableListOf<AutoClearedViewRef<*>>()
    private fun <T : Any> autoClearedViewRef(): AutoClearedViewRef<T> =
        AutoClearedViewRef<T>().also(viewReferences::add)

    // Views
    private val _channelsRecyclerRef = autoClearedViewRef<RecyclerView>()
    private var channelsRecycler: RecyclerView by _channelsRecyclerRef
    private val _progressBarRef = autoClearedViewRef<ProgressBar>()
    private var progressBar: ProgressBar by _progressBarRef
    private val _swipeRefreshRef = autoClearedViewRef<SwipeRefreshLayout>()
    private var swipeRefresh: SwipeRefreshLayout by _swipeRefreshRef
    private val _stateContainerRef = autoClearedViewRef<LinearLayout>()
    private var stateContainer: LinearLayout by _stateContainerRef
    private val _retryButtonRef = autoClearedViewRef<TextView>()
    private var retryButton: TextView by _retryButtonRef
    private val _errorTextRef = autoClearedViewRef<TextView>()
    private var errorText: TextView by _errorTextRef
    private val _categoriesScrollRef = autoClearedViewRef<HorizontalScrollView>()
    private var categoriesScroll: HorizontalScrollView by _categoriesScrollRef
    private val _searchInputRef = autoClearedViewRef<EditText>()
    private var searchInput: EditText by _searchInputRef
    private val _btnSearchRef = autoClearedViewRef<ImageView>()
    private var btnSearch: ImageView by _btnSearchRef
    private val _channelsSectionHeaderRef = autoClearedViewRef<View>()
    private var channelsSectionHeader: View by _channelsSectionHeaderRef
    private val _channelsSearchContainerRef = autoClearedViewRef<View>()
    private var channelsSearchContainer: View by _channelsSearchContainerRef
    private val _channelsSectionSubtitleRef = autoClearedViewRef<TextView>()
    private var channelsSectionSubtitle: TextView by _channelsSectionSubtitleRef

    // Guía contextual exclusiva de la composición Android TV.
    private var tvPlayerEmptyState: View? = null
    private var tvCurrentChannelInfo: View? = null
    private var tvCurrentChannelLogo: ImageView? = null
    private var tvCurrentChannelName: TextView? = null
    private var tvCurrentChannelCategory: TextView? = null
    private var tvPlayerGuide: TextView? = null
    private var tvPlayerKeysHint: TextView? = null
    private var tvPlayerFooterHint: TextView? = null
    private var tvListGuide: TextView? = null

    // Reproductor integrado móvil
    private val _inlinePlayerContainerRef = autoClearedViewRef<FrameLayout>()
    private var inlinePlayerContainer: FrameLayout by _inlinePlayerContainerRef
    private val _inlinePlayerViewRef = autoClearedViewRef<PlayerView>()
    private var inlinePlayerView: PlayerView by _inlinePlayerViewRef
    private val _inlineWebViewRef = autoClearedViewRef<WebView>()
    private var inlineWebView: WebView by _inlineWebViewRef
    private val _inlineProgressBarRef = autoClearedViewRef<ProgressBar>()
    private var inlineProgressBar: ProgressBar by _inlineProgressBarRef
    private val _inlineErrorTextRef = autoClearedViewRef<TextView>()
    private var inlineErrorText: TextView by _inlineErrorTextRef
    private val _inlineControlsBarRef = autoClearedViewRef<LinearLayout>()
    private var inlineControlsBar: LinearLayout by _inlineControlsBarRef
    private val _inlineTimelineContainerRef = autoClearedViewRef<View>()
    private var inlineTimelineContainer: View by _inlineTimelineContainerRef
    private val _inlineSeekBarRef = autoClearedViewRef<SeekBar>()
    private var inlineSeekBar: SeekBar by _inlineSeekBarRef
    private val _inlineTimeCurrentRef = autoClearedViewRef<TextView>()
    private var inlineTimeCurrent: TextView by _inlineTimeCurrentRef
    private val _inlineTimeDurationRef = autoClearedViewRef<TextView>()
    private var inlineTimeDuration: TextView by _inlineTimeDurationRef
    private val _inlineChannelLogoRef = autoClearedViewRef<ImageView>()
    private var inlineChannelLogo: ImageView by _inlineChannelLogoRef
    private val _inlineChannelNameRef = autoClearedViewRef<TextView>()
    private var inlineChannelName: TextView by _inlineChannelNameRef
    private val _inlineBtnPlayPauseRef = autoClearedViewRef<ImageButton>()
    private var inlineBtnPlayPause: ImageButton by _inlineBtnPlayPauseRef
    private val _inlineBtnSourcesRef = autoClearedViewRef<ImageButton>()
    private var inlineBtnSources: ImageButton by _inlineBtnSourcesRef
    private val _inlineBtnReloadRef = autoClearedViewRef<ImageButton>()
    private var inlineBtnReload: ImageButton by _inlineBtnReloadRef
    private val _inlineBtnCastRef = autoClearedViewRef<ImageButton>()
    private var inlineBtnCast: ImageButton by _inlineBtnCastRef
    private val _inlineBtnFullscreenRef = autoClearedViewRef<ImageButton>()
    private var inlineBtnFullscreen: ImageButton by _inlineBtnFullscreenRef
    private val _inlineBtnCloseRef = autoClearedViewRef<ImageButton>()
    private var inlineBtnClose: ImageButton by _inlineBtnCloseRef
    private var inlineExoPlayer: ExoPlayer? = null
    private var inlinePlaybackEngineController: InlinePlaybackEngineController? = null
    private var inlinePlayerTransferController: InlinePlayerTransferController? = null
    private var inlineRecoveryController: PlaybackRecoveryController? = null
    private var inlineChannel: Channel? = null
    private var inlineSourceIndex = 0
    private var inlineCurrentStreamUrl = ""
    private var inlineCurrentStreamType = StreamType.AUTO
    private var inlineCastController: CastController? = null
    private var inlineCastDiscoveryStarted = false
    private var inlineGeneration = 0
    private var inlineControlsVisible = false
    private var isLaunchingFullscreen = false
    private val inlineControlsHandler = Handler(Looper.getMainLooper())
    private var hideInlineControlsRunnable: Runnable? = null
    private var inlineTimelineController: PlayerTimelineController? = null
    private val lastPlayedChannelStore by lazy(LazyThreadSafetyMode.NONE) { LastPlayedChannelStore(requireContext()) }

    // Adapter y datos
    private lateinit var channelsAdapter: ChannelsAdapter
    private var originalChannels = listOf<Channel>()
    private var filteredChannels = listOf<Channel>()
    private var channelNumbersByIdentity: Map<String, Int> = emptyMap()
    private var currentCategory = "todos"
    private var currentCountry = "todos"
    private var isSearchVisible = false

    // ✅ Lista dinámica de categorías (se genera desde los datos)
    private var categoryBarController: ChannelCategoryBarController? = null
    private var inlinePlayerPresentationController: InlinePlayerPresentationController? = null

    // Optimizaciones
    private var channelSearchController: DebouncedChannelSearchController? = null
    private var filterJob: Job? = null
    private var filterGeneration = 0
    private var categoryMetadataJob: Job? = null

    private var isTV = false
    private var viewGeneration = 0

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        // Android TV necesita una composición horizontal propia: vista previa a la izquierda,
        // catálogo a la derecha. El layout móvil permanece independiente y compacto.
        val layoutRes = if (DeviceHelper.isTV(requireContext())) {
            R.layout.fragment_channels_tv
        } else {
            R.layout.fragment_channels
        }
        return inflater.inflate(layoutRes, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        viewGeneration++
        isTV = DeviceHelper.isTV(requireContext())
        initViews(view)
        setupInlinePlayerPresentationController()

        setupCategoryBar(view)
        setupInlineTimelineController()
        setupInlinePlaybackEngine()
        setupInlinePlayerTransferController()
        applyChannelScreenLayout(view)
        setupChannelInteractions()
        restoreInitialTvFocus(view)
    }

    private fun setupInlinePlayerPresentationController() {
        inlinePlayerPresentationController = InlinePlayerPresentationController(
            contextProvider = { requireContext() },
            isTV = { isTV },
            inlinePlayerContainer = inlinePlayerContainer,
            channelsSectionHeader = channelsSectionHeader,
            channelsSearchContainer = channelsSearchContainer,
            searchInput = searchInput,
            channelsSectionSubtitle = channelsSectionSubtitle,
            inlineChannelName = inlineChannelName,
            inlineChannelLogo = inlineChannelLogo,
            inlineBtnSources = inlineBtnSources,
            inlineErrorText = inlineErrorText,
            inlinePlayerView = inlinePlayerView,
            inlineWebView = inlineWebView,
            tvPlayerEmptyState = tvPlayerEmptyState,
            tvCurrentChannelInfo = tvCurrentChannelInfo,
            tvCurrentChannelLogo = tvCurrentChannelLogo,
            tvCurrentChannelName = tvCurrentChannelName,
            tvCurrentChannelCategory = tvCurrentChannelCategory,
            tvPlayerGuide = tvPlayerGuide,
            tvPlayerFooterHint = tvPlayerFooterHint,
            filteredChannelCount = { filteredChannels.size },
            searchIsVisible = { isSearchVisible },
            onMobileSearchHidden = { isSearchVisible = false },
            showControlsTemporarily = ::showInlineControlsTemporarily
        )
    }

    private fun setupCategoryBar(view: View) {
        categoryBarController = ChannelCategoryBarController(
            context = requireContext(),
            container = view.findViewById(R.id.categories_container),
            searchInput = searchInput,
            channelsRecycler = channelsRecycler,
            inlinePlayerContainer = inlinePlayerContainer,
            isTV = isTV,
            getChannels = { originalChannels },
            getCurrentCategory = { currentCategory },
            getCurrentCountry = { currentCountry },
            setCurrentCountry = { currentCountry = it },
            onCategorySelected = ::selectCategory,
            onCountryChanged = {
                applyFiltersAndUpdate {
                    if (isTV) categoryBarController?.focusSelectedCategory()
                }
            },
            onFocusChannelList = ::focusChannelList,
            onCategoryFocusTargetChanged = { focusId ->
                if (::channelsAdapter.isInitialized) channelsAdapter.setCategoryFocusTarget(focusId)
            }
        )
    }

    private fun setupInlineTimelineController() {
        inlineTimelineController = PlayerTimelineController(
            handler = inlineControlsHandler,
            container = inlineTimelineContainer,
            seekBar = inlineSeekBar,
            currentTime = inlineTimeCurrent,
            durationTime = inlineTimeDuration,
            playerProvider = { inlineExoPlayer },
            isTimelineEnabled = { inlineControlsVisible },
            shouldContinueUpdates = {
                inlineControlsVisible && isResumed && !isHidden && inlineExoPlayer != null &&
                    inlineChannel != null && inlinePlayerContainer.visibility == View.VISIBLE
            },
            // El inline permite seek si hay duración positiva.
            canSeekOnStopTracking = { player -> player.duration > 0L }
        )
    }

    private fun setupInlinePlaybackEngine() {
        inlineRecoveryController?.dispose()
        inlineRecoveryController = PlaybackRecoveryController(
            handler = inlineControlsHandler,
            isGenerationCurrent = { generation -> generation == inlineGeneration },
            isZapping = { isLaunchingFullscreen || isHidden || !isAdded },
            playerProvider = { inlineExoPlayer },
            streamProvider = { inlineCurrentStreamUrl to inlineCurrentStreamType },
            networkAvailable = { context?.let(NetworkUtils::hasActiveConnection) ?: false },
            releasePlayer = ::releaseInlineEngine,
            replayStream = ::replayInlineStreamAfterRecovery,
            showError = { message ->
                if (isAdded && _inlineErrorTextRef.isInitialized) showInlineError(message)
            },
            showLoading = {
                if (isAdded && _inlineProgressBarRef.isInitialized) {
                    inlineProgressBar.visibility = View.VISIBLE
                    inlineErrorText.visibility = View.GONE
                }
            }
        )
        inlinePlaybackEngineController = InlinePlaybackEngineController(
            contextProvider = { requireContext() },
            playerView = inlinePlayerView,
            webViewProvider = { inlineWebView },
            progressBar = inlineProgressBar,
            errorText = inlineErrorText,
            playPauseButton = inlineBtnPlayPause,
            timelineContainer = inlineTimelineContainer,
            isTV = { isTV },
            currentGeneration = { inlineGeneration },
            currentStream = { inlineCurrentStreamUrl to inlineCurrentStreamType },
            currentPlayer = { inlineExoPlayer },
            setCurrentPlayer = { inlineExoPlayer = it },
            recovery = { inlineRecoveryController },
            isWebViewTransferred = {
                isLaunchingFullscreen && _inlineWebViewRef.isInitialized && inlineWebView.parent == null
            },
            onSourceFailure = ::handleInlineSourceFailure,
            onPlaybackReady = {
                updateInlinePlayPauseIcon()
                inlineTimelineController?.update()
                if (!isTV) startInlineTimelineUpdates()
                showInlineControlsTemporarily()
            },
            onPlayStateChanged = ::updateInlinePlayPauseIcon,
            onWebPageLoaded = ::showInlineControlsTemporarily,
            stopTimelineUpdates = ::stopInlineTimelineUpdates
        )
    }

    private fun setupInlinePlayerTransferController() {
        inlinePlayerTransferController = InlinePlayerTransferController(
            playerProvider = { inlineExoPlayer },
            streamUrlProvider = { inlineCurrentStreamUrl },
            streamTypeProvider = { inlineCurrentStreamType },
            sourceIndexProvider = { inlineSourceIndex },
            channelProvider = { inlineChannel },
            webView = inlineWebView,
            recoveryProvider = { inlineRecoveryController },
            playbackEngineProvider = { inlinePlaybackEngineController },
            setLaunchingFullscreen = { isLaunchingFullscreen = it }
        )
    }

    private fun applyChannelScreenLayout(view: View) {
        ChannelScreenLayoutController(
            root = view,
            isTV = isTV,
            channelsSectionHeader = channelsSectionHeader,
            channelsSearchContainer = channelsSearchContainer,
            btnSearch = btnSearch,
            searchInput = searchInput,
            categoriesScroll = categoriesScroll,
            channelsRecycler = channelsRecycler,
            inlinePlayerContainer = inlinePlayerContainer,
            inlineControlsBar = inlineControlsBar,
            inlineChannelLogo = inlineChannelLogo,
            inlineChannelName = inlineChannelName,
            inlineTimelineContainer = inlineTimelineContainer,
            inlineTimeCurrent = inlineTimeCurrent,
            inlineTimeDuration = inlineTimeDuration,
            inlineSeekBar = inlineSeekBar,
            onSearchVisibilityChanged = { visible -> isSearchVisible = visible }
        ).applyDeviceSpecificLayout()
    }

    private fun setupChannelInteractions() {
        setupInlinePlayer()
        setupSearch()
        setupRecyclerView()
        setupStates()
        renderInitialState()
    }

    private fun restoreInitialTvFocus(view: View) {
        if (!isTV) return
        val expectedViewGeneration = viewGeneration
        view.post {
            if (expectedViewGeneration != viewGeneration || !isAdded ||
                !_inlinePlayerContainerRef.isInitialized || !_retryButtonRef.isInitialized ||
                !inlinePlayerContainer.isShown) return@post
            if (retryButton.isShown) retryButton.requestFocus()
            else inlinePlayerContainer.requestFocus()
        }
    }

    private fun initViews(view: View) {
        bindCatalogViews(view)
        bindTvGuideViews(view)
        bindInlinePlayerViews(view)
    }

    private fun bindCatalogViews(view: View) {
        channelsRecycler = view.findViewById(R.id.channels_recycler)
        progressBar = view.findViewById(R.id.progress_bar)
        errorText = view.findViewById(R.id.error_text)
        swipeRefresh = view.findViewById(R.id.swipe_refresh)
        stateContainer = view.findViewById(R.id.state_container)
        retryButton = view.findViewById(R.id.retry_button)
        categoriesScroll = view.findViewById(R.id.categories_scroll)
        searchInput = view.findViewById(R.id.search_input)
        btnSearch = view.findViewById(R.id.btn_search)
        channelsSectionHeader = view.findViewById(R.id.channels_section_header)
        channelsSearchContainer = view.findViewById(R.id.channels_search_container)
        channelsSectionSubtitle = view.findViewById(R.id.channels_section_subtitle)
    }

    private fun bindTvGuideViews(view: View) {
        tvPlayerEmptyState = view.findViewById(R.id.tv_player_empty_state)
        tvCurrentChannelInfo = view.findViewById(R.id.tv_current_channel_info)
        tvCurrentChannelLogo = view.findViewById(R.id.tv_current_channel_logo)
        tvCurrentChannelName = view.findViewById(R.id.tv_current_channel_name)
        tvCurrentChannelCategory = view.findViewById(R.id.tv_current_channel_category)
        tvPlayerGuide = view.findViewById(R.id.tv_player_guide)
        tvPlayerKeysHint = view.findViewById(R.id.tv_player_keys_hint)
        tvPlayerFooterHint = view.findViewById(R.id.tv_player_footer_hint)
        tvListGuide = view.findViewById(R.id.tv_list_guide)
    }

    private fun bindInlinePlayerViews(view: View) {
        inlinePlayerContainer = view.findViewById(R.id.inline_player_container)
        inlinePlayerContainer.addOnLayoutChangeListener { v, left, _, right, _, _, _, _, _ ->
            val width = right - left
            if (width > 0) {
                val targetHeight = (width * 9f / 16f).toInt()
                if (v.layoutParams.height != targetHeight) {
                    v.layoutParams = v.layoutParams.apply { height = targetHeight }
                }
            }
        }
        inlinePlayerView = view.findViewById(R.id.inline_player_view)
        inlineWebView = view.findViewById(R.id.inline_web_view)
        inlineProgressBar = view.findViewById(R.id.inline_progress_bar)
        inlineErrorText = view.findViewById(R.id.inline_error_text)
        inlineControlsBar = view.findViewById(R.id.inline_controls_bar)
        inlineTimelineContainer = view.findViewById(R.id.inline_timeline_container)
        inlineSeekBar = view.findViewById(R.id.inline_seek_bar)
        inlineTimeCurrent = view.findViewById(R.id.inline_time_current)
        inlineTimeDuration = view.findViewById(R.id.inline_time_duration)
        inlineChannelLogo = view.findViewById(R.id.inline_channel_logo)
        inlineChannelName = view.findViewById(R.id.inline_channel_name)
        inlineBtnPlayPause = view.findViewById(R.id.inline_btn_play_pause)
        inlineBtnSources = view.findViewById(R.id.inline_btn_sources)
        inlineBtnReload = view.findViewById(R.id.inline_btn_reload)
        inlineBtnCast = view.findViewById(R.id.inline_btn_cast)
        inlineBtnFullscreen = view.findViewById(R.id.inline_btn_fullscreen)
        inlineBtnClose = view.findViewById(R.id.inline_btn_close)
    }

    private fun setupInlinePlayer() {
        if (isTV) setupTvInlinePlayer() else setupMobileInlinePlayer()
        setupInlineTimelineControls()
        setupInlineActionButtons()
    }

    private fun setupTvInlinePlayer() {
        configureTvInlinePresentation()
        configureTvInlineNavigation()
        configureTvInlineFocusFeedback()
    }

    private fun configureTvInlinePresentation() {
        // En TV el reproductor es un objetivo real del D-pad, incluso antes de elegir canal.
        inlinePlayerContainer.visibility = View.VISIBLE
        inlinePlayerContainer.isFocusable = true
        inlinePlayerContainer.isFocusableInTouchMode = true
        inlinePlayerContainer.isClickable = true
        inlinePlayerView.isFocusable = false
        inlinePlayerView.isFocusableInTouchMode = false
        inlinePlayerView.isClickable = false
        inlineWebView.isFocusable = false
        inlineWebView.isFocusableInTouchMode = false
        inlineWebView.isClickable = false
        inlineBtnCast.visibility = View.GONE
        inlineControlsBar.visibility = View.GONE
        inlineTimelineContainer.visibility = View.GONE
        tvPlayerEmptyState?.visibility = View.VISIBLE
        tvCurrentChannelInfo?.visibility = View.GONE
        tvPlayerGuide?.setText(R.string.tv_player_idle_guide)
        tvPlayerKeysHint?.setText(R.string.tv_player_keys_hint)
        tvPlayerFooterHint?.setText(R.string.tv_player_footer_hint)
    }

    private fun configureTvInlineNavigation() {
        inlinePlayerContainer.nextFocusLeftId = R.id.menu_channels
        inlinePlayerContainer.nextFocusRightId = R.id.channels_recycler
        inlinePlayerContainer.nextFocusUpId = R.id.menu_channels
        inlinePlayerContainer.nextFocusDownId = R.id.tv_inline_channels_button
        inlinePlayerContainer.setOnClickListener { activateTvPlayer() }
        inlinePlayerContainer.setOnKeyListener { view, keyCode, event ->
            if (event.action != KeyEvent.ACTION_DOWN || event.repeatCount > 0) return@setOnKeyListener false
            when (keyCode) {
                KeyEvent.KEYCODE_DPAD_CENTER,
                KeyEvent.KEYCODE_ENTER,
                KeyEvent.KEYCODE_NUMPAD_ENTER -> {
                    view.performClick()
                    true
                }
                KeyEvent.KEYCODE_DPAD_RIGHT -> {
                    focusChannelList()
                    true
                }
                KeyEvent.KEYCODE_DPAD_LEFT -> {
                    requireActivity().findViewById<View>(R.id.menu_channels)?.requestFocus() == true
                }
                else -> false
            }
        }
    }

    private fun configureTvInlineFocusFeedback() {
        inlinePlayerContainer.setOnFocusChangeListener { _, hasFocus ->
            // La ayuda debe describir el destino real del foco, no el control sugerido.
            val guideRes = when {
                hasFocus && inlineChannel != null -> R.string.tv_player_active_guide
                hasFocus -> R.string.tv_player_idle_guide
                inlineChannel != null -> R.string.tv_player_preview_ready_guide
                else -> R.string.tv_player_idle_guide
            }
            tvPlayerGuide?.setText(guideRes)
        }
    }

    private fun setupMobileInlinePlayer() {
        val hostActivity = activity as? AppCompatActivity
        if (hostActivity != null) {
            inlineCastController = CastController(
                activity = hostActivity,
                button = inlineBtnCast,
                handler = inlineControlsHandler,
                currentStream = {
                    val channel = inlineChannel
                    val url = inlineCurrentStreamUrl
                    if (channel == null || url.isBlank() || inlineCurrentStreamType == StreamType.IFRAME) null
                    else CastStream(url, inlineCurrentStreamType, channel.name)
                },
                onCastStarted = {
                    inlineExoPlayer?.pause()
                    updateInlinePlayPauseIcon()
                },
                onStatusChanged = { message -> tvPlayerGuide?.text = message }
            ).also { controller ->
                controller.setup(isTV = false)
                inlineBtnCast.visibility = View.GONE
            }
        } else {
            inlineBtnCast.visibility = View.GONE
        }

        // Mantener el marco 16:9 desde el primer render evita saltos al elegir el primer canal.
        inlinePlayerContainer.visibility = View.VISIBLE
        tvPlayerEmptyState?.visibility = View.VISIBLE
        inlinePlayerView.isFocusable = false
        inlinePlayerView.isClickable = true
        inlinePlayerView.setOnClickListener {
            if (inlineControlsVisible) hideInlineControls() else showInlineControlsTemporarily()
        }
        // No consume los toques del reproductor web: sus controles internos siguen funcionando.
        inlineWebView.applyPlayerSettings()
        inlineWebView.setOnTouchListener { _, event ->
            if (event.action == MotionEvent.ACTION_UP) showInlineControlsTemporarily()
            false
        }
    }

    private fun setupInlineTimelineControls() {
        inlineSeekBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onStartTrackingTouch(seekBar: SeekBar?) {
                inlineTimelineController?.onStartTracking()
                showInlineControlsTemporarily()
            }

            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                inlineTimelineController?.onProgressChanged(progress, fromUser)
            }

            override fun onStopTrackingTouch(seekBar: SeekBar?) {
                inlineTimelineController?.onStopTracking()
                showInlineControlsTemporarily()
            }
        })
    }

    private fun setupInlineActionButtons() {
        inlineBtnPlayPause.setOnClickListener {
            val player = inlineExoPlayer ?: return@setOnClickListener
            if (player.isPlaying) player.pause() else player.play()
            updateInlinePlayPauseIcon()
            showInlineControlsTemporarily()
        }
        inlineBtnSources.setOnClickListener { showInlineSourcePicker() }
        inlineBtnReload.setOnClickListener { reloadInlineTransmission() }
        inlineBtnCast.visibility = View.GONE
        inlineBtnFullscreen.setOnClickListener { launchInlineFullscreen() }
        inlineBtnClose.setOnClickListener { closeInlinePlayer() }
    }

    private fun updateTvPreviewIdentity(channel: Channel) {
        inlinePlayerPresentationController?.updateTvPreviewIdentity(channel)
    }

    /** Reattaches a native player returned from fullscreen without resetting its media item. */
    private fun restoreInlineSession(session: InlinePlayerHandoff.Session) {
        val channel = session.channel
        restoreInlineSessionIdentity(channel, session)

        // Resume the embedded WebView even for a native session so later iframe selections work.
        inlineWebView.onResume()
        restoreReturnedWebView(session)

        when {
            session.player != null && session.streamType != StreamType.IFRAME -> {
                restoreNativePlaybackSession(session, session.player)
            }
            session.webView != null && session.streamType == StreamType.IFRAME -> {
                restoreWebPlaybackSession(session)
            }
            else -> restartInlineSession(channel)
        }
        refreshInlineCastAvailability()
    }

    private fun restoreInlineSessionIdentity(channel: Channel, session: InlinePlayerHandoff.Session) {
        inlineRecoveryController?.reset(cancelPendingReconnect = true)
        inlineChannel = channel
        inlineSourceIndex = session.sourceIndex.coerceAtLeast(0)
        inlineCurrentStreamUrl = session.streamUrl
        inlineCurrentStreamType = session.streamType
        if (::channelsAdapter.isInitialized) channelsAdapter.setPreviewChannel(channel)
        inlinePlayerContainer.visibility = View.VISIBLE
        updateTvPreviewIdentity(channel)
        inlineChannelName.text = channel.name
        inlineChannelLogo.loadChannelLogo(channel.name, channel.logo)
        inlineBtnSources.visibility = if ((channel.options?.size ?: 0) > 1) View.VISIBLE else View.GONE
        inlineErrorText.visibility = View.GONE
    }

    private fun restoreReturnedWebView(session: InlinePlayerHandoff.Session) {
        val returnedWebView = session.webView ?: return
        // Restore the original WebView instance to its exact inline slot, even if the active
        // source changed while fullscreen was open.
        inlineWebView = returnedWebView
        (inlineWebView.parent as? ViewGroup)?.removeView(inlineWebView)
        val params = session.webViewLayoutParams ?: FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.MATCH_PARENT
        )
        val index = session.webViewParentIndex.coerceIn(0, inlinePlayerContainer.childCount)
        inlinePlayerContainer.addView(inlineWebView, index, params)
    }

    private fun restoreNativePlaybackSession(session: InlinePlayerHandoff.Session, player: ExoPlayer) {
        if (session.webView != null) {
            // Clear the transferred document if fullscreen switched from iframe to native video.
            inlineWebView.webViewClient = WebViewClient()
            inlineWebView.webChromeClient = WebChromeClient()
            inlineWebView.stopLoading()
            inlineWebView.loadUrl("about:blank")
            inlineWebView.visibility = View.GONE
        }
        inlineGeneration++
        val generation = inlineGeneration
        inlinePlayerView.visibility = View.VISIBLE
        inlinePlaybackEngineController?.attachExistingPlayer(player, generation)
        inlineProgressBar.visibility = if (
            player.playbackState == Player.STATE_BUFFERING || player.playbackState == Player.STATE_IDLE
        ) View.VISIBLE else View.GONE
        player.playWhenReady = session.wasPlaying
        updateInlinePlayPauseIcon()
        if (player.playbackState == Player.STATE_READY) {
            inlineProgressBar.visibility = View.GONE
            inlineErrorText.visibility = View.GONE
            inlineTimelineController?.update()
        }
    }

    private fun restoreWebPlaybackSession(session: InlinePlayerHandoff.Session) {
        inlineGeneration++
        val generation = inlineGeneration
        inlinePlayerView.player = null
        inlinePlayerView.visibility = View.GONE
        inlineWebView.visibility = View.VISIBLE
        inlineProgressBar.visibility = View.GONE
        startInlineWebView(session.streamUrl, generation, loadUrl = false)
    }

    private fun restartInlineSession(channel: Channel) {
        // Restart only when neither a reusable native player nor the original WebView was returned.
        showInlinePlayer(channel, startPlayback = false)
        startInlinePlayback(channel, inlineSourceIndex)
    }

    private fun activateTvPlayer() {
        if (!isTV) return
        if (inlineChannel != null) {
            launchInlineFullscreen()
        } else {
            tvPlayerGuide?.setText(R.string.tv_player_no_channel_selected)
            focusChannelList()
        }
    }

    /** Move to the current channel in the right-hand list, or its first item if none is selected. */
    private fun focusChannelList() {
        if (!isTV || !_channelsRecyclerRef.isInitialized || !::channelsAdapter.isInitialized) return
        val itemCount = channelsAdapter.itemCount
        if (itemCount <= 0) {
            val fallback = if (retryButton.isShown) retryButton else searchInput
            fallback.requestFocus()
            return
        }
        val selectedPosition = inlineChannel?.let { channel ->
            filteredChannels.indexOfFirst { ChannelIdentity.same(it, channel) }
        } ?: -1
        val remembered = channelsAdapter.getLastFocusedPosition()
        val targetPosition = when {
            selectedPosition in 0 until itemCount -> selectedPosition
            remembered in 0 until itemCount -> remembered
            else -> 0
        }
        val recycler = channelsRecycler
        val expectedViewGeneration = viewGeneration
        recycler.post {
            if (expectedViewGeneration != viewGeneration || !isAdded ||
                !_channelsRecyclerRef.isInitialized || !recycler.isShown) return@post
            recycler.scrollToPosition(targetPosition)
            recycler.post itemFocus@{
                if (expectedViewGeneration != viewGeneration || !_channelsRecyclerRef.isInitialized) return@itemFocus
                val target = recycler.findViewHolderForAdapterPosition(targetPosition)?.itemView
                if (target?.isShown == true && target.requestFocus()) return@itemFocus
                recycler.requestFocus()
            }
        }
    }

    private fun focusSelectedCategory() {
        categoryBarController?.focusSelectedCategory()
    }

    private fun rememberLastActiveChannel(channel: Channel) {
        if (!isTV || !isAdded) return
        lastPlayedChannelStore.remember(channel)
    }

    private fun restoreLastActiveChannel(channels: List<Channel>) {
        if (!isTV || inlineChannel != null || !isAdded || channels.isEmpty()) return
        val lastChannel = lastPlayedChannelStore.resolve(channels) ?: return
        showInlinePlayer(lastChannel)
    }

    private fun showInlinePlayer(channel: Channel, startPlayback: Boolean = true) {        inlineRecoveryController?.reset(cancelPendingReconnect = true)
        // El reproductor se actualiza sin mover la lista. En TV el foco permanece en el canal
        // que acaba de seleccionarse, incluso si el D-pad mantiene pulsado OK.

        // Invalida callbacks tardíos de la fuente anterior antes de cambiar de canal.
        inlineGeneration++
        stopInlineCastDiscovery()
        inlineCurrentStreamUrl = ""
        inlineCurrentStreamType = StreamType.AUTO
        inlineBtnCast.visibility = View.GONE
        inlineChannel = channel
        rememberLastActiveChannel(channel)
        inlineSourceIndex = 0
        if (::channelsAdapter.isInitialized) channelsAdapter.setPreviewChannel(channel)
        inlinePlayerPresentationController?.showSelectedChannel(channel)

        if (startPlayback) {
            startInlinePlayback(channel, 0)
        } else {
            releaseInlineEngine()
            inlineProgressBar.visibility = View.GONE
        }
        if (isTV) restoreTvFocusForChannel(ChannelIdentity.key(channel), scrollIfNeeded = true)
    }

    /** Keep D-pad focus tied to channel identity, not an adapter position that can change. */
    private fun restoreTvFocusForChannel(key: String, scrollIfNeeded: Boolean) {
        if (!isTV || !_channelsRecyclerRef.isInitialized || !::channelsAdapter.isInitialized) return
        val recycler = channelsRecycler
        val expectedViewGeneration = viewGeneration
        recycler.post {
            if (expectedViewGeneration != viewGeneration || !_channelsRecyclerRef.isInitialized) return@post
            recycler.post secondFocusRestore@{
                if (expectedViewGeneration != viewGeneration || !isAdded || isHidden ||
                    !_channelsRecyclerRef.isInitialized || !recycler.isShown) {
                    return@secondFocusRestore
                }
                val position = channelsAdapter.getPositionForKey(key)
                if (position < 0) return@secondFocusRestore
                val row = recycler.findViewHolderForAdapterPosition(position)?.itemView
                if (row?.isShown == true) {
                    if (!row.hasFocus()) row.requestFocus()
                    return@secondFocusRestore
                }
                if (scrollIfNeeded) {
                    recycler.scrollToPosition(position)
                    recycler.post finalFocusRestore@{
                        if (expectedViewGeneration != viewGeneration || !_channelsRecyclerRef.isInitialized) return@finalFocusRestore
                        val attachedRow = recycler.findViewHolderForAdapterPosition(position)?.itemView
                        if (attachedRow?.isShown == true && !attachedRow.hasFocus()) attachedRow.requestFocus()
                    }
                }
            }
        }
    }

    private fun currentFocusedChannelKey(): String? {
        if (!isTV || !_channelsRecyclerRef.isInitialized || !::channelsAdapter.isInitialized) return null
        val focusedView = channelsRecycler.findFocus() ?: return null
        val holder = channelsRecycler.findContainingViewHolder(focusedView) ?: return null
        val channel = channelsAdapter.getChannelAt(holder.bindingAdapterPosition) ?: return null
        return ChannelIdentity.key(channel)
    }

    /** Recarga la fuente actualmente seleccionada sin cambiar de canal ni saltar a otra opción. */
    private fun reloadInlineTransmission() {
        val channel = inlineChannel ?: return
        val sourceIndex = inlineSourceIndex
        inlineRecoveryController?.reset(cancelPendingReconnect = true)
        inlineErrorText.visibility = View.GONE
        inlineProgressBar.visibility = View.VISIBLE
        startInlinePlayback(channel, sourceIndex)
        showInlineControlsTemporarily()
    }

    private fun startInlinePlayback(channel: Channel, sourceIndex: Int) {
        if (!isAdded || view == null) return
        if (sourceIndex != inlineSourceIndex) {
            inlineRecoveryController?.reset(cancelPendingReconnect = true)
        }
        val generation = prepareInlinePlaybackAttempt(sourceIndex)
        val selection = InlinePlaybackSourceResolver.resolve(channel, sourceIndex)
        if (selection == null) {
            showInlineError("No se pudo reproducir ninguna fuente de este canal.")
            return
        }
        val url = selection.url
        val type = selection.type
        if (url.isBlank()) {
            handleInlineSourceFailure(generation)
            return
        }

        inlineCurrentStreamUrl = url
        inlineCurrentStreamType = type
        refreshInlineCastAvailability()
        if (type == StreamType.IFRAME) startInlineWebView(url, generation)
        else startInlineExoPlayer(url, type, generation)
    }

    private fun prepareInlinePlaybackAttempt(sourceIndex: Int): Int {
        // During a source switch, Cast must not expose the previous stream URL.
        inlineRecoveryController?.stopWatchdog()
        inlineRecoveryController?.cancelStablePlaybackTimer()
        inlineGeneration++
        stopInlineCastDiscovery()
        inlineCurrentStreamUrl = ""
        inlineCurrentStreamType = StreamType.AUTO
        if (_inlineBtnCastRef.isInitialized) inlineBtnCast.visibility = View.GONE
        releaseInlineEngine()
        inlineSourceIndex = sourceIndex
        inlineErrorText.visibility = View.GONE
        inlineProgressBar.visibility = View.VISIBLE
        return inlineGeneration
    }

    /** Replays exactly the failed source after recovery; it never advances to another option. */
    private fun replayInlineStreamAfterRecovery(url: String, type: String, playWhenReady: Boolean) {
        if (!isAdded || view == null || inlineChannel == null || isLaunchingFullscreen) return
        inlineGeneration++
        val generation = inlineGeneration
        inlineCurrentStreamUrl = url
        inlineCurrentStreamType = type
        inlineErrorText.visibility = View.GONE
        inlineProgressBar.visibility = View.VISIBLE
        startInlineExoPlayer(url, type, generation, playWhenReady)
    }

    private fun startInlineExoPlayer(
        url: String,
        type: String,
        generation: Int,
        playWhenReady: Boolean = true
    ) {
        inlinePlaybackEngineController?.startExoPlayer(url, type, generation, playWhenReady)
    }

    private fun startInlineWebView(url: String, generation: Int, loadUrl: Boolean = true) {
        inlinePlaybackEngineController?.startWebView(url, generation, loadUrl)
    }

    private fun handleInlineSourceFailure(generation: Int) {
        if (generation != inlineGeneration) return
        // Mantener la fuente elegida: el cambio de fuente siempre debe ser manual.
        showInlineError("No se pudo cargar esta fuente. Podés elegir otra manualmente.")
    }

    private fun showInlineError(message: String) {
        stopInlineTimelineUpdates()
        inlineProgressBar.visibility = View.GONE
        inlineErrorText.text = if (isTV) "$message\n\nElegí Recargar para volver a intentar." else "$message\n\nTocá ↻ Recargar para volver a intentar."
        inlineErrorText.visibility = View.VISIBLE
        showInlineControlsTemporarily()
        // En móvil se mantiene la barra visible mientras haya error, para que Recargar no
        // desaparezca antes de poder tocarlo. La acción de recarga vuelve a activar el timeout.
        if (!isTV && inlinePlayerContainer.visibility == View.VISIBLE) {
            hideInlineControlsRunnable?.let { inlineControlsHandler.removeCallbacks(it) }
            hideInlineControlsRunnable = null
        }
    }

    private fun releaseInlineEngine() {
        inlineRecoveryController?.stopWatchdog()
        inlineRecoveryController?.cancelStablePlaybackTimer()
        inlineRecoveryController?.cancelPendingReconnect()
        inlinePlaybackEngineController?.release()
    }

    private fun startInlineTimelineUpdates() {
        inlineTimelineController?.startUpdates()
    }

    private fun stopInlineTimelineUpdates() {
        inlineTimelineController?.stopUpdates()
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density + 0.5f).toInt()

    private fun updateInlinePlayPauseIcon() {
        val isPlaying = inlineExoPlayer?.isPlaying == true
        inlineBtnPlayPause.setImageResource(if (isPlaying) R.drawable.ic_pause else R.drawable.ic_play)
        inlineBtnPlayPause.contentDescription = if (isPlaying) "Pausar" else "Reproducir"
    }

    private fun revealInlineControl(target: View, slide: Boolean) {
        target.animate().cancel()
        if (target.visibility != View.VISIBLE) {
            target.alpha = 0f
            target.translationY = if (slide) dp(12).toFloat() else 0f
            target.visibility = View.VISIBLE
        }
        target.animate()
            .alpha(1f)
            .translationY(0f)
            .setDuration(230L)
            .setInterpolator(android.view.animation.DecelerateInterpolator(1.35f))
            .withEndAction {
                if (target.visibility == View.VISIBLE) {
                    target.alpha = 1f
                    target.translationY = 0f
                }
            }
            .start()
    }

    private fun concealInlineControl(target: View, slide: Boolean) {
        if (target.visibility != View.VISIBLE) return
        target.animate().cancel()
        target.animate()
            .alpha(0f)
            .translationY(if (slide) dp(10).toFloat() else 0f)
            .setDuration(150L)
            .setInterpolator(android.view.animation.AccelerateInterpolator())
            .withEndAction {
                target.visibility = View.GONE
                target.alpha = 1f
                target.translationY = 0f
            }
            .start()
    }

    private fun showInlineControlsTemporarily() {
        if (isTV || !_inlineControlsBarRef.isInitialized || inlinePlayerContainer.visibility != View.VISIBLE) return
        inlineControlsVisible = true
        val scrim = inlinePlayerContainer.findViewById<View>(R.id.inline_controls_scrim)
        revealInlineControl(scrim, slide = false)
        revealInlineControl(inlineControlsBar, slide = true)
        inlineControlsBar.bringToFront()

        if (inlinePlayerView.visibility == View.VISIBLE) {
            revealInlineControl(inlineBtnPlayPause, slide = false)
            inlineBtnPlayPause.bringToFront()
            startInlineTimelineUpdates()
            inlineTimelineContainer.post {
                if (inlineControlsVisible && inlineTimelineContainer.visibility == View.VISIBLE) {
                    revealInlineControl(inlineTimelineContainer, slide = true)
                    inlineTimelineContainer.bringToFront()
                }
            }
        } else {
            concealInlineControl(inlineBtnPlayPause, slide = false)
            concealInlineControl(inlineTimelineContainer, slide = true)
            stopInlineTimelineUpdates()
        }

        hideInlineControlsRunnable?.let { inlineControlsHandler.removeCallbacks(it) }
        hideInlineControlsRunnable = Runnable { hideInlineControls() }
        inlineControlsHandler.postDelayed(hideInlineControlsRunnable!!, 4_000L)
    }

    private fun hideInlineControls() {
        if (!_inlineControlsBarRef.isInitialized) return
        inlineControlsVisible = false
        concealInlineControl(inlinePlayerContainer.findViewById<View>(R.id.inline_controls_scrim), slide = false)
        concealInlineControl(inlineControlsBar, slide = true)
        concealInlineControl(inlineTimelineContainer, slide = true)
        concealInlineControl(inlineBtnPlayPause, slide = false)
        stopInlineTimelineUpdates()
        hideInlineControlsRunnable?.let { inlineControlsHandler.removeCallbacks(it) }
        hideInlineControlsRunnable = null
    }

    private fun refreshInlineCastAvailability() {
        if (!_inlineBtnCastRef.isInitialized) return
        val canCast = !isTV &&
            inlinePlayerContainer.visibility == View.VISIBLE &&
            inlineChannel != null &&
            inlineCurrentStreamUrl.isNotBlank() &&
            inlineCurrentStreamType != StreamType.IFRAME &&
            inlineCastController?.isConfigured == true

        inlineBtnCast.visibility = if (canCast) View.VISIBLE else View.GONE
        if (canCast && isResumed && !isHidden) {
            startInlineCastDiscovery()
        } else {
            stopInlineCastDiscovery()
        }
    }

    private fun startInlineCastDiscovery() {
        if (inlineCastDiscoveryStarted || inlineCastController?.isConfigured != true) return
        inlineCastController?.startDiscovery()
        inlineCastDiscoveryStarted = true
    }

    private fun stopInlineCastDiscovery() {
        if (!inlineCastDiscoveryStarted) return
        inlineCastController?.stopDiscovery()
        inlineCastDiscoveryStarted = false
    }

    private fun showInlineSourcePicker() {
        val channel = inlineChannel ?: return
        val options = channel.options.orEmpty()
        if (options.size < 2) return
        androidx.appcompat.app.AlertDialog.Builder(requireContext())
            .setTitle("Seleccionar fuente")
            .setItems(options.map { it.name }.toTypedArray()) { _, which ->
                startInlinePlayback(channel, which)
                showInlineControlsTemporarily()
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    private fun closeInlinePlayer() {
        inlineRecoveryController?.reset(cancelPendingReconnect = true)
        inlineGeneration++
        stopInlineCastDiscovery()
        inlineCurrentStreamUrl = ""
        inlineCurrentStreamType = StreamType.AUTO
        inlineBtnCast.visibility = View.GONE
        hideInlineControls()
        hideInlineControlsRunnable?.let { inlineControlsHandler.removeCallbacks(it) }
        releaseInlineEngine()
        inlinePlayerContainer.visibility = View.VISIBLE
        tvPlayerEmptyState?.visibility = View.VISIBLE
        inlineProgressBar.visibility = View.GONE
        inlineErrorText.visibility = View.GONE
        inlineChannel = null
        if (isTV) {
            lastPlayedChannelStore.clear()
            view?.findViewById<View>(R.id.tv_inline_search_button)?.visibility = View.VISIBLE
            if (::channelsAdapter.isInitialized) channelsAdapter.setCategoryFocusTarget(R.id.tv_inline_search_button)
        }
        if (::channelsAdapter.isInitialized) channelsAdapter.setPreviewChannel(null)
        channelsSectionHeader.visibility = View.GONE
        isSearchVisible = false
        channelsSearchContainer.visibility = View.GONE
        searchInput.setText("")
        syncHeaderSearchButton(false)
        currentCategory = currentCategory.ifBlank { "todos" }
        if (isTV) {
            tvPlayerEmptyState?.visibility = View.VISIBLE
            tvCurrentChannelInfo?.visibility = View.GONE
            tvCurrentChannelLogo?.setImageResource(R.drawable.ic_channel_placeholder)
            tvCurrentChannelName?.setText(R.string.tv_channel_not_selected)
            tvCurrentChannelCategory?.setText(R.string.tv_live_category)
            tvPlayerGuide?.setText(R.string.tv_player_idle_guide)
            inlinePlayerContainer.requestFocus()
        }
    }

    private fun launchInlineFullscreen() {
        val channel = inlineChannel ?: return
        launchPlayerActivity(channel, fromInline = true)
    }

    private fun openPlayerPanelShortcut(openSearch: Boolean) {
        if (!isTV || !isAdded) return
        val channel = inlineChannel ?: originalChannels.firstOrNull {
            !it.streamUrl.isNullOrBlank() || !it.options.isNullOrEmpty()
        }
        if (channel == null) {
            Toast.makeText(requireContext(), "No hay canales disponibles para abrir el reproductor", Toast.LENGTH_SHORT).show()
            return
        }

        // Solo transferir la sesión integrada si existe un canal ya seleccionado.
        val reuseInlineSession = inlineChannel != null && ChannelIdentity.same(inlineChannel!!, channel)
        launchPlayerActivity(
            channel = channel,
            fromInline = reuseInlineSession,
            openChannelPanel = true,
            openChannelSearch = openSearch
        )
    }

    private fun launchPlayerActivity(
        channel: Channel,
        fromInline: Boolean,
        openChannelPanel: Boolean = false,
        openChannelSearch: Boolean = false
    ) {
        val catalog = PlayerLaunchRequestFactory.resolveCatalog(originalChannels, channel)
        val handoff = inlinePlayerTransferController?.prepare(channel, fromInline)
            ?: InlinePlayerTransferPlan.NONE
        val catalogToken = PlayerChannelCatalog.publish(catalog.channels)
        val launchIntent = PlayerLaunchRequestFactory.createIntent(
            context = requireContext(),
            channel = channel,
            catalog = catalog,
            catalogToken = catalogToken,
            fromInline = fromInline,
            isTV = isTV,
            sourceIndex = inlineSourceIndex,
            handoff = handoff,
            openChannelPanel = openChannelPanel,
            openChannelSearch = openChannelSearch
        )
            .putExtra(PlayerLaunchExtras.OPEN_CHANNEL_PANEL, openChannelPanel)
            .putExtra(PlayerLaunchExtras.OPEN_CHANNEL_SEARCH, openChannelSearch)

        try {
            startActivity(launchIntent)
            if (!isTV) requireActivity().overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
        } catch (error: Exception) {
            isLaunchingFullscreen = false
            if (handoff.transferNativePlayer || handoff.transferWebView) {
                InlinePlayerHandoff.cancelPendingFullscreen()?.let(::restoreInlineSession)
            }
            android.util.Log.e("InlinePlayer", "No se pudo abrir pantalla completa", error)
            Toast.makeText(
                requireContext(),
                "No se pudo abrir el reproductor a pantalla completa",
                Toast.LENGTH_SHORT
            ).show()
        }
    }

    private fun maybeOpenFullscreenAfterRotation(newConfig: Configuration) {
        if (isTV || isHidden || newConfig.orientation != Configuration.ORIENTATION_LANDSCAPE) return
        if (inlineChannel == null || inlinePlayerContainer.visibility != View.VISIBLE || isLaunchingFullscreen) return
        launchPlayerActivity(inlineChannel!!, fromInline = true)
    }

    private fun setupSearch() {
        // El contenedor del campo cambia solo su borde cuando el EditText recibe foco.
        // No requiere animación, escalado ni una capa adicional de renderizado.
        searchInput.setOnFocusChangeListener { _, hasFocus ->
            (searchInput.parent as? View)?.isSelected = hasFocus
        }
        if (!isTV) {
            btnSearch.setOnClickListener {
                searchInput.requestFocus()
                val inputMethodManager = requireContext().getSystemService(
                    android.content.Context.INPUT_METHOD_SERVICE
                ) as android.view.inputmethod.InputMethodManager
                inputMethodManager.showSoftInput(searchInput, android.view.inputmethod.InputMethodManager.SHOW_IMPLICIT)
            }
        }

        channelSearchController = DebouncedChannelSearchController(
            searchInput = searchInput,
            isSearchActive = {
                isSearchVisible && _searchInputRef.isInitialized && searchInput.visibility == View.VISIBLE
            },
            viewGeneration = { viewGeneration },
            currentCategory = { currentCategory },
            resetCategoryToAll = {
                currentCategory = "todos"
                categoryBarController?.selectCategory("todos")
            },
            applyFilters = ::applyFiltersAndUpdate
        ).also { it.attach() }
        if (isTV) {
            view?.findViewById<View>(R.id.tv_inline_channels_button)?.apply {
                isFocusable = true
                isFocusableInTouchMode = true
                setOnClickListener { openPlayerPanelShortcut(openSearch = false) }
            }
            view?.findViewById<View>(R.id.tv_inline_search_button)?.apply {
                isFocusable = true
                isFocusableInTouchMode = true
                setOnClickListener { openPlayerPanelShortcut(openSearch = true) }
            }
        }
    }

    /** Opens/closes the search field from the shared header (mobile and Android TV). */
    fun toggleSearchFromHeader() {
        if (!isAdded || isHidden || !_searchInputRef.isInitialized) return

        if (isTV) {
            val opening = !isSearchVisible
            toggleSearch()
            view?.findViewById<View>(R.id.tv_inline_search_button)?.visibility =
                if (opening) View.GONE else View.VISIBLE
            if (::channelsAdapter.isInitialized) {
                channelsAdapter.setCategoryFocusTarget(
                    if (opening) R.id.search_input else R.id.tv_inline_search_button
                )
            }
            if (opening) {
                searchInput.requestFocus()
            } else {
                val playerSearchButton = view?.findViewById<View>(R.id.tv_inline_search_button)
                if (playerSearchButton?.requestFocus() != true) {
                    activity?.findViewById<View>(R.id.header_search_button)?.requestFocus()
                }
            }
            return
        }

        if (channelsSearchContainer.visibility == View.VISIBLE) {
            channelsSearchContainer.visibility = View.GONE
            isSearchVisible = false
            searchInput.setText("")
            searchInput.clearFocus()
            val imm = requireContext().getSystemService(android.content.Context.INPUT_METHOD_SERVICE) as android.view.inputmethod.InputMethodManager
            imm.hideSoftInputFromWindow(searchInput.windowToken, 0)
            syncHeaderSearchButton(false)
            applyFiltersAndUpdate()
        } else {
            channelsSearchContainer.visibility = View.VISIBLE
            searchInput.visibility = View.VISIBLE
            isSearchVisible = true
            searchInput.requestFocus()
            val imm = requireContext().getSystemService(android.content.Context.INPUT_METHOD_SERVICE) as android.view.inputmethod.InputMethodManager
            imm.showSoftInput(searchInput, android.view.inputmethod.InputMethodManager.SHOW_IMPLICIT)
            syncHeaderSearchButton(true)
        }
    }

    private fun syncHeaderSearchButton(open: Boolean) {
        val button = activity?.findViewById<ImageButton>(R.id.header_search_button) ?: return
        button.setImageResource(if (open) R.drawable.ic_close else R.drawable.ic_search)
        button.contentDescription = getString(
            if (open) R.string.close_channel_search else R.string.open_channel_search
        )
        button.nextFocusDownId = if (open) R.id.search_input else R.id.inline_player_container
    }

    private fun toggleSearch() {
        if (isTV) {
            isSearchVisible = !isSearchVisible
            channelsSearchContainer.visibility = if (isSearchVisible) View.VISIBLE else View.GONE
            if (isSearchVisible) {
                searchInput.visibility = View.VISIBLE
                syncHeaderSearchButton(true)
            } else {
                searchInput.setText("")
                searchInput.clearFocus()
                syncHeaderSearchButton(false)
                applyFiltersAndUpdate()
            }
            return
        }

        isSearchVisible = !isSearchVisible

        if (isSearchVisible) {
            searchInput.visibility = View.VISIBLE
            searchInput.requestFocus()
            if (!isTV) {
                val imm = requireContext().getSystemService(android.content.Context.INPUT_METHOD_SERVICE) as android.view.inputmethod.InputMethodManager
                imm.showSoftInput(searchInput, android.view.inputmethod.InputMethodManager.SHOW_IMPLICIT)
            } else {
                searchInput.startAnimation(AnimationUtils.loadAnimation(requireContext(), android.R.anim.fade_in))
            }
        } else {
            searchInput.visibility = View.GONE
            searchInput.text.clear()
            if (!isTV) {
                val imm = requireContext().getSystemService(android.content.Context.INPUT_METHOD_SERVICE) as android.view.inputmethod.InputMethodManager
                imm.hideSoftInputFromWindow(searchInput.windowToken, 0)
            }
            applyFiltersAndUpdate()
        }
    }

    private fun applyFiltersAndUpdate(onListCommitted: (() -> Unit)? = null) {
        if (originalChannels.isEmpty()) {
            filterGeneration++
            filterJob?.cancel()
            filterJob = null
            onListCommitted?.invoke()
            return
        }

        val requestGeneration = ++filterGeneration
        val expectedViewGeneration = viewGeneration
        val sourceSnapshot = originalChannels
        val categorySnapshot = currentCategory
        val countrySnapshot = currentCountry
        val querySnapshot = if (isSearchVisible && _searchInputRef.isInitialized &&
            searchInput.visibility == View.VISIBLE) searchInput.text.toString() else ""

        filterJob?.cancel()
        filterJob = viewLifecycleOwner.lifecycleScope.launch {
            // Un catálogo grande no debe filtrar ni normalizar nombres en el hilo visual.
            val result = withContext(Dispatchers.Default) {
                ChannelFilterEngine.filter(sourceSnapshot, categorySnapshot, countrySnapshot, querySnapshot)
            }
            if (requestGeneration != filterGeneration || expectedViewGeneration != viewGeneration ||
                view == null || !isAdded || !::channelsAdapter.isInitialized) return@launch

            filteredChannels = result
            channelsAdapter.submitList(result) {
                if (requestGeneration == filterGeneration && view != null &&
                    expectedViewGeneration == viewGeneration) onListCommitted?.invoke()
            }
            if (isTV) {
                channelsSectionSubtitle.text = if (result.isEmpty()) {
                    getString(R.string.tv_channels_subtitle_empty)
                } else {
                    getString(R.string.tv_channels_subtitle_count, result.size)
                }
            }
            if (result.isEmpty()) showState("No se encontraron canales", isError = false, showRetry = false)
            else hideState()
        }
    }

    // La fuente puede traer cientos de group-title. Las reglas de clasificación se mantienen
    // en ChannelFilterEngine para que el Fragment solo coordine la presentación.
    private fun generateCategoriesFromChannels(channels: List<Channel>) {
        if (channels.isEmpty()) return
        if (isTV) {
            categoryMetadataJob?.cancel()
            val expectedViewGeneration = viewGeneration
            categoryMetadataJob = viewLifecycleOwner.lifecycleScope.launch {
                val channelNumbers = withContext(Dispatchers.Default) {
                    ChannelCatalog.channelNumbersByIdentity(channels)
                }
                if (expectedViewGeneration != viewGeneration || view == null || !isAdded ||
                    originalChannels !== channels) return@launch

                // Los números deben estar disponibles antes del primer render en TV.
                // De lo contrario, el adaptador muestra "—" para todos los canales.
                channelNumbersByIdentity = channelNumbers
                applyFiltersAndUpdate { restoreLastActiveChannel(channels) }
            }
            return
        }
        categoryMetadataJob?.cancel()
        val expectedViewGeneration = viewGeneration
        categoryMetadataJob = viewLifecycleOwner.lifecycleScope.launch {
            val metadata = withContext(Dispatchers.Default) {
                Triple(
                    ChannelFilterEngine.availableCategories(channels),
                    ChannelFilterEngine.availableCountries(channels),
                    ChannelCatalog.channelNumbersByIdentity(channels)
                )
            }
            if (expectedViewGeneration != viewGeneration || view == null || !isAdded || originalChannels !== channels) {
                return@launch
            }
            channelNumbersByIdentity = metadata.third
            val availableCountries = metadata.second.toSet()
            if (availableCountries.isEmpty()) currentCountry = ChannelFilterEngine.ALL_COUNTRIES
            else if (currentCountry != ChannelFilterEngine.ALL_COUNTRIES && currentCountry !in availableCountries) {
                currentCountry = ChannelFilterEngine.ALL_COUNTRIES
            }
            categoryBarController?.render(metadata.first, metadata.second)
            applyFiltersAndUpdate()
        }
    }

    private fun selectCategory(categoryKey: String) {
        if (currentCategory == categoryKey) return
        val focusedChannelKey = currentFocusedChannelKey()

        currentCategory = categoryKey

        // El controlador actualiza el chip activo y conserva la navegación vertical del mando.
        categoryBarController?.selectCategory(categoryKey)

        if (isSearchVisible) {
            toggleSearch()
        }

        applyFiltersAndUpdate {
            // Esperar al commit del AsyncListDiffer evita solicitar foco sobre un ViewHolder viejo.
            val key = focusedChannelKey
            if (isTV && key != null && channelsAdapter.getPositionForKey(key) >= 0) {
                restoreTvFocusForChannel(key, scrollIfNeeded = true)
            } else if (isTV) {
                focusSelectedCategory()
            }
        }
        // No desplazar la lista al principio al cambiar de categoría o seleccionar una vista previa.
    }

    private fun setupRecyclerView() {
        channelsRecycler.layoutManager = GridLayoutManager(requireContext(), calculateSpanCount())

        channelsAdapter = ChannelsAdapter(
            onItemClick = { channel, position -> openPlayer(channel, position) },
            channelNumber = { channel -> channelNumbersByIdentity[ChannelIdentity.key(channel)] ?: 0 }
        )

        channelsRecycler.adapter = channelsAdapter

        if (isTV) {
            channelsRecycler.isFocusable = true
            channelsRecycler.isFocusableInTouchMode = true
            // El foco inicial va al reproductor; desde allí se entra a la lista con →.
            inlinePlayerContainer.nextFocusRightId = R.id.channels_recycler
            channelsRecycler.nextFocusLeftId = R.id.inline_player_container
            channelsAdapter.setCategoryFocusTarget(R.id.tv_inline_search_button)
        }
    }

    /**
     * Devuelve el foco a un elemento real de la lista en Android TV.
     * El retraso doble permite que RecyclerView procese el scroll y adjunte el ViewHolder,
     * evitando que el mando quede enfocado en el contenedor sin un indicador visible.
     */
    fun requestTvFocus() {
        if (!isTV || !_channelsRecyclerRef.isInitialized || !::channelsAdapter.isInitialized) return
        val container = inlinePlayerContainer
        val expectedViewGeneration = viewGeneration
        container.post {
            if (expectedViewGeneration != viewGeneration || !isAdded ||
                !_inlinePlayerContainerRef.isInitialized || !_retryButtonRef.isInitialized ||
                !::channelsAdapter.isInitialized || !container.isShown) return@post
            if (retryButton.isShown && channelsAdapter.itemCount == 0) retryButton.requestFocus()
            else container.requestFocus()
        }
    }

    /** Columnas según el ancho disponible: TV por rangos fijos; móvil/tablet una cada ~320dp. */
    private fun calculateSpanCount(): Int {
        if (isTV) return 1
        val dpWidth = resources.configuration.screenWidthDp
        return (dpWidth / 320).coerceAtLeast(1)
    }

    // MainActivity maneja la rotación sin recrearse: recalculamos la lista y ampliamos el reproductor.
    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        if (_channelsRecyclerRef.isInitialized) {
            (channelsRecycler.layoutManager as? GridLayoutManager)?.spanCount = calculateSpanCount()
        }
        maybeOpenFullscreenAfterRotation(newConfig)
    }

    /** Al crear las vistas: muestra la carga en curso o el último resultado que tenga la activity. */
    private fun renderInitialState() {
        val main = activity as? MainActivity
        val result = main?.getLoadResult()
        if (main == null || main.isLoadingChannels() || result == null) {
            showLoading(true)
        } else {
            applyResult(result)
        }
    }

    private fun setupStates() {
        swipeRefresh.setColorSchemeResources(R.color.accent)
        swipeRefresh.setProgressBackgroundColorSchemeResource(R.color.space_surface_raised)
        swipeRefresh.isEnabled = !isTV // en TV no hay gesto: se usa el botón Reintentar
        swipeRefresh.setOnRefreshListener { (activity as? MainActivity)?.reloadChannels() }
        retryButton.setOnClickListener { (activity as? MainActivity)?.reloadChannels() }
    }

    private fun applyResult(result: LoadResult) {
        filterGeneration++
        filterJob?.cancel()
        filterJob = null
        categoryMetadataJob?.cancel()
        categoryMetadataJob = null
        originalChannels = result.channels
        channelNumbersByIdentity = emptyMap()
        currentCategory = "todos"
        currentCountry = "todos"
        showLoading(false)
        swipeRefresh.isRefreshing = false

        if (originalChannels.isEmpty()) {
            filteredChannels = emptyList()
            channelsAdapter.submitList(emptyList())
            categoryBarController?.clear()
            when {
                result.notConfigured ->
                    showState("Todavía no hay una lista de canales configurada.", isError = false, showRetry = false)
                result.failed ->
                    showState("No se pudo cargar la lista de canales.\nRevisá tu conexión e intentá de nuevo.", isError = true, showRetry = true)
                else ->
                    showState("La lista de canales está vacía.", isError = false, showRetry = true)
            }
        } else {
            generateCategoriesFromChannels(originalChannels)
        }
    }

    private fun showState(message: String, isError: Boolean, showRetry: Boolean) {
        errorText.text = message
        errorText.setTextColor(
            ContextCompat.getColor(requireContext(), if (isError) R.color.error else R.color.text_secondary)
        )
        retryButton.isVisible = showRetry
        stateContainer.isVisible = true
        if (showRetry && isTV) retryButton.requestFocus()
    }

    private fun hideState() {
        stateContainer.isVisible = false
    }

    private fun showLoading(show: Boolean) {
        progressBar.isVisible = show
    }

    /** True si las vistas ya existen (entre onViewCreated y onDestroyView). */
    private fun isViewReady() = view != null && _progressBarRef.isInitialized && ::channelsAdapter.isInitialized

    /** La activity avisa que empezó (o se repitió) la carga de la lista. */
    fun onLoadStarted() {
        if (!isViewReady()) return
        hideState()
        if (!swipeRefresh.isRefreshing) showLoading(true)
    }

    /**
     * La activity llama a esto cuando termina de cargar. Si el fragmento todavía no creó sus vistas
     * no hay nada que actualizar: [renderInitialState] leerá el resultado desde la activity al crearlas.
     */
    fun showResult(result: LoadResult) {
        if (!isViewReady()) return
        applyResult(result)
    }

    // En TV, al volver del reproductor el foco regresa al canal que se estaba mirando.
    override fun onResume() {
        super.onResume()
        isLaunchingFullscreen = false

        // Do not consume a returned session until this Fragment has a usable view. This avoids
        // losing the transferred engine during transient navigation/lifecycle changes.
        val returnedSession = if (!isHidden && isViewReady()) {
            InlinePlayerHandoff.takeReturnedToInline()
        } else null

        if (returnedSession != null) {
            restoreInlineSession(returnedSession)
            val key = ChannelIdentity.key(returnedSession.channel)
            if (channelsAdapter.getPositionForKey(key) >= 0) {
                restoreTvFocusForChannel(key, scrollIfNeeded = true)
            } else {
                focusSelectedCategory()
            }
        } else {
            if (isTV && !isHidden && isViewReady()) restoreTvFocus()
            if (!isHidden && _inlinePlayerContainerRef.isInitialized && inlineChannel != null &&
                inlinePlayerContainer.visibility == View.VISIBLE) {
                inlineWebView.onResume()
                val player = inlineExoPlayer
                if (player != null) {
                    player.play()
                } else if (inlineWebView.visibility != View.VISIBLE) {
                    // Fallback for WebView sources or if the native handoff was unavailable.
                    startInlinePlayback(inlineChannel!!, inlineSourceIndex)
                }
            }
        }
        if (!isHidden && inlineControlsVisible && inlineExoPlayer != null) startInlineTimelineUpdates()
        refreshInlineCastAvailability()
    }

    override fun handleBack(): Boolean {
        if (!isTV || !isSearchVisible || !_searchInputRef.isInitialized) return false
        toggleSearch()
        view?.findViewById<View>(R.id.tv_inline_search_button)?.visibility = View.VISIBLE
        if (::channelsAdapter.isInitialized) channelsAdapter.setCategoryFocusTarget(R.id.tv_inline_search_button)
        view?.findViewById<View>(R.id.tv_inline_search_button)?.requestFocus()
        return true
    }

    override fun onPause() {
        super.onPause()
        inlineRecoveryController?.stopWatchdog()
        inlineRecoveryController?.cancelStablePlaybackTimer()
        inlineRecoveryController?.cancelPendingReconnect()
        stopInlineTimelineUpdates()
        stopInlineCastDiscovery()
        inlineExoPlayer?.pause()
        if (_inlineWebViewRef.isInitialized) inlineWebView.onPause()
    }

    override fun onHiddenChanged(hidden: Boolean) {
        super.onHiddenChanged(hidden)
        if (hidden) {
            inlineRecoveryController?.stopWatchdog()
            inlineRecoveryController?.cancelStablePlaybackTimer()
            inlineRecoveryController?.cancelPendingReconnect()
            stopInlineTimelineUpdates()
            stopInlineCastDiscovery()
            inlineExoPlayer?.pause()
            if (_inlineWebViewRef.isInitialized) inlineWebView.onPause()
        } else if (_inlineWebViewRef.isInitialized) {
            // Fragment visibility callbacks can arrive before onViewCreated() or after view teardown.
            inlineWebView.onResume()
            inlineExoPlayer?.play()
            if (inlineControlsVisible && inlineExoPlayer != null) startInlineTimelineUpdates()
            refreshInlineCastAvailability()
        }
    }

    private fun restoreTvFocus() {
        val lastKey = channelsAdapter.getLastFocusedChannelKey()
        if (lastKey != null && channelsAdapter.getPositionForKey(lastKey) >= 0) {
            restoreTvFocusForChannel(lastKey, scrollIfNeeded = true)
            return
        }
        val position = channelsAdapter.getLastFocusedPosition()
        if (position < 0 || position >= channelsAdapter.itemCount) return
        channelsRecycler.scrollToPosition(position)
        val recycler = channelsRecycler
        val expectedViewGeneration = viewGeneration
        recycler.post {
            if (expectedViewGeneration != viewGeneration || !_channelsRecyclerRef.isInitialized) return@post
            recycler.findViewHolderForAdapterPosition(position)?.itemView?.requestFocus()
        }
    }

    private fun isSameActivePreview(channel: Channel): Boolean {
        val current = inlineChannel ?: return false
        if (!ChannelIdentity.same(current, channel)) return false
        if (inlinePlayerContainer.visibility != View.VISIBLE || inlineCurrentStreamUrl.isBlank()) return false
        if (inlineErrorText.visibility == View.VISIBLE) return false
        if (inlineExoPlayer?.playbackState == Player.STATE_ENDED) return false
        return inlineExoPlayer != null || inlineWebView.visibility == View.VISIBLE || inlineProgressBar.visibility == View.VISIBLE
    }

    private fun openPlayer(channel: Channel, position: Int) {
        if (isTV && isSameActivePreview(channel)) {
            // Volver a confirmar explícitamente la fila que ya se está previsualizando abre
            // fullscreen transfiriendo la sesión activa; no reinicia el stream ni el buffer.
            launchPlayerActivity(channel, fromInline = true)
            return
        }
        if (channel.streamUrl.isNullOrEmpty() && channel.options.isNullOrEmpty()) {
            Toast.makeText(requireContext(), "Este canal no tiene fuentes disponibles", Toast.LENGTH_SHORT).show()
            return
        }

        if (isTV) {
            showInlinePlayer(channel)
        } else if (resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE) {
            // Si el móvil ya está en horizontal, abre la pantalla dedicada directamente.
            showInlinePlayer(channel, startPlayback = false)
            launchPlayerActivity(channel, fromInline = true)
        } else {
            // En vertical el canal queda integrado encima de la lista, sin abandonar la pantalla.
            showInlinePlayer(channel)
        }
    }

    override fun onDestroyView() {
        disposeViewControllers()
        destroyInlineWebViewUnlessTransferred()
        clearTvViewReferences()
        // Break Fragment -> View references before FragmentManager can retain this instance.
        viewReferences.forEach { it.clear() }
        super.onDestroyView()
    }

    private fun disposeViewControllers() {
        filterGeneration++
        filterJob?.cancel()
        filterJob = null
        categoryMetadataJob?.cancel()
        categoryMetadataJob = null
        stopInlineCastDiscovery()
        inlineCastController?.dispose()
        inlineCastController = null
        channelSearchController?.dispose()
        channelSearchController = null
        hideInlineControlsRunnable?.let(inlineControlsHandler::removeCallbacks)
        hideInlineControlsRunnable = null
        stopInlineTimelineUpdates()
        inlineGeneration++
        viewGeneration++
        inlineRecoveryController?.dispose()
        inlineRecoveryController = null
        releaseInlineEngine()
        inlinePlaybackEngineController = null
        inlinePlayerTransferController = null
        inlineTimelineController = null
        categoryBarController = null
        inlinePlayerPresentationController = null
    }

    private fun destroyInlineWebViewUnlessTransferred() {
        if (!_inlineWebViewRef.isInitialized) return
        val webViewWasTransferred = isLaunchingFullscreen && inlineWebView.parent == null
        // These callbacks close over this Fragment. Remove them even when keeping the WebView
        // alive for fullscreen, otherwise the handed-off view can retain this view hierarchy.
        inlineWebView.webChromeClient = WebChromeClient()
        inlineWebView.webViewClient = WebViewClient()
        inlineWebView.setOnTouchListener(null)
        inlineWebView.setOnClickListener(null)
        inlineWebView.setOnKeyListener(null)
        inlineWebView.removeJavascriptInterface("AndroidWebViewBridge")
        if (webViewWasTransferred) return

        inlineWebView.stopLoading()
        (inlineWebView.parent as? ViewGroup)?.removeView(inlineWebView)
        inlineWebView.removeAllViews()
        inlineWebView.destroy()
    }

    private fun clearTvViewReferences() {
        // Nullable TV-only aliases also reference the destroyed view tree.
        tvPlayerEmptyState = null
        tvCurrentChannelInfo = null
        tvCurrentChannelLogo = null
        tvCurrentChannelName = null
        tvCurrentChannelCategory = null
        tvPlayerGuide = null
        tvPlayerKeysHint = null
        tvPlayerFooterHint = null
        tvListGuide = null
    }

}