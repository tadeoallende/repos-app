package com.angulismotv.fragments

import kotlin.properties.ReadWriteProperty
import kotlin.reflect.KProperty

/**
 * Stores a Fragment view reference that can be explicitly cleared in onDestroyView().
 * Access after clearing fails loudly instead of silently reusing a stale view instance.
 */
internal class AutoClearedViewRef<T : Any> : ReadWriteProperty<Any?, T> {
    private var value: T? = null

    val isInitialized: Boolean
        get() = value != null

    override fun getValue(thisRef: Any?, property: KProperty<*>): T =
        value ?: error("View property '${property.name}' accessed outside its view lifecycle")

    override fun setValue(thisRef: Any?, property: KProperty<*>, value: T) {
        this.value = value
    }

    fun clear() {
        value = null
    }
}
