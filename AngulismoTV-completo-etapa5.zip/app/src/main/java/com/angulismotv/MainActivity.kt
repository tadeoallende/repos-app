package com.angulismotv

import android.os.Bundle
import android.util.Log
import android.view.KeyEvent
import android.view.Gravity
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.RecyclerView
import com.angulismotv.databinding.ActivityMainBinding
import com.angulismotv.fragments.AgendaFragment
import com.angulismotv.fragments.ChannelsFragment
import com.angulismotv.data.ChannelRepository
import com.angulismotv.data.LoadResult
import com.angulismotv.models.Channel
import com.angulismotv.utils.DeviceHelper
import com.angulismotv.utils.UpdateManager
import com.bumptech.glide.Glide
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    // El rail de TV vive en view_tv_side_menu.xml; su navegación permanece en esta Activity.
    private val sideMenu: LinearLayout by lazy(LazyThreadSafetyMode.NONE) { findViewById(R.id.side_menu) }
    private val menuChannels: LinearLayout by lazy(LazyThreadSafetyMode.NONE) { findViewById(R.id.menu_channels) }
    private val menuAgenda: LinearLayout by lazy(LazyThreadSafetyMode.NONE) { findViewById(R.id.menu_agenda) }
    private val menuChannelsText: TextView by lazy(LazyThreadSafetyMode.NONE) { findViewById(R.id.menu_channels_text) }
    private val menuAgendaText: TextView by lazy(LazyThreadSafetyMode.NONE) { findViewById(R.id.menu_agenda_text) }
    private var allChannels = listOf<Channel>()
    private var channelsLoading = true
    private var lastLoadResult: LoadResult? = null
    private var channelLoadGeneration = 0
    private var channelLoadJob: Job? = null
    private var isTV = false
    private val sideMenuCollapsedWidth: Int get() = dimen(R.dimen.tv_navigation_rail_collapsed_width)
    private val sideMenuExpandedWidth: Int get() = dimen(R.dimen.tv_navigation_rail_expanded_width)

    // ── Navegación ──────────────────────────────────────────────────────────
    // Sección activa actual — arranca siempre en Canales
    private var currentNavId: Int = R.id.nav_channels

    // Reutilizar los Fragment restaurados por FragmentManager tras una recreación.
    // Crear siempre una instancia nueva podía dejar dos ChannelsFragment en el mismo contenedor.
    private val fragmentChannels by lazy(LazyThreadSafetyMode.NONE) {
        supportFragmentManager.findFragmentByTag(TAG_CHANNELS) as? ChannelsFragment ?: ChannelsFragment()
    }
    private val fragmentAgenda by lazy(LazyThreadSafetyMode.NONE) {
        supportFragmentManager.findFragmentByTag(TAG_AGENDA) as? AgendaFragment ?: AgendaFragment()
    }

    // ────────────────────────────────────────────────────────────────────────

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        isTV = DeviceHelper.isTV(this)
        currentNavId = savedInstanceState?.getInt(STATE_CURRENT_NAV, R.id.nav_channels)
            ?.takeIf { it == R.id.nav_channels || it == R.id.nav_agenda }
            ?: R.id.nav_channels

        Glide.with(this)
            .load(R.drawable.logo2)
            .placeholder(android.R.drawable.ic_menu_gallery)
            .error(android.R.drawable.ic_menu_gallery)
            .into(binding.logoImage)

        setupNavigation()
        setupBackHandler()
        loadAllChannels()

        // Check de actualizaciones (silencioso — solo muestra diálogo si hay novedad)
        UpdateManager(this).checkForUpdates(silent = true)
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putInt(STATE_CURRENT_NAV, currentNavId)
    }

    // ==================== NAVEGACIÓN ====================

    private fun setupNavigation() {
        // Si Android restauró FragmentManager, recuperamos las instancias existentes y solo
        // mostramos la sección seleccionada. No agregar un segundo ChannelsFragment.
        val fragmentManager = supportFragmentManager
        val activeFragment = fragmentForId(currentNavId)
        val inactiveFragment = fragmentForId(
            if (currentNavId == R.id.nav_channels) R.id.nav_agenda else R.id.nav_channels
        )
        fragmentManager.beginTransaction().apply {
            if (activeFragment.isAdded) show(activeFragment)
            else add(R.id.fragment_container, activeFragment, tagForId(currentNavId))
            if (inactiveFragment.isAdded) hide(inactiveFragment)
        }.commit()

        if (isTV) {
            binding.bottomNavigation.visibility = View.GONE
            sideMenu.visibility = View.VISIBLE
            setMainContentInset(sideMenuCollapsedWidth)

            // La navegación principal queda limitada a Canales y Agenda.
            setupTvHeader()
            setupSideMenu()
        } else {
            sideMenu.visibility = View.GONE
            binding.bottomNavigation.visibility = View.VISIBLE
            setMainContentInset(0)
            setupMobileHeader()
            setupBottomNavigation()
            if (binding.bottomNavigation.selectedItemId != currentNavId) {
                binding.bottomNavigation.selectedItemId = currentNavId
            }
        }
    }

    /**
     * Navega a la sección indicada por navId.
     * - Reutiliza instancias existentes (show/hide) en vez de recrear fragments.
     * - En TV colapsa el menú lateral al confirmar la navegación.
     */
    private fun navigateTo(navId: Int) {
        if (isTV && navId != R.id.nav_channels && navId != R.id.nav_agenda) return
        if (navId == currentNavId) {
            handleCurrentSectionReselection()
            return
        }

        val target = fragmentForId(navId)
        val transaction = supportFragmentManager.beginTransaction()
        if (!isTV) transaction.setCustomAnimations(android.R.anim.fade_in, android.R.anim.fade_out)
        supportFragmentManager.findFragmentByTag(tagForId(currentNavId))?.let { fragment -> transaction.hide(fragment) }
        if (target.isAdded) transaction.show(target) else transaction.add(
            R.id.fragment_container, target, tagForId(navId)
        )
        transaction.commit()
        currentNavId = navId
        syncNavigationSelection(navId)
    }

    private fun handleCurrentSectionReselection() {
        if (!isTV) return
        // Confirming the active section returns focus to content and collapses the menu.
        focusActiveContent()
        collapseSideMenu()
    }

    private fun syncNavigationSelection(navId: Int) {
        if (isTV) {
            updateSideMenuSelection(navId)
            collapseSideMenu()
            binding.fragmentContainer.post { focusActiveContent() }
        } else if (binding.bottomNavigation.selectedItemId != navId) {
            binding.bottomNavigation.selectedItemId = navId
        }
    }

    private fun fragmentForId(navId: Int): Fragment = when (navId) {
        R.id.nav_channels -> fragmentChannels
        R.id.nav_agenda   -> fragmentAgenda
        else              -> fragmentChannels
    }

    private fun tagForId(navId: Int): String = when (navId) {
        R.id.nav_channels -> TAG_CHANNELS
        R.id.nav_agenda   -> TAG_AGENDA
        else              -> TAG_CHANNELS
    }

    // ==================== BACK HANDLER ====================

    /**
     * Lógica de back unificada para móvil y TV:
     *
     * 1. Si el fragment visible tiene su propio manejo de back → delegar
     * 2. Si no estamos en Canales → volver a Canales (sección raíz)
     * 3. Si ya estamos en Canales → confirmar salida con diálogo
     *
     * Para TV también se intercepta KEYCODE_BACK en dispatchKeyEvent
     * antes de que cualquier vista lo consuma.
     */
    private fun setupBackHandler() {
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                handleBack()
            }
        })
    }

    private fun handleBack() {
        // 1. Intentar que el fragment activo maneje el back (ej: WebView con historial)
        val activeFragment = supportFragmentManager.findFragmentByTag(tagForId(currentNavId))
        if (activeFragment is BackHandler && activeFragment.handleBack()) return

        // 2. Si el menú lateral de TV está expandido, colapsarlo
        if (isTV && isSideMenuExpanded()) {
            focusActiveContent()
            collapseSideMenu()
            return
        }

        // 3. Si no estamos en la sección raíz, volver a Canales
        if (currentNavId != R.id.nav_channels) {
            navigateTo(R.id.nav_channels)
            return
        }

        // 4. Estamos en la raíz → confirmar salida
        showExitDialog()
    }

    private fun showExitDialog() {
        AlertDialog.Builder(this)
            .setTitle("Salir de AngulismoTV")
            .setMessage("¿Querés cerrar la aplicación?")
            .setPositiveButton("Salir") { _, _ -> finish() }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    // ==================== TV KEY DISPATCH ====================

    /**
     * Para TV interceptamos el back a nivel de Activity antes de que
     * cualquier View o Fragment lo consuma — mismo patrón que UnifiedPlayerActivity.
     */
    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        if (!isTV) return super.dispatchKeyEvent(event)
        if (event.action != KeyEvent.ACTION_DOWN) return super.dispatchKeyEvent(event)

        if (event.keyCode == KeyEvent.KEYCODE_BACK) {
            handleBack()
            return true
        }

        // La flecha derecha entra en la sección que tiene el foco visual, aunque todavía
        // no se haya confirmado con OK. No usar currentNavId: puede apuntar a otra sección.
        if (event.keyCode == KeyEvent.KEYCODE_DPAD_RIGHT && anySideMenuItemFocused()) {
            val focusedNavId = when {
                menuChannels.hasFocus() -> R.id.nav_channels
                menuAgenda.hasFocus() -> R.id.nav_agenda
                else -> currentNavId
            }
            navigateTo(focusedNavId)
            return true
        }

        return super.dispatchKeyEvent(event)
    }

    // ==================== SIDE MENU (TV) ====================

    private fun setupSideMenu() {
        collapseSideMenu(animate = false)

        setupSideMenuItem(menuChannels, menuChannelsText, R.id.nav_channels)
        setupSideMenuItem(menuAgenda, menuAgendaText, R.id.nav_agenda)
        updateSideMenuSelection(currentNavId)
    }

    private fun setupSideMenuItem(container: LinearLayout, label: TextView, navId: Int) {
        label.visibility = View.GONE
        container.isFocusable = true
        container.isFocusableInTouchMode = true
        container.isClickable = true
        container.setOnFocusChangeListener { _, hasFocus ->
            if (hasFocus) {
                expandSideMenu()
                setSideMenuLabelsVisible(true)
            } else {
                // Esperar al siguiente ciclo para no colapsar entre dos opciones del propio rail.
                container.post {
                    if (!anySideMenuItemFocused()) collapseSideMenu()
                }
            }
        }
        container.setOnClickListener { navigateTo(navId) }
    }

    private fun setSideMenuLabelsVisible(visible: Boolean) {
        val showLabels = visible && anySideMenuItemFocused()
        menuChannelsText.visibility = if (showLabels) View.VISIBLE else View.GONE
        menuAgendaText.visibility = if (showLabels) View.VISIBLE else View.GONE
    }

    private fun updateSideMenuSelection(navId: Int) {
        listOf(
            menuChannels to R.id.nav_channels,
            menuAgenda to R.id.nav_agenda
        ).forEach { (view, id) ->
            val selected = id == navId
            view.isSelected = selected
            view.contentDescription = when (id) {
                R.id.nav_channels -> if (selected) "Canales, sección actual" else "Canales"
                R.id.nav_agenda -> if (selected) "Agenda, sección actual" else "Agenda"
                else -> view.contentDescription
            }
            view.refreshDrawableState()
            val iconSlot = view.getChildAt(0) as? android.widget.FrameLayout
            val icon = iconSlot?.getChildAt(0) as? android.widget.ImageView
            icon?.setColorFilter(
                androidx.core.content.ContextCompat.getColor(
                    this,
                    if (selected) R.color.accent else R.color.text_secondary
                )
            )
        }
    }

    private fun anySideMenuItemFocused(): Boolean =
        menuChannels.hasFocus() || menuAgenda.hasFocus()

    private fun isSideMenuExpanded(): Boolean = sideMenu.layoutParams.width >= sideMenuExpandedWidth

    private fun expandSideMenu() {
        setSideMenuLabelsVisible(true)
        setSideMenuWidth(sideMenuExpandedWidth)
    }

    private fun collapseSideMenu(animate: Boolean = true) {
        // Se conserva el parámetro para las llamadas existentes; el rail ya no anima su ancho.
        setSideMenuLabelsVisible(false)
        setSideMenuWidth(sideMenuCollapsedWidth)
    }

    private fun setSideMenuWidth(width: Int) {
        val params = sideMenu.layoutParams
        if (params.width != width) {
            params.width = width
            sideMenu.layoutParams = params
        }
    }

    private fun setMainContentInset(inset: Int) {
        val params = binding.mainContainer.layoutParams as android.widget.FrameLayout.LayoutParams
        if (params.marginStart != inset) {
            params.marginStart = inset
            binding.mainContainer.layoutParams = params
        }
    }

    private fun setupTvHeader() {
        binding.headerClock.visibility = View.VISIBLE
        val params = binding.logoImage.layoutParams as android.widget.FrameLayout.LayoutParams
        params.width = dimen(R.dimen.header_logo_width)
        params.height = dimen(R.dimen.header_logo_height_tv)
        params.gravity = Gravity.START or Gravity.CENTER_VERTICAL
        params.marginStart = dimen(R.dimen.header_logo_margin_start_tv)
        binding.logoImage.layoutParams = params

        // En Android TV la búsqueda se abre desde el acceso bajo el reproductor.
        binding.headerSearchButton.visibility = View.GONE
        binding.headerSearchButton.isFocusable = false
        binding.headerSearchButton.isFocusableInTouchMode = false
        binding.headerSearchButton.isFocusable = true
        binding.headerSearchButton.isFocusableInTouchMode = true
        binding.headerSearchButton.contentDescription = getString(R.string.open_channel_search)
        binding.headerSearchButton.setImageResource(R.drawable.ic_search)
        (binding.headerSearchButton.layoutParams as? android.widget.FrameLayout.LayoutParams)?.let { buttonParams ->
            buttonParams.width = dimen(R.dimen.header_search_button_size_tv)
            buttonParams.height = dimen(R.dimen.header_search_button_size_tv)
            buttonParams.marginEnd = dimen(R.dimen.header_search_button_margin_end_tv)
            binding.headerSearchButton.layoutParams = buttonParams
        }
        binding.headerSearchButton.nextFocusDownId = R.id.inline_player_container
        binding.headerSearchButton.nextFocusLeftId = R.id.inline_player_container
        binding.headerSearchButton.setOnClickListener {
            if (currentNavId != R.id.nav_channels) {
                navigateTo(R.id.nav_channels)
                binding.fragmentContainer.post { fragmentChannels.toggleSearchFromHeader() }
            } else {
                fragmentChannels.toggleSearchFromHeader()
            }
        }
    }

    private fun setupMobileHeader() {
        binding.headerClock.visibility = View.GONE
        // Cabecera compacta: marca a la izquierda y búsqueda a la derecha, como en una app de TV comercial.
        binding.headerContainer.layoutParams = binding.headerContainer.layoutParams.apply {
            height = dimen(R.dimen.header_height_mobile)
        }
        val contentParams = binding.mainContainer.layoutParams as android.widget.FrameLayout.LayoutParams
        contentParams.marginStart = 0
        contentParams.topMargin = dimen(R.dimen.header_height_mobile)
        binding.mainContainer.layoutParams = contentParams

        val logoParams = binding.logoImage.layoutParams as android.widget.FrameLayout.LayoutParams
        logoParams.width = dimen(R.dimen.header_logo_width)
        logoParams.height = dimen(R.dimen.header_logo_height_mobile)
        logoParams.gravity = Gravity.START or Gravity.CENTER_VERTICAL
        logoParams.marginStart = dimen(R.dimen.header_logo_margin_start_mobile)
        binding.logoImage.layoutParams = logoParams
        binding.headerSearchButton.visibility = View.VISIBLE
        binding.headerSearchButton.setOnClickListener {
            if (currentNavId != R.id.nav_channels) {
                navigateTo(R.id.nav_channels)
                binding.fragmentContainer.post { fragmentChannels.toggleSearchFromHeader() }
            } else {
                fragmentChannels.toggleSearchFromHeader()
            }
        }
    }

    private fun focusActiveContent() {
        val activeFragment = supportFragmentManager.findFragmentByTag(tagForId(currentNavId)) ?: return
        activeFragment.view?.post {
            when (currentNavId) {
                R.id.nav_channels -> {
                    // Espera a que RecyclerView tenga sus elementos adjuntos antes de enfocar.
                    // Así se evita dejar el foco en un contenedor vacío al volver desde Agenda.
                    val channelsFragment = activeFragment as? ChannelsFragment
                    if (channelsFragment != null) {
                        channelsFragment.requestTvFocus()
                    } else {
                        activeFragment.view?.findViewById<RecyclerView>(R.id.channels_recycler)?.requestFocus()
                    }
                }
                R.id.nav_agenda -> activeFragment.view?.findViewById<View>(R.id.web_view)?.requestFocus()
            }
        }
    }

    private fun dimen(resourceId: Int): Int = resources.getDimensionPixelSize(resourceId)

    // ==================== BOTTOM NAVIGATION (MÓVIL) ====================

    private fun setupBottomNavigation() {
        binding.bottomNavigation.setOnItemSelectedListener { item ->
            // Evitar re-navegación al mismo destino
            if (item.itemId != currentNavId) {
                navigateTo(item.itemId)
            }
            true
        }
    }

    // ==================== DATA LOADING ====================

    private fun loadAllChannels() {
        if (channelLoadJob?.isActive == true) {
            Log.d(TAG, "Se omite una recarga duplicada: ya hay una carga en curso")
            return
        }
        val generation = ++channelLoadGeneration
        channelsLoading = true
        fragmentChannels.onLoadStarted()
        channelLoadJob = lifecycleScope.launch {
            try {
                if (lastLoadResult == null) {
                    val cached = ChannelRepository.loadCached(this@MainActivity)
                    if (cached != null && generation == channelLoadGeneration && !isFinishing && !isDestroyed) {
                        allChannels = cached.channels
                        lastLoadResult = cached
                        fragmentChannels.showResult(cached)
                        Log.d(TAG, "Catálogo local mostrado de inmediato: " + cached.channels.size + " canales")
                    }
                }
                val fresh = ChannelRepository.loadAll(this@MainActivity)
                // Una recarga más nueva siempre gana: no aplicar respuestas obsoletas.
                if (generation != channelLoadGeneration || isFinishing || isDestroyed) return@launch
                val result = if (fresh.channels.isEmpty() && allChannels.isNotEmpty() &&
                    (fresh.failed || fresh.partialFailure)) {
                    Log.w(TAG, "Falló la actualización; se conserva el último catálogo válido")
                    LoadResult(allChannels, partialFailure = true, sourceName = "Caché local")
                } else fresh
                allChannels = result.channels
                lastLoadResult = result
                fragmentChannels.showResult(result)
                val sourceLabel = result.sourceName ?: "ninguna"
                Log.d(TAG, "Canales cargados: ${allChannels.size} (fuente=$sourceLabel, fallo=${result.failed}, parcial=${result.partialFailure})")
            } catch (cancelled: CancellationException) {
                throw cancelled
            } catch (error: Exception) {
                if (generation != channelLoadGeneration || isFinishing || isDestroyed) return@launch
                Log.e(TAG, "No se pudieron cargar los canales (${error.javaClass.simpleName})", error)
                val result = if (allChannels.isNotEmpty()) {
                    LoadResult(allChannels, partialFailure = true, sourceName = "Caché local")
                } else LoadResult(emptyList(), failed = true)
                lastLoadResult = result
                fragmentChannels.showResult(result)
            } finally {
                if (generation == channelLoadGeneration) channelsLoading = false
            }
        }
    }

    override fun onDestroy() {
        // Cancel any in-flight catalogue request and drop the completed Job reference explicitly.
        channelLoadGeneration++
        channelLoadJob?.cancel()
        channelLoadJob = null
        super.onDestroy()
    }

    // ==================== PUBLIC API ====================

    fun getChannels(): List<Channel> = allChannels

    fun isLoadingChannels(): Boolean = channelsLoading

    fun getLoadResult(): LoadResult? = lastLoadResult

    /** Vuelve a pedir la lista de canales (botón Reintentar y deslizar para actualizar). */
    fun reloadChannels() = loadAllChannels()

    // ==================== COMPANION ====================

    companion object {
        private const val TAG          = "MainActivity"
        private const val TAG_CHANNELS = "fragment_channels"
        private const val TAG_AGENDA   = "fragment_agenda"
        private const val STATE_CURRENT_NAV = "state_current_navigation"
    }
}

/**
 * Interface que pueden implementar los Fragments para manejar
 * el botón Back internamente (ej: WebView con historial de navegación).
 *
 * Retornar true significa "yo lo manejé, no hagas nada más".
 * Retornar false delega el back a MainActivity.
 */
interface BackHandler {
    fun handleBack(): Boolean
}