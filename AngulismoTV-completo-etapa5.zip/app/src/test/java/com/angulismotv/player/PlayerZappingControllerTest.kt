package com.angulismotv.player

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class PlayerZappingControllerTest {
    private val scheduler = FakeScheduler()
    private val started = mutableListOf<String>()
    private val applied = mutableListOf<Pair<Int, String>>()
    private var currentIndex = 0
    private var channels = listOf("A", "B", "C", "D", "E")

    private val controller = PlayerZappingController<String>(
        schedule = scheduler::schedule,
        cancel = scheduler::cancel,
        channelCount = { channels.size },
        channelAt = { channels.getOrNull(it) },
        currentIndex = { currentIndex },
        onTransitionStarted = { started += it },
        onChannelApplied = { index, channel ->
            applied += index to channel
            currentIndex = index
        }
    )

    @Test
    fun `changing channel wraps around the catalog`() {
        controller.changeChannel(-1)
        scheduler.advance(PlayerZappingController.START_DELAY_MS)
        assertEquals(listOf(4 to "E"), applied)
    }

    @Test
    fun `zapping runs in two steps and releases after the reset delay`() {
        controller.changeChannel(1)

        assertTrue(controller.isZapping)
        assertEquals(listOf("B"), started)
        assertTrue(applied.isEmpty())

        scheduler.advance(PlayerZappingController.START_DELAY_MS)
        assertEquals(listOf(1 to "B"), applied)
        assertTrue(controller.isZapping)

        scheduler.advance(PlayerZappingController.RESET_DELAY_MS)
        assertFalse(controller.isZapping)
    }

    @Test
    fun `presses during a transition are accumulated and applied as one net change`() {
        controller.changeChannel(1)
        controller.changeChannel(1)
        controller.changeChannel(1)
        controller.changeChannel(-1)

        scheduler.advance(PlayerZappingController.START_DELAY_MS + PlayerZappingController.RESET_DELAY_MS)
        // El primer cambio llevó a B (1); el neto acumulado (+1) se despacha al liberar.
        assertEquals(listOf("B", "C"), started)

        scheduler.advance(PlayerZappingController.START_DELAY_MS + PlayerZappingController.RESET_DELAY_MS)
        assertEquals(listOf(1 to "B", 2 to "C"), applied)
        assertFalse(controller.isZapping)
    }

    @Test
    fun `accumulated presses that cancel out do not start another change`() {
        controller.changeChannel(1)   // inicia el cambio a B
        controller.changeChannel(1)   // +1 acumulado
        controller.changeChannel(-1)  // -1 acumulado: neto 0

        scheduler.advance(10_000L)
        assertEquals(listOf(1 to "B"), applied)
    }

    @Test
    fun `reset cancels the pending transition and clears accumulated presses`() {
        controller.changeChannel(1)
        controller.changeChannel(1)
        controller.reset()

        assertFalse(controller.isZapping)
        assertEquals(0, scheduler.pendingCount)
        scheduler.advance(10_000L)
        assertTrue(applied.isEmpty())
    }

    @Test
    fun `empty catalog ignores changes and drops pending presses`() {
        channels = emptyList()
        controller.changeChannel(1)

        assertFalse(controller.isZapping)
        assertTrue(started.isEmpty())
        assertEquals(0, scheduler.pendingCount)
    }

    @Test
    fun `cancelling the scheduled apply keeps the current channel untouched`() {
        controller.zapTo(3, "D")
        controller.cancelScheduledApply()

        scheduler.advance(10_000L)
        assertTrue(applied.isEmpty())
    }

    @Test
    fun `dispose cancels every pending timer`() {
        controller.zapTo(2, "C")
        scheduler.advance(PlayerZappingController.START_DELAY_MS)
        controller.dispose()

        assertEquals(0, scheduler.pendingCount)
    }

    @Test
    fun `explicit zap replaces a transition that has not been applied yet`() {
        controller.zapTo(1, "B")
        controller.zapTo(3, "D")

        scheduler.advance(PlayerZappingController.START_DELAY_MS)
        assertEquals(listOf(3 to "D"), applied)
    }
}
