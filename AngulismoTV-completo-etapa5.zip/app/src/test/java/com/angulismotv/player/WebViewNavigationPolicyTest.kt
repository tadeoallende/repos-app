package com.angulismotv.player

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class WebViewNavigationPolicyTest {
    @Test fun allowsOriginalHostAndItsSubdomains() {
        assertFalse(WebViewNavigationPolicy.shouldBlockTopLevelNavigation(
            initialHost = "player.example.com",
            requestedHost = "player.example.com",
            isMainFrame = true,
            isRedirect = false
        ))
        assertFalse(WebViewNavigationPolicy.shouldBlockTopLevelNavigation(
            initialHost = "example.com",
            requestedHost = "cdn.example.com",
            isMainFrame = true,
            isRedirect = false
        ))
    }

    @Test fun blocksLookalikeHostsAndMissingHosts() {
        assertTrue(WebViewNavigationPolicy.shouldBlockTopLevelNavigation(
            initialHost = "example.com",
            requestedHost = "notexample.com",
            isMainFrame = true,
            isRedirect = false
        ))
        assertTrue(WebViewNavigationPolicy.shouldBlockTopLevelNavigation(
            initialHost = "example.com",
            requestedHost = null,
            isMainFrame = true,
            isRedirect = false
        ))
    }

    @Test fun permitsSubresourcesAndServerRedirects() {
        assertFalse(WebViewNavigationPolicy.shouldBlockTopLevelNavigation(
            initialHost = "example.com",
            requestedHost = "outside.example.net",
            isMainFrame = false,
            isRedirect = false
        ))
        assertFalse(WebViewNavigationPolicy.shouldBlockTopLevelNavigation(
            initialHost = "example.com",
            requestedHost = "outside.example.net",
            isMainFrame = true,
            isRedirect = true
        ))
    }
}
