package com.angulismotv.player

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class ChannelNumberEntryControllerTest {
    private val scheduler = FakeScheduler()
    private val shown = mutableListOf<String>()
    private var hidden = 0
    private val requested = mutableListOf<Int>()
    private var channelCount = 125
    private var zapping = false
    private var currentIndex = 0

    private val controller = ChannelNumberEntryController(
        schedule = scheduler::schedule,
        cancel = scheduler::cancel,
        showEntry = { shown += it },
        hideEntry = { hidden++ },
        channelCount = { channelCount },
        isZapping = { zapping },
        currentIndex = { currentIndex },
        requestChannel = { requested += it }
    ).also { it.configureForCatalog(channelCount) }

    @Test
    fun `typed number is applied when the timeout expires`() {
        controller.appendDigit(1)
        controller.appendDigit(2)

        assertEquals(listOf("1", "12"), shown)
        assertTrue(controller.hasPending)
        assertTrue(requested.isEmpty())

        scheduler.advance(ChannelNumberEntryController.DEFAULT_TIMEOUT_MS)
        assertEquals(listOf(11), requested)
        assertFalse(controller.hasPending)
        assertEquals(1, hidden)
    }

    @Test
    fun `complete valid number is applied immediately`() {
        controller.appendDigit(1)
        controller.appendDigit(2)
        controller.appendDigit(5)

        assertEquals(listOf(124), requested)
        assertEquals(0, scheduler.pendingCount)
    }

    @Test
    fun `each digit restarts the timeout`() {
        controller.appendDigit(4)
        scheduler.advance(ChannelNumberEntryController.DEFAULT_TIMEOUT_MS - 100L)
        controller.appendDigit(2)
        scheduler.advance(ChannelNumberEntryController.DEFAULT_TIMEOUT_MS - 100L)

        assertTrue(requested.isEmpty())
        scheduler.advance(100L)
        assertEquals(listOf(41), requested)
    }

    @Test
    fun `explicit confirmation applies the number without waiting`() {
        controller.appendDigit(7)
        controller.commit()

        assertEquals(listOf(6), requested)
        assertEquals(0, scheduler.pendingCount)
    }

    @Test
    fun `number outside the catalog is discarded`() {
        controller.appendDigit(9)
        controller.appendDigit(9)
        controller.appendDigit(9)
        scheduler.advance(ChannelNumberEntryController.DEFAULT_TIMEOUT_MS)

        assertTrue(requested.isEmpty())
        assertFalse(controller.hasPending)
    }

    @Test
    fun `selecting the channel already playing does nothing`() {
        currentIndex = 4
        controller.appendDigit(5)
        controller.commit()

        assertTrue(requested.isEmpty())
    }

    @Test
    fun `digits are ignored while a channel change is in progress`() {
        zapping = true
        controller.appendDigit(3)

        assertTrue(shown.isEmpty())
        assertFalse(controller.hasPending)
    }

    @Test
    fun `digits are ignored when the catalog is empty`() {
        channelCount = 0
        controller.appendDigit(3)

        assertTrue(shown.isEmpty())
    }

    @Test
    fun `large catalogs accept four digits`() {
        channelCount = 1_500
        controller.configureForCatalog(channelCount)
        controller.appendDigit(1)
        controller.appendDigit(2)
        controller.appendDigit(3)
        assertTrue(requested.isEmpty())

        controller.appendDigit(4)
        assertEquals(listOf(1233), requested)
    }

    @Test
    fun `reconfiguring the catalog discards what was typed`() {
        controller.appendDigit(8)
        controller.configureForCatalog(50)

        assertFalse(controller.hasPending)
        assertEquals(0, scheduler.pendingCount)
    }
}
