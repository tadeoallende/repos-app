package com.angulismotv.player

import com.google.android.exoplayer2.Player
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class StreamOptionFallbackPolicyTest {
    @Test
    fun `advances when no player is attached or the player is idle or buffering`() {
        assertTrue(shouldAdvance(playbackState = null))
        assertTrue(shouldAdvance(playbackState = Player.STATE_IDLE))
        assertTrue(shouldAdvance(playbackState = Player.STATE_BUFFERING))
    }

    @Test
    fun `does not replace a stream that has reached a stable playback state`() {
        assertFalse(shouldAdvance(playbackState = Player.STATE_READY))
        assertFalse(shouldAdvance(playbackState = Player.STATE_ENDED))
    }

    @Test
    fun `ignores stale fallback tasks after the stream or selected option changes`() {
        assertFalse(shouldAdvance(generationMatches = false))
        assertFalse(shouldAdvance(isZapping = true))
        assertFalse(shouldAdvance(channelMatches = false))
        assertFalse(shouldAdvance(optionMatches = false))
    }

    private fun shouldAdvance(
        generationMatches: Boolean = true,
        isZapping: Boolean = false,
        channelMatches: Boolean = true,
        optionMatches: Boolean = true,
        playbackState: Int? = Player.STATE_IDLE
    ): Boolean = StreamOptionFallbackPolicy.shouldAdvance(
        generationMatches = generationMatches,
        isZapping = isZapping,
        channelMatches = channelMatches,
        optionMatches = optionMatches,
        playbackState = playbackState
    )
}
