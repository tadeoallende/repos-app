package com.angulismotv.player

import org.junit.Assert.assertEquals
import org.junit.Test

class PlayerTimeFormatterTest {
    @Test fun `formats negative positions as zero`() {
        assertEquals("00:00", PlayerTimeFormatter.format(-5_000L))
    }

    @Test fun `formats minutes and seconds`() {
        assertEquals("01:05", PlayerTimeFormatter.format(65_000L))
    }

    @Test fun `formats hours when needed`() {
        assertEquals("1:01:01", PlayerTimeFormatter.format(3_661_000L))
    }
}
