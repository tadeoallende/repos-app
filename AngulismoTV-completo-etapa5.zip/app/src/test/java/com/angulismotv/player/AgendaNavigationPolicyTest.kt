package com.angulismotv.player

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class AgendaNavigationPolicyTest {
    @Test fun allowsAgendaAndTransmissionOnProductionOrigin() {
        assertTrue(AgendaNavigationPolicy.isAllowedMainFrameUrl("https://angulismotv.pages.dev/agenda"))
        assertTrue(AgendaNavigationPolicy.isAllowedMainFrameUrl("https://angulismotv.pages.dev/transmision/abc"))
    }

    @Test fun allowsConfiguredLegacyOrigins() {
        assertTrue(AgendaNavigationPolicy.isAllowedMainFrameUrl("https://angulismotv-dnh.pages.dev/agenda"))
        assertTrue(AgendaNavigationPolicy.isAllowedMainFrameUrl("https://angulismotv.workers.dev/transmision/abc"))
    }

    @Test fun rejectsLookalikeHostsAndNonHttpsUrls() {
        assertFalse(AgendaNavigationPolicy.isAllowedMainFrameUrl("https://angulismotv.pages.dev.evil.example/agenda"))
        assertFalse(AgendaNavigationPolicy.isAllowedMainFrameUrl("https://evil.example/?next=angulismotv.pages.dev"))
        assertFalse(AgendaNavigationPolicy.isAllowedMainFrameUrl("http://angulismotv.pages.dev/agenda"))
        assertFalse(AgendaNavigationPolicy.isAllowedMainFrameUrl("javascript:alert(1)"))
        assertFalse(AgendaNavigationPolicy.isAllowedMainFrameUrl(null))
        assertTrue(AgendaNavigationPolicy.isAllowedMainFrameUrl(
            "https://tv.example.org/transmision/abc", "https://tv.example.org"
        ))
        assertFalse(AgendaNavigationPolicy.isAllowedMainFrameUrl(
            "https://evil.example/transmision/abc", "https://tv.example.org"
        ))
    }
}
