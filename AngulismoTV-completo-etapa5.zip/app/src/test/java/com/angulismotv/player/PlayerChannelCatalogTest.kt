package com.angulismotv.player

import com.angulismotv.models.Channel
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class PlayerChannelCatalogTest {
    @Test
    fun `catalog is available with its published token`() {
        val channels = listOf(Channel(name = "Channel A"), Channel(name = "Channel B"))
        val token = PlayerChannelCatalog.publish(channels)

        assertEquals(channels, PlayerChannelCatalog.get(token))
    }

    @Test
    fun `older token cannot access a replaced catalog`() {
        val firstToken = PlayerChannelCatalog.publish(listOf(Channel(name = "Old catalog")))
        val latest = listOf(Channel(name = "Current catalog"))
        val secondToken = PlayerChannelCatalog.publish(latest)

        assertTrue(PlayerChannelCatalog.get(firstToken).isEmpty())
        assertEquals(latest, PlayerChannelCatalog.get(secondToken))
    }
}
