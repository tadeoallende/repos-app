package com.angulismotv.player

import com.angulismotv.models.StreamType
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class CastMediaPolicyTest {

    @Test
    fun describesHlsLiveStream() {
        val media = CastMediaPolicy.describe(
            CastStream("https://cdn.example/live/index.m3u8", StreamType.HLS, "Canal en vivo")
        )

        assertEquals("application/x-mpegURL", media?.contentType)
        assertEquals(StreamType.HLS, media?.resolvedType)
        assertTrue(media?.isLive == true)
    }

    @Test
    fun distinguishesOnDemandStreamWhenFlagIsExplicit() {
        val media = CastMediaPolicy.describe(
            CastStream("https://cdn.example/archive.m3u8", StreamType.HLS, "Repetición", isLive = false)
        )

        assertFalse(media?.isLive ?: true)
    }

    @Test
    fun describesDashAndMp4ContentTypes() {
        val dash = CastMediaPolicy.describe(
            CastStream("https://cdn.example/live/manifest.mpd", StreamType.DASH, "DASH")
        )
        val mp4 = CastMediaPolicy.describe(
            CastStream("https://cdn.example/movie.mp4", StreamType.MP4, "Película", isLive = false)
        )

        assertEquals("application/dash+xml", dash?.contentType)
        assertTrue(dash?.isLive == true)
        assertEquals("video/mp4", mp4?.contentType)
        assertFalse(mp4?.isLive ?: true)
    }

    @Test
    fun refusesIframesAndInvalidSchemes() {
        assertNull(CastMediaPolicy.describe(
            CastStream("https://player.example/embed/123", StreamType.IFRAME, "Iframe")
        ))
        assertNull(CastMediaPolicy.describe(
            CastStream("file:///storage/video.mp4", StreamType.MP4, "Archivo local")
        ))
        assertNull(CastMediaPolicy.describe(
            CastStream("ftp://cdn.example/video.mp4", StreamType.MP4, "FTP no admitido")
        ))
        assertNull(CastMediaPolicy.describe(
            CastStream("", StreamType.AUTO, "Sin fuente")
        ))
        assertNull(CastMediaPolicy.describe(
            CastStream("https://cdn.example/video.mkv", StreamType.AUTO, "MKV no compatible")
        ))
        assertNull(CastMediaPolicy.describe(
            CastStream("https://cdn.example/video.avi", StreamType.AUTO, "AVI no compatible")
        ))
    }
}
