package com.angulismotv.player

import com.angulismotv.models.StreamType
import org.junit.Assert.assertEquals
import org.junit.Test

class StreamUtilsTest {
    @Test fun detectsHlsByPathIgnoringQuery() {
        assertEquals(StreamType.HLS, StreamUtils.resolveType("https://cdn.example/live/index.m3u8?token=abc", null))
    }

    @Test fun doesNotInferFormatFromQueryParameters() {
        assertEquals(StreamType.HLS, StreamUtils.resolveType("https://cdn.example/watch?redirect=.mpd", null))
    }

    @Test fun detectsDashAndProgressiveVideo() {
        assertEquals(StreamType.DASH, StreamUtils.resolveType("https://cdn.example/live/manifest.mpd", null))
        assertEquals(StreamType.MP4, StreamUtils.resolveType("https://cdn.example/movie.mp4?token=abc", null))
    }

    @Test fun detectsYoutubeSubdomainsAsIframes() {
        assertEquals(StreamType.IFRAME, StreamUtils.resolveType("https://www.youtube.com/embed/abc", null))
        assertEquals(StreamType.IFRAME, StreamUtils.resolveType("https://youtu.be/abc", null))
    }

    @Test fun explicitSupportedTypeWins() {
        assertEquals(StreamType.DASH, StreamUtils.resolveType("https://cdn.example/live.m3u8", " DASH "))
    }

    @Test fun invalidExplicitTypeFallsBackToUrlDetection() {
        assertEquals(StreamType.MP4, StreamUtils.resolveType("https://cdn.example/video.mp4", "unknown"))
    }
}
