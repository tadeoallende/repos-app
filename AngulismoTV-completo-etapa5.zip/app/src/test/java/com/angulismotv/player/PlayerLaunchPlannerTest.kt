package com.angulismotv.player

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class PlayerLaunchPlannerTest {
    private val sourcesByChannel = mapOf("A" to 0, "B" to 3, "C" to 1)

    private fun plan(
        shared: List<String> = emptyList(),
        legacy: List<String>? = null,
        single: String? = null,
        index: Int = 0,
        source: Int = 0,
        panel: Boolean = false,
        search: Boolean = false
    ) = PlayerLaunchPlanner.plan(
        sharedCatalog = shared,
        legacyCatalog = legacy,
        singleChannel = single,
        requestedIndex = index,
        requestedSourceIndex = source,
        sourceCountOf = { sourcesByChannel[it] ?: 0 },
        openChannelPanel = panel,
        openChannelSearch = search
    )

    @Test
    fun `shared catalog wins over legacy catalog and single channel`() {
        val result = plan(shared = listOf("A", "B"), legacy = listOf("C"), single = "C", index = 1)
        assertEquals(listOf("A", "B"), result.channels)
        assertEquals("B", result.selectedChannel)
    }

    @Test
    fun `legacy catalog is used when there is no shared catalog`() {
        val result = plan(legacy = listOf("B", "C"), single = "A", index = 1)
        assertEquals(listOf("B", "C"), result.channels)
        assertEquals("C", result.selectedChannel)
    }

    @Test
    fun `single channel keeps the requested channel and ignores the stale index`() {
        val result = plan(single = "B", index = 5)
        assertEquals(listOf("B"), result.channels)
        assertEquals(0, result.channelIndex)
        assertEquals("B", result.selectedChannel)
    }

    @Test
    fun `no data at all means no selection`() {
        val result = plan()
        assertTrue(result.channels.isEmpty())
        assertNull(result.selectedChannel)
        assertNull(result.sourceIndex)
    }

    @Test
    fun `an index outside the catalog is moved into range`() {
        assertEquals(1, plan(shared = listOf("A", "B"), index = 9).channelIndex)
        assertEquals(0, plan(shared = listOf("A", "B"), index = -3).channelIndex)
    }

    @Test
    fun `a valid index is respected`() {
        assertEquals("C", plan(shared = listOf("A", "B", "C"), index = 2).selectedChannel)
    }

    @Test
    fun `requested source is kept only when the channel has it`() {
        assertEquals(2, plan(shared = listOf("B"), source = 2).sourceIndex)
        assertNull(plan(shared = listOf("B"), source = 3).sourceIndex)
        assertNull(plan(shared = listOf("B"), source = -1).sourceIndex)
    }

    @Test
    fun `a channel without sources never gets a source index`() {
        assertNull(plan(shared = listOf("A"), source = 0).sourceIndex)
    }

    @Test
    fun `source index is checked against the channel actually selected`() {
        val result = plan(shared = listOf("B", "C"), index = 1, source = 2)
        assertEquals("C", result.selectedChannel)
        assertNull(result.sourceIndex)
    }

    @Test
    fun `panel and search flags pass through untouched`() {
        val on = plan(shared = listOf("A"), panel = true, search = true)
        assertTrue(on.openChannelPanel)
        assertTrue(on.openChannelSearch)
        val off = plan(shared = listOf("A"))
        assertFalse(off.openChannelPanel)
        assertFalse(off.openChannelSearch)
    }
}
