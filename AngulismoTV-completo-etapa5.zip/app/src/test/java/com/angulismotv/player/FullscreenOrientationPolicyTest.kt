package com.angulismotv.player

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class FullscreenOrientationPolicyTest {
    @Test
    fun initialPortraitDoesNotExitFullscreen() {
        val policy = FullscreenOrientationPolicy()
        assertEquals(FullscreenOrientationPolicy.Position.PORTRAIT_BEFORE_LANDSCAPE, policy.classify(0))
        assertFalse(policy.shouldExitToInline(5))
    }

    @Test
    fun returnsToInlineOnlyAfterPhysicalLandscapeThenPortrait() {
        val policy = FullscreenOrientationPolicy()
        assertEquals(FullscreenOrientationPolicy.Position.LANDSCAPE, policy.classify(90))
        assertFalse(policy.shouldExitToInline(90))
        assertTrue(policy.shouldExitToInline(0))
    }

    @Test
    fun supportsReverseLandscapeAndUpsideDownPortrait() {
        val policy = FullscreenOrientationPolicy()
        assertEquals(FullscreenOrientationPolicy.Position.LANDSCAPE, policy.classify(270))
        assertEquals(FullscreenOrientationPolicy.Position.PORTRAIT_AFTER_LANDSCAPE, policy.classify(180))
    }

    @Test
    fun ignoresTransitionAndUnknownReadings() {
        val policy = FullscreenOrientationPolicy()
        assertEquals(FullscreenOrientationPolicy.Position.UNKNOWN, policy.classify(-1))
        assertEquals(FullscreenOrientationPolicy.Position.UNKNOWN, policy.classify(360))
        assertEquals(FullscreenOrientationPolicy.Position.TRANSITION, policy.classify(45))
        policy.classify(90)
        assertEquals(FullscreenOrientationPolicy.Position.TRANSITION, policy.classify(225))
    }
}
