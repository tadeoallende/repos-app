package com.angulismotv.player

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class ChannelNumberInputBufferTest {
    @Test
    fun `accepts digits and commits valid three digit channel immediately`() {
        val input = ChannelNumberInputBuffer()
        assertEquals("1", input.append(1, 125)?.value)
        assertEquals("12", input.append(2, 125)?.value)
        val last = input.append(5, 125)
        assertEquals("125", last?.value)
        assertTrue(last?.shouldCommitImmediately == true)
        assertEquals(125, input.takeNumber())
        assertEquals("", input.value)
    }

    @Test
    fun `invalid three digit channel waits for normal confirmation timeout`() {
        val input = ChannelNumberInputBuffer()
        input.append(9, 20)
        input.append(9, 20)
        val last = input.append(9, 20)
        assertFalse(last?.shouldCommitImmediately == true)
        assertEquals(999, input.takeNumber())
    }

    @Test
    fun `fourth digit starts a fresh entry instead of growing indefinitely`() {
        val input = ChannelNumberInputBuffer()
        input.append(1, 200)
        input.append(2, 200)
        input.append(3, 200)
        assertEquals("4", input.append(4, 200)?.value)
    }

    @Test
    fun `large catalogs accept five digit channel numbers without committing after digit three`() {
        val input = ChannelNumberInputBuffer.forChannelCount(20_000)
        assertFalse(input.append(1, 20_000)?.shouldCommitImmediately == true)
        assertFalse(input.append(2, 20_000)?.shouldCommitImmediately == true)
        assertFalse(input.append(3, 20_000)?.shouldCommitImmediately == true)
        assertFalse(input.append(4, 20_000)?.shouldCommitImmediately == true)
        val last = input.append(5, 20_000)
        assertEquals("12345", last?.value)
        assertTrue(last?.shouldCommitImmediately == true)
        assertEquals(12345, input.takeNumber())
    }

    @Test
    fun `four digit catalogs wait for timeout after three digits`() {
        val input = ChannelNumberInputBuffer.forChannelCount(1_200)
        input.append(1, 1_200)
        input.append(0, 1_200)
        val third = input.append(5, 1_200)
        assertFalse(third?.shouldCommitImmediately == true)
        val fourth = input.append(0, 1_200)
        assertTrue(fourth?.shouldCommitImmediately == true)
    }

    @Test
    fun `zero is displayed but never selects a channel and empty catalog is ignored`() {
        val input = ChannelNumberInputBuffer()
        val zero = input.append(0, 20)
        assertEquals("0", zero?.value)
        assertFalse(zero?.shouldCommitImmediately == true)
        input.clear()
        assertNull(input.append(1, 0))
        assertEquals("", input.value)
    }
}
