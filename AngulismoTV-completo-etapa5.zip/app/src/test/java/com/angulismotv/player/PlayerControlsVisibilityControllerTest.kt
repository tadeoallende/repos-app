package com.angulismotv.player

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class PlayerControlsVisibilityControllerTest {
    private val scheduler = FakeScheduler()
    private val reveals = mutableListOf<Boolean>()
    private val visibleDuringReveal = mutableListOf<Boolean>()
    private var hides = 0
    private var panelOpen = false

    private val controller: PlayerControlsVisibilityController =
        PlayerControlsVisibilityController(
            schedule = scheduler::schedule,
            cancel = scheduler::cancel,
            isSidePanelOpen = { panelOpen },
            onReveal = { temporarily ->
                reveals += temporarily
                visibleDuringReveal += controller.isVisible
            },
            onHide = { hides++ }
        )

    @Test
    fun `show marks the controls visible before running the view effects`() {
        controller.show()

        assertTrue(controller.isVisible)
        assertEquals(listOf(false), reveals)
        assertEquals(listOf(true), visibleDuringReveal)
    }

    @Test
    fun `temporary reveal is reported to the view layer`() {
        controller.showTemporarily()

        assertEquals(listOf(true), reveals)
    }

    @Test
    fun `controls hide after the auto-hide delay`() {
        controller.show()
        scheduler.advance(PlayerControlsVisibilityController.DEFAULT_AUTO_HIDE_MS - 1L)
        assertTrue(controller.isVisible)

        scheduler.advance(1L)
        assertFalse(controller.isVisible)
        assertEquals(1, hides)
    }

    @Test
    fun `user activity restarts the countdown`() {
        controller.show()
        scheduler.advance(4_000L)
        controller.resetAutoHide()
        scheduler.advance(4_000L)
        assertTrue(controller.isVisible)

        scheduler.advance(1_000L)
        assertFalse(controller.isVisible)
        assertEquals(1, hides)
    }

    @Test
    fun `an open side panel keeps the controls visible when the timer expires`() {
        controller.show()
        panelOpen = true
        scheduler.advance(10_000L)

        assertTrue(controller.isVisible)
        assertEquals(0, hides)
    }

    @Test
    fun `explicit hide cancels the timer and runs the view effects once`() {
        controller.show()
        controller.hide()
        scheduler.advance(10_000L)

        assertFalse(controller.isVisible)
        assertEquals(1, hides)
        assertEquals(0, scheduler.pendingCount)
    }

    @Test
    fun `cancelling the auto-hide leaves the controls on screen`() {
        controller.showTemporarily()
        controller.cancelAutoHide()
        scheduler.advance(60_000L)

        assertTrue(controller.isVisible)
        assertEquals(0, hides)
    }

    @Test
    fun `toggle shows when hidden and hides when visible`() {
        controller.toggleTemporarily()
        assertTrue(controller.isVisible)
        assertEquals(listOf(true), reveals)

        controller.toggleTemporarily()
        assertFalse(controller.isVisible)
        assertEquals(1, hides)
    }

    @Test
    fun `forcing the hidden state skips view effects and ignores a late timer`() {
        controller.show()
        controller.forceHiddenState()
        scheduler.advance(10_000L)

        assertFalse(controller.isVisible)
        assertEquals(0, hides)
    }
}
