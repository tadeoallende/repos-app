package com.angulismotv.player

/** Temporizador manual para probar controladores sin Handler ni Looper. */
internal class FakeScheduler {
    private data class Task(val runnable: Runnable, val dueAt: Long)

    private val tasks = mutableListOf<Task>()
    private var now = 0L

    val pendingCount: Int get() = tasks.size

    fun schedule(runnable: Runnable, delayMs: Long) {
        tasks += Task(runnable, now + delayMs)
    }

    fun cancel(runnable: Runnable) {
        tasks.removeAll { it.runnable === runnable }
    }

    /** Avanza el reloj ejecutando, en orden, las tareas vencidas (incluidas las que se programen en el camino). */
    fun advance(ms: Long) {
        val target = now + ms
        while (true) {
            val next = tasks.filter { it.dueAt <= target }.minByOrNull { it.dueAt } ?: break
            tasks.remove(next)
            now = maxOf(now, next.dueAt)
            next.runnable.run()
        }
        now = target
    }
}
