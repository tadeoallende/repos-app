package com.angulismotv.player

import com.angulismotv.models.StreamType
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class PlaybackRecoveryPolicyTest {
    @Test
    fun `retry delay follows configured progressive schedule`() {
        assertEquals(1_000L, PlaybackRecoveryPolicy.reconnectDelayMs(1))
        assertEquals(2_000L, PlaybackRecoveryPolicy.reconnectDelayMs(2))
        assertEquals(8_000L, PlaybackRecoveryPolicy.reconnectDelayMs(4))
        assertEquals(30_000L, PlaybackRecoveryPolicy.reconnectDelayMs(7))
    }

    @Test
    fun `retry delay remains capped for later attempts`() {
        assertEquals(30_000L, PlaybackRecoveryPolicy.reconnectDelayMs(8))
        assertEquals(30_000L, PlaybackRecoveryPolicy.reconnectDelayMs(100))
    }

    @Test(expected = IllegalArgumentException::class)
    fun `retry attempt must be positive`() {
        PlaybackRecoveryPolicy.reconnectDelayMs(0)
    }

    @Test
    fun `permanent HTTP responses do not trigger repeated retries`() {
        assertTrue(PlaybackRecoveryPolicy.isPermanentHttpStatus(400))
        assertTrue(PlaybackRecoveryPolicy.isPermanentHttpStatus(401))
        assertTrue(PlaybackRecoveryPolicy.isPermanentHttpStatus(403))
        assertTrue(PlaybackRecoveryPolicy.isPermanentHttpStatus(410))
        assertFalse(PlaybackRecoveryPolicy.isPermanentHttpStatus(404))
        assertFalse(PlaybackRecoveryPolicy.isPermanentHttpStatus(408))
        assertFalse(PlaybackRecoveryPolicy.isPermanentHttpStatus(429))
        assertFalse(PlaybackRecoveryPolicy.isPermanentHttpStatus(500))
    }

    @Test
    fun `only HLS and DASH retry indefinitely after the configured limit`() {
        assertTrue(PlaybackRecoveryPolicy.retryBeyondLimit(StreamType.HLS))
        assertTrue(PlaybackRecoveryPolicy.retryBeyondLimit(StreamType.DASH))
        assertFalse(PlaybackRecoveryPolicy.retryBeyondLimit(StreamType.MP4))
        assertFalse(PlaybackRecoveryPolicy.retryBeyondLimit(StreamType.IFRAME))
        assertEquals(4, PlaybackRecoveryPolicy.MAX_FINITE_RECONNECT_ATTEMPTS)
        assertEquals(15_000L, PlaybackRecoveryPolicy.STABLE_PLAYBACK_RESET_MS)
        assertEquals(5_000L, PlaybackRecoveryPolicy.NETWORK_RECHECK_INTERVAL_MS)
    }
}
