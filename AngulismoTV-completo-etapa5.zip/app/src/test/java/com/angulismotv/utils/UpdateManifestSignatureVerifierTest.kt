package com.angulismotv.utils

import java.security.KeyPairGenerator
import java.security.Signature
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class UpdateManifestSignatureVerifierTest {
    @Test
    fun acceptsSignatureForExactManifestBytes() {
        val pair = KeyPairGenerator.getInstance("RSA").apply { initialize(2048) }.generateKeyPair()
        val manifest = "{\"versionCode\":5}".toByteArray(Charsets.UTF_8)
        val signer = Signature.getInstance("SHA256withRSA").apply {
            initSign(pair.private)
            update(manifest)
        }
        val signature = signer.sign()

        assertTrue(UpdateManifestSignatureVerifier.verifyWithPublicKey(manifest, signature, pair.public))
    }

    @Test
    fun rejectsModifiedManifestAndInvalidSignature() {
        val pair = KeyPairGenerator.getInstance("RSA").apply { initialize(2048) }.generateKeyPair()
        val manifest = "{\"versionCode\":5}".toByteArray(Charsets.UTF_8)
        val signer = Signature.getInstance("SHA256withRSA").apply {
            initSign(pair.private)
            update(manifest)
        }
        val signature = signer.sign()

        assertFalse(
            UpdateManifestSignatureVerifier.verifyWithPublicKey(
                "{\"versionCode\":6}".toByteArray(Charsets.UTF_8), signature, pair.public
            )
        )
        assertFalse(
            UpdateManifestSignatureVerifier.verifyWithPublicKey(manifest, ByteArray(32), pair.public)
        )
    }
}
