package com.angulismotv.utils

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.ByteArrayInputStream

class ApkIntegrityVerifierTest {
    @Test
    fun calculatesKnownSha256ForEmptyContent() {
        val actual = ByteArrayInputStream(byteArrayOf()).use { ApkIntegrityVerifier.calculateSha256(it) }
        assertEquals("e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855", actual)
    }

    @Test
    fun calculatesKnownSha256ForAsciiContent() {
        val actual = ByteArrayInputStream("abc".toByteArray()).use { ApkIntegrityVerifier.calculateSha256(it) }
        assertEquals("ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad", actual)
    }

    @Test
    fun validatesOnlySixtyFourHexadecimalCharacters() {
        assertTrue(ApkIntegrityVerifier.isValidSha256("a".repeat(64)))
        assertTrue(ApkIntegrityVerifier.isValidSha256("A1".repeat(32)))
        assertFalse(ApkIntegrityVerifier.isValidSha256("a".repeat(63)))
        assertFalse(ApkIntegrityVerifier.isValidSha256("a".repeat(64) + "0"))
        assertFalse(ApkIntegrityVerifier.isValidSha256("g".repeat(64)))
    }

    @Test
    fun matchIsCaseInsensitiveAndRejectsWrongHash() {
        val bytes = "abc".toByteArray()
        val expected = "BA7816BF8F01CFEA414140DE5DAE2223B00361A396177A9CB410FF61F20015AD"
        assertTrue(ByteArrayInputStream(bytes).use { ApkIntegrityVerifier.matches(it, expected) })
        assertFalse(ByteArrayInputStream(bytes).use { ApkIntegrityVerifier.matches(it, "0".repeat(64)) })
        assertFalse(ByteArrayInputStream(bytes).use { ApkIntegrityVerifier.matches(it, "not-a-hash") })
    }
}
