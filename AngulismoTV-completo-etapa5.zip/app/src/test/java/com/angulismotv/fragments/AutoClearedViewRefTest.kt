package com.angulismotv.fragments

import org.junit.Assert.assertFalse
import org.junit.Assert.assertSame
import org.junit.Assert.assertTrue
import org.junit.Test

class AutoClearedViewRefTest {
    private class RefHost {
        private val reference = AutoClearedViewRef<Any>()
        var value: Any by reference
        val isInitialized: Boolean get() = reference.isInitialized
        fun clear() = reference.clear()
    }

    @Test
    fun referenceCanBeSetAndCleared() {
        val host = RefHost()
        val instance = Any()

        host.value = instance
        assertTrue(host.isInitialized)
        assertSame(instance, host.value)

        host.clear()
        assertFalse(host.isInitialized)
    }

    @Test
    fun accessAfterClearFailsFast() {
        val host = RefHost()
        host.value = Any()
        host.clear()

        val failure = runCatching { host.value }.exceptionOrNull()
        assertTrue(failure is IllegalStateException)
    }
}
