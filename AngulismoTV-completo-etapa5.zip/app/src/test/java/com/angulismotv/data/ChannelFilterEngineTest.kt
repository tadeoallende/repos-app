package com.angulismotv.data

import com.angulismotv.models.Channel
import org.junit.Assert.assertEquals
import org.junit.Test

class ChannelFilterEngineTest {
    private val channels = listOf(
        Channel(name = "ESPN Argentina", category = "Sports", country = "AR"),
        Channel(name = "Noticias Uno", category = "News", country = "CO"),
        Channel(name = "Cine Familiar", category = "Movies", country = "AR"),
        Channel(name = "ESPN Internacional", category = "Deportes", country = "US")
    )

    @Test
    fun `normalizes source categories into stable user categories`() {
        assertEquals("deportes", ChannelFilterEngine.categoryKey("Motorsport"))
        assertEquals("noticias", ChannelFilterEngine.categoryKey("Current Affairs"))
        assertEquals("peliculas", ChannelFilterEngine.categoryKey("Movies"))
        assertEquals("peliculas", ChannelFilterEngine.categoryKey("Películas"))
        assertEquals("musicales", ChannelFilterEngine.categoryKey("Música"))
        assertEquals("estilo-vida", ChannelFilterEngine.categoryKey("Travel"))
        assertEquals("internacionales", ChannelFilterEngine.categoryKey("World"))
        assertEquals("eventos", ChannelFilterEngine.categoryKey("Special Events"))
        assertEquals("otros", ChannelFilterEngine.categoryKey("Shopping"))
    }

    @Test
    fun `available categories only include categories present in catalog`() {
        assertEquals(
            listOf("todos", "deportes", "noticias", "peliculas"),
            ChannelFilterEngine.availableCategories(channels).map { it.first }
        )
        assertEquals(emptyList<Pair<String, String>>(), ChannelFilterEngine.availableCategories(emptyList()))
    }

    @Test
    fun `many source group names collapse into a concise category list`() {
        val varied = listOf(
            Channel(name = "A", category = "Sports"),
            Channel(name = "B", category = "Football"),
            Channel(name = "C", category = "Motorsport"),
            Channel(name = "D", category = "News"),
            Channel(name = "E", category = "Current Affairs"),
            Channel(name = "F", category = "Movies"),
            Channel(name = "G", category = "Film"),
            Channel(name = "H", category = "Shopping")
        )

        assertEquals(
            listOf("todos", "deportes", "noticias", "peliculas", "otros"),
            ChannelFilterEngine.availableCategories(varied).map { it.first }
        )
    }

    @Test
    fun `international lifestyle and events groups appear in the stable category order`() {
        val varied = listOf(
            Channel(name = "A", category = "Special Events"),
            Channel(name = "B", category = "Travel"),
            Channel(name = "C", category = "International")
        )
        assertEquals(
            listOf("todos", "internacionales", "estilo-vida", "eventos"),
            ChannelFilterEngine.availableCategories(varied).map { it.first }
        )
    }

    @Test
    fun `country keys and labels handle ISO codes and missing country`() {
        assertEquals("ar", ChannelFilterEngine.countryKey("AR, South America"))
        assertEquals("sin_pais", ChannelFilterEngine.countryKey("  "))
        assertEquals("Argentina", ChannelFilterEngine.countryLabel("ar"))
        assertEquals("Sin país informado", ChannelFilterEngine.countryLabel("sin_pais"))
    }

    @Test
    fun `explicit query searches all categories while preserving country filter`() {
        val result = ChannelFilterEngine.filter(
            channels = channels,
            category = "deportes",
            country = "ar",
            query = " espn "
        )
        assertEquals(listOf("ESPN Argentina"), result.map { it.name })
    }

    @Test
    fun `blank query keeps selected category filter`() {
        assertEquals(
            listOf("ESPN Argentina", "ESPN Internacional"),
            ChannelFilterEngine.filter(channels, "deportes", "todos", "").map { it.name }
        )
    }

    @Test
    fun `query searches across categories but still respects selected country`() {
        val globalSearch = ChannelFilterEngine.filter(
            channels = channels,
            category = "deportes",
            country = "todos",
            query = "Noticias Uno"
        )
        assertEquals(listOf("Noticias Uno"), globalSearch.map { it.name })

        val countryLimitedSearch = ChannelFilterEngine.filter(
            channels = channels,
            category = "deportes",
            country = "ar",
            query = "Noticias Uno"
        )
        assertEquals(emptyList<String>(), countryLimitedSearch.map { it.name })
    }

    @Test
    fun `all filters and blank query preserve catalog ordering`() {
        assertEquals(channels, ChannelFilterEngine.filter(channels, "todos", "todos", "  "))
    }
}
