package com.angulismotv.data

import com.angulismotv.models.Channel
import com.angulismotv.models.ChannelIdentity
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class LastPlayedChannelResolverTest {
    private val sports = Channel(name = "Sports", logo = "sports.png", category = "Deportes")
    private val news = Channel(name = "News", logo = "news.png", category = "Noticias")
    private val channels = listOf(sports, news)

    @Test
    fun prefersStableIdentityWhenItMatches() {
        assertEquals(news, LastPlayedChannelResolver.resolve(channels, ChannelIdentity.key(news), "Sports", "sports.png"))
    }

    @Test
    fun fallsBackToCaseInsensitiveNameAndMatchingLogo() {
        assertEquals(news, LastPlayedChannelResolver.resolve(channels, "removed-key", "nEwS", "news.png"))
    }

    @Test
    fun fallsBackToCaseInsensitiveNameWhenLogoChanged() {
        assertEquals(news, LastPlayedChannelResolver.resolve(channels, null, "NEWS", "old-logo.png"))
    }

    @Test
    fun returnsNullForAnEmptyOrUnmatchedCatalog() {
        assertNull(LastPlayedChannelResolver.resolve(emptyList(), null, "News", null))
        assertNull(LastPlayedChannelResolver.resolve(channels, null, "Unknown", null))
    }
}
