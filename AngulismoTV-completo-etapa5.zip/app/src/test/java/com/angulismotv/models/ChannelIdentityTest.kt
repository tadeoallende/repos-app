package com.angulismotv.models

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotEquals
import org.junit.Test

class ChannelIdentityTest {
    @Test
    fun sameNameAndLogoButDifferentStreamsAreDifferentChannels() {
        val first = Channel(name = "Noticias", logo = "logo.png", streamUrl = "http://one.example/live.m3u8")
        val second = Channel(name = "Noticias", logo = "logo.png", streamUrl = "http://two.example/live.m3u8")

        assertNotEquals(ChannelIdentity.key(first), ChannelIdentity.key(second))
    }

    @Test
    fun changingLogoDoesNotChangeStreamIdentity() {
        val first = Channel(name = "Canal 1", logo = "old.png", streamUrl = "http://example.com/live.m3u8")
        val second = Channel(name = "Canal 1", logo = "new.png", streamUrl = "http://example.com/live.m3u8")

        assertEquals(ChannelIdentity.key(first), ChannelIdentity.key(second))
    }

    @Test
    fun channelsWithoutDirectUrlUseAlternativeSourcesAsIdentity() {
        val first = Channel(
            name = "Canal web", logo = "logo.png",
            options = listOf(StreamOption(name = "Principal", iframe = "https://one.example/embed"))
        )
        val second = Channel(
            name = "Canal web", logo = "logo.png",
            options = listOf(StreamOption(name = "Principal", iframe = "https://two.example/embed"))
        )

        assertNotEquals(ChannelIdentity.key(first), ChannelIdentity.key(second))
    }
}
