package com.angulismotv.ui

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class PlayerPanelLayoutPolicyTest {
    @Test
    fun `keeps compact dimensions on narrow screens`() {
        val dimensions = PlayerPanelLayoutPolicy.calculate(320f)
        assertEquals(120, dimensions.menuWidthDp)
        assertEquals(96f, dimensions.channelListWidthDp, 0.01f)
        assertTrue(dimensions.menuWidthDp + dimensions.channelListWidthDp <= 320f - 104f + 0.01f)
    }

    @Test
    fun `uses wider panel on a large television`() {
        val dimensions = PlayerPanelLayoutPolicy.calculate(1920f)
        assertEquals(208, dimensions.menuWidthDp)
        assertEquals(420f, dimensions.channelListWidthDp, 0.01f)
        assertTrue(dimensions.menuWidthDp + dimensions.channelListWidthDp < 1920f)
    }

    @Test
    fun `handles invalid negative available width without negative list size`() {
        val dimensions = PlayerPanelLayoutPolicy.calculate(-20f)
        assertTrue(dimensions.channelListWidthDp >= 0f)
    }
}
