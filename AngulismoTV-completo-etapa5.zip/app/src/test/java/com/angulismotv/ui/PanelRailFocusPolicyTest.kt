package com.angulismotv.ui

import com.angulismotv.ui.PanelRailFocusPolicy.Direction
import com.angulismotv.ui.PanelRailFocusPolicy.Item
import com.angulismotv.ui.PanelRailFocusPolicy.Target
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class PanelRailFocusPolicyTest {
    @Test
    fun `down walks the rail from close to search to the channel list to categories`() {
        assertEquals(Target.SEARCH, PanelRailFocusPolicy.next(Item.CLOSE, Direction.DOWN))
        assertEquals(Target.ALL_CHANNELS, PanelRailFocusPolicy.next(Item.SEARCH, Direction.DOWN))
        assertEquals(Target.FIRST_CATEGORY, PanelRailFocusPolicy.next(Item.ALL_CHANNELS, Direction.DOWN))
    }

    @Test
    fun `up walks the rail back up`() {
        assertEquals(Target.SEARCH, PanelRailFocusPolicy.next(Item.ALL_CHANNELS, Direction.UP))
        assertEquals(Target.CLOSE, PanelRailFocusPolicy.next(Item.SEARCH, Direction.UP))
    }

    @Test
    fun `close has nothing above it so the system decides`() {
        assertNull(PanelRailFocusPolicy.next(Item.CLOSE, Direction.UP))
    }

    @Test
    fun `every item and direction pair is covered or intentionally left to the system`() {
        val handled = Item.values().flatMap { item ->
            Direction.values().mapNotNull { direction ->
                PanelRailFocusPolicy.next(item, direction)?.let { item to direction }
            }
        }
        assertEquals(5, handled.size)
    }
}
