# AngulismoTV — Catálogo argentino y búsqueda, Etapa 32

## Cambios

- La versión pasa a `versionCode 6` / `versionName 1.5` para que el actualizador reconozca esta entrega como posterior a 1.4.
- La fuente predeterminada IPTV-org usa exclusivamente `https://iptv-org.github.io/iptv/countries/ar.m3u`.
- `IptvOrgPlaylistPolicy` normaliza URL antiguas de listas oficiales IPTV-org (incluido `index.m3u`) a Argentina. `IPTV_ORG_URL=disabled` sigue desactivando esa fuente y las URLs personalizadas de otros hosts se conservan.
- El panel lateral del reproductor reutiliza las categorías normalizadas de la pantalla principal. Los `group-title` de origen se agrupan en categorías legibles en español en vez de mostrar cada grupo como categoría independiente.
- Los totales por categoría se calculan con una agrupación en una pasada, evitando recorrer todo el catálogo una vez por categoría.
- La búsqueda ignora mayúsculas, tildes y puntuación, admite términos en distinto orden y busca también en categoría y país. Se preserva el orden del catálogo.
- Las expresiones regulares de normalización se compilan una sola vez y se reutilizan.
- Se añadieron pruebas unitarias para la política de playlist argentina y los casos de búsqueda normalizada.
- El workflow de firma del manifiesto ahora ofrece `6` / `1.5` como valores predeterminados, para reducir el riesgo de firmar accidentalmente un manifiesto con una versión antigua.
- La guía de compilación indica que la fuente oficial predeterminada es Argentina.

## Límites intencionales

- Si la playlist argentina falla, se conserva el fallback JSON existente para no romper instalaciones que dependen de fuentes propias. Ese fallback no se fuerza a Argentina automáticamente.
- No se cambió globalmente el permiso de tráfico HTTP ni el modo de contenido mixto del WebView: algunos streams públicos aún pueden depender de HTTP. Se requiere una etapa aparte con pruebas por origen para endurecer esa política sin cortar reproducción.
- No se alteraron el flujo de firma RSA del manifiesto, Cast, Agenda, reproducción ni la navegación a pantalla completa.

## Publicación del APK

Después de que GitHub Actions compile la nueva versión, usá el SHA-256 del APK recién generado y firmá un manifiesto de actualización con `versionCode: 6` y `versionName: 1.5`. No reutilices el hash ni el manifiesto firmado de la versión 1.4.

## Validación

- Se revisó estáticamente el código, las pruebas añadidas y la configuración de versión.
- Se intentó `./gradlew testDebugUnitTest --no-daemon`, pero el entorno no pudo resolver `services.gradle.org` (`UnknownHostException`). Por lo tanto, **no se afirma que las pruebas o la compilación hayan pasado**.
- La validación de compilación debe hacerse en GitHub Actions; después hay que probar búsqueda, selección de categoría y reproducción en móvil y TV.
