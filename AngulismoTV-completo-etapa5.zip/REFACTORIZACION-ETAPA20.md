# AngulismoTV — Etapa 20: IPTV-org como fuente primaria

## Comportamiento

1. La aplicación consulta primero `IPTV_ORG_URL`, que por defecto usa la playlist pública principal de IPTV-org: `https://iptv-org.github.io/iptv/index.m3u`.
2. `M3uPlaylistParser` transforma entradas M3U/EXTINF en el modelo interno `Channel`: nombre visible, `tvg-logo`, `group-title`, URL del stream y tipo aproximado (HLS, DASH, MP4 o WebView cuando corresponde).
3. Si la descarga falla, la cabecera/formato no es válida o no hay entradas reproducibles, se activa el fallback existente: `CHANNELS_URL` y `EVENTS_URL` (JSON propios).
4. Si IPTV-org entrega una lista válida y no vacía, se muestra esa lista. Los feeds propios no se mezclan con la lista primaria: se conservan como respaldo, según lo pedido.

La referencia oficial indica que `index.m3u` es la lista principal con los canales del repositorio. Hay playlists separadas por país/categoría; la fuente se puede sobrescribir sin cambiar código.

## Configuración

- `IPTV_ORG_URL`: fuente primaria, por defecto `https://iptv-org.github.io/iptv/index.m3u`.
- Para restringirse a Argentina: `https://iptv-org.github.io/iptv/countries/ar.m3u`.
- Para apagar explícitamente la fuente primaria: valor literal `disabled`.
- `CHANNELS_URL` y `EVENTS_URL`: las fuentes JSON propias que se usan como fallback.

En GitHub Actions, `IPTV_ORG_URL` es un secreto opcional. Si falta o está vacío, Gradle utiliza la URL oficial por defecto. Si se establece como `disabled`, se saltea IPTV-org y se usan directamente los feeds propios.

## Límites defensivos

- La URL de la playlist debe ser HTTPS y se rechazan redirecciones finales a HTTP.
- Los streams extraídos admiten URL HTTP/HTTPS, porque algunos feeds de IPTV pueden ofrecer streams HTTP.
- La lectura tiene un límite de 32 MiB y el parser limita el catálogo a 30.000 canales.
- El parser descarta URLs que no sean HTTP/HTTPS, líneas sin una entrada `EXTINF`, y canales sin nombre; elimina duplicados por nombre/URL.
- El parser trabaja línea por línea para no crear una copia extra con todas las líneas del M3U.
- La entrada numérica del control remoto ahora admite 3, 4 o 5 cifras según el tamaño del catálogo cargado, para que el catálogo global no deje inaccesibles los canales posteriores al 999.
- La apertura de pantalla completa ya no serializa el catálogo completo en un `Intent`; esto evita `TransactionTooLargeException` con listas grandes. Si el proceso se recrea y el catálogo en memoria ya no existe, el reproductor conserva como mínimo el canal actual.

## Archivos principales

- `data/IptvOrgDataSource.kt`: descarga con cancelación y límites.
- `data/M3uPlaylistParser.kt`: parser independiente de la red.
- `data/ChannelRepository.kt`: prioridad/fallback y deduplicación.
- `player/PlayerChannelCatalog.kt`: mantiene el catálogo en memoria para evitar meter miles de objetos `Parcelable` en el `Intent` del fullscreen; el `Intent` pasa un token y el canal actual.
- `gradle` / `app/build.gradle.kts`: propiedad compilada `IPTV_ORG_URL`.
- `.github/workflows/build.yml`: pasa el secreto opcional a Gradle.
- `app/src/test/java/com/angulismotv/data/M3uPlaylistParserTest.kt`: pruebas de M3U.
- `app/src/test/java/com/angulismotv/player/ChannelNumberInputBufferTest.kt`: casos 3/4/5 cifras.

## Alcance

No se cambió la Agenda ni la lógica de reproducción. Los enlaces de IPTV-org pueden cambiar o dejar de estar activos; el fallback protege la carga del catálogo si la playlist primaria no se puede usar, pero no puede reemplazar automáticamente cada stream individual que falla durante la reproducción.
