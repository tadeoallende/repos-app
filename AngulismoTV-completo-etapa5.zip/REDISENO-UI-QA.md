# AngulismoTV — rediseño de menús, transmisión y navegación por foco (v4)

## Objetivo

Reducir superficies tipo tarjeta y bordes redundantes, integrar los controles con el degradado espacial y corregir el recorrido de foco del mando en Android TV, conservando las funciones de Canales, Agenda, zapping, búsqueda, selección de fuente y reproducción.

## Menú lateral principal (Android TV)

- Se eliminó el marco perimetral del rail. La barra usa una superficie oscura continua que se distingue del fondo espacial sin parecer una tarjeta flotante.
- La sección activa recibe un fondo cian muy tenue; el contorno brillante queda reservado para el elemento que realmente tiene foco.
- Se redujo la elevación para suavizar la sombra del menú cuando se expande sobre el contenido.
- Se definieron destinos de foco arriba/abajo explícitos entre Canales y Agenda.
- Se actualizaron las descripciones de accesibilidad para que anuncien la sección y si es la sección actual.

## Menú lateral del reproductor

- Categorías, encabezados y lista de canales comparten el degradado de la superficie del panel, sin bandas de color repetidas ni tarjetas anidadas.
- El buscador no muestra borde o relleno permanente; el tratamiento resaltado aparece al enfocarlo.
- Las filas de categorías y canales quedan transparentes cuando no están seleccionadas. La selección usa un relleno cian de baja opacidad; el anillo de foco aparece solo durante la navegación.
- Los contadores dejaron de usar un marco propio.
- Se redujeron ligeramente el logo, los márgenes y la altura de las filas del listado del reproductor para mejorar el espacio disponible en pantallas TV estrechas.

## Controles visibles de la transmisión

- Los botones secundarios son transparentes por defecto y se integran con el degradado del video. Al enfocarlos mantienen una señal clara para el D-pad y al presionarlos usan el color de acento.
- El botón principal de reproducción conserva una superficie circular discreta y un borde cian para mantener la jerarquía visual.
- Se quitaron los separadores verticales entre grupos de controles; el espaciado reemplaza las líneas divisorias.
- Se eliminó el subtítulo repetitivo “AHORA EN REPRODUCCIÓN”; se conserva logo y nombre del canal.
- Los cambios usan recursos de color centralizados y drawables XML estáticos; no se agregaron animaciones, blur ni dependencias nuevas.

## Corrección del foco que saltaba el botón de menú

El orden usado por el código para recorrer los controles no coincidía con el orden visual: `btn_menu` figuraba antes de los botones de transporte aunque aparece después de Retroceder/Reproducir/Adelantar. Por eso al avanzar desde Adelantar el mando saltaba el botón del menú y podía ir directamente a Opciones.

Ahora el recorrido lógico sigue el orden visual de izquierda a derecha:

1. Retroceder (si está disponible).
2. Reproducir/Pausar.
3. Adelantar (si está disponible).
4. Abrir menú de canales.
5. Transmitir (cuando corresponde).
6. Opciones (si hay más de una fuente).
7. Cerrar reproductor.

La lista se filtra por visibilidad, estado enfocable y habilitación. También se recalculan los `nextFocusLeftId` y `nextFocusRightId` cuando cambian las opciones de la fuente para evitar que el sistema navegue usando destinos antiguos.

Dentro del panel, el foco pasa de Categorías/Buscador a la lista al pulsar Derecha. Desde la lista, Derecha cierra el panel y devuelve el foco al reproductor en vez de dejarlo saltar a un control que esté detrás del panel. Izquierda desde la lista vuelve a Categorías; Izquierda desde Categorías cierra el panel.

## Comprobaciones estáticas realizadas

- 59 archivos XML de `app/src/main` parseados correctamente; 0 errores de sintaxis XML.
- 0 IDs duplicados dentro de los layouts.
- 0 referencias locales sin resolver en los XML modificados.
- Se comprobó que el orden `visibleControls()` coincide con el orden de los botones en `activity_unified_player.xml`.
- Se comprobó que el código recalcula las relaciones de foco izquierda/derecha al actualizar la visibilidad de los controles.
- Se verificó la existencia de los cambios de navegación del panel al pasar de categorías/lista y al regresar al reproductor.

## Limitaciones de validación

No se pudo ejecutar una compilación Android ni pruebas interactivas. `./gradlew --version` falla al intentar descargar Gradle 8.13 con `UnknownHostException: services.gradle.org`, y este entorno no tiene un Android SDK configurado. Las verificaciones son estáticas y no sustituyen una compilación ni una prueba en dispositivo/emulador.

## Pruebas recomendadas en Android Studio

1. Instalar en un Android TV o emulador y recorrer los controles de izquierda a derecha. Confirmar que la secuencia pasa por Abrir menú entre Adelantar y Opciones/Cerrar cuando esos controles están visibles.
2. Abrir el menú con el botón, recorrer Categorías, Buscador y canales; verificar que Derecha no deja el foco atrapado detrás del panel.
3. Cerrar con Izquierda desde Categorías o Derecha desde la lista y confirmar que el foco vuelve al reproductor.
4. Cambiar de canal con zapping y probar canales con imagen clara y oscura para comprobar que el degradado mantiene legibles los controles.
5. Comprobar en 720p y 1080p, especialmente los nombres de canales largos y las filas del panel lateral.
