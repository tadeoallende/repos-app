# AngulismoTV v12 — Auditoría de robustez y rendimiento

## Alcance

Base de trabajo: `AngulismoTV-movil-reproductor-v11-fix.zip`. Se mantuvieron los layouts y la estructura visual de móvil/Android TV; los cambios se concentran en carga de datos, reproducción, ciclo de vida, actualizaciones y diagnósticos.

## Cambios aplicados

### 1. Carga de canales y eventos
- Se cambió la descarga bloqueante por peticiones asíncronas de OkHttp.
- La cancelación de la coroutine cancela la llamada de red subyacente.
- Se valida que las URLs de los feeds y las fuentes de reproducción sean HTTP(S) y tengan host.
- Las respuestas JSON se limitan a 4 MiB incluso cuando el servidor no informa el tamaño.
- Se descartan canales sin nombre, fuentes inválidas y opciones repetidas.
- Se normalizan tipos de stream desconocidos y categorías vacías.
- Se eliminan duplicados exactos entre feeds y se informa si una fuente falló parcialmente.
- Se eliminó el registro de URLs completas para reducir el riesgo de exponer tokens en logs.

### 2. Recargas concurrentes
- `MainActivity` cancela la carga anterior cuando empieza una nueva.
- Se agregó un identificador de generación para impedir que una respuesta vieja sobrescriba una recarga reciente.
- Los errores inesperados dejan la pantalla en un estado recuperable, en vez de mantener indefinidamente el indicador de carga.
- Las cancelaciones se propagan y no se presentan como errores de red.

### 3. Reproducción
- El tipo de stream se deduce por la ruta de la URL, no por coincidencias accidentales en el query string.
- Se valida el esquema y host antes de pasar una URL al reproductor.
- Se corrigió la reanudación: al volver de segundo plano solo se reanuda automáticamente si el stream estaba reproduciéndose antes; no se fuerza Play si el usuario lo había pausado.
- Se desacopla el puente JavaScript y se detiene el monitor al destruir la Activity.
- El puente valida tiempos no finitos/negativos y limita el tiempo actual a la duración reportada.
- Se dejó de borrar toda la caché de WebView al salir, evitando trabajo innecesario en la próxima apertura.
- Los logs de navegación muestran el host, no la URL completa con parámetros.

### 4. Actualizaciones
- El manifiesto y el APK deben usar HTTPS.
- Se valida el host, el número de versión, el nombre y la URL del APK antes de mostrar una actualización.
- Se limita el manifiesto a 256 KiB y se limita la longitud de notas/nombre de versión.
- Se admite una redirección únicamente si el destino final continúa siendo HTTPS.
- El parámetro `versionCode` se agrega sin romper los parámetros existentes del endpoint.
- El nombre de archivo se sanea antes de pasarlo a DownloadManager.
- Se quitó una comprobación innecesaria de `WRITE_EXTERNAL_STORAGE`: la app descarga en una carpeta administrada por DownloadManager o en el directorio externo privado de la app.
- Se verifica el permiso de Android para instalar paquetes y se ofrece abrir la configuración correspondiente.
- El executor de comprobación se comparte para evitar crear un hilo persistente por cada instancia.

### 5. Red y adaptadores
- Se quitó el interceptor HTTP de logging del cliente compartido para evitar que las URLs de streams y sus parámetros aparezcan en logs; los logs de WebView ahora identifican el host en vez de registrar la URL completa.
- `NetworkUtils` ahora falla de forma segura si el servicio de conectividad no está disponible y distingue conectividad declarada de conectividad validada.
- El adaptador ignora toques sobre filas que ya no pertenecen al RecyclerView (`NO_POSITION`).

### 6. Pruebas añadidas
- Pruebas unitarias para detección HLS/DASH/MP4, embeds de YouTube, parámetros de URL y tipos explícitos desconocidos.

## Verificaciones realizadas

- 71 archivos XML parseados correctamente.
- Balance básico de llaves e imports duplicados revisados en los archivos Kotlin modificados.
- Prueba de humo JVM de `StreamUtils`: correcta.
- `ChannelRepository.kt` compilado de forma aislada contra stubs de sus dependencias para validar sintaxis y tipos Kotlin básicos.
- No se pudo ejecutar Gradle/Android build: el entorno no resuelve `services.gradle.org` (`UnknownHostException`). Por lo tanto, no se afirma que el APK compile hasta ejecutar CI o una compilación local.

## Riesgos pendientes que requieren decisión/validación real

1. **WebView y contenido mixto:** el reproductor permite contenido mixto para mantener compatibilidad con embeds y fuentes antiguas. Esto amplía la superficie de ataque; bloquearlo puede romper canales HTTP existentes. Lo ideal para una versión comercial es migrar las fuentes a HTTPS y endurecer esta política gradualmente.
2. **Fuentes de terceros:** una página iframe puede cambiar su comportamiento o dejar de exponer controles sin que la app pueda repararlo automáticamente. Probar con proveedores reales sigue siendo necesario.
3. **Actualizador APK:** HTTPS valida el transporte, pero el manifiesto no incorpora checksum/firma independiente. Android verifica la firma del paquete al instalar; para un canal de distribución comercial conviene publicar y validar un SHA-256 firmado o usar distribución administrada.
4. **QA en dispositivos:** falta ejecutar build Debug/Release, probar móvil y Android TV, probar mando/foco, red intermitente, feed inválido, actualización y rotación de pantalla.

## Cómo verificar en tu entorno

1. Descomprimir el ZIP en una carpeta nueva.
2. Ejecutar `./gradlew testDebugUnitTest assembleDebug assembleRelease` (Windows: `gradlew.bat testDebugUnitTest assembleDebug assembleRelease`).
3. Probar en un celular y en Android TV; verificar que Pausa se conserve al volver a la app y que una recarga cancele la anterior.
4. Revisar el workflow `Build` de GitHub Actions: compila Debug y Release y publica el APK Debug como artefacto.
