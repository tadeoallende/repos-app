# Diagnóstico de audio: fallback de decodificador y panel "Info de audio"

## Objetivo

Reducir los canales con video pero sin audio y poder diagnosticarlos sin Logcat. No agrega códecs nuevos: eso (Media3 + FFmpeg) queda pendiente hasta confirmar con datos reales que el problema es el códec.

## Cambios

- `StreamMediaSourceFactory.createRenderersFactory()`: `DefaultRenderersFactory` con `setEnableDecoderFallback(true)`. El reproductor de pantalla completa ya lo tenía; ahora también lo usa el reproductor integrado, y ambos comparten la misma fábrica.
- Panel **Info de audio** (botón con icono de parlante junto a "Opciones" en los controles de pantalla completa, solo con fuentes nativas; se oculta en iframe). Muestra modelo y Android del dispositivo, canal, tipo y host de la fuente, estado del audio y, por pista, códec, MIME, canales, frecuencia, soporte y si está seleccionada, más el último error. Nunca muestra la URL completa.
- Aviso breve (Toast) cuando el canal tiene audio pero ninguna pista es compatible con el dispositivo. No se avisa por "sin pistas": en HLS puede ser transitorio.
- `FullscreenPlayerEventController` e `InlinePlaybackEngineController` registran `onTracksChanged` y los errores de reproducción con logs `PlayerAudio` (sin URLs con tokens).
- `PlayerControlStateController` recibe el nuevo botón y lo incluye en el orden de foco del mando.

## Cómo usarlo con un usuario afectado

1. Abrir el canal sin sonido en pantalla completa.
2. Tocar o seleccionar el botón de parlante (Info de audio) y mandar una captura.
3. Interpretar: "no puede decodificar ese formato" = códec; "no expone pistas" = fuente; "pista seleccionada" con silencio = volumen o salida de audio del dispositivo.

## Validación

- Se verificó que los XML están bien formados y se revisó el diff a mano.
- **No se compiló ni se ejecutaron pruebas** (el entorno no tiene Kotlin ni acceso a Gradle). Compilar y probar en un dispositivo.
- Pruebas unitarias en `PlayerAudioDiagnosticPolicyTest`.
