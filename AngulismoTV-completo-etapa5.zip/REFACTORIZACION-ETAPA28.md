# AngulismoTV — Etapa 28: modularización de UI y verificación de APK

## Cambios

- Se extrajo el ajuste de espaciado y tamaños por dispositivo de `ChannelsFragment` a `ui/ChannelScreenLayoutController.kt`. La selección de dispositivo y la navegación siguen en el fragment; las reglas de presentación quedan separadas.
- Se extrajo la distribución horizontal/vertical de los controles fullscreen de `UnifiedPlayerActivity` a `ui/PlayerControlsLayoutController.kt`. La actividad sigue coordinando el ciclo de vida y la reproducción.
- Se aisló el cálculo y la comparación SHA-256 en `utils/ApkIntegrityVerifier.kt`; `UpdateManifestClient` y `ApkUpdateInstaller` comparten la misma validación del formato del hash.
- Cada descarga conserva el SHA-256 que le corresponde. Ya no se usa una variable mutable compartida para recordar el último hash solicitado.
- La lectura del APK y el cálculo SHA-256 ocurren en un ejecutor de fondo. El instalador del sistema solo se abre cuando la comprobación termina correctamente; si falla, se cancela la instalación.
- Se agregaron pruebas unitarias para hashes conocidos, formato hexadecimal, comparación sin distinguir mayúsculas/minúsculas y rechazo de valores incorrectos.
- Se refinó la pantalla de Android TV con un panel lateral de canales de superficie degradada, borde tenue y esquinas más coherentes con el reproductor. El estado favorito se distingue con el acento cian.
- Se mantiene el catálogo de versiones y los bundles de dependencias en `gradle/libs.versions.toml`; no se añadieron dependencias externas nuevas.

## Formato del manifiesto

El manifiesto sigue necesitando `sha256`, que debe ser el hash del APK final que se publica. En Windows se puede calcular con:

```powershell
certutil -hashfile .\app-release.apk SHA256
```

En Linux/macOS:

```bash
sha256sum app-release.apk
```

El campo `sha256` del JSON debe contener los 64 caracteres hexadecimales resultantes, sin prefijo ni espacios.

## Límite de seguridad

SHA-256 detecta que el archivo descargado no coincide con el hash esperado. Por sí solo **no autentica el manifiesto**: si un atacante puede reemplazar tanto el APK como el JSON del mismo hosting, puede publicar otro hash coincidente. Para cubrir ese escenario, la siguiente capa es una firma digital del manifiesto verificada con una clave pública embebida en la app y cuya clave privada nunca se suba al hosting ni al repositorio. La firma de publicación Android también debe mantenerse estable entre versiones.

## Validación realizada en este entorno

- `ApkIntegrityVerifier` compiló con `kotlinc` y pasó pruebas de humo con SHA-256 conocidos, comparación válida y hashes incorrectos.
- Se parsearon los 75 XML Android del proyecto sin errores.
- No se confirmó una compilación Gradle completa ni pruebas Android: este entorno no tiene Android SDK y la distribución Gradle/dependencias no está instalada localmente. Ejecutar el workflow `Build` en GitHub Actions y después probar en teléfono y Android TV antes de publicar.
