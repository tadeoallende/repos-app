# Refactorización — Etapa 15

## Objetivo

Continuar la refactorización de la app Android AngulismoTV sobre la etapa 14, reduciendo responsabilidades mezcladas y lógica duplicada sin cambiar deliberadamente la interfaz ni el flujo de reproducción. Esta etapa conserva un único módulo Gradle: separar módulos Android antes de disponer de un build verificable agregaría riesgo innecesario.

## Cambios incluidos

### Reproducción

- `player/PlaybackRecoveryController.kt`: concentra watchdog, reintentos, temporizadores y cancelación de reconexiones. Recibe el acceso al reproductor y las acciones de UI mediante callbacks.
- `player/PlaybackRecoveryPolicy.kt`: separa los límites y la estrategia de espera en una política determinista, testeable sin Android.
- `player/PlayerTimelineController.kt`: administra la barra de tiempo y las actualizaciones periódicas compartidas por el mini reproductor y pantalla completa; permite inyectar la regla de seek para conservar el comportamiento de cada contexto.
- `player/PlayerTimeFormatter.kt`: unifica el formato `mm:ss` / `h:mm:ss` para el mini reproductor y pantalla completa.
- `player/WebViewPlaybackController.kt`: mueve la navegación del WebView de reproducción, manejo de errores de página principal, fullscreen de contenido web, bridge y limpieza de ciclo de vida fuera de `UnifiedPlayerActivity`.
- `player/WebViewNavigationPolicy.kt`: centraliza las reglas de navegación principal compartidas entre el mini reproductor y pantalla completa. Mantiene el comportamiento existente: permite subrecursos y redirecciones del proveedor, y bloquea navegación principal a hosts ajenos no redireccionados.
- `player/StreamMediaSourceFactory.kt` y `player/StreamUrlPolicy.kt` (de la etapa 14): siguen siendo el punto común para construir fuentes nativas y validar URLs HTTP(S).

### Datos y catálogo

- `data/ChannelFeedDataSource.kt`: encapsula la descarga individual de un feed JSON, límite de bytes, conversión DTO→modelo y validación de URLs/opciones.
- `data/ChannelRepository.kt`: queda como coordinador de feeds concurrentes, deduplicación y resultado agregado.
- `data/ChannelCatalog.kt`: comparte filtro por categoría, búsqueda y recopilación de categorías entre la lista móvil y el panel lateral de TV, manteniendo sus reglas de mayúsculas, espacios y orden.

### Actualizaciones

- `utils/UpdateManifestClient.kt`: obtiene y valida el manifiesto remoto de actualización por HTTPS.
- `utils/ApkUpdateInstaller.kt`: controla DownloadManager, estado de descarga, errores de espacio y apertura del instalador.
- `utils/UpdateManager.kt`: conserva la coordinación, preferencia de comprobaciones y presentación de diálogos. Se eliminó una referencia a `showStoragePermissionDialog()` que no tenía implementación en el código anterior; ante un fallo de inicio de descarga se muestra el error general de descarga.

### Dependencias

- Los alias quedan agrupados por función en `gradle/libs.versions.toml` y `app/build.gradle.kts`.
- Se retiraron cuatro dependencias declaradas sin referencias en código ni recursos: ConstraintLayout, AndroidX WebKit, Lifecycle ViewModel KTX y ExoPlayer Cast extension. Se mantienen las dependencias efectivamente utilizadas por el reproductor, Cast, UI, red, JSON y pruebas.

### Pruebas añadidas

- `ChannelCatalogTest.kt`
- `PlaybackRecoveryPolicyTest.kt`
- `PlayerTimeFormatterTest.kt`
- `WebViewNavigationPolicyTest.kt`

La suite previa `StreamUtilsTest.kt` se mantiene.

## Compatibilidad y alcance

- Se conservan el módulo Gradle único, IDs de vistas, recursos, rutas de navegación y firmas públicas utilizadas por las pantallas.
- La extracción del WebView mantiene el mismo `WebView` y bridge durante el traspaso de la sesión desde el mini reproductor; no se fuerza una navegación nueva cuando corresponde reutilizar la página cargada.
- No se modificó `AgendaFragment.kt` ni el sitio web separado de Agenda.
- `UnifiedPlayerActivity` y `ChannelsFragment` siguen siendo clases grandes. La etapa reduce responsabilidades concretas y prepara el siguiente paso, pero no pretende dejar completada toda la arquitectura en una sola pasada.

## Validación

Se realizó revisión estática, validación del catálogo TOML, análisis de XML, búsqueda de referencias obsoletas y smoke checks Kotlin aislados para las funciones puras. La compilación Android y la suite JUnit completa no pudieron ejecutarse porque Gradle 8.13 no está disponible localmente y el wrapper no pudo descargarlo: `UnknownHostException: services.gradle.org`. Por lo tanto, esta entrega no se declara compilada ni se afirma que los tests JUnit hayan pasado en Gradle.
