# Etapa 14 — Refactorización de responsabilidades y dependencias

## Objetivo
Reducir lógica duplicada y centralizar reglas que afectan a varias pantallas sin cambiar la UI ni el comportamiento funcional de Canales, Agenda o el reproductor.

## Cambios

- `StreamMediaSourceFactory` centraliza la creación de `MediaSource` para HLS, DASH y MP4; mini reproductor y pantalla completa ya no mantienen dos implementaciones independientes.
- La misma clase ofrece perfiles explícitos de búfer (`INLINE` y `FULLSCREEN`), manteniendo intencionalmente distintos sus consumos de memoria/latencia.
- `StreamUrlPolicy` centraliza la validación HTTP/HTTPS de URLs de reproducción. El repositorio y los dos reproductores usan la misma regla.
- Una fuente `iframe` no se acepta como fuente nativa de ExoPlayer; se devuelve un error explícito en vez de tratarla silenciosamente como HLS.
- Las dependencias se agruparon en bundles del Version Catalog por responsabilidad: UI, reproducción, red/JSON, Cast y pruebas.
- Se retiró `logging-interceptor`, que no se utiliza en el código actual. No se agregó logging de red que pudiera exponer URLs con tokens.

## Límites intencionales

- No se dividió el proyecto en múltiples módulos Gradle todavía. Antes conviene extraer contratos/modelos y tests de las clases de UI, y contar con compilación completa en CI; mover módulos en este momento añadiría riesgo sin poder validar el build localmente.
- `ChannelsFragment` y `UnifiedPlayerActivity` siguen siendo clases grandes. La siguiente etapa debe extraer coordinadores de UI (búsqueda/foco, sesión de reproducción, overlays) en cambios pequeños y testeables.
- No se modificó `AgendaFragment` ni la WebView de agenda.

## Validación

- Validación estática de los alias y bundles del Version Catalog.
- Búsqueda de los bloques duplicados de construcción de fuentes y validadores anteriores.
- Revisión básica de balance de llaves Kotlin y XML.
- La compilación Gradle no pudo ejecutarse: el wrapper necesita descargar Gradle 8.13 y el entorno devuelve `UnknownHostException` para `services.gradle.org`.
