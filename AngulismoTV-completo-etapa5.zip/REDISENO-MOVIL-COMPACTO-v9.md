# AngulismoTV — Rediseño móvil compacto (v9)

## Objetivo

Adaptar la vista de móvil a la referencia aportada: reproducción arriba, filtros inmediatamente debajo y una lista de canales continua con poco espacio desperdiciado. Los cambios están aislados por `DeviceHelper.isTV`; Android TV conserva tamaños de lectura y espacios para mando.

## Cambios móviles

- Cabecera reducida a 48 dp, con marca alineada a la izquierda y búsqueda a la derecha.
- Se reutiliza la búsqueda existente: el campo se despliega al tocar el icono de cabecera y vuelve a ocultarse al tocarlo otra vez. Al entrar en búsqueda desde Agenda, la app vuelve a Canales.
- Se oculta el bloque redundante de título/subtítulo en móvil; la navegación inferior sigue siendo la indicación de sección.
- El campo de búsqueda desplegado mide 38 dp.
- Filtros horizontales de 32 dp, con 8 dp de margen exterior y 2 dp verticales.
- Lista móvil continua, sin tarjetas individuales permanentes: filas mínimas de 44 dp, logos de 30 dp, texto de 14 sp y 1 dp entre filas.
- Reproductor integrado casi a ancho completo, con margen de 2 dp, sin borde exterior y radios de 6 dp.
- Overlay de reproducción integrado con el degradado: controles secundarios transparentes salvo en pulsación/foco, botones de 40 dp, identidad del canal compacta y línea de tiempo de 24 dp.
- La barra inferior Canales/Agenda y el motor de reproducción se mantienen.

## No se añadió

No se incorporan Cine, Series, Favoritos, EPG ni información de programas que no exista en el modelo de AngulismoTV. Las filas solo muestran el nombre y logo reales del canal.

## Android TV

La lógica de adaptación restaura las medidas grandes de búsqueda, filtros y lista en TV. Los controles del reproductor integrado no se muestran allí; el panel de pantalla completa sigue siendo independiente.
