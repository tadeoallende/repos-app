# AngulismoTV — Etapa 36: reproductor más resiliente

## Base y alcance

Base de trabajo: **Etapa 35 — Refactor profunda**. Esta etapa se centra en los motores nativos ExoPlayer/HLS/DASH usados por el mini-reproductor y por la pantalla completa, además de su coordinación con la red y los cambios de fuente.

Se mantuvo ExoPlayer 2.19.1, los perfiles actuales de buffering, el WebView de fuentes iframe, el diseño del reproductor, la geometría del menú lateral de TV, la orientación actual y el traspaso de sesión entre mini-reproductor y pantalla completa. No se mezcló una migración de biblioteca con este cambio de comportamiento.

## Cambios

### Recuperación uniforme en mini y pantalla completa

- El mini-reproductor ahora comparte el controlador de recuperación con pantalla completa. Los errores de reproducción nativa y los bloqueos detectados por el watchdog ya no dependen exclusivamente de que el usuario pulse Recargar.
- Los errores síncronos al construir/preparar una fuente también pasan por la política de recuperación en ambos motores, en lugar de quedar fuera del flujo normal.
- Se conserva la fuente que estaba seleccionada durante los reintentos automáticos. El mini-reproductor no avanza solo a otra fuente. En pantalla completa se conserva el mecanismo previo de fallback a una opción alternativa después de 12 segundos cuando un canal tiene opciones nativas adicionales.

### Reintentos con espera progresiva

Los reintentos siguen esta pauta de espera: **1, 2, 4, 8, 12, 20 y 30 segundos**, y luego se quedan en **30 segundos**. Un único reintento puede quedar pendiente a la vez; los errores y el watchdog no consumen intentos duplicados durante esa espera.

- **HLS/DASH (normalmente transmisiones en vivo):** pueden seguir intentando recuperarse, pero con espera máxima de 30 segundos. Se elimina el ciclo previo que podía volver a intentar cada 500 ms y saturar una fuente caída.
- **Fuentes finitas, como MP4:** hasta cuatro reintentos externos; después se muestra un error claro y queda disponible la recarga/cambio manual de fuente.
- **Respuestas HTTP 400, 401, 403, 405 y 410:** se tratan como rechazo o configuración que no suele arreglarse repitiendo inmediatamente la misma URL. Se detienen los reintentos automáticos y se informa el código.
- **HTTP 404, 408, 429 y 5xx:** no se marcan automáticamente como definitivos. En HLS en vivo, un 404 puede corresponder a un recurso temporal del manifiesto/segmento; se prefiere reintentar con espera antes que declarar muerta la transmisión demasiado pronto.

La política interna de cargas de ExoPlayer se mantiene tal como estaba; estos reintentos actúan como una segunda capa cuando ExoPlayer ya notifica un error final o el watchdog detecta un bloqueo.

### Watchdog y recuperación de la reproducción

- Revisa el estado cada cinco segundos mientras el reproductor tiene intención de reproducir.
- Si permanece en `BUFFERING` durante tres revisiones, solicita recuperación.
- Si está en `READY` pero la posición permanece congelada durante dos revisiones, solicita recuperación. Si la posición vuelve a avanzar mientras espera, se cancela el reinicio pendiente.
- No interpreta una pausa deliberada ni una supresión de reproducción del sistema como una transmisión congelada.
- El contador de reintentos solo se reinicia tras 15 segundos de reproducción real y estable, no apenas el reproductor alcanza `READY`. Esto evita que una fuente que alterna rápidamente entre funcionar y fallar vuelva siempre al intervalo más corto.

### Red y estado del usuario

- Si no hay una conexión activa, se comprueba de nuevo cada cinco segundos sin consumir el presupuesto de reintentos. Cuando vuelve la conexión, se retoma el backoff desde el primer intervalo.
- La detección usa transportes de red activos y no exige la validación de Internet de Android, lo que evita descartar por defecto redes locales que pueden alojar una fuente IPTV.
- Antes de reconstruir el reproductor se vuelve a leer la intención actual de reproducción. Si el usuario pausa durante la espera, el nuevo reproductor permanece pausado; si reanuda, se conserva esa intención.
- Se cancelan tareas antiguas al cambiar canal/fuente, cerrar el mini-reproductor, pausar/ocultar el Fragment, iniciar el traspaso a pantalla completa o destruir sus vistas. Así se reduce el riesgo de que un reintento antiguo vuelva a abrir una fuente que ya no está seleccionada.

## Archivos principales modificados

- `PlaybackRecoveryController.kt`: backoff, watchdog, clasificación de HTTP, espera sin red, conservación de play/pausa y temporizadores de estabilidad.
- `PlaybackRecoveryPolicy.kt` y `PlaybackRecoveryPolicyTest.kt`: política explícita de tiempos, límites y clases de respuesta.
- `InlinePlaybackEngineController.kt` y `FullscreenPlayerEventController.kt`: aplicación de la recuperación en ambos motores.
- `ChannelsFragment.kt` y `UnifiedPlayerActivity.kt`: ciclo de vida, cambio de fuente y traspaso entre mini-reproductor y pantalla completa.
- `NetworkUtils.kt`: consulta de conexión activa para la recuperación, separada de la comprobación de Internet validado que ya existía.

## Verificaciones realizadas aquí

- **Prueba de humo de política/controlador:** pasó con 11 comprobaciones de política y cuatro escenarios del controlador: pausa durante la espera, pérdida/recuperación de conexión, límite de cuatro reintentos para fuentes finitas y error HTTP 401.
- **Compilación Kotlin aislada con stubs:** pasaron `PlaybackRecoveryController`, `InlinePlaybackEngineController` y `FullscreenPlayerEventController` contra interfaces simuladas de Android/ExoPlayer. Esto ayuda a detectar errores de sintaxis y conexiones entre esos controladores, pero **no sustituye** una compilación Android real.
- **XML:** se pudieron parsear los 75 archivos XML del proyecto.
- **Fin natural de contenido:** el mini-reproductor y pantalla completa no reinician automáticamente un HLS/DASH que terminó si ExoPlayer indica que era contenido finito; el reintento al llegar a `ENDED` queda reservado a una ventana en vivo o duración desconocida.
- **Presupuesto de reintentos finitos:** una vez agotados los cuatro reintentos externos, se detiene también el watchdog para evitar que un flujo congelado reactive nuevos ciclos detrás del mensaje de error.
- **ZIP final:** integridad comprobada con `unzip -t`.

### Verificación pendiente

No pude completar `./gradlew testDebugUnitTest` ni una compilación Android real en este entorno: el wrapper intentó descargar Gradle 8.13 desde `services.gradle.org` y falló con `UnknownHostException`. Tampoco se probó en un televisor o celular físico. La validación de compilación e instalación debe hacerse con GitHub Actions antes de instalar el APK.

## Pruebas recomendadas en el dispositivo

1. En celular, reproducir una señal HLS/M3U en el mini-reproductor, apagar la red durante unos segundos y restaurarla. Confirmar que vuelve la misma fuente y que no se pierde el diseño vertical.
2. En una fuente HLS/DASH de contenido bajo demanda, dejar que llegue al final. Confirmar que no se reinicia desde el principio; para una señal en vivo, comprobar que `ENDED` inicia recuperación.
3. Mientras hay un reintento pendiente, pausar el reproductor. Confirmar que al recuperarse la fuente sigue pausada; luego reanudar manualmente.
4. Repetir en pantalla completa con el control remoto: navegación D-pad, botones visibles, foco, pausa/reanudación y regreso al mini-reproductor sin audio duplicado.
5. Probar una fuente que responde HTTP 401/403 y una con fallos transitorios. Confirmar que los errores de autorización muestran un mensaje accionable y que un 404 no se convierte inmediatamente en error terminal.
6. Probar un MP4 que no responda y una señal HLS caída. Verificar los cuatro reintentos de fuentes finitas y la espera progresiva limitada a 30 segundos para HLS/DASH.
7. Cambiar de canal o fuente durante un reintento, salir de pantalla completa y ocultar la pantalla. Confirmar que no se revive la fuente anterior.
8. Probar un iframe/WebView y Cast para comprobar que los flujos existentes siguen intactos.

## Referencias de diseño

- Android documenta la política de errores de carga como el mecanismo que determina si una carga se reintenta, cuánto se espera y cuándo debe tratarse como fatal: [LoadErrorHandlingPolicy](https://developer.android.com/reference/androidx/media3/exoplayer/upstream/LoadErrorHandlingPolicy).
- ExoPlayer distingue intención de reproducir (`playWhenReady`), estado del reproductor y supresión de reproducción; la recuperación usa esas señales para no confundir una pausa con una transmisión congelada: [Player.java, ExoPlayer release-v2](https://github.com/google/ExoPlayer/blob/release-v2/library/common/src/main/java/com/google/android/exoplayer2/Player.java).
- Las guías de Android TV recomiendan navegación predecible por D-pad y foco accesible en todos los controles: [Navegación en Android TV](https://developer.android.com/training/tv/get-started/navigation).
