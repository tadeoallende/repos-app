# Etapa 31 — Firma digital del manifiesto de actualización

Esta etapa hace que AngulismoTV rechace manifiestos sin firma válida. La firma es un archivo Base64 separado, con el mismo nombre del JSON y el sufijo `.sig` (por ejemplo, `update.json` y `update.json.sig`). Ambos deben servirse desde HTTPS.

## La clave pública

La clave pública que compartiste quedó en `app/src/main/res/raw/update_public_key.pem`. Es pública y se incorpora a la aplicación para verificar firmas. La clave privada **no** se incluye en el proyecto.

El workflow espera que el secreto de GitHub se llame exactamente `UPDATE_PRIVATE_KEY_PEM`. Antes de firmar, compara la clave pública derivada del secreto con la clave integrada en la app; si no coinciden, aborta.

## Cómo preparar una actualización desde el navegador

1. Ejecutá **Actions → Build** y descargá el artefacto `AngulismoTV-debug`. Incluye el APK y `SHA256SUMS.txt`.
2. Subí el APK a un enlace HTTPS directo y estable. Copiá el hash de ese archivo desde `SHA256SUMS.txt`.
3. Abrí **Actions → Firmar manifiesto de actualización → Run workflow**.
4. Completá el nombre del manifiesto, versión, URL pública del APK, hash SHA-256, notas y si será obligatoria. El archivo de salida debe coincidir con el nombre final del manifiesto al que apunta `UPDATE_URL`; si `UPDATE_URL` termina en `update.json`, usá `update.json`.
5. Ejecutá el workflow y descargá el artefacto `manifiesto-firmado`. Subí **sin editar ni volver a formatear** los dos archivos que contiene al mismo directorio público: `update.json` y `update.json.sig` (con el nombre elegido).
6. La aplicación solicita la firma en `UPDATE_URL + .sig`, en la misma ruta y con la extensión `.sig`. Por ejemplo, para `https://ejemplo.com/update.json`, buscará `https://ejemplo.com/update.json.sig`.

El nombre exacto y los bytes importan: cualquier cambio en el JSON después de firmarlo invalida la firma. No firmes APK distinto del que apuntás en `apkUrl`; el hash que se firma debe ser del mismo archivo publicado.

## Comprobaciones adicionales

- `versionCode` de la nueva versión debe superar el `versionCode` del APK instalado.
- El APK debe estar firmado con el mismo certificado Android que la aplicación ya instalada; de lo contrario Android rechazará la instalación aunque la firma del manifiesto y el SHA-256 sean correctos. La variante `debug` de un runner efímero puede usar una clave de depuración distinta, así que no la des por apta para actualizar instalaciones existentes sin probarla.
- La firma digital protege la autenticidad del manifiesto. El SHA-256 comprueba la integridad del APK descargado. Son verificaciones diferentes y ambas son necesarias.
- Si la app ya está distribuida, necesitarás compilar e instalar esta nueva versión con la clave de firma Android adecuada. La verificación de la firma del manifiesto no se añade retroactivamente a APK ya instalados.

## Validaciones incluidas

- Firma RSA con SHA-256 sobre los bytes exactos del manifiesto.
- HTTPS obligatorio para JSON, firma y APK.
- Verificación de firma previa al análisis JSON y al uso de los campos.
- Verificación del SHA-256 del APK antes de invocar el instalador.
- Tamaño limitado para el manifiesto y la firma.
- El workflow no genera salida firmada si falta el secreto o si la clave privada no coincide con la pública integrada.

## Alcance de la comprobación

Se incorporaron pruebas unitarias para verificar aceptación de una firma válida y rechazo si el contenido cambia. El build completo debe confirmarse en GitHub Actions; la integración no se debe considerar validada en un dispositivo hasta comprobarlo en un celular/TV.
