# AngulismoTV — Etapa 33: auditoría y mejoras conservadoras

**Fecha:** 21 de octubre de 2026  
**Base:** ZIP de la Etapa 32, corrección de búsqueda/playlist argentina  
**Objetivo:** mejorar búsqueda, reducción de categorías, consumo en segundo plano y robustez sin rediseñar las funciones ya probadas.

## Resumen ejecutivo

Esta etapa aplica cambios pequeños y reversibles en la capa de catálogo y en dos ciclos de vida. No se modifica la geometría del reproductor ni se cambia el motor de reproducción. La seguridad de los embeds y la publicación del APK quedan identificadas como riesgos para una etapa dedicada, porque un cambio brusco puede romper streams existentes o las actualizaciones instaladas.

## Cambios incluidos

### 1. Búsqueda global y estado de filtros

- Al escribir una consulta, la búsqueda ignora el chip de categoría previamente seleccionado y lo restablece visualmente a **Todos**.
- Se mantiene el filtro de país, cuando hay uno elegido.
- Al estar cerrada u oculta la búsqueda, el filtrado ignora el texto residual.
- Al cambiar el texto se cancela la tarea diferida anterior. El callback pendiente comprueba la generación de la vista y que el campo siga visible antes de cambiar la lista.
- La búsqueda de nombre conserva la normalización de tildes, puntuación y orden de palabras. Se añaden sinónimos para categorías internacionales, estilo de vida y eventos.

### 2. Catálogo con categorías acotadas

- La normalización de `group-title` quita marcas diacríticas antes de clasificar, así `Películas` y `Musica` no generan grupos distintos por acentos.
- `International`, `Travel`, `Special Events` y sus equivalentes normalizados se asignan a categorías visibles estables.
- El listado dinámico queda limitado a las categorías definidas por la app más `Todos` (14 opciones máximas en el orden configurado), en lugar de crear un chip por cada `group-title` de la playlist.

### 3. Watchdog de reproducción

- El monitor no interpreta una pausa intencional como una emisión congelada.
- Se cancela el watchdog si se invalida la generación, entra el proceso de zapping o ya no hay reproductor.
- El listener de ExoPlayer reinicia el monitor cuando `playWhenReady` vuelve a activarse, y `onStop()` lo detiene al abandonar la actividad.

### 4. Agenda / WebView

- La WebView de Agenda se pausa cuando la actividad se pausa o el fragmento queda oculto, y se reanuda cuando vuelve a ser visible.
- Los errores de imágenes, anuncios e iframes no deben reemplazar el estado de toda la Agenda: el error en pantalla se reserva a fallos de navegación principal.
- Se conserva el cierre existente (`stopLoading`, separación del padre, retirada del puente JavaScript y `destroy`) al destruir la vista.

### 5. Versión del proyecto

- `versionCode`: **7**
- `versionName`: **1.6**

Esto solo versiona el código del ZIP. **No** se ha generado ni firmado aquí un `update.json` de producción; debe hacerse después de obtener el APK real y calcular su SHA-256. El workflow de firma que ya está en la raíz del repositorio puede seguir mostrando por defecto `6` / `1.5`: hasta reemplazar ese workflow por la versión nueva, al ejecutarlo manualmente se deben elegir explícitamente `version_code=7` y `version_name=1.6`.

## Hallazgos pendientes, por prioridad

### P0 — El workflow externo puede compilar otro ZIP

El archivo `.github/workflows/build.yml` de la **raíz del repositorio `repos-app`** selecciona `ls *.zip | head -1`. Si quedan dos ZIP con prefijo `00-`, la etapa vieja puede ganar por orden alfabético. El workflow raíz no se actualiza al subir este ZIP, porque está fuera del proyecto extraído.

**Antes de subir esta etapa:** quitar el ZIP antiguo `00-...etapa32...zip` de la raíz, o cambiar el workflow raíz para compilar exactamente el ZIP modificado en el commit. Abrir el resumen de Actions y comprobar que imprima el nombre `00-AngulismoTV-etapa33-auditoria-optimizacion.zip`.

El workflow raíz también publica actualmente `app-debug.apk` aunque compile `release` como comprobación R8. Para distribución de actualizaciones, conviene pasar a APK de release firmado con un keystore estable de GitHub Secrets, verificar la huella del certificado y publicar solo ese artefacto. La firma RSA del manifiesto y el SHA-256 del APK son controles diferentes de la firma Android que permite actualizar la app existente.

### P1 — WebView y contenido HTTP

- `AndroidManifest.xml` declara `android:usesCleartextTraffic="true"`.
- `PlayerWebViewSettings.kt` usa `MIXED_CONTENT_ALWAYS_ALLOW`.
- `WebViewNavigationPolicy.shouldBlockTopLevelNavigation()` permite cualquier navegación marcada como redirección antes de comparar hosts.

Esto mantiene compatibilidad con ciertos embeds públicos, pero amplía la superficie de navegación. No se cambia automáticamente en esta etapa porque puede dejar streams en negro. Siguiente paso recomendado: telemetría de hosts reales, pruebas de regresión por fuente, allowlist de host/redirecciones y limitar contenido mixto donde sea compatible. Nunca aceptar errores TLS para “arreglar” una fuente.

### P1 — Actualizador y certificado

El código verificador comprueba `SHA256withRSA` sobre los bytes exactos del manifiesto y el instalador compara el SHA-256 del APK antes de abrir el instalador. Eso es una buena base. Falta asegurar el circuito completo de publicación: APK release firmado de forma reproducible, certificado Android estable, manifiesto con la URL/hash reales, firma RSA generada al final y prueba de actualización sobre una versión ya instalada.

### P2 — Migración gradual a Media3

El proyecto utiliza `com.google.android.exoplayer2` 2.19.1. La guía oficial indica que ExoPlayer independiente está descontinuado y recomienda migrar a AndroidX Media3. No se migró en esta etapa: en AngulismoTV el reproductor está acoplado con Cast, el mini-reproductor, el traspaso a pantalla completa y el control por mando. Conviene hacerlo en una rama/etapa aparte con pruebas en TV y móvil.

### P2 — SDK objetivo

El proyecto tiene `compileSdk = 36` pero `targetSdk = 34`. Para distribución directa por GitHub esto no bloquea la instalación por sí mismo. Si se publica o actualiza en Google Play, los requisitos vigentes desde el 31 de agosto de 2026 distinguen móvil (Android 16/API 36 para nuevas apps y actualizaciones) de Android TV (API 34). Para móvil ya publicada, API 34 queda por debajo del nivel 35 requerido para disponibilidad a nuevos usuarios con Android más reciente. La elevación del target debe ser una etapa planificada: puede cambiar la navegación Atrás, el tratamiento de ventanas/edge-to-edge y el comportamiento de WebView.

### P2 — Rendimiento medido, no supuesto

Hay perfiles de buffer de 10–45 s para mini-reproductor y 15–60 s para pantalla completa. No se redujeron sin mediciones: los tiempos de buffer no equivalen a una cantidad fija de RAM y una reducción agresiva puede aumentar cortes en conexiones inestables. La siguiente auditoría debería medir memoria PSS/Native Heap, tiempo de primera imagen, rebuffering y cambios de canal en un teléfono y TV de gama baja.

## Verificación ejecutada en este entorno

- Integridad del ZIP base: `unzip -t` sin errores.
- XML de Android: **75 archivos parseados; 0 errores de XML**.
- Compilación local de las piezas puras de catálogo/búsqueda con `kotlinc` y dobles de modelo: **13 comprobaciones smoke pasaron**.
- Intento de `./gradlew testDebugUnitTest --offline --no-daemon`: **no ejecutado** porque el wrapper intentó descargar Gradle 8.13 y el entorno falló con `UnknownHostException: services.gradle.org`.

Por eso **no se declara compilación Gradle, tests JUnit de la app ni prueba real en un dispositivo**. Deben verificarse en GitHub Actions y luego con mando y táctil.

## Lista de prueba de regresión

### Celular

1. Elegir una categoría, abrir el buscador y escribir un nombre que esté en otra categoría: debe aparecer y el chip activo volver a `Todos`.
2. Escribir una consulta, cerrar el buscador, reabrirlo vacío y confirmar que el texto anterior no filtra la lista.
3. Seleccionar un país y repetir la búsqueda global: el país debe seguir limitando resultados.
4. Iniciar un canal, pausar/reanudar, pasar a pantalla completa solo con el botón y volver sin cortar ni duplicar la sesión.
5. Abrir Agenda, volver a Canales y confirmar que el contenido de Agenda no sigue actualizándose visiblemente en segundo plano.

### Android TV

1. Navegar por lista, categorías, búsqueda y reproductor exclusivamente con D-pad/Select/Back.
2. Comprobar que el foco siempre es visible, que la lista sigue desplazándose con un elemento enfocado y que Atrás vuelve al nivel anterior.
3. Probar reproducción, pausa deliberada, cambio de canal, error de fuente y vuelta a la lista.
4. Cambiar entre Canales y Agenda varias veces y observar RAM, lentitud o reinicios.

## Referencias oficiales

- Android: [gestión de memoria y ciclo de vida de WebView](https://developer.android.com/develop/ui/views/layout/webapps/manage-webview-memory).
- Android TV: [principios y pruebas de navegación con D-pad](https://developer.android.com/training/tv/get-started/navigation) y [criterios de calidad de TV](https://developer.android.com/docs/quality-guidelines/tv-app-quality).
- AndroidX: [guía de migración de ExoPlayer a Media3](https://developer.android.com/media/media3/exoplayer/migration-guide).
- Google Play: [requisitos de target SDK vigentes](https://developer.android.com/google/play/requirements/target-sdk).
