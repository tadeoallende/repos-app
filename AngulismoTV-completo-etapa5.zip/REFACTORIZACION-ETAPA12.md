# Etapa 12 — Rediseño del panel del reproductor

## Objetivo
Reorganizar visualmente la barra inferior para que tenga jerarquía clara, separación entre identidad del canal, controles principales y acciones secundarias.

## Cambios
- Superficie oscura más sobria, borde sutil y esquinas más suaves.
- Identidad del canal agrupada en logo, nombre y etiqueta secundaria.
- Controles de reproducción agrupados al centro.
- Menú, Cast, opciones y cierre agrupados como acciones secundarias.
- La barra se eleva por encima de las superficies de vídeo y WebView.
- Al finalizar la carga de un WebView en TV, la barra se presenta temporalmente y vuelve a ocultarse mediante el temporizador habitual.
- `showControls()` y `showControlsTemporarily()` muestran el panel independientemente del motor de reproducción.

## Conservación
- No se modificó la lógica de navegación de categorías/canales ni el redimensionamiento del vídeo al abrir el panel lateral.
- Se conservaron los IDs usados por Kotlin; el layout del reproductor tiene 38 IDs únicos.
- La lógica de reproducción y selección de fuente se mantiene.

## Validación
- XML parseado correctamente.
- Integridad del ZIP pendiente tras empaquetado.
- No se pudo completar la compilación local: el wrapper de Gradle intenta descargar Gradle 8.13 y el entorno no tiene acceso a `services.gradle.org`. Compilar con GitHub Actions y probar en TV/celular antes de considerar la etapa validada.
