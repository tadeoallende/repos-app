# AngulismoTV — Gestión de canales, etapa 26

## Cambios

- Se sustituyó la tira dinámica de cientos de `group-title` por un máximo de diez categorías generales: Deportes, Noticias, Películas, Series, Infantiles, Musicales, Documentales, Educativos, Entretenimiento y Otros, además de Todos.
- Se añadió un selector compacto `País: ...` que abre una lista seleccionable, en vez de añadir decenas o cientos de países a la tira horizontal.
- El filtro de país usa `tvg-country` cuando la playlist lo proporciona. Si no existe, intenta inferir el código ISO a partir del sufijo de `tvg-id` (por ejemplo, `canal.ar`). Los canales sin metadatos quedan bajo `Sin país informado`.
- El catálogo JSON propio también acepta el campo opcional `country`.
- Se agregó una prueba del parser para ambos caminos de lectura de país.
- Se mantiene IPTV-org como fuente principal y el catálogo JSON propio como fallback. No se modificó la Agenda ni se bloquearon streams HTTP.

## Verificaciones

- 72 archivos XML parseados: 0 errores.
- ZIP comprobado con `unzip -t`: sin errores.
- No fue posible ejecutar Gradle/tests: el wrapper intentó descargar Gradle 8.13 y el entorno no pudo resolver `services.gradle.org` (`UnknownHostException`). La compilación y la navegación real en dispositivos siguen pendientes de validar.

## Nota sobre la cobertura por país

La precisión del filtro depende de los metadatos presentes en la fuente. Cuando un canal no informa el país y su `tvg-id` no tiene un sufijo ISO reconocible, se muestra en `Sin país informado`; no se inventa un país por el nombre del canal.
