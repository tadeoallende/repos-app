# AngulismoTV — Rediseño del menú del reproductor y overlay (v8)

## Objetivo

Adaptar la jerarquía de navegación de la referencia aportada por el usuario a las funciones reales de AngulismoTV, manteniendo la paleta espacial y evitando fondos, tarjetas o acciones que no existen en la aplicación.

## Menú lateral del reproductor (Android TV)

- Cabecera «Canales» con cierre del panel.
- Acción rápida «Buscar canales», con campo de búsqueda desplegable.
- Acción fija «Lista de canales», que muestra el catálogo completo sin duplicar la categoría «Todos» dentro de la lista dinámica.
- Sección «Categorías» alimentada por las categorías presentes en el catálogo.
- Columna contigua con la lista de canales filtrada, selección actual y acceso a opciones de fuente cuando el canal las ofrece.
- Se conservan el número de canales, el conteo por categoría y la identificación del canal seleccionado.
- No se añaden acciones ficticias para favoritos, suscripciones ni programación electrónica, ya que esas funciones no existen en el modelo actual.

## Overlay de reproducción

- La línea de tiempo se integra dentro de la misma banda degradada que los controles; deja de ser un elemento flotante separado.
- La identidad del canal usa su logo, nombre y categoría real del catálogo.
- Los controles conservan únicamente acciones implementadas: retroceder/adelantar cuando la fuente lo permite, reproducir/pausar, menú de canales, Cast en dispositivos compatibles, opciones de fuente y cerrar.
- En orientación vertical móvil, el overlay coloca la identidad arriba y los grupos de acciones debajo para preservar el espacio del nombre.
- En horizontal y Android TV, la identidad y las acciones quedan en una misma fila.

## Foco con D-pad

- Arriba/abajo entre Buscar y Lista de canales tiene destinos explícitos.
- Abajo desde Lista de canales lleva a la primera categoría; arriba desde la primera categoría vuelve a Lista de canales.
- Derecha desde Buscar abre la búsqueda; derecha desde una acción/categoría entra en los canales; derecha desde la lista vuelve al vídeo cerrando el panel.
- Izquierda desde la lista devuelve el foco a la acción o categoría actual.
- Al seleccionar una categoría se filtra la lista y el foco vuelve al canal actual dentro del filtro, o al primer canal disponible.

## Consideraciones de rendimiento

- Sin nuevas dependencias, fondos animados, blur ni animaciones de escala.
- Las listas siguen usando RecyclerView y DiffUtil.
- La UI se adapta mediante parámetros de layout en función de la orientación, sin recrear el reproductor ni cambiar el motor de reproducción.
