# QA — Etapa 20

## Verificaciones completadas

**14 comprobaciones unitarias aisladas pasaron** (6 del parser M3U, 6 de numeración y 2 del catálogo compartido).

- Los seis tests de `M3uPlaylistParserTest` se ejecutaron en un harness aislado: OK.
- Los seis tests de `ChannelNumberInputBufferTest`, incluidos los casos dinámicos de cuatro y cinco cifras, se ejecutaron en el mismo harness aislado: OK.
- Los dos tests de `PlayerChannelCatalogTest` verifican acceso por token y rechazo de tokens antiguos cuando se publica un catálogo nuevo.
- Se compilaron aisladamente `M3uPlaylistParser`, `StreamUtils`, `IptvOrgDataSource` y `ChannelRepository` con stubs de los tipos Android/OkHttp/capa de feeds para comprobar la sintaxis y el tipado de Kotlin: OK. Esta comprobación no sustituye el build real Android.
- Smoke check de parseo M3U con metadatos y tipos de stream: OK.
- Se compiló de forma aislada `PlayerChannelCatalog.kt` con el modelo simulado para confirmar la API de token usada por ambas Activities.
- Catálogo `gradle/libs.versions.toml`: válido.
- Los XML del proyecto se analizan correctamente.
- El workflow contiene `testDebugUnitTest`, `assembleDebug` y `assembleRelease`; se agregó `IPTV_ORG_URL` a las variables de entorno Gradle.
- Búsqueda estática: no queda ninguna referencia a `showStoragePermissionDialog`.
- ZIP final: se verificará su integridad al empaquetar la entrega.

## No verificado en este entorno

`./gradlew testDebugUnitTest --stacktrace` no pudo iniciar: Gradle Wrapper necesitaba descargar Gradle 8.13 y falló con `UnknownHostException: services.gradle.org`. Por eso no afirmo que el build Android completo, la suite JUnit ejecutada por Gradle o el ensamblado debug/release hayan finalizado correctamente. GitHub Actions deberá confirmarlos en un entorno con acceso a Gradle.

## Cobertura que queda para la prueba en dispositivo

Confirmar carga real desde Internet de `index.m3u`, cambio de categorías en una lista grande, reproducción de varias URL, fallback desconectando/bloqueando la fuente principal, consumo de memoria y respuesta al cambio de orientación en móvil.
