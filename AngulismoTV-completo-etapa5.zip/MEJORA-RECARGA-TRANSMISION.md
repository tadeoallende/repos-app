# Mejora de reproductor — botón Recargar transmisión

## Qué cambia
- Se agrega un botón de recarga con icono de flecha circular a la barra de controles del reproductor a pantalla completa.
- También se incluye en la barra del reproductor integrado del celular, para reintentar una señal sin tener que abrir pantalla completa.
- Mantiene el lenguaje visual existente: mismo fondo, tamaño, tintado, espaciado y respuesta al foco que los demás controles.
- En Android TV, el control de pantalla completa forma parte del recorrido DPAD/OK. El reproductor integrado de TV mantiene su interfaz despejada; cuando se abre pantalla completa, Recargar está disponible en sus controles.
- La acción reintenta la fuente que está activa sin cambiar de canal ni probar automáticamente otra opción. En WebView/iframe fuerza una navegación nueva; en reproducción nativa vuelve a preparar el stream.
- Ante un error del reproductor integrado en celular o del reproductor completo, los controles permanecen visibles para facilitar el reintento. Tras pulsar Recargar vuelve a habilitarse el autocierre normal de la barra.
- La selección de canal, la fuente IPTV-org principal y el fallback JSON no se modifican.

## Archivos modificados para la recarga
- `app/src/main/res/layout/activity_unified_player.xml`
- `app/src/main/res/layout/fragment_channels.xml`
- `app/src/main/res/layout/fragment_channels_tv.xml`
- `app/src/main/res/drawable/ic_refresh.xml` (nuevo)
- `app/src/main/java/com/angulismotv/UnifiedPlayerActivity.kt`
- `app/src/main/java/com/angulismotv/fragments/ChannelsFragment.kt`

## Verificación
- En la auditoría posterior se validaron sintácticamente los 72 XML del proyecto (cero errores).
- La compilación Gradle y las pruebas completas siguen pendientes: el entorno no puede descargar Gradle 8.13 porque no resuelve `services.gradle.org`.
