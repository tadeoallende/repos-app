# UnifiedPlayerActivity — Etapa 3: panel lateral de TV

Refactor sin cambio de comportamiento: apertura/cierre y foco del panel lateral salen de la Activity.

## Qué se movió

| Antes (en la Activity) | Ahora |
|---|---|
| `isPanelOpen`, `openSidePanel`, `closeSidePanel` | `TvSidePanelController` (`isOpen`, `open`, `close`, `toggle`) |
| `moveFocusToCategoriesPanel`, `moveFocusToChannelsList`, `focusFirstCategory`, `isRightPanelFocused`, `isDescendantFocused` | `TvSidePanelController` |
| Tabla de foco vertical del rail (cerrar, buscar, lista de canales) | `PanelRailFocusPolicy` (lógica pura) + `TvSidePanelController.handleVerticalFocus` |

La Activity conserva lo que le pertenece y se lo pasa al controlador por lambdas: tamaño de pantalla, canal actual, vista enfocada y qué hacer al cerrar (`restorePlayerFocus()` y reinicio del auto-ocultado de controles, igual que antes).

## Comportamiento conservado

- Ancho del panel calculado con `PlayerPanelLayoutPolicy` y textos "Buscar"/"Canales" según el ancho en dp.
- Sin datos todavía: el foco va al buscador.
- Al cerrar: se desactiva la búsqueda, se colapsa el ancho y se devuelve el foco al reproductor.
- Foco vertical del rail: Cerrar ↓ Buscar ↓ Lista ↓ primera categoría, y de vuelta hacia arriba; cualquier otro caso lo resuelve el sistema.
- El controlador lee `isTV` en cada uso (no al crearse), porque la Activity lo asigna en `onCreate`.

## Pruebas nuevas

`PanelRailFocusPolicyTest` (4 casos): recorrido hacia abajo, hacia arriba, sin destino sobre "Cerrar" y cobertura exacta de la tabla (5 transiciones manejadas). El resto del controlador depende de vistas reales y queda para pruebas en dispositivo.

## Validación

Revisión manual del diff y búsqueda de referencias sueltas. **No se compiló ni se ejecutaron pruebas** (sin Kotlin/Gradle en el entorno). Probar en un TV: abrir/cerrar el panel con el botón de menú y con el mando, y navegar el rail con arriba/abajo.

## Siguiente

Etapa 4: visibilidad y auto-ocultado de controles.
