# QA — Recargar transmisión

## Pruebas manuales recomendadas
1. En celular, seleccionar un canal y usar Recargar desde el reproductor integrado; verificar que conserva canal y fuente.
2. En celular, abrir un canal iframe en el reproductor integrado y recargar: el documento debe navegar de nuevo.
3. Simular una fuente inválida o desconectarse de internet: con el error visible, Recargar debe seguir accesible.
4. En celular, repetir los casos anteriores en pantalla completa.
5. En Android TV, abrir el reproductor completo, navegar con DPAD hasta Recargar y activarlo con OK.
6. Confirmar que la barra vuelve a ocultarse tras una recarga cuando ya no hay error.
7. Comprobar orientación, transferencia de sesión, selección de canal, cambio de fuente y cierre normal tras recargar.

## Verificaciones estáticas
- 72 XML de recursos analizados: cero errores sintácticos.
- 864 referencias a recursos revisadas con inventario local: cero sin resolver.
- Gradle y pruebas completas no confirmadas porque la descarga de Gradle 8.13 falla por DNS en `services.gradle.org`.
