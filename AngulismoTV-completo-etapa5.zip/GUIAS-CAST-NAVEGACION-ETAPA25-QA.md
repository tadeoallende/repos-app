# QA — Etapa 25

## Comprobaciones estáticas

- Validar XML de recursos.
- Verificar integridad del ZIP.
- Revisar que los dos usos de `CastController` suministren callbacks válidos y que el parámetro nuevo tenga valor por defecto para compatibilidad.
- Confirmar que la Agenda, el catálogo IPTV-org, el fallback JSON y la política de orientación no fueron editados.

## Pruebas manuales necesarias

1. En móvil, abrir Cast y verificar el mensaje de búsqueda, conectar, enviar una fuente compatible y observar el resultado.
2. Rechazar o elegir una fuente no compatible y comprobar que el aviso explica qué hacer.
3. Interrumpir la red durante Cast y comprobar el mensaje de reconexión/desconexión.
4. En el reproductor integrado, comprobar que el estado se ve en la guía sin tapar el video ni los controles.
5. En Android TV, navegar solo con DPAD: subir/bajar por canales, OK para vista previa, volver al video y probar entrada numérica si el mando la soporta.
6. Confirmar que los mensajes de Cast no alteran la selección de canal ni provocan navegación inesperada.

## Resultado y límites

Las comprobaciones estáticas pueden realizarse localmente. La compilación completa depende de que Gradle y sus dependencias estén disponibles; no declarar build correcto si no se ejecuta. No se ha validado en un Chromecast/Android TV físico en esta revisión.

## Validaciones realizadas en este entorno

- 71 archivos XML: 0 errores de sintaxis.
- ZIP: `unzip -t` finalizó sin errores.
- `./gradlew testDebugUnitTest --offline --stacktrace`: no llegó a ejecutar tareas; el wrapper intentó obtener Gradle 8.13 y falló con `UnknownHostException: services.gradle.org`. Por tanto, compilación y tests quedan sin confirmar.
