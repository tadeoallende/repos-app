# UnifiedPlayerActivity — Etapa 2: zapping y entrada numérica de canal

Refactor sin cambio de comportamiento: se mueve la lógica de cambio de canal fuera de la Activity.

## Qué se movió

| Antes (en la Activity) | Ahora |
|---|---|
| `zapTo`, `changeChannel`, `dispatchPendingZap`, `scheduleChannelZap`, `cancelPendingZappingReset`, `isZapping`, acumulador y runnables | `PlayerZappingController<T>` |
| `appendChannelNumberDigit`, `commitChannelNumberInput`, buffer y temporizador de dígitos | `ChannelNumberEntryController` |
| `showZappingOverlay`, `hideZappingRunnable` | `ZappingOverlayController` |

La Activity conserva solo lo que depende del motor y las vistas, en dos callbacks:
- `beginZapTransition(channel)`: detiene la reproducción actual, prepara el WebView, muestra progreso y overlay.
- `applyZappedChannel(index, channel)`: fija el canal elegido, actualiza identidad/favorito e inicia la reproducción.

## Comportamiento conservado

- Dos pasos con las mismas esperas (300 ms hasta aplicar el canal, 200 ms hasta liberar el zapping).
- Pulsaciones CH+/CH- durante una transición: se acumulan y se aplican juntas al terminar.
- Entrada numérica: 3, 4 o 5 cifras según el catálogo; se confirma al completar un número válido, con OK o a los 1,5 s.
- Recarga manual: cancela la transición y descarta pulsaciones acumuladas (`reset()`).
- `onDestroy()` y el retorno al mini-player siguen cancelando los temporizadores pendientes.

## Pruebas nuevas (JVM, sin emulador)

Los controladores reciben el temporizador por lambdas, así que se prueban con un `FakeScheduler`:
- `PlayerZappingControllerTest` (9 casos): vuelta al inicio/final, secuencia de dos pasos, acumulación y neto, neto cero, reset, catálogo vacío, cancelación, dispose y cambio explícito que reemplaza a uno pendiente.
- `ChannelNumberEntryControllerTest` (10 casos): confirmación por tiempo, número completo, reinicio del tiempo, OK, número fuera de rango, mismo canal, ignorar durante zapping, catálogo vacío, 4 cifras y reconfiguración.

## Validación

Revisión manual del diff y simulación a mano de cada prueba contra el código. **No se compiló ni se ejecutaron las pruebas** (sin Kotlin/Gradle en el entorno): correr `./gradlew testDebugUnitTest` y probar zapping con el mando en un TV.

## Siguiente

Etapa 3: apertura/cierre del panel lateral y su foco.
