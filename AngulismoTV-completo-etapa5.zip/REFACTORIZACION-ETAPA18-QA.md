# QA — Etapa 18

## Controles realizados

- XML de `activity_unified_player.xml` y `side_menu_item_bg.xml` revisados; la validación XML general se ejecuta en el chequeo al empaquetar.
- Verificada por búsqueda la ausencia del estado `state_selected` en `side_menu_item_bg.xml` y la conservación de los estados `state_focused` y `state_pressed`.
- Verificado que el indicador tiene `layout_gravity="center"`, fondo transparente, tipografía 32sp y sombra, sin drawable de tarjeta.
- La lógica Kotlin de selección de canales no se cambió.
- ZIP comprobado con `unzip -t`.

## Pendiente

No se ejecutó compilación Android: las etapas previas documentaron que Gradle Wrapper no pudo descargar Gradle 8.13 por fallo DNS en el entorno. Confirmar el build con GitHub Actions y observar el rail con el mando y la entrada numérica en un dispositivo real.
