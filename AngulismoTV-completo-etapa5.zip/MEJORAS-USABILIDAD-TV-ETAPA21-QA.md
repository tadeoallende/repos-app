# QA — etapa 21

## Cambios estáticos comprobados

- Rail: `dispatchKeyEvent` resuelve `menuChannels`/`menuAgenda` por foco y llama a `navigateTo` con el destino correspondiente.
- Identidad: no quedan comparaciones `name + logo` en los puntos principales de selección, numeración, vista previa y restauración de foco de los archivos modificados.
- Vista previa/fullscreen: confirmar el canal que ya está reproduciéndose llama a `launchPlayerActivity(..., fromInline = true)`, reutilizando el handoff existente.
- Catálogo: se evita usar el índice 0 como sustituto cuando el canal no se encuentra en el snapshot original.
- Accesibilidad: una única `contentDescription` incluye número y disponibilidad de fuentes.
- Se añadieron tres pruebas unitarias para `ChannelIdentity`.
- Los XML se validaron con parser XML y el ZIP final con `unzip -t`.

## No comprobado

- Compilación/test Android: no se pudo iniciar Gradle 8.13 por DNS (`services.gradle.org` no resolvió).
- Mando físico, repeticiones de OK, HDMI-CEC, streams reales HTTP/HTTPS e iframes: requieren pruebas en un dispositivo real.

## Matriz manual recomendada

1. Rail enfocado en Agenda → derecha → debe entrar en Agenda; repetir desde Canales.
2. Abrir una señal desde la lista → debe aparecer la vista previa; volver a confirmar esa fila → fullscreen sin reiniciar el stream.
3. Volver de fullscreen → foco en la fila/categoría coherente, sin saltar a otra señal con nombre/logo repetidos.
4. Probar dos señales con igual nombre y logo, pero URL diferente; cada una debe conservar selección/número propio.
5. Probar una señal HTTP, una HTTPS y una iframe; verificar que no cambia la política de carga ni el handoff.
6. Probar lista filtrada, categorías y búsqueda en el panel lateral del reproductor.
7. Ejecutar workflow CI: `testDebugUnitTest`, `assembleDebug`, `assembleRelease`.
