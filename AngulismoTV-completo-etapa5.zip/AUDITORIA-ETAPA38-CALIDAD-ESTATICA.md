# AngulismoTV — Etapa 38: auditoría estática de calidad y seguridad

## Base y alcance

- Base: `00-AngulismoTV-etapa37-ui-frutiger-aero-espacial.zip`.
- Revisión estática de los 62 archivos Kotlin de `app/src/main` (aprox. 10.920 líneas), manifiesto, configuración Gradle, recursos XML, actualizador, reproductor WebView/ExoPlayer, Cast y ciclos de vida.
- Esta etapa no rediseña la interfaz ni modifica deliberadamente el flujo de reproducción.

## Limpieza aplicada

Se eliminaron únicamente tres recursos drawable que no tenían referencias en el código, layouts, manifiesto ni configuración:

- `app/src/main/res/drawable/search_trigger_bg.xml`
- `app/src/main/res/drawable/ic_menu_panel.xml`
- `app/src/main/res/drawable/bg_player_title_chip.xml`

No se eliminaron layouts, iconos de launcher ni clases Kotlin por inferencia. El detector estático puede producir falsos positivos con recursos usados mediante ViewBinding, por eso `activity_main.xml` se conservó.

## Comprobaciones realizadas

- Los 75 XML del proyecto se analizaron con un parser XML: no se encontraron errores de sintaxis.
- No se encontraron declaraciones duplicadas de clases/objetos/interfaces de nivel superior con el escaneo aplicado.
- No se encontraron claves privadas, keystores o patrones habituales de tokens de GitHub/AWS dentro del ZIP.
- La clave pública de verificación se mantiene en recursos de la aplicación; no se encontró una clave privada en el proyecto.
- El ZIP de entrada pasó `unzip -t` sin errores. El ZIP de salida debe validarse también después de empaquetar.
- Se revisaron los puntos de liberación de `ExoPlayer`, `WebView`, callbacks `Handler`, `BroadcastReceiver`, `Cast`, jobs de catálogo y referencias de vistas de Fragment. El código tiene limpieza explícita en los principales ciclos de vida; esta revisión estática no demuestra ausencia absoluta de fugas en ejecución.

## Controles de seguridad revisados

- El manifiesto de actualización exige HTTPS.
- El cliente de actualización valida la firma RSA del manifiesto antes de interpretar el JSON y limita el tamaño de las respuestas.
- Las redirecciones del actualizador no pueden bajar de HTTPS a HTTP.
- El enlace de descarga del APK también exige HTTPS y el SHA-256 se compara antes de abrir el instalador.
- `WebView` deshabilita el acceso a archivos y contenido local y rechaza errores de certificado TLS.
- `CrashReporter` solo se instala en builds debug.

## Riesgos residuales que no se cambiaron

1. `android:usesCleartextTraffic="true"` y `MIXED_CONTENT_ALWAYS_ALLOW` amplían la superficie de riesgo. Se mantienen porque las fuentes IPTV/embeds existentes pueden usar HTTP o contenido mixto; quitarlos globalmente podría dejar canales sin reproducir. Una restricción más fuerte requeriría inventariar y probar las fuentes reales.
2. JavaScript está habilitado en WebView y se expone un puente JavaScript limitado a controles/estado del reproductor. Es necesario para los embeds compatibles. No se detectó una interfaz que permita ejecutar código arbitrario desde JavaScript, pero la seguridad final depende de los hosts y páginas de terceros cargados.
3. El permiso `REQUEST_INSTALL_PACKAGES` es necesario para el actualizador integrado. Debe conservarse el flujo de manifiesto firmado y hash de APK en futuras modificaciones.
4. Se observaron algunos recursos sin referencias y se quitaron solo tres con ausencia de referencias comprobada. No se hizo una eliminación masiva de recursos porque las referencias dinámicas y generadas pueden producir falsos positivos.

## Validación que queda pendiente

No fue posible ejecutar `./gradlew testDebugUnitTest`: el wrapper intentó descargar Gradle 8.13 desde `services.gradle.org` y el entorno respondió `UnknownHostException`. Por tanto, **no se afirma que esta etapa compile ni que los tests hayan pasado**. El workflow de GitHub Actions debe ejecutar los tests, `assembleDebug` y `assembleRelease`; después conviene probar la reproducción en móvil y Android TV.

## Pruebas de regresión recomendadas

1. Compilar con el workflow actual y confirmar tests + debug + release.
2. Abrir canales HLS/MP4 e iframe; probar cambiar canal, fuentes, pausa, recarga y Cast.
3. Probar mini-reproductor vertical y pantalla completa en móvil, más navegación D-pad en Android TV.
4. Probar actualización válida, firma incorrecta, hash incorrecto y URL no HTTPS; los casos inválidos deben detener la instalación.
