# UnifiedPlayerActivity — Etapa 1: auditoría y correcciones seguras

Alcance: solo correcciones de bajo riesgo. No se mueve código entre clases (eso empieza en la etapa 2).

## Correcciones

1. **Favoritos inalcanzables con el mando de TV.** `btnFavoriteChannel` se hacía enfocable en TV pero no estaba en la lista de controles que usa `PlayerControlFocusController` (izquierda/derecha lo saltaban) ni en `activateFocusedControl`. Ahora está en ambos, entre "Opciones" y "Recargar", igual que en el layout.
2. **Diálogos sin ciclo de vida.** Los diálogos de fuentes e "Info de audio" no se cerraban si la Activity se destruía con uno abierto (riesgo de `WindowLeaked`). Ahora pasan por `showManagedDialog()`, que guarda la referencia, evita duplicados y se cierra en `onDestroy()`.
3. **Índice de canal fuera de rango.** Con un catálogo no vacío y un `channel_index` inválido se mostraba "No hay canales disponibles". Ahora el índice se ajusta al rango válido (`coerceIn`).
4. **Orden del archivo.** Se renombraron los encabezados de sección repetidos (SIDE PANEL y WEBVIEW aparecían dos veces).

## Observaciones sin cambiar (a verificar en dispositivo o en etapas siguientes)

- En TV, `OnBackPressedCallback` no hace nada: el botón Atrás se resuelve solo en `dispatchKeyEvent`. Conviene probar el gesto/tecla Atrás en dispositivos con Android 13+.
- `onDestroy()` usa `recovery` (lazy) después de `recovery.dispose()`; hoy es inofensivo porque solo llama a funciones de parada, pero conviene encapsularlo.
- `loadChannelData()` mezcla lectura del Intent, selección del canal y arranque de reproducción.

## Plan de etapas

- Etapa 2: zapping y entrada numérica (`zapTo`, `scheduleChannelZap`, overlay, buffer de dígitos) a un controlador propio.
- Etapa 3: apertura/cierre del panel lateral y su foco.
- Etapa 4: visibilidad y auto-ocultado de controles.
- Etapa 5: carga de datos del Intent y diálogos.

## Validación

Revisión manual del diff. No se compiló ni se ejecutaron pruebas (sin Kotlin/Gradle en el entorno).
