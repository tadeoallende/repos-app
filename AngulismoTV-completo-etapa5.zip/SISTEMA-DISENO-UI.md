# Sistema de diseño visual de AngulismoTV

## Dónde personalizar
- app/src/main/res/values/colors.xml: paleta Aqua espacial, superficies, contraste y estados.
- app/src/main/res/values/dimens.xml: escalas de espaciado/tipografía y tamaños adaptados a móvil y Android TV.
- app/src/main/res/values/styles.xml: estilos comunes de textos, chips y controles del reproductor.
- app/src/main/res/layout/item_channel.xml e item_channel_tv.xml: filas de canales en XML para móvil y TV.
- app/src/main/res/layout/item_category.xml e item_category_tv.xml: medidas de chips en XML.
- Selectores de estado en res/drawable y res/color: colores de selección de categorías definidos en XML.
- app/src/main/res/drawable/: fondos, bordes, selectores de foco y estados de interacción.
- app/src/main/res/layout/view_tv_side_menu.xml: estructura del rail de navegación exclusivo de Android TV.
- app/src/main/res/layout/: estructura de las pantallas; mantener referencias a tokens compartidos.

## Componentes conectados
Botones de acción y transporte del reproductor, acción primaria, carga/error, zapping, cronología, identidad del canal, controles inline, búsqueda de cabecera, chips, nombre/número de canal, conteos y reloj. Las decisiones de visibilidad y foco por modo de reproducción están en PlayerControlStateController; las medidas fijas se centralizan en dimens.xml y Kotlin conserva la orquestación de sesión.

## Reglas
1. Ajustar primero un token común; crear una excepción por pantalla solo cuando sea necesaria.
2. Mantener separado layout (estructura), styles (apariencia), drawables (fondos/estados) y Kotlin (comportamiento).
3. En Android TV, el foco visible y la navegación D-pad son obligatorios.
4. Mostrar el reloj de la cabecera únicamente en Android TV; mantenerlo oculto en móvil.
5. Conservar la reproducción, favoritos, recarga, pantalla completa, Cast, selección de fuente, orientación y navegación existentes.
6. Mantener el vídeo en negro real; evitar blur, partículas y animaciones permanentes para no elevar el coste gráfico.

Esta es una primera etapa incremental: prioriza los componentes repetidos y los valores más propensos a cambios globales. La extracción adicional de lógica de ChannelsFragment y UnifiedPlayerActivity debe hacerse separando responsabilidades con pruebas, no con una sustitución masiva.
