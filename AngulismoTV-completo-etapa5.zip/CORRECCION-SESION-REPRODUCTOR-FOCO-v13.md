# AngulismoTV v13 — continuidad del reproductor y foco de Android TV

Esta revisión parte de **AngulismoTV v12 Robustez**. La Agenda (WebView independiente) no se modificó.

## 1. Mantener la sesión al pasar a pantalla completa

- En Android TV, el reproductor nativo del mini-player se transfiere a `UnifiedPlayerActivity` como la misma instancia de ExoPlayer.
- Cuando la URL y el tipo de fuente coinciden, la actividad de pantalla completa conecta esa instancia al `PlayerView` sin volver a establecer el `MediaSource` ni llamar a `prepare()`. Esto conserva posición, estado y búfer cuando el origen lo permite.
- Al cerrar la pantalla completa, la sesión vuelve al fragmento con el canal, fuente, intención de reproducción y motor actuales; la instancia no se libera por duplicado.
- Se restaura el ciclo de vida del WebView del fragmento incluso después de una sesión nativa, para que seleccionar posteriormente un iframe no se encuentre con la vista suspendida.
- Para fuentes iframe, se transfiere el WebView activo durante el flujo TV, en vez de crear otra página que vuelva a cargar. Si durante pantalla completa se cambia a una fuente nativa, el iframe anterior se descarga para evitar audio de fondo.
- Si no se puede abrir la actividad, se restaura la sesión ofrecida, incluido el WebView si había sido separado del fragmento.

## 2. Foco y activación repetida de canales

- Se eliminó el desplazamiento automático al inicio de la lista al seleccionar una vista previa.
- El canal activo se reconoce por identidad de canal, no solo por la posición visible del `RecyclerView`.
- Una segunda activación del mismo canal mientras la vista previa ya está activa no destruye y recrea el reproductor. Esto evita reinicios de búfer y reduce el riesgo de que una pulsación larga/repetida desplace el foco.
- El adaptador guarda el último canal enfocado además del índice, para poder restaurar el foco después de cambios de lista o al volver de pantalla completa.
- Los cambios de categoría esperan el commit de `AsyncListDiffer` antes de pedir el foco de vuelta; si el canal enfocado ya no pertenece a la categoría, el foco vuelve a la categoría seleccionada.
- Se corrigió una referencia `focusedChannelKey` que en la v12 quedaba fuera de ámbito; ahora la identidad se captura dentro de la operación de categoría que la utiliza.
- Los clics resuelven el elemento desde la lista actual del adaptador para reducir carreras con actualizaciones de lista.

## 3. Limpieza adicional

- Las sesiones transferidas que resulten obsoletas limpian sus recursos de forma centralizada, incluyendo el WebView separado.
- Cambiar de iframe a reproducción nativa comprueba qué vista estaba realmente activa, en vez de fiarse del tipo de fuente que pudo haber sido actualizado previamente en la selección.

## 4. Alcance

No se cambiaron layouts ni lógica de la Agenda. Los cambios de esta revisión se concentran en `ChannelsFragment`, `ChannelsAdapter`, `UnifiedPlayerActivity` y `InlinePlayerHandoff`.

## 5. Limitaciones conocidas

La transferencia intenta conservar la sesión. El comportamiento exacto del iframe depende del proveedor externo y de sus scripts; no puede garantizarse continuidad si el sitio bloquea la reutilización, se recarga internamente o el WebView requiere permisos/estado no exportable.
