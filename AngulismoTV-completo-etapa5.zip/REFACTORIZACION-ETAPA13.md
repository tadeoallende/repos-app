# Etapa 13 — Reproductor móvil integrado y controles adaptativos

## Cambios
- En móviles, al seleccionar un canal desde la pantalla vertical de Canales, el vídeo aparece integrado encima de la lista en lugar de abrir siempre una actividad horizontal.
- La cabecera y el buscador de la sección se ocultan mientras el mini reproductor está activo para reservar espacio a la lista.
- La barra del mini reproductor tiene nombre/logo del canal, play/pausa para reproducción nativa, selector de fuente cuando hay alternativas, pantalla completa y cierre.
- Se incorpora una línea de tiempo sólo para fuentes nativas que exponen duración y búsqueda; se oculta para iframes y transmisiones no buscables.
- Al pasar el teléfono a horizontal mientras se reproduce un canal integrado, se abre la pantalla dedicada. Al regresar físicamente a vertical desde esa pantalla, se vuelve al mini reproductor.
- La pantalla de reproducción móvil permite la rotación del dispositivo; Android TV mantiene el reproductor fijado en horizontal.
- En el reproductor dedicado, los controles vuelven a mostrarse cuando termina de cargar el WebView, incluso si la página tarda más que el temporizador inicial. La vista personalizada de vídeo web se aloja dentro del contenedor del reproductor para que la barra propia pueda dibujarse encima.
- El reproductor dedicado respeta el índice de fuente seleccionada al pasar desde el mini reproductor.

## Elementos conservados
- No se alteraron los adaptadores ni los datos de canales.
- El menú lateral de TV conserva las columnas contiguas y el comportamiento de reducción del área de vídeo.
- La lógica de selección de categorías, búsqueda y navegación principal se conserva.

## Validación
- Los XML del proyecto se analizaron correctamente y no quedaron referencias `R.id` sin declaración.
- Se revisó sintaxis Kotlin; el compilador de Gradle no pudo ejecutarse en este entorno porque falta descargar Gradle 8.13 y no hay conexión disponible.
- La compilación APK y la prueba real en móvil/TV quedan pendientes de GitHub Actions y del dispositivo.
