# AngulismoTV — UX guiada, etapa 24

## Cambios
- Se agregó una guía compacta para el control remoto en la barra inferior del reproductor fullscreen de Android TV. Solo aparece en TV, junto con los controles, y conserva los colores tipográficos existentes.
- Cuando falla una fuente en el reproductor fullscreen, el mensaje ahora explica cómo volver a intentarlo usando Recargar. La redacción cambia según sea TV o móvil.
- En el reproductor integrado, los errores también explican la acción de recarga; en TV indica seleccionar Recargar y en móvil tocar el botón ↻.
- Se preservaron los flujos de reproducción, Cast, fuentes, orientación, navegación de Agenda y selección de canales.

## Criterio de UX
Las guías aparecen donde la acción es relevante; no se añadió un tutorial persistente que tape el contenido. En Android TV la guía solo ocupa espacio cuando ya están visibles los controles. En móvil, la instrucción adicional aparece solo ante un error.
