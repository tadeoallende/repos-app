# AngulismoTV — Etapa 16

## Numeración clásica de canales y prevención de la regresión de compilación

### Numeración del mando

- Los canales se muestran con su número de posición en la lista global tanto en la lista principal como en el panel lateral del reproductor.
- En Android TV, desde el reproductor a pantalla completa y con el panel lateral cerrado, los dígitos del mando permiten introducir el número de canal. Se aceptan teclas numéricas superiores y del teclado numérico.
- La entrada admite hasta tres cifras, muestra el número mientras se escribe y confirma con OK/Enter o automáticamente después de 1,5 segundos sin nuevas teclas.
- Una entrada válida de tres cifras se confirma inmediatamente. Los números fuera del catálogo no cambian el canal.
- Se extrajo el estado de entrada a `ChannelNumberInputBuffer`, una clase Kotlin sin dependencias Android, y se añadieron pruebas unitarias para los límites principales.

### Error de compilación informado

El error de GitHub Actions era `Unresolved reference: showStoragePermissionDialog` en `UpdateManager.kt`. En esta versión no hay llamadas ni referencias a ese símbolo. El manejo de error de descarga queda en el callback existente del instalador, que muestra el diálogo de error de descarga. Se agregó un chequeo de referencias al informe QA.

### CI de GitHub

El workflow `.github/workflows/build.yml` ejecuta ahora, en este orden:

1. `./gradlew testDebugUnitTest --stacktrace`
2. `./gradlew assembleDebug --stacktrace`
3. `./gradlew assembleRelease --stacktrace`

Se conserva Java 17, Gradle Wrapper 8.13 y el setup de Android SDK. Así el repositorio valida primero las pruebas y luego ambas variantes de empaquetado en cada push y pull request.

### Alcance y limitaciones

No se modificó la Agenda. No se cambió el comportamiento de reproducción ni la transferencia de sesión del mini reproductor. La compilación Android completa no pudo ejecutarse en este entorno porque el wrapper no logra resolver `services.gradle.org` por DNS. Por lo tanto, la ejecución real de `testDebugUnitTest`, `assembleDebug` y `assembleRelease` debe confirmarse en GitHub Actions al subir esta versión; no se declara como compilación exitosa local.
