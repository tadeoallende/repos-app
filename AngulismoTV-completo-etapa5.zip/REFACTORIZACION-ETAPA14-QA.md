# QA — Refactorización etapa 14

## Revisiones estáticas
- [x] El catálogo de dependencias declara todos los alias usados por los bundles.
- [x] Mini reproductor y pantalla completa usan `StreamMediaSourceFactory`.
- [x] La validación de URL se centralizó en `StreamUrlPolicy` para repositorio y reproducción.
- [x] Eliminada dependencia `logging-interceptor` no usada.
- [x] XML del proyecto parseable.
- [x] ZIP íntegro.

## Pendiente
- [ ] `./gradlew testDebugUnitTest`
- [ ] `./gradlew assembleDebug`
- [ ] `./gradlew assembleRelease`
- [ ] Prueba real en Android TV y móvil.

Motivo del bloqueo del build en este entorno: no se puede resolver `services.gradle.org` para descargar Gradle 8.13. Las revisiones estáticas no garantizan compilación.
