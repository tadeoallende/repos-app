# AngulismoTV — Etapa 27: favoritos, TV y actualizador

## Implementado
- Botón de favoritos en el reproductor, con estrella vacía/llena y descripción accesible según el estado.
- Persistencia local de favoritos mediante `FavoritesStore`, con clave estable basada en `ChannelIdentity`; no depende de la posición del canal en el catálogo.
- El estado del botón se actualiza al cambiar de canal y al abrir el reproductor.
- En Android TV, el botón entra en el orden de foco; los controles tienen una ampliación breve y discreta al recibir foco para hacer más visible la selección.
- El manifiesto de actualizaciones ahora exige el campo `sha256` (64 caracteres hexadecimales). Se rechazan manifiestos que no lo incluyan.
- Después de descargar el APK y antes de abrir el instalador, se calcula SHA-256 sobre el archivo descargado y se compara en tiempo constante con el valor esperado. Si no coincide, no se inicia la instalación.

## Formato del manifiesto de actualización
El JSON remoto debe incluir, además de los campos existentes, un hash del APK exacto que se publicó:

```json
{
  "versionCode": 123,
  "versionName": "1.2.3",
  "apkUrl": "https://example.com/angulismotv.apk",
  "sha256": "<64 caracteres hexadecimales del SHA-256 real del APK>",
  "releaseNotes": "Mejoras y correcciones",
  "forceUpdate": false
}
```

El valor de ejemplo no es un hash válido para publicar: debe reemplazarse por el SHA-256 calculado del APK final. Sin este campo válido, las actualizaciones se rechazan de forma segura.

## Límite de seguridad importante
SHA-256 detecta corrupción o diferencias entre el APK y el hash publicado, pero si un atacante puede modificar tanto el APK como el manifiesto servido desde el mismo hosting, también puede reemplazar el hash. Para protegerse de un hosting/manifiesto comprometido, la siguiente capa recomendada es firmar el manifiesto digitalmente con una clave privada fuera del servidor y verificar la firma con una clave pública embebida en la app. La firma Android del APK también debe seguir validándose por el instalador del sistema y conservar el mismo certificado de publicación.

## Modularidad
Se extrajo la persistencia de favoritos a `data/FavoritesStore.kt`, evitando mezclar el almacenamiento con la lógica de reproducción. El proyecto ya dispone de componentes separados para Cast, recuperación, política de URLs, fuentes multimedia y repositorio de catálogo. `UnifiedPlayerActivity` y `ChannelsFragment` todavía contienen bastante lógica heredada; conviene dividirlas en etapas pequeñas con pruebas por cada extracción para evitar regresiones en Cast, WebView, orientación, zapping y Android TV. Esta etapa no simula una refactorización total de esas clases.

## Validación
Se validaron los XML y la integridad del ZIP. La compilación de Gradle y las pruebas instrumentadas no se consideran confirmadas en este entorno; hay que ejecutar `./gradlew testDebugUnitTest` y probar el APK en móvil y Android TV antes de publicar.
