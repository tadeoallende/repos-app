# AngulismoTV — mejoras de usabilidad Android TV (etapa 21)

## Cambios incluidos

1. **Rail lateral:** la flecha derecha ahora navega a la opción del rail que realmente tiene el foco visual (Canales o Agenda), aunque la sección todavía no se haya confirmado con OK.
2. **Identidad de canal centralizada:** se agregó `ChannelIdentity`, que prioriza URL y tipo de stream; para canales sin URL directa usa las fuentes alternativas y, como último recurso, datos descriptivos. Se usa en DiffUtil, foco recordado/restaurado, marca de vista previa, numeración, selección de canales del reproductor y zapping.
3. **Fullscreen con menos pasos:** volver a confirmar una fila que ya está reproduciéndose en la vista previa de TV abre fullscreen transfiriendo la sesión activa, en lugar de no hacer nada o reiniciar el stream.
4. **Catálogo más seguro al abrir fullscreen:** si el canal no aparece en la instantánea del catálogo por una actualización, se agrega al catálogo entregado al reproductor en lugar de seleccionar silenciosamente el canal de índice cero.
5. **Selección segura desde el panel del reproductor:** no inicia zapping si el canal no se puede resolver en el catálogo actual.
6. **Descripción accesible:** la descripción de la fila conserva el número del canal y anuncia de forma coherente si tiene reproducción directa, fuentes alternativas o ninguna fuente configurada.
7. **Pruebas unitarias:** agregadas pruebas de `ChannelIdentity` para señales con igual nombre/logo pero URL distinta, logos cambiantes y canales de iframe sin URL directa.

## Compatibilidad preservada

- IPTV-org continúa siendo la fuente principal y las fuentes JSON propias siguen siendo el fallback existente.
- No se cambió la política global de HTTP ni se eliminaron streams `http://`.
- No se modificó `AgendaFragment` ni la política de orientación/fullscreen.
- No se modificó el flujo de reproducción nativa o iframe; el fullscreen usa el mecanismo de transferencia de sesión ya existente.

## Validación

- ZIP de entrada íntegro antes de modificarlo.
- Validación de XML y estructura del ZIP realizada tras los cambios.
- Se intentó ejecutar `./gradlew testDebugUnitTest --offline --stacktrace`, pero el wrapper intentó descargar Gradle 8.13 y el entorno no resolvió `services.gradle.org` (`UnknownHostException`). Por eso no se afirma que el proyecto compile ni que las pruebas unitarias hayan pasado.
- Pendiente: GitHub Actions (`testDebugUnitTest`, `assembleDebug`, `assembleRelease`) y prueba física con D-pad/CEC en Android TV.
