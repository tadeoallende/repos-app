# AngulismoTV — Etapa 19

## Corrección de fullscreen que regresaba solo a vertical

### Causa raíz

En `UnifiedPlayerActivity.onConfigurationChanged()`, al detectar la primera configuración horizontal, se cambiaba inmediatamente `requestedOrientation` a `SCREEN_ORIENTATION_FULL_SENSOR`. Ese modo vuelve a aceptar orientación vertical aunque el teléfono todavía esté físicamente en vertical. El sistema podía, por tanto, volver a portrait inmediatamente después de abrir fullscreen.

### Solución

- El fullscreen móvil lanzado desde el reproductor integrado mantiene `SCREEN_ORIENTATION_SENSOR_LANDSCAPE`; no se desbloquea a `FULL_SENSOR` al recibir la configuración horizontal.
- Se agregó `FullscreenOrientationPolicy`, que distingue la postura inicial en portrait de un regreso físico a portrait después de haber observado landscape.
- `OrientationEventListener` solo devuelve al mini reproductor después de detectar una orientación física estable de portrait tras landscape. El debounce es de 550 ms y se cancela ante lecturas de transición, desconocidas o de landscape.
- El listener se habilita en `onResume`, se deshabilita en `onPause` y se limpia en `onDestroy`.
- El retorno sigue usando `InlinePlayerHandoff`, por lo que la intención es conservar la sesión de ExoPlayer o la misma instancia de WebView.
- La orientación de Android TV y el comportamiento de la Agenda no se modificaron.

### Auditoría relacionada

- Confirmado por búsqueda estática que no queda ninguna asignación de `SCREEN_ORIENTATION_FULL_SENSOR` en `UnifiedPlayerActivity`.
- Revisado que la ruta de fullscreen todavía usa los indicadores de traspaso de sesión nativa/WebView, y que la ruta automática por rotación tiene una protección `isLaunchingFullscreen` contra aperturas duplicadas.
- Añadidas pruebas unitarias a la política de orientación para el estado inicial portrait, landscape, regreso a portrait, reverse landscape, lecturas desconocidas y ángulos de transición.
- El workflow existente ya ejecuta `testDebugUnitTest`, `assembleDebug` y `assembleRelease`.

### Limitación

No fue posible ejecutar el build Android completo en este entorno porque Gradle Wrapper no pudo resolver `services.gradle.org` (`UnknownHostException`). Los smoke checks Kotlin aislados pasan, pero el build y las pruebas JUnit deben confirmarse en GitHub Actions. Tampoco se puede simular de forma concluyente el sensor físico del dispositivo desde las verificaciones estáticas; se recomienda probar en un teléfono real tanto el giro a landscape como el regreso a portrait, con una fuente nativa y una de iframe.
