# AngulismoTV — Etapa 17

## Corrección prioritaria: fullscreen móvil sin reiniciar la fuente

### Causa confirmada

`ChannelsFragment.launchPlayerActivity()` solo transfería el ExoPlayer/WebView existente cuando `isTV` era verdadero. En móviles pausaba la previsualización y abría `UnifiedPlayerActivity` sin sesión transferida. `UnifiedPlayerActivity.loadChannelData()` volvía a seleccionar la fuente y `showExoPlayer()` construía un ExoPlayer, ejecutaba `setMediaSource()` y `prepare()`; con iframe también se llamaba al flujo normal de carga de página. Ese segundo motor/carga explica que fullscreen pareciera reiniciar el canal.

### Corrección

- La transferencia del ExoPlayer preparado se habilita también en móvil cuando se entra a fullscreen desde un preview activo.
- Para fuentes iframe se transfiere la instancia WebView cargada, en vez de crear otra navegación.
- Al cerrar el reproductor fullscreen iniciado desde el preview, el motor/sesión vuelve al fragmento también en móvil.
- Al entrar desde vertical, primero se fuerza el giro a horizontal; una vez allí se permite al sensor detectar el regreso a vertical y volver al mini-player.
- La rotación por sí sola no necesita llamar a `prepare()` cuando la sesión ya se entregó.

## Correcciones basadas en la auditoría externa

1. **R8/Gson:** se conservan clases y campos DTO anidados de `ChannelFeedDataSource` para evitar que la minificación cambie nombres usados por reflexión en release.
2. **Restauración de fragments:** `MainActivity` reutiliza las instancias recuperadas por `FragmentManager`, no agrega un `ChannelsFragment` nuevo ciegamente y guarda/restaura la sección activa.
3. **Agenda WebView:** la lista blanca usa hosts parseados en lugar de `String.contains`, incorpora `angulismotv.pages.dev`, admite la ruta `/agenda` y las rutas `/transmision/...` del mismo host, bloquea navegación principal externa y deshabilita acceso a archivos/contenido local. Se implementa correctamente el bloqueo de ventanas en `WebChromeClient`.
4. **HTTP sin cifrar:** se deja pendiente la restricción global de cleartext porque la app recibe fuentes IPTV dinámicas y admite URLs `http`. No se conocen todos los hosts que podrían necesitar HTTP; activar una allowlist parcial bloquearía canales actuales o futuros. Antes de cambiarla, hay que confirmar que todas las fuentes de feeds son HTTPS o proporcionar la lista de hosts legacy.

## Agenda

La Agenda ahora carga `BuildConfig.WEB_BASE_URL + "/agenda"`. Los eventos pueden navegar a `/transmision/...` en el mismo origen `https://angulismotv.pages.dev`; ese host está autorizado. Las solicitudes de subframe/iframe se dejan funcionar para no bloquear los reproductores embebidos.

## Pruebas y limitaciones

Se añade `AgendaNavigationPolicyTest` para URLs de Agenda, transmisión, hosts falsos y esquemas no HTTPS. Los cambios Kotlin/XML requieren pasar las pruebas unitarias, `assembleDebug` y `assembleRelease` en GitHub Actions. El entorno de edición no pudo descargar Gradle 8.13 por un fallo DNS, por lo que no se afirma compilación Android completa sin el resultado de CI.
