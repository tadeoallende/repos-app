# QA — Etapa 17

## Chequeos estáticos planificados/realizados

- La causa del reinicio se confirma por ruta de código: el traspaso estaba condicionado a `isTV`; sin traspaso, `loadChannelData()` reejecutaba la carga y `showExoPlayer()` llamaba `prepare()`.
- R8 ahora conserva `ChannelFeedDataSource$*` y sus campos.
- MainActivity recupera fragments por tags, no agrega siempre la misma etiqueta y persiste la sección activa.
- Agenda usa una política de hosts en vez de `url.contains`, y el bloqueo de `onCreateWindow` está en `WebChromeClient`.
- Agregado test unitario puro `AgendaNavigationPolicyTest`.
- La sesión de reproducción se transfiere a fullscreen y de vuelta en móvil y TV, siempre que la fuente se haya iniciado desde el reproductor integrado y el motor esté disponible.

## No afirmado como verificado

No se dispone de un build Android completo en este entorno. Ejecutar el wrapper necesita obtener Gradle 8.13, pero la resolución de `services.gradle.org` puede fallar por DNS. La confirmación de `testDebugUnitTest`, `assembleDebug` y `assembleRelease` debe venir de GitHub Actions.

## Punto de seguridad aplazado deliberadamente

`android:usesCleartextTraffic="true"` continúa habilitado temporalmente para no romper fuentes IPTV HTTP servidas dinámicamente desde feeds externos. Para limitarlo correctamente hay que conocer los hosts HTTP necesarios o migrar esos streams a HTTPS y validar el catálogo real.
