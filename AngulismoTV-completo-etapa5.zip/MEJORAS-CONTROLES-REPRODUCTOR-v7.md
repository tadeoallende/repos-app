# AngulismoTV — Mejora de controles del reproductor (v7)

## Cambios incluidos

- Los controles secundarios del reproductor incorporan feedback táctil nativo (`RippleDrawable`) con una máscara redondeada.
- Se conserva un estado de foco visible y de alto contraste para Android TV y navegación por teclado. El estado normal es transparente, para evitar volver a llenar la pantalla de tarjetas.
- El botón Reproducir/Pausar es visualmente primario en el reproductor integrado y en pantalla completa.
- El tamaño de las acciones del reproductor se adapta al espacio disponible: el reproductor integrado usa 44 dp en pantallas estrechas y 48 dp en dispositivos con ancho mínimo de 360 dp; los controles de pantalla completa escalan a 48 dp en orientación horizontal.
- Las etiquetas accesibles se sincronizan con la acción disponible: “Reproducir” o “Pausar”.
- No se añadieron dependencias ni animaciones pesadas.

## Comprobaciones

- 64 XML parseados correctamente.
- Referencias locales a recursos verificadas: sin referencias no resueltas.
- IDs duplicados dentro de layouts: no encontrados.
- Cambios de icono/etiqueta revisados estáticamente en `UnifiedPlayerActivity.kt` y `ChannelsFragment.kt`.
- Integridad del ZIP comprobada después de exportarlo.

## Limitación

No se pudo completar `./gradlew --offline assembleDebug`: el wrapper intenta descargar Gradle 8.13 y el entorno responde `UnknownHostException: services.gradle.org`. Por eso, no puedo afirmar que hubo compilación o prueba visual en dispositivo. Esas pruebas deben ejecutarse con Gradle y Android SDK disponibles.
