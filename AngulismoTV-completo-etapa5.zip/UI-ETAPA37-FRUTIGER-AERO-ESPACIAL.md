# AngulismoTV — Etapa 37: sistema visual Frutiger Aero espacial

## Objetivo

Unificar la interfaz en una paleta azul noche + aqua + verde agua y mejorar la lectura y el foco sin cambiar la arquitectura de navegación o la reproducción.

## Cambios incluidos

- Paleta centralizada en `values/colors.xml`: fondos azul petróleo, superficies teal, aqua como acento, verde agua secundario y texto secundario con más contraste.
- El fondo ambiental continúa usando gradientes XML estáticos. No se agregan blur, partículas, videos de fondo, animaciones permanentes ni efectos de escala.
- El rail de navegación de TV ahora distingue la sección activa incluso cuando no tiene foco; el foco conserva un contorno de alto contraste.
- El campo de búsqueda indica visualmente el foco con un borde aqua estático.
- Botones del reproductor integrado pasan a 44 dp con padding de icono equilibrado.
- Chips de categorías pasan de 32 a 36 dp; filas de canales móviles pasan a un mínimo de 48 dp para mejorar el área táctil y la separación.
- Los textos secundarios de TV, mensajes de error y etiquetas de reproducción se hicieron más legibles a distancia.
- Menos elevación en la navegación inferior y el rail lateral; no se agregaron sombras ni animaciones nuevas.
- El contenedor de video conserva el negro real durante reproducción para no degradar el contenido.

## Navegación TV

Se conserva la distribución de dos columnas: vista previa a la izquierda y lista de canales a la derecha, con el rail lateral fijo. El código existente ya define rutas explícitas para el D-pad y restaura el foco por identidad del canal. Cambiar la geometría global implicaría riesgo funcional sin una mejora demostrable; la etapa refuerza estados visuales y mantiene el coste de renderizado bajo.

Principios de navegación contrastados con la guía oficial de Android TV: navegación predecible, todos los controles alcanzables con D-pad, foco claramente visible y jerarquía simple. Referencias: https://developer.android.com/training/tv/get-started/navigation y https://developer.android.com/develop/adaptive-apps/guides/tv/build-adaptive-apps-for-tv.

## Archivos principales modificados

- `app/src/main/res/values/colors.xml`
- `app/src/main/res/values/themes.xml`
- `app/src/main/res/values/dimens.xml`
- `app/src/main/res/values-sw360dp/dimens.xml` (también sincronizado para móviles de ancho habitual)
- `app/src/main/res/drawable/side_menu_item_bg.xml`
- `app/src/main/res/drawable/bg_inline_player_control.xml`
- `app/src/main/res/drawable/bg_player_error.xml`
- `app/src/main/res/drawable/search_bg.xml`
- `app/src/main/res/layout/activity_main.xml`
- `app/src/main/res/layout/fragment_channels.xml`
- `app/src/main/res/layout/fragment_channels_tv.xml`
- `app/src/main/res/layout/item_category.xml`
- `app/src/main/res/layout/item_channel.xml`
- `app/src/main/java/com/angulismotv/ui/ChannelScreenLayoutController.kt`
- `app/src/main/java/com/angulismotv/fragments/ChannelsFragment.kt`

## Verificación y límites

Esta etapa es un cambio de recursos y dos ajustes de UI en Kotlin; no se cambian los motores de reproducción ni los flujos de actualización. Aún debe compilarse con el workflow Android completo y probarse en un móvil y un televisor reales. Las comprobaciones estáticas (XML, referencias y diff) se informan por separado y no se presentan como compilación de Android.
