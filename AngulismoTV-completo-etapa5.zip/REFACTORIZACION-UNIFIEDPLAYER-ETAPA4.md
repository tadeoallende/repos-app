# UnifiedPlayerActivity — Etapa 4: visibilidad y auto-ocultado de controles

Refactor sin cambio de comportamiento: el estado de los controles y su temporizador salen de la Activity.

## Qué se movió

| Antes (en la Activity) | Ahora |
|---|---|
| `controlsVisible` (var), `hideControlsRunnable`, `resetAutoHideTimer` con 5 s fijos | `PlayerControlsVisibilityController` (`isVisible`, `show`, `showTemporarily`, `toggleTemporarily`, `hide`, `resetAutoHide`, `cancelAutoHide`, `forceHiddenState`) |
| Alternar mostrar/ocultar al tocar (dos copias) | `toggleTemporarily()` |

La Activity conserva los efectos sobre vistas en dos funciones: `applyControlsReveal(temporarily)` (animaciones, foco, línea de tiempo) y `applyControlsHide()`. `resetAutoHideTimer`, `showControls`, `showControlsTemporarily` y `hideControls` siguen existiendo como envoltorios de una línea para no tocar los 20 puntos de llamada ni las referencias `::`. `controlsVisible` pasa a ser una propiedad de solo lectura sobre el controlador.

## Comportamiento conservado

- Auto-ocultado a los 5 s; con el panel lateral abierto el vencimiento no oculta nada (al cerrarlo ya se reinicia la cuenta).
- Al mostrar, el estado figura como visible antes de aplicar los efectos, igual que antes para el foco y la línea de tiempo. Se verificó que animaciones y `updateControlsVisibility()` no leen ese estado, por lo que adelantarlo no cambia nada.
- `showError()` sigue mostrando la barra y cancelando el auto-ocultado para que "Recargar" siga accesible.
- La configuración de TV sigue marcando los controles como ocultos (`forceHiddenState()`).

## Pruebas nuevas

`PlayerControlsVisibilityControllerTest` (9 casos, con `FakeScheduler`): estado visible antes de los efectos, revelado temporal, ocultado a los 5 s (en 4.999 ms aún visible), reinicio por actividad, panel abierto, ocultado explícito, cancelación, alternar y estado forzado.

## Validación

Revisión manual del diff y de cada prueba contra el código. **No se compiló ni se ejecutaron pruebas** (sin Kotlin/Gradle en el entorno). Probar en TV (controles aparecen y se ocultan a los 5 s, no se ocultan con el panel abierto) y en móvil (toque alterna controles).

## Siguiente

Etapa 5: lectura del Intent y diálogos.
