# AngulismoTV — Refactorización Etapa 8

## Objetivo

Pulir la tipografía y simplificar la navegación manteniendo como base la Etapa 7 corregida.

## Cambios realizados

- La navegación principal ahora ofrece únicamente **Canales** y **Agenda** tanto en móvil como en TV.
- Se eliminaron las entradas de Foro y Multicam de la barra inferior y del rail de TV; también se retiraron sus fragments, layouts e iconos que ya no tenían uso.
- Las etiquetas de navegación se muestran como “Canales” y “Agenda” en lugar de mayúsculas sostenidas.
- Se añadieron apariencias tipográficas específicas para los estados activo e inactivo de la barra inferior: Roboto/sans-serif, 12sp y espaciado discreto.
- Se aplica sans-serif como tipografía base del tema y se refina la tipografía de búsqueda, chips de categorías y nombres de canales.
- Las categorías se presentan en formato de título para facilitar su lectura.
- La envoltura local de Agenda adopta el fondo de la aplicación, el indicador de carga en cian y un mensaje de error legible.
- No se modificaron intencionalmente las reglas de reproducción, las fuentes, la recuperación del reproductor ni la navegación con el mando entre Canales y Agenda.

## Alcance y validación

La página de Agenda carga contenido web desde `WEB_BASE_URL`; esta etapa estiliza la envoltura nativa de Android, pero no reescribe la tipografía interna del sitio servido remotamente.

Validación realizada: los 54 XML restantes se analizaron sin errores de sintaxis y no quedan referencias a Foro/Multicam en el código, layouts ni menú principal. No pude ejecutar una compilación completa en este entorno porque no hay una distribución Gradle instalada/en caché y la descarga no está disponible. La Etapa 8 no debe considerarse estable hasta que GitHub Actions genere el APK y se pruebe en el celular/televisor.
