# AngulismoTV — Etapa 4: acabado del reproductor Android TV

## Base y alcance

Esta etapa parte de `AngulismoTV-TV-Player-Etapa3.zip`, que se mantiene como base. Se conservan el motor ExoPlayer/WebView, las fuentes de reproducción, Cast, búsqueda, selección de canales, categorías, zapping, reconexión y el diseño móvil.

## Cambios

- Se conserva el identificador del último control del reproductor que recibió foco en Android TV.
- Al volver del panel lateral o mostrar de nuevo los controles, se intenta recuperar ese control si sigue visible y enfocable. Si la fuente actual oculta ese control (por ejemplo, los controles de búsqueda temporal en un iframe), se usa el primer control válido.
- El cambio de foco en los controles reinicia el temporizador de ocultación mientras los controles estén visibles y el panel lateral esté cerrado, evitando que se oculten mientras el usuario sigue navegando con el mando.
- Si OK/Enter llega a los controles visibles pero el foco quedó accidentalmente en una superficie no accionable, se recupera el foco a un control válido en vez de dejar el mando sin respuesta.

## Validación

- Pendiente ejecutar la compilación Android completa y probar en un dispositivo Android TV. Las verificaciones estáticas de XML/Kotlin no sustituyen esas pruebas.
- Pruebas manuales recomendadas: navegar por controles, abrir/cerrar panel, volver de categorías/canales, cambiar entre fuentes ExoPlayer e iframe, verificar que los controles se oculten tras 5 segundos sin interacción y que el móvil conserve el comportamiento anterior.
