# AngulismoTV — Etapa 29: refactorización de catálogo, categorías y panel del reproductor

## Objetivo

Reducir responsabilidades dentro de `UnifiedPlayerActivity` y `ChannelsFragment` sin reescribir el motor de reproducción ni alterar intencionalmente la navegación, el zapping, el sistema de favoritos o la transferencia del reproductor integrado a pantalla completa.

## Cambios de arquitectura

### Reproductor de pantalla completa

- `ui/PlayerChannelPanelController.kt` ahora coordina el catálogo del panel lateral, las categorías, los resultados de búsqueda, el recuento y el estado visual de «Lista de canales».
- `UnifiedPlayerActivity` conserva el ciclo de vida de reproducción, la navegación del mando, el zapping, la orientación, Cast y la coordinación de WebView/ExoPlayer. Delega el panel y expone callbacks concretos para seleccionar canales, gestionar el foco y cerrar el panel.
- `ui/PlayerPanelLayoutPolicy.kt` contiene las reglas puras para elegir el ancho del rail de categorías y la lista según la resolución disponible. `openSidePanel()` aplica las dimensiones calculadas en vez de mezclar el cálculo con la gestión de la vista.

### Pantalla Canales

- `data/ChannelFilterEngine.kt` centraliza la clasificación general, la normalización de países, los nombres visibles, las categorías disponibles y el filtrado combinado por categoría/país/búsqueda.
- `ui/ChannelCategoryBarController.kt` contiene la construcción y presentación de los chips, el selector de país, sus estilos y la navegación de foco D-pad. El estado `selected` del chip de país se mantiene sincronizado con el filtro aplicado.
- `ChannelsFragment` mantiene la orquestación de la pantalla, el estado de filtros, la actualización del `RecyclerView` y la reproducción integrada. La barra visual recibe esos estados y notifica cambios mediante callbacks.
- El controlador de categorías se libera en `onDestroyView()` para no retener las vistas de una instancia de la pantalla que dejó de existir.

## Tamaño resultante

Conteos de líneas de los archivos principales después de la extracción:

| Archivo | Antes de esta etapa | Después |
|---|---:|---:|
| `UnifiedPlayerActivity.kt` | 2.043 | 1.805 |
| `ChannelsFragment.kt` | 1.700 | 1.483 |

El código de las responsabilidades extraídas queda distribuido en controladores pequeños que pueden revisarse por separado. Las clases principales siguen teniendo tamaño considerable, especialmente la gestión de reproducción integrada; esta etapa no se presenta como una reescritura completa de esas clases.

## Pruebas agregadas

- `ChannelFilterEngineTest.kt`: reglas de clasificación, categorías disponibles, países, filtrado combinado y orden del catálogo.
- `PlayerPanelLayoutPolicyTest.kt`: dimensiones para pantalla estrecha, TV amplia y ancho no válido.

## Validaciones ejecutadas en este entorno

- Compilación Kotlin aislada del motor de filtros y de la política de dimensiones, con modelos sustitutos para aislar esas reglas: completada.
- Comprobaciones funcionales de humo de las reglas de filtros/dimensiones: completadas.
- Compilación sintáctica de los dos controladores nuevos contra stubs locales livianos de APIs Android: completada. Esto no sustituye la compilación con el Android SDK real.
- Análisis XML: 75 archivos procesados, sin errores.
- `./gradlew testDebugUnitTest --no-daemon`: no pudo comenzar porque el entorno no pudo resolver `services.gradle.org` (`UnknownHostException`). Por tanto, **no se declara validado un build Gradle completo ni la ejecución de toda la suite JUnit**.

## Comprobación manual pendiente

Después de que GitHub Actions compile el proyecto, revisar en móvil y Android TV: apertura/cierre del panel, búsqueda, cambio de categorías y países, foco con D-pad, selección de canal, favoritos, Cast, recarga, reproducción WebView/ExoPlayer y paso de mini-reproductor a pantalla completa.

## Seguridad del actualizador

Se conserva el verificador SHA-256 de la Etapa 28. El hash permite rechazar APK que no coincidan con el manifiesto descargado, pero no autentica ese manifiesto si APK y manifiesto se reemplazan juntos. La firma digital del manifiesto con una clave pública embebida sigue siendo una mejora separada pendiente.
