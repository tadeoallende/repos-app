# Correcciones de compilación — Etapa 31

Se corrigieron los cinco diagnósticos Kotlin compartidos en el log de GitHub Actions:

1. Se añadió a `UnifiedPlayerActivity` la función `formatCategoryLabel`, que normaliza las etiquetas de categoría.
2. Se cambió `putParcelableExtra("current_channel", channel)` por `putExtra("current_channel", channel)`, usando la API real de `Intent` para el objeto `Parcelable`.
3. Al restaurar el foco de Android TV, la clave ya no se construye como un `Pair` de nombre y logo; se usa `ChannelIdentity.key(...)`, el mismo identificador que utiliza `ChannelsAdapter`.

## Validación

- Se inspeccionaron los tres puntos exactos del log.
- El ZIP de origen pasó la prueba de integridad antes de modificarlo.
- No se pudo completar una compilación Gradle en este entorno porque no se pudo resolver `services.gradle.org`; la compilación final se debe confirmar con GitHub Actions.
