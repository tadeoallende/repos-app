# Rediseño móvil del reproductor — v11

## Cambios
- Eliminados visualmente el logo y el nombre del canal de la banda de controles del reproductor integrado en móvil.
- El control Reproducir/Pausar ahora aparece centrado sobre el video, con una superficie circular discreta.
- Ajustes, Cast, pantalla completa y cerrar quedan agrupados abajo a la derecha, sin una tarjeta rectangular ocupando todo el ancho.
- La línea de tiempo se mantiene por encima de las acciones inferiores y se oculta junto con los controles temporales.
- El botón central sigue el mismo timeout de controles (4 segundos) y no se muestra para fuentes iframe que no exponen el control nativo.
- El layout Android TV no se modificó; los cambios se limitan a `fragment_channels.xml`, que es el layout de móvil.

## Validaciones realizadas
- XML parseado con `ElementTree`.
- IDs del layout comprobados sin duplicados.
- Referencias de IDs Kotlin comprobadas contra el layout móvil.
- ZIP verificado con `unzip -t`.

La compilación Android/Gradle y la prueba en dispositivo deben ejecutarse en un entorno con Android SDK y acceso a las dependencias.
