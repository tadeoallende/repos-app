# QA — Etapa 19

## Verificaciones realizadas

- Compilación aislada con `kotlinc` de `FullscreenOrientationPolicy.kt`: correcta.
- Smoke checks ejecutados con JVM para postura inicial portrait, detección landscape, retorno a portrait, landscape invertido, portrait invertido, ángulo de transición y lectura desconocida: PASS.
- Añadido `FullscreenOrientationPolicyTest.kt` para ejecutar los mismos casos en la suite JUnit de Gradle.
- Validación por búsqueda: ninguna asignación ejecutable a `SCREEN_ORIENTATION_FULL_SENSOR` en `UnifiedPlayerActivity`; el cambio que causaba el rebote vertical fue eliminado.
- Validación por búsqueda: no existe referencia a `showStoragePermissionDialog` en el código fuente.
- XML de recursos y manifiesto parseables; `gradle/libs.versions.toml` es válido.
- ZIP final verificado con `unzip -t`.

## Pendiente / no afirmado

`./gradlew testDebugUnitTest --stacktrace` no llegó al compilador Android porque Gradle Wrapper no pudo descargar Gradle 8.13 debido a `UnknownHostException: services.gradle.org`. No afirmo que la app completa compile hasta que GitHub Actions termine con éxito.

Se debe comprobar en móvil físico:
1. Abrir un canal en vertical y pulsar fullscreen: debe quedarse horizontal, sin recargar.
2. Mantener el teléfono físicamente vertical después de tocar fullscreen: no debe cerrarse solo.
3. Girar físicamente a landscape y luego a portrait: debe volver al reproductor integrado.
4. Repetir con stream nativo y con iframe.
5. Cerrar fullscreen por botón/atrás y verificar que la sesión vuelva al mini reproductor.
