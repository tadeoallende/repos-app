# AngulismoTV — Etapa 18: ajustes visuales del menú TV y del ingreso de número

## Menú lateral de Android TV

- Se quitó el fondo que aparecía por el estado `selected` del rail Canales/Agenda.
- La sección actual sigue identificándose por el color del icono, controlado por `MainActivity.updateSideMenuSelection()`.
- Se conserva el fondo y el borde para `focused` y `pressed`, para que el usuario pueda identificar dónde está el foco del mando mientras navega. Esto es distinto de la sección seleccionada y evita perder una indicación de accesibilidad/navegación.

## Entrada de número de canal

- El indicador `channel_number_overlay` ahora se muestra centrado en la pantalla.
- Se quitó el fondo tipo chip y el padding de tarjeta.
- El texto subió de 22sp a 32sp, usa una familia tipográfica más pesada y sombra oscura suave para destacarlo sobre el video sin agregar fondo opaco.
- El número sigue siendo temporal y se oculta al confirmar/cumplirse el tiempo de espera; la lógica de zapping no se modificó.

## Alcance

No se modificaron el motor de reproducción, la transferencia de sesión, la Agenda ni la lógica de numeración.
