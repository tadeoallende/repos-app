# AngulismoTV — Etapa 25: estados visuales de Cast y guía de navegación

## Cambios

- Se agregó un callback de estado a `CastController` sin alterar el mecanismo de selección de rutas ni la carga remota.
- Se comunican estados relevantes: búsqueda de dispositivos, conexión, reconexión, transmisión iniciada, rechazo de reproducción, error de conexión y desconexión.
- En el reproductor integrado, el estado se presenta en la guía visible del reproductor, usando el estilo ya existente.
- En el reproductor de pantalla completa, el estado actualiza la descripción accesible del botón Cast; en móvil también se muestra un aviso breve para que el resultado de la acción sea visible.
- La guía de lista para Android TV ahora explica navegación vertical, vista previa/selección, retorno al video y salto por número de canal.
- Se aclaró el texto de búsqueda para indicar que se busca por nombre.

## Conservación

- No se modificó la Agenda.
- No se modificó la fuente IPTV-org ni el fallback JSON.
- No se cambió la política de orientación ni el traspaso de sesión al reproductor completo.
- No se introdujeron dependencias nuevas.

## Limitaciones

Los mensajes describen los eventos recibidos del SDK de Google Cast; no sustituyen una prueba con receptor físico. La disponibilidad de reproducción sigue dependiendo del formato y de las restricciones de cada fuente.
