# AngulismoTV — Auditoría estática y limpieza, Etapa 30

## Alcance

Base de trabajo: **Etapa 29** (`AngulismoTV-etapa29.zip`). Esta entrega es una auditoría estática con correcciones conservadoras centradas en ciclos de vida Android, callbacks pendientes, comportamiento de WebView, descarga de actualizaciones, normalización de identificadores y deduplicación de canales.

Inventario del proyecto revisado: **53 archivos Kotlin de producción (9.345 líneas), 16 archivos Kotlin de pruebas, 75 archivos XML y 224 archivos en total**. Se revisó el código de las áreas con mayor riesgo y se realizaron búsquedas estáticas por referencias a vistas, handlers, receptores, WebView, imports sin uso evidentes y marcadores de código pendiente.

> **Importante:** no es una certificación de ausencia de fugas o errores. Una auditoría estática ayuda a hallar riesgos, pero no reemplaza un build Android completo, pruebas de instrumentación ni la comprobación en un celular y Android TV.

## Correcciones aplicadas

### 1. Ciclo de vida de `ChannelsFragment`

- Las referencias de vistas pasan a delegados `AutoClearedViewRef`, que se vacían al ejecutar `onDestroyView()`. Un acceso accidental después de limpiar una vista falla explícitamente en vez de reutilizar en silencio una referencia antigua.
- Se retiran los callbacks diferidos de búsqueda y ocultación de controles, se detienen las actualizaciones de la línea de tiempo, se libera el controlador de Cast y se invalidan generaciones de callbacks al destruir la vista.
- Los resultados diferidos del adaptador y algunos callbacks de foco validan que sigan perteneciendo a la generación de vista vigente.
- Se neutralizan clientes y listeners del WebView integrado que capturaban el Fragment; en la ruta normal, el WebView se detiene, separa y destruye.
- **Corrección del traspaso a pantalla completa:** si el WebView está siendo transferido a `UnifiedPlayerActivity`, la liberación de la vista anterior ya no debe navegarlo a `about:blank`. Eso podía cortar el iframe en vivo durante un traspaso que pretendía conservarlo.
- El controlador de línea de tiempo deja de actualizar controles cuando el panel está oculto, pausado o ya no corresponde a una vista activa.

### 2. Ciclo de vida de `AgendaFragment`

- Al destruir la vista se cancelan callbacks pendientes, se retira el puente JavaScript `AgendaFullscreen`, se neutralizan `WebViewClient`/`WebChromeClient`, se separa y destruye el WebView y se limpian las referencias a vistas.
- Los callbacks de progreso y error comprueban que las vistas aún estén inicializadas antes de actualizarlas.
- Las acciones de pantalla completa comprueban el estado de las vistas antes de cambiar la jerarquía. Esto reduce el riesgo de tocar una vista vieja después de salir de la pantalla o recrear el Fragment.

### 3. Descarga e instalación de actualizaciones

- `ApkUpdateInstaller` trabaja con `applicationContext`, no con una Activity pasada como contexto.
- Se valida que la URL del APK sea HTTPS y que el SHA-256 tenga formato válido antes de descargar.
- El receptor de `DownloadManager` ya no se retira ante el primer broadcast sin verificar el estado final. Consulta los estados pendiente, en ejecución o pausado hasta confirmar éxito o error, y cancela el seguimiento/receptor en un estado terminal.
- Se consulta el estado inmediatamente después de registrar el receptor para cubrir la carrera donde la descarga finaliza antes del registro.
- La verificación SHA-256 se hace en un ejecutor de fondo y la instalación solo se abre después de que el hash coincide.
- Una nueva descarga administrada cancela el seguimiento y trata de eliminar la transferencia anterior, evitando dejar una descarga previa consumiendo datos sin seguimiento.
- `UpdateManager` conserva la Activity a través de `WeakReference` y no muestra diálogos cuando la Activity ya está terminando o destruida.
- La limpieza automática solo elimina APK dentro del área privada externa de la app. Se evita barrer la carpeta pública `Downloads`, donde podría haber archivos del usuario con nombres coincidentes.

### 4. Callbacks del reproductor y cierre de pantallas

- `WebViewPlayerBridge` lleva control de generación de adjunción/detección y cancela reintentos al reiniciarse o desconectarse; callbacks de JavaScript de una página anterior se descartan si quedaron obsoletos.
- `UnifiedPlayerActivity` retira el callback diferido que restablece el indicador de cambio de canal y cancela la ocultación del overlay al destruirse. Los cambios rápidos de canal ya no deberían hacer que un callback antiguo oculte el estado de uno más reciente.
- `MainActivity` cancela expresamente la carga de canales e invalida su generación en `onDestroy()`, de modo que un resultado viejo no debe actualizar una Activity destruida.

### 5. Duplicación y normalización de claves

- Se centraliza en `ChannelCatalog.feedDeduplicationKey()` la clave de deduplicación usada por el catálogo y `ChannelRepository`, quitando la implementación duplicada.
- La clave incluye las fuentes alternativas ordenadas de cada canal. La implementación anterior podía considerar duplicados canales con el mismo nombre/logo/URL principal aunque tuvieran opciones de reproducción alternativas diferentes, perdiendo fuentes válidas.
- Las normalizaciones usadas para identificadores técnicos (tipo de stream, esquemas y claves de catálogo) emplean `Locale.ROOT`; no dependen del idioma del dispositivo. Esto evita diferencias de identificadores en configuraciones como turco.
- Se eliminó una importación `Uri` que no se usaba en `StreamMediaSourceFactory`.

## Pruebas y comprobaciones realizadas

| Comprobación | Resultado |
|---|---|
| Parseo de recursos XML | **Correcto:** los 75 XML analizados se pueden parsear. |
| Integridad del ZIP generado | **Correcta:** `unzip -t` comprobó el archivo completo sin errores. |
| Smoke test aislado de `AutoClearedViewRef` y verificación SHA-256 | **Correcto** en compilación Kotlin aislada con pruebas de uso y vectores SHA-256. |
| Compilación aislada de `WebViewPlayerBridge` / scripts con stubs Android/JSON mínimos | **Correcta**, con advertencias de parámetros sin uso propias de los stubs. No equivale a compilar contra el SDK real. |
| Smoke test aislado de la clave de deduplicación del catálogo | **Correcto:** mantiene distintas listas de fuentes alternativas y el resultado no depende del locale del sistema. |
| Detección estática de imports no usados evidentes / TODO / FIXME / `NotImplementedError` | No se encontraron imports evidentemente sobrantes en el barrido final ni marcadores pendientes claros en las rutas revisadas. Esto no demuestra que no exista código muerto. |
| `./gradlew testDebugUnitTest --offline --no-daemon` | **No ejecutable en este entorno:** el wrapper necesita descargar Gradle 8.13 y no pudo resolver `services.gradle.org` por falta de conectividad DNS. |
| Build Android completo y prueba en celular/TV | **Pendientes:** no se deben dar por aprobados. |

## Riesgos residuales que no cambié a ciegas

### Prioridad alta: autenticidad del manifiesto de actualización

La app compara el SHA-256 del APK descargado con el hash entregado por el manifiesto. Esto detecta corrupción y discrepancias, **pero no protege frente a un atacante que pueda modificar a la vez el manifiesto y el APK** en el mismo origen. Para esa amenaza se necesita autenticidad independiente, por ejemplo una firma criptográfica del manifiesto verificada con una clave pública embebida en la app, además de HTTPS y una política de rotación de claves. No incorporé una firma inventada: antes hay que definir y proteger la clave privada de publicación.

### Prioridad alta/condicional: tráfico HTTP y contenido mixto en WebView

`AndroidManifest.xml` permite tráfico sin cifrar (`usesCleartextTraffic="true"`) y la configuración de WebView permite contenido mixto (`MIXED_CONTENT_ALWAYS_ALLOW`). Eso amplía la superficie de ataque. **No lo desactivé automáticamente** porque algunas listas IPTV o páginas embebidas antiguas podrían depender de HTTP y dejar de reproducirse. Recomiendo una migración separada con pruebas por fuente: allowlist de hosts si es posible, política por origen y eliminación progresiva del contenido mixto.

### Revisión arquitectónica posterior

`UnifiedPlayerActivity.kt` y `ChannelsFragment.kt` siguen siendo clases grandes. Esta etapa evita algunos problemas de ciclo de vida y elimina duplicación concreta, pero no intenta extraer todos sus métodos a nuevos controladores de una sola vez. Conviene dividir más responsabilidades en etapas pequeñas después de obtener un build real y comprobar el reproductor integrado, el paso a pantalla completa, la lista de canales, Cast, la Agenda y el control por mando. Reducir líneas sin pruebas no es un objetivo suficiente y podría romper el traspaso de WebView o la navegación.

### Comportamientos de estado global que requieren prueba funcional

El catálogo compartido y los datos de traspaso del reproductor conservan estado deliberadamente para restaurar canales entre pantallas. No se limpian indiscriminadamente porque eso podría romper la vuelta desde pantalla completa o el estado de reproducción. Sus casos de recreación de Activity y cambio rápido de canales deben probarse en dispositivo.

## Lista recomendada antes de distribuir esta versión

1. Ejecutar `./gradlew testDebugUnitTest` y `./gradlew assembleDebug` en GitHub Actions con acceso a Gradle.
2. En celular: abrir canal, pausar/reanudar, cambiar fuente, abrir/cerrar pantalla completa, volver a la lista y rotar la pantalla.
3. En Android TV: navegar solo con mando, abrir categorías, cambiar de canal rápido, mostrar/ocultar controles y volver a la lista.
4. Probar al menos una fuente nativa, una URL HLS, un iframe/WebView, una fuente alternativa, Cast si se usa, y una actualización de APK correcta y fallida.
5. Diseñar y añadir la firma del manifiesto de actualizaciones antes de considerar protegido el canal de actualización frente a la modificación maliciosa del origen.

## Conclusión

La Etapa 30 corrige problemas concretos de referencias a vistas, callbacks que podían sobrevivir a la vista, limpieza del WebView, transferencia a pantalla completa, seguimiento de descargas y deduplicación de canales con fuentes alternativas. La entrega queda **revisada estáticamente, pero no certificada mediante build Android ni pruebas en dispositivos**; esos estados quedan expresamente pendientes.
